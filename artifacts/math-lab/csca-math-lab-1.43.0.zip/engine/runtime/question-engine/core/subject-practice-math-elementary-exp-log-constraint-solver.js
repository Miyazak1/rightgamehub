"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emember = exports.elementaryExpLogConstraintIntervalText = exports.etxt = exports.ecmp = exports.ediv = exports.emul = exports.esub = exports.eneg = exports.eadd = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_CONSTRAINTS = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPES = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPE_VERSION = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SOLVER_VERSION = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_TEMPLATE = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_FAMILY = void 0;
exports.eq = eq;
exports.eread = eread;
exports.epow = epow;
exports.normalizeElementaryExpLogConstraintSegments = normalizeElementaryExpLogConstraintSegments;
exports.parseElementaryExpLogConstraintIntervals = parseElementaryExpLogConstraintIntervals;
exports.elementaryExpLogConstraintScopeFrom = elementaryExpLogConstraintScopeFrom;
exports.elementaryExpLogConstraintPrompt = elementaryExpLogConstraintPrompt;
exports.elementaryExpLogConstraintParametersValid = elementaryExpLogConstraintParametersValid;
exports.elementaryExpLogConstraintParametersFrom = elementaryExpLogConstraintParametersFrom;
exports.elementaryExpLogConstraintDerive = elementaryExpLogConstraintDerive;
exports.solveSubjectPracticeMathElementaryExpLogConstraint = solveSubjectPracticeMathElementaryExpLogConstraint;
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_FAMILY = 'math_elementary_exp_log_constraint_reasoning';
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_TEMPLATE = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_FAMILY + '_v1';
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SOLVER_VERSION = 'math-elementary-exp-log-constraint-solver-v1-exact-rational';
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPE_VERSION = 'math-hard-elementary-exp-log-constraint-v1';
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPES = ['exponential_substitution_rational_inequality', 'logarithmic_difference_domain_inequality', 'exponential_quadratic_closed_interval_range', 'nested_logarithm_rational_domain_intersection'];
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-FUNC-002', boundedRationalParameters: true, rationalNumeratorMax: 1000000, rationalDenominatorMax: 10000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function eq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
    return { n: a < 0n ? -1n : 1n, d: 0n }; if (b < 0n) {
    a = -a;
    b = -b;
} let x = a < 0n ? -a : a, y = b; while (y) {
    const t = x % y;
    x = y;
    y = t;
} return { n: a / x, d: b / x }; }
const eadd = (a, b) => eq(a.n * b.d + b.n * a.d, a.d * b.d), eneg = (a) => eq(-a.n, a.d), esub = (a, b) => (0, exports.eadd)(a, (0, exports.eneg)(b)), emul = (a, b) => eq(a.n * b.n, a.d * b.d), ediv = (a, b) => { if (!b.n)
    throw Error('division_by_zero'); return eq(a.n * b.d, a.d * b.n); };
exports.eadd = eadd, exports.eneg = eneg, exports.esub = esub, exports.emul = emul, exports.ediv = ediv;
const ecmp = (a, b) => !a.d || !b.d ? (!a.d && !b.d ? (a.n < b.n ? -1 : a.n > b.n ? 1 : 0) : !a.d ? Number(a.n) : -Number(b.n)) : (a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0);
exports.ecmp = ecmp;
const etxt = (a) => !a.d ? (a.n < 0n ? '-inf' : 'inf') : String(a.n) + (a.d === 1n ? '' : '/' + a.d);
exports.etxt = etxt;
function eread(s) { if (s === '-inf')
    return eq(-1, 0); if (s === 'inf')
    return eq(1, 0); if (!/^-?\d+(?:\/[1-9]\d*)?$/.test(s) || s.length > 32)
    throw Error('rational_syntax'); const [n, d = '1'] = s.split('/'); return eq(BigInt(n), BigInt(d)); }
function epow(a, n) { if (!Number.isInteger(n) || Math.abs(n) > 16 || a.n <= 0n || !a.d)
    throw Error('power_outside_bounds'); return n < 0 ? eq(a.d ** BigInt(-n), a.n ** BigInt(-n)) : eq(a.n ** BigInt(n), a.d ** BigInt(n)); }
const z = eq(0), ni = eq(-1, 0), pi = eq(1, 0), valid = (s) => (0, exports.ecmp)(s.lo, s.hi) < 0 || !(0, exports.ecmp)(s.lo, s.hi) && s.lc && s.hc;
function normalizeElementaryExpLogConstraintSegments(ss) { const out = []; for (const s of ss.filter(valid).map(x => ({ ...x, lc: !!x.lo.d && x.lc, hc: !!x.hi.d && x.hc })).sort((x, y) => (0, exports.ecmp)(x.lo, y.lo) || Number(y.lc) - Number(x.lc))) {
    const p = out[out.length - 1];
    if (!p || (0, exports.ecmp)(s.lo, p.hi) > 0 || !(0, exports.ecmp)(s.lo, p.hi) && !p.hc && !s.lc) {
        out.push(s);
        continue;
    }
    const c = (0, exports.ecmp)(s.hi, p.hi);
    if (c > 0) {
        p.hi = s.hi;
        p.hc = s.hc;
    }
    else if (!c)
        p.hc = p.hc || s.hc;
} return out; }
const elementaryExpLogConstraintIntervalText = (ss) => normalizeElementaryExpLogConstraintSegments(ss).map(s => (s.lc ? '[' : '(') + (0, exports.etxt)(s.lo) + ',' + (0, exports.etxt)(s.hi) + (s.hc ? ']' : ')')).join(' U ') || 'empty';
exports.elementaryExpLogConstraintIntervalText = elementaryExpLogConstraintIntervalText;
function parseElementaryExpLogConstraintIntervals(t) { if (t === 'empty')
    return []; if (typeof t !== 'string' || t.length > 600)
    return null; try {
    const ss = t.split(' U ').map(s => { const m = /^([[(])(-?\d+(?:\/[1-9]\d*)?|-inf),\s*(-?\d+(?:\/[1-9]\d*)?|inf)([\])])$/.exec(s); if (!m)
        throw Error('interval_syntax'); const a = { lo: eread(m[2]), hi: eread(m[3]), lc: m[1] === '[', hc: m[4] === ']' }; if (!valid(a) || !a.lo.d && a.lc || !a.hi.d && a.hc || [a.lo, a.hi].some(x => x.d && (x.n < -1000000000000n || x.n > 1000000000000n || x.d > 100000000n)))
        throw Error('interval_bounds'); return a; });
    return ss.length <= 4 ? normalizeElementaryExpLogConstraintSegments(ss) : null;
}
catch {
    return null;
} }
const emember = (ss, x) => ss.some(s => ((0, exports.ecmp)(x, s.lo) > 0 || !(0, exports.ecmp)(x, s.lo) && s.lc) && ((0, exports.ecmp)(x, s.hi) < 0 || !(0, exports.ecmp)(x, s.hi) && s.hc));
exports.emember = emember;
function representative(l, h) { return !l.d ? (0, exports.esub)(h, eq(1)) : !h.d ? (0, exports.eadd)(l, eq(1)) : (0, exports.ediv)((0, exports.eadd)(l, h), eq(2)); }
function cutSet(extra, test) { const xs = [ni, ...extra.filter(x => x.d).sort(exports.ecmp).filter((x, j, a) => !j || (0, exports.ecmp)(x, a[j - 1])), pi], out = []; for (let j = 0; j < xs.length; j++) {
    if (xs[j].d && test(xs[j]))
        out.push({ lo: xs[j], hi: xs[j], lc: true, hc: true });
    if (j + 1 < xs.length && test(representative(xs[j], xs[j + 1])))
        out.push({ lo: xs[j], hi: xs[j + 1], lc: false, hc: false });
} return normalizeElementaryExpLogConstraintSegments(out); }
function diffWitness(a, b) { const xs = [ni, ...[...a, ...b].flatMap(s => [s.lo, s.hi]).filter(x => x.d).sort(exports.ecmp).filter((x, j, v) => !j || (0, exports.ecmp)(x, v[j - 1])), pi]; for (let j = 0; j < xs.length; j++) {
    if (xs[j].d && (0, exports.emember)(a, xs[j]) !== (0, exports.emember)(b, xs[j]))
        return (0, exports.etxt)(xs[j]);
    if (j + 1 < xs.length) {
        const t = representative(xs[j], xs[j + 1]);
        if ((0, exports.emember)(a, t) !== (0, exports.emember)(b, t))
            return (0, exports.etxt)(t);
    }
} return null; }
const rec = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
function elementaryExpLogConstraintScopeFrom(value) { const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactElementaryExpLogConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 69 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.ELEMENTARY_EXP_LOG_CONSTRAINT_FAMILY && p?.planTemplate === exports.ELEMENTARY_EXP_LOG_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.ELEMENTARY_EXP_LOG_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'elementary_exp_log_constraint_system' && s?.scenarioAction === scope && exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
function elementaryExpLogConstraintPrompt(p, lang) {
    const d = p.data, i = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPES.indexOf(p.scope), lead = lang === 'zh' ? '变量 x 为实数，保留区间端点的开闭。' : 'The variable x is real; retain endpoint inclusion. ', tail = lang === 'zh' ? ' 求全部解集。' : ' Find the complete solution set.';
    if (i === 0)
        return lead + 'b=(' + d[0] + '); u(x)=(' + d[1] + ')*x+(' + d[2] + '); t=b^u(x); (t-b^(' + d[3] + '))*(t-b^(' + d[4] + '))/(t-b^(' + d[5] + ')) ' + d[8] + ' 0; x in [' + d[6] + ',' + d[7] + '].' + tail;
    if (i === 1)
        return lead + 'b=(' + d[0] + '); A(x)=(' + d[1] + ')*x+(' + d[2] + '); B(x)=(' + d[3] + ')*x+(' + d[4] + '); log_b(A(x))-log_b(B(x)) ' + d[8] + ' (' + d[5] + '); x in [' + d[6] + ',' + d[7] + '].' + tail;
    if (i === 2)
        return lead + 'b=(' + d[0] + '); u(x)=(' + d[1] + ')*x+(' + d[2] + '); y=(' + d[3] + ')*b^(2*u(x))+(' + d[4] + ')*b^u(x)+(' + d[5] + '); x in [' + d[6] + ',' + d[7] + '].' + (lang === 'zh' ? ' 求 y 的完整值域。' : ' Find the complete range of y.');
    return lead + 'b=(' + d[0] + '); u(x)=(' + d[1] + ')*x+(' + d[2] + '); F(x)=log_b((log_b(u(x))-(' + d[3] + '))/(log_b(u(x))-(' + d[4] + ')))+log_b((' + d[5] + ')-x).' + (lang === 'zh' ? ' 求 F 的定义域。' : ' Find the domain of F.');
}
function elementaryExpLogConstraintParametersValid(p) { try {
    const i = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPES.indexOf(p.scope), d = p.data;
    if (i < 0 || d.length !== [9, 9, 8, 6][i])
        return false;
    const vs = d.slice(0, i < 2 ? 8 : d.length).map(eread), small = (v) => !!v.d && v.n >= -1000000n && v.n <= 1000000n && v.d <= 10000n;
    if (!vs.every(small) || !['2', '3', '4', '5', '1/2', '1/3', '1/4', '1/5'].includes(d[0]))
        return false;
    const integer = (v, n) => v.d === 1n && v.n >= BigInt(-n) && v.n <= BigInt(n), slope = (v) => integer(v, 4) && !!v.n;
    if (!slope(vs[1]) || !integer(vs[2], 8))
        return false;
    if (i < 2 && !['>', '>=', '<', '<='].includes(d[8]))
        return false;
    if (i === 0 && (!vs.slice(3, 6).every(v => integer(v, 4)) || new Set(d.slice(3, 6)).size !== 3))
        return false;
    if (i === 1 && (!slope(vs[3]) || !integer(vs[4], 8) || !integer(vs[5], 4) || !(0, exports.ecmp)((0, exports.emul)(vs[1], vs[4]), (0, exports.emul)(vs[2], vs[3]))))
        return false;
    if (i === 2 && (!slope(vs[3]) || !vs[4].n || !integer(vs[5], 8)))
        return false;
    if (i === 3 && (!vs.slice(3, 5).every(v => integer(v, 4)) || !(0, exports.ecmp)(vs[3], vs[4])))
        return false;
    if (i < 3 && (0, exports.ecmp)(vs[6], vs[7]) >= 0)
        return false;
    if (i === 2 && !vs.slice(6, 8).every(x => integer((0, exports.eadd)((0, exports.emul)(vs[1], x), vs[2]), 4)))
        return false;
    return true;
}
catch {
    return false;
} }
function elementaryExpLogConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 2000)
    return null; const i = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPES.indexOf(scope), nums = [...text.matchAll(/\((-?\d+(?:\/[1-9]\d*)?)\)/g)].map(x => x[1]), range = /x in \[(-?\d+(?:\/[1-9]\d*)?),(-?\d+(?:\/[1-9]\d*)?)\]/.exec(text), op = / (>=|<=|>|<) /.exec(text); if (nums.length !== 6)
    return null; const data = i === 3 ? nums : [...nums, ...(range ? range.slice(1) : []), ...(i < 2 && op ? [op[1]] : [])], p = { scope, data }; return elementaryExpLogConstraintParametersValid(p) && elementaryExpLogConstraintPrompt(p, lang) === text ? p : null; }
function elementaryExpLogConstraintDerive(p) {
    if (!elementaryExpLogConstraintParametersValid(p))
        return null;
    const i = exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPES.indexOf(p.scope), s = p.data, v = s.slice(0, i < 2 ? 8 : s.length).map(eread), [b, a, c] = v, dir = (0, exports.ecmp)(b, eq(1)), aff = (x) => (0, exports.eadd)((0, exports.emul)(a, x), c), inv = (u) => (0, exports.ediv)((0, exports.esub)(u, c), a), fmt = exports.elementaryExpLogConstraintIntervalText;
    let result = [], relaxed = [], critical = [], steps = [], rangeWitnesses = [];
    const op = (sign) => s[8] === '>' ? sign > 0 : s[8] === '>=' ? sign >= 0 : s[8] === '<' ? sign < 0 : sign <= 0;
    if (i === 0) {
        const roots = v.slice(3, 6).map(inv), l = v[6], h = v[7], inside = (x) => (0, exports.ecmp)(x, l) >= 0 && (0, exports.ecmp)(x, h) <= 0, ineq = (x) => { const signs = v.slice(3, 6).map(k => dir * (0, exports.ecmp)(aff(x), k)); return !!signs[2] && op(signs[0] * signs[1] * signs[2]); };
        critical = [...roots, l, h];
        result = cutSet(critical, x => inside(x) && ineq(x));
        relaxed = [cutSet(critical, ineq), cutSet(critical, inside)];
        steps = ['t=b^u>0; b=' + s[0] + '; affine=' + s[1] + 'x+(' + s[2] + ')', 'critical x=' + roots.map(exports.etxt).join(','), 'base direction=' + dir + '; affine direction=' + (0, exports.ecmp)(a, z), 'exclude pole x=' + (0, exports.etxt)(roots[2]), 'intersect D=[' + s[6] + ',' + s[7] + ']'];
    }
    else if (i === 1) {
        const d = v[3], e = v[4], k = Number(v[5].n), K = epow(b, k), B = (x) => (0, exports.eadd)((0, exports.emul)(d, x), e), domain = (x) => (0, exports.ecmp)(aff(x), z) > 0 && (0, exports.ecmp)(B(x), z) > 0, l = v[6], h = v[7], inside = (x) => (0, exports.ecmp)(x, l) >= 0 && (0, exports.ecmp)(x, h) <= 0;
        const coef = (0, exports.esub)(a, (0, exports.emul)(K, d)), con = (0, exports.esub)(c, (0, exports.emul)(K, e));
        critical = [inv(z), (0, exports.ediv)((0, exports.eneg)(e), d), l, h, ...(coef.n ? [(0, exports.ediv)((0, exports.eneg)(con), coef)] : [])];
        const ineq = (x) => B(x).n !== 0n && op(dir * (0, exports.ecmp)((0, exports.ediv)(aff(x), B(x)), K));
        result = cutSet(critical, x => domain(x) && ineq(x) && inside(x));
        relaxed = [cutSet(critical, x => ineq(x) && inside(x)), cutSet(critical, x => domain(x) && inside(x))];
        steps = ['A>0 and B>0; zeros=' + (0, exports.etxt)(inv(z)) + ',' + (0, exports.etxt)((0, exports.ediv)((0, exports.eneg)(e), d)), 'log difference = log(A/B) only on domain', 'b^k=' + (0, exports.etxt)(K) + '; base direction=' + dir, 'ratio boundary ' + (0, exports.etxt)(coef) + 'x+(' + (0, exports.etxt)(con) + ')=0', 'intersect D=[' + s[6] + ',' + s[7] + ']'];
    }
    else if (i === 2) {
        const A = v[3], B = v[4], C = v[5], ts = v.slice(6, 8).map(x => epow(b, Number(aff(x).n))).sort(exports.ecmp), vertex = (0, exports.ediv)((0, exports.eneg)(B), (0, exports.emul)(eq(2), A)), evalAt = (t) => (0, exports.eadd)((0, exports.eadd)((0, exports.emul)(A, (0, exports.emul)(t, t)), (0, exports.emul)(B, t)), C), ys = [evalAt(ts[0]), evalAt(ts[1]), ...((0, exports.ecmp)(vertex, ts[0]) >= 0 && (0, exports.ecmp)(vertex, ts[1]) <= 0 ? [evalAt(vertex)] : [])].sort(exports.ecmp);
        result = [{ lo: ys[0], hi: ys[ys.length - 1], lc: true, hc: true }];
        if ((0, exports.ecmp)(vertex, z) <= 0)
            return null;
        for (const [name, x] of [['lower', (0, exports.esub)(v[6], eq(2))], ['upper', (0, exports.eadd)(v[7], eq(2))]]) {
            const ex = aff(x);
            if (ex.d !== 1n || ex.n < -16n || ex.n > 16n)
                return null;
            const value = evalAt(epow(b, Number(ex.n)));
            if ((0, exports.emember)(result, value))
                return null;
            rangeWitnesses.push({ omitted: name + ' domain bound', parameter: (0, exports.etxt)(x), value: (0, exports.etxt)(value) });
        }
        critical = [...ts, vertex];
        steps = ['u(D)=[' + v.slice(6, 8).map(x => (0, exports.etxt)(aff(x))).join(',') + ']; base=' + s[0], 't(D)=[' + ts.map(exports.etxt).join(',') + ']', 'quadratic vertex t=' + (0, exports.etxt)(vertex), 'endpoint/vertex values=' + ys.map(exports.etxt).join(','), 'attained min,max=' + fmt(result)];
    }
    else {
        const pv = Number(v[3].n), qv = Number(v[4].n), limit = v[5], x0 = inv(z), xp = inv(epow(b, pv)), xq = inv(epow(b, qv)), domain = (x) => (0, exports.ecmp)(aff(x), z) > 0, outer = (x) => { if (!domain(x))
            return false; const u = aff(x), ps = dir * (0, exports.ecmp)(u, epow(b, pv)), qs = dir * (0, exports.ecmp)(u, epow(b, qv)); return !!qs && ps * qs > 0; }, bound = (x) => (0, exports.ecmp)(x, limit) < 0;
        critical = [x0, xp, xq, limit];
        result = cutSet(critical, x => outer(x) && bound(x));
        relaxed = [cutSet(critical, x => domain(x) && bound(x)), cutSet(critical, outer)];
        steps = ['inner argument ' + s[1] + 'x+(' + s[2] + ')>0', 'log quotient roots mapped to ' + (0, exports.etxt)(xp) + ',' + (0, exports.etxt)(xq), 'outer argument positive; pole excluded', 'base direction=' + dir + '; affine direction=' + (0, exports.ecmp)(a, z), 'intersect x<' + s[5]];
    }
    const answer = fmt(result), effective = relaxed.map((x, j) => ({ omitted: j === 0 ? 'first restriction' : 'second restriction', relaxedSet: fmt(x), witness: diffWitness(result, x) })).filter(x => x.witness !== null);
    if (!result.length || result.length > 3 || !parseElementaryExpLogConstraintIntervals(answer) || (i === 2 ? rangeWitnesses.length : effective.length) < 2)
        return null;
    const finitePositions = result.flatMap((x, j) => [...(x.lo.d ? [{ j, k: 'lc' }] : []), ...(x.hi.d ? [{ j, k: 'hc' }] : [])]);
    if (finitePositions.length < 2)
        return null;
    const flipped = (pos) => { const cp = result.map(x => ({ ...x })); cp[pos.j][pos.k] = !cp[pos.j][pos.k]; return fmt(cp); };
    const errors = [{ intent: 'wrong_first_finite_endpoint_inclusion', text: flipped(finitePositions[0]) }, { intent: 'wrong_last_finite_endpoint_inclusion', text: flipped(finitePositions[finitePositions.length - 1]) }, { intent: 'reverse_affine_output_sign', text: fmt(result.map(x => ({ lo: (0, exports.eneg)(x.hi), hi: (0, exports.eneg)(x.lo), lc: x.hc, hc: x.lc }))) }].map(e => ({ ...e, key: e.text }));
    if (new Set([answer, ...errors.map(e => e.key)]).size !== 4)
        return null;
    const proof = 'parameters=' + s.join(',') + '; ' + steps.join('; '), hardEvidence = { version: 'elementary-exp-log-constraint-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 3, reasoningSteps: 4, quantitativeRelations: 2, effectiveConstraints: i === 2 ? rangeWitnesses : effective, criticalPoints: critical.map(exports.etxt), answer, visibleProof: proof, studentCalibrated: false };
    return { answer, text: answer, errors, proof, hardEvidence };
}
function solveSubjectPracticeMathElementaryExpLogConstraint(candidate, context = {}) { const scope = elementaryExpLogConstraintScopeFrom(context.questionPlan), parameters = elementaryExpLogConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? elementaryExpLogConstraintDerive(parameters) : null, reasonCodes = []; if (!d)
    reasonCodes.push('elementary_exp_log_constraint_outside_hard_scope'); if (candidate.subject !== 'math' || candidate.topicId !== 69 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
    reasonCodes.push('elementary_exp_log_constraint_identity'); const options = candidate.options ?? [], keys = options.map(o => { const a = parseElementaryExpLogConstraintIntervals(o.text); return a ? (0, exports.elementaryExpLogConstraintIntervalText)(a) : null; }); if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
    reasonCodes.push('elementary_exp_log_constraint_options'); for (const lang of ['zh', 'en']) {
    const l = candidate.localizations?.[lang];
    if (!parameters || JSON.stringify(elementaryExpLogConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
        reasonCodes.push('elementary_exp_log_constraint_' + lang + '_stem');
    if (JSON.stringify(l?.options?.map(o => { const a = parseElementaryExpLogConstraintIntervals(o.text); return [o.id, a ? (0, exports.elementaryExpLogConstraintIntervalText)(a) : null]; })) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
        reasonCodes.push('elementary_exp_log_constraint_' + lang + '_options');
} const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null; if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('elementary_exp_log_constraint_answer'); const meta = candidate.optionMetadata ?? []; if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
    reasonCodes.push('elementary_exp_log_constraint_error_intent'); const scopeId = parameters ? exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPE_VERSION + ':' + scope : null; return { solverVersion: exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.ELEMENTARY_EXP_LOG_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.ELEMENTARY_EXP_LOG_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['elementary_exp_log_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
