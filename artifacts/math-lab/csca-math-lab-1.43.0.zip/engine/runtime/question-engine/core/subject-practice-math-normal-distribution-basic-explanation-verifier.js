"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathNormalDistributionBasicExplanation = verifySubjectPracticeMathNormalDistributionBasicExplanation;
const subject_practice_math_normal_distribution_basic_solver_1 = require("./subject-practice-math-normal-distribution-basic-solver");
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_EXPLANATION_VERIFIER_VERSION = 'math-normal-distribution-basic-explanation-verifier-v1-bound-bilingual';
function verifySubjectPracticeMathNormalDistributionBasicExplanation(candidate, context = {}) {
    const s = (0, subject_practice_math_normal_distribution_basic_solver_1.solveSubjectPracticeMathNormalDistributionBasic)(candidate, context), p = s.parameters;
    let expression = '', zhPrefix = '', enPrefix = '';
    if (p && s.expectedValue) {
        const value = (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(s.expectedValue);
        if (p.target === 'mean')
            expression = 'mu=' + p.mu;
        else if (p.target === 'variance')
            expression = 'sigma^2=' + p.variance;
        else if (p.target === 'standard_deviation')
            expression = 'sigma=sqrt(' + p.variance + ')=' + p.sigma + '>0';
        else if (p.target === 'z')
            expression = 'sigma=sqrt(' + p.variance + ')=' + p.sigma + '; z=(' + p.x + '-(' + p.mu + '))/' + p.sigma + '=' + value;
        else if (p.target === 'symmetry')
            expression = 'mu=' + p.mu + '; P(X' + p.comparison + p.mu + ')=1/2; P(X=' + p.mu + ')=0';
        else {
            const c = p.k === 1 ? (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(17, 25) : p.k === 2 ? (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(19, 20) : (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(997, 1000), center = (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(c);
            expression = 'sigma=sqrt(' + p.variance + ')=' + p.sigma + '; L=' + p.mu + '-' + p.k + '*' + p.sigma + '=' + p.lower + '; U=' + p.mu + '+' + p.k + '*' + p.sigma + '=' + p.upper + '; central≈' + center;
            if (p.target === 'central')
                expression += '; P(L<=X<=U)≈' + value;
            else if (p.target === 'outside')
                expression += '; P(X<L or X>U)≈1-(' + center + ')=' + value;
            else
                expression += '; P(X' + (p.target === 'left' ? '<L' : '>U') + ')≈(1-(' + center + '))/2=' + value;
        }
        expression = 'N(' + p.mu + ', ' + p.variance + '); ' + expression;
        zhPrefix = p.target === 'symmetry' ? '连续正态分布关于均值对称，均值处单点概率为零：' : s.approximation ? '使用题给近似经验规律（不是精确正态积分值）：' : '按题中正态分布参数计算：';
        enPrefix = p.target === 'symmetry' ? 'Continuity and symmetry about the mean give: ' : s.approximation ? 'Using the stated empirical approximation, not an exact normal integral: ' : 'Using the stated normal parameters: ';
    }
    const zhBound = Boolean(expression) && candidate.explanation === zhPrefix + expression + '。对应选项 ' + s.selectedOptionId + '。' && candidate.localizations?.zh?.explanation === candidate.explanation;
    const enBound = Boolean(expression) && candidate.localizations?.en?.explanation === enPrefix + expression + '. Option ' + s.selectedOptionId + '.';
    const reasonCodes = [];
    if (s.status !== 'verified')
        reasonCodes.push('math_normal_basic_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('math_normal_basic_explanation_zh_not_bound');
    if (!enBound)
        reasonCodes.push('math_normal_basic_explanation_en_not_bound');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: s.scopeId, zhBound, enBound,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
