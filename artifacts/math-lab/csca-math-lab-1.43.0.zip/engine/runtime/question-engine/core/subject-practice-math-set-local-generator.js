"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SET_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathSetLocalGenerator = createSubjectPracticeMathSetLocalGenerator;
const subject_practice_math_set_solver_1 = require("./subject-practice-math-set-solver");
const subject_practice_math_set_independent_oracle_1 = require("./subject-practice-math-set-independent-oracle");
const subject_practice_math_set_explanation_verifier_1 = require("./subject-practice-math-set-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_SET_LOCAL_GENERATOR_VERSION = 'math-set-local-generator-v1';
const SCOPES = new Set(['finite_union', 'finite_intersection', 'finite_difference', 'finite_complement']);
function obj(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').trim(); }
function normalizedSeed(value) { const n = Number(value); return Number.isFinite(n) ? Math.abs(Math.trunc(n)) : 0; }
function scopeFrom(planValue, validate) {
    const plan = obj(planValue);
    const render = obj(plan?.renderConstraints);
    const scope = clean(render?.exactSetOperationScope);
    return validate(planValue).valid && clean(plan?.taskFamily) === 'math_finite_set_operation'
        && clean(plan?.planTemplate) === 'math_finite_set_operation_v1' && SCOPES.has(scope) ? scope : null;
}
function rotate(values, shift) { return values.map((n) => ((n - 1 + shift) % 8) + 1).sort((a, b) => a - b); }
function setText(values) { return `{${values.join(',')}}`; }
function uniqueSets(values) {
    const seen = new Set();
    return values.filter((value) => { const key = setText(value); if (seen.has(key))
        return false; seen.add(key); return true; });
}
function candidateFor(blueprint, seed, scope) {
    const universe = [1, 2, 3, 4, 5, 6, 7, 8];
    const shift = seed % 8;
    const a = rotate([1, 3, 5, 7], shift);
    const b = rotate([2, 3, 6, 7], shift);
    const A = new Set(a);
    const B = new Set(b);
    const result = scope === 'finite_union' ? [...new Set([...a, ...b])].sort((x, y) => x - y)
        : scope === 'finite_intersection' ? a.filter((x) => B.has(x))
            : scope === 'finite_difference' ? a.filter((x) => !B.has(x))
                : universe.filter((x) => !A.has(x));
    const symmetric = universe.filter((x) => (A.has(x) ? 1 : 0) + (B.has(x) ? 1 : 0) === 1);
    const complementB = universe.filter((x) => !B.has(x));
    const alternatives = uniqueSets([result, a, b, symmetric, complementB, universe, []]).slice(0, 4);
    if (alternatives.length !== 4 || setText(alternatives[0]) !== setText(result))
        throw new Error('math_set_generator_option_construction_failed');
    const correctIndex = seed % 4;
    const correct = alternatives[0];
    const ordered = alternatives.slice(1);
    ordered.splice(correctIndex, 0, correct);
    const ids = ['A', 'B', 'C', 'D'];
    const options = ordered.map((value, index) => ({ id: ids[index], text: setText(value) }));
    const operationZh = scope === 'finite_union' ? 'A∪B' : scope === 'finite_intersection' ? 'A∩B' : scope === 'finite_difference' ? 'A\\B' : 'U中A的补集';
    const operationEn = scope === 'finite_union' ? 'A union B' : scope === 'finite_intersection' ? 'A intersection B' : scope === 'finite_difference' ? 'A minus B' : 'the complement of A in U';
    const prompt = `已知全集 U=${setText(universe)}，集合 A=${setText(a)}，集合 B=${setText(b)}。求${operationZh}。`;
    const promptEn = `Let U=${setText(universe)}, A=${setText(a)}, and B=${setText(b)}. Find ${operationEn}.`;
    const explanation = `${operationZh}保留满足该集合运算定义的元素，逐项检查U中的元素，得到${setText(result)}。`;
    const explanationEn = `${operationEn} keeps exactly the elements required by the set-operation definition. Checking each element of U gives ${setText(result)}.`;
    const distractorDescriptor = (value, index) => {
        const key = setText(value);
        const known = [
            [setText(a), 'returned_operand_a', ['confused_result_with_operand_a']],
            [setText(b), 'returned_operand_b', ['confused_result_with_operand_b']],
            [setText(symmetric), 'used_symmetric_difference', ['excluded_shared_members']],
            [setText(complementB), 'used_complement_of_b', ['confused_requested_operation_with_complement']],
            [setText(universe), 'returned_full_universe', ['included_every_universe_member']],
            [setText([]), 'returned_empty_set', ['excluded_all_members']]
        ].find(([candidateKey]) => candidateKey === key);
        return {
            optionId: ids[index],
            distractorIntent: String(known?.[1] ?? `incorrect_finite_set_result_${index + 1}`),
            misconceptionTags: known?.[2] ?? ['finite_set_operation_error']
        };
    };
    return {
        subject: 'math', topicId: blueprint.topicId, blueprintId: blueprint.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice',
        prompt, options, correctAnswer: ids[correctIndex], explanation, knowledgeTags: ['集合', '有限集合运算', scope],
        optionMetadata: ordered.flatMap((value, index) => index === correctIndex ? [] : [distractorDescriptor(value, index)]),
        localizations: { zh: { prompt, options, explanation, knowledgeTags: ['集合', '有限集合运算'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Sets', 'Finite set operations'] } },
        syllabusVersion: blueprint.syllabusVersion
    };
}
function createSubjectPracticeMathSetLocalGenerator(ports) {
    return function generate(input) {
        const seed = normalizedSeed(input.seed);
        const exactScope = scopeFrom(input.questionPlan, ports.validate);
        const supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'basic' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice';
        if (!exactScope || !supported)
            return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SET_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_set_local_generator_question_plan_not_supported'] };
        const candidate = candidateFor(input.blueprint, seed, exactScope);
        const context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_set_solver_1.solveSubjectPracticeMathSet)(candidate, context);
        const oracleEvidence = (0, subject_practice_math_set_independent_oracle_1.verifySubjectPracticeMathSetWithIndependentOracle)(candidate, context);
        const explanationEvidence = (0, subject_practice_math_set_explanation_verifier_1.verifySubjectPracticeMathSetExplanation)(candidate, context);
        const adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SET_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_set_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
