"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.geoCircleText = exports.geoLineText = exports.geoText = exports.geoDiv = exports.geoMul = exports.geoSub = exports.geoAdd = exports.geoAbs = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINTS = exports.PLANE_ANALYTIC_GEOMETRY_SCOPES = exports.PLANE_ANALYTIC_GEOMETRY_SCOPE_VERSION = exports.PLANE_ANALYTIC_GEOMETRY_SOLVER_VERSION = exports.PLANE_ANALYTIC_GEOMETRY_TEMPLATE = exports.PLANE_ANALYTIC_GEOMETRY_FAMILY = void 0;
exports.planeAnalyticGeometryScopeFrom = planeAnalyticGeometryScopeFrom;
exports.geoGcd = geoGcd;
exports.geoQ = geoQ;
exports.geoSqrt = geoSqrt;
exports.planeAnalyticGeometryPrompt = planeAnalyticGeometryPrompt;
exports.planeAnalyticGeometryDerive = planeAnalyticGeometryDerive;
exports.planeAnalyticGeometryParametersFrom = planeAnalyticGeometryParametersFrom;
exports.planeAnalyticGeometryOptionKey = planeAnalyticGeometryOptionKey;
exports.planeAnalyticGeometryDistractors = planeAnalyticGeometryDistractors;
exports.solveSubjectPracticeMathPlaneAnalyticGeometry = solveSubjectPracticeMathPlaneAnalyticGeometry;
exports.PLANE_ANALYTIC_GEOMETRY_FAMILY = 'math_plane_analytic_geometry_relation';
exports.PLANE_ANALYTIC_GEOMETRY_TEMPLATE = exports.PLANE_ANALYTIC_GEOMETRY_FAMILY + '_v1';
exports.PLANE_ANALYTIC_GEOMETRY_SOLVER_VERSION = 'math-plane-analytic-geometry-solver-v1-exact-rational';
exports.PLANE_ANALYTIC_GEOMETRY_SCOPE_VERSION = 'math-medium-plane-analytic-geometry-v1';
exports.PLANE_ANALYTIC_GEOMETRY_SCOPES = ['line_intersection_then_point_distance', 'parallel_lines_distance',
    'circle_line_chord_length', 'circle_tangent_at_point'];
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINTS = { topicCode: 'M-GEO-001', boundedIntegerParameters: true,
    exactRationalArithmetic: true, maximumAbsoluteValue: 10000, completeAnalyticGeometryCertificate: true,
    externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
const obj = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
function planeAnalyticGeometryScopeFrom(value) {
    const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactPlaneAnalyticGeometryScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 72 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === exports.PLANE_ANALYTIC_GEOMETRY_FAMILY && p?.planTemplate === exports.PLANE_ANALYTIC_GEOMETRY_TEMPLATE && r?.questionType === 'single_choice'
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'plane_line_circle_object' && s?.scenarioAction === scope
        && Object.entries(exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && exports.PLANE_ANALYTIC_GEOMETRY_SCOPES.includes(scope) ? scope : null;
}
const geoAbs = (x) => x < 0n ? -x : x;
exports.geoAbs = geoAbs;
function geoGcd(a, b) { a = (0, exports.geoAbs)(a); b = (0, exports.geoAbs)(b); while (b) {
    const t = a % b;
    a = b;
    b = t;
} return a; }
function geoQ(n, d = 1) {
    let a = BigInt(n), b = BigInt(d);
    if (!b)
        throw Error('zero_denominator');
    if (b < 0n) {
        a = -a;
        b = -b;
    }
    const g = geoGcd(a, b);
    return [a / g, b / g];
}
const geoAdd = (a, b) => geoQ(a[0] * b[1] + b[0] * a[1], a[1] * b[1]);
exports.geoAdd = geoAdd;
const geoSub = (a, b) => geoQ(a[0] * b[1] - b[0] * a[1], a[1] * b[1]);
exports.geoSub = geoSub;
const geoMul = (a, b) => geoQ(a[0] * b[0], a[1] * b[1]);
exports.geoMul = geoMul;
const geoDiv = (a, b) => geoQ(a[0] * b[1], a[1] * b[0]);
exports.geoDiv = geoDiv;
const geoText = (q) => String(q[0]) + (q[1] === 1n ? '' : '/' + q[1]);
exports.geoText = geoText;
function geoSqrt(n) { if (n < 0n)
    return null; let lo = 0n, hi = n + 1n; while (hi - lo > 1n) {
    const m = (lo + hi) / 2n;
    if (m * m <= n)
        lo = m;
    else
        hi = m;
} return lo * lo === n ? lo : null; }
const geoLineText = (v) => '(' + v[0] + ')*x+(' + v[1] + ')*y+(' + v[2] + ')=0';
exports.geoLineText = geoLineText;
const geoCircleText = (v) => 'x^2+y^2+(' + v[0] + ')*x+(' + v[1] + ')*y+(' + v[2] + ')=0';
exports.geoCircleText = geoCircleText;
function planeAnalyticGeometryPrompt(p, lang) {
    const point = '(' + p.point.join(',') + ')';
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[0])
        return lang === 'zh'
            ? '两直线 L1: ' + (0, exports.geoLineText)(p.l1) + ' 与 L2: ' + (0, exports.geoLineText)(p.l2) + ' 交于 P，给定 Q=' + point + '。求距离 PQ。'
            : 'Lines L1: ' + (0, exports.geoLineText)(p.l1) + ' and L2: ' + (0, exports.geoLineText)(p.l2) + ' intersect at P. Given Q=' + point + ', find the distance PQ.';
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[1])
        return lang === 'zh'
            ? '给定两直线 L1: ' + (0, exports.geoLineText)(p.l1) + ' 与 L2: ' + (0, exports.geoLineText)(p.l2) + '。先确认平行并统一系数尺度，再求两线间距离。'
            : 'Given lines L1: ' + (0, exports.geoLineText)(p.l1) + ' and L2: ' + (0, exports.geoLineText)(p.l2) + ', verify parallelism and normalize the coefficients, then find their distance.';
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[2])
        return lang === 'zh'
            ? '圆 C: ' + (0, exports.geoCircleText)(p.circle) + ' 与直线 L: ' + (0, exports.geoLineText)(p.l1) + ' 相交于两点。求所截弦的全长。'
            : 'Circle C: ' + (0, exports.geoCircleText)(p.circle) + ' intersects line L: ' + (0, exports.geoLineText)(p.l1) + ' at two points. Find the full chord length.';
    return lang === 'zh' ? '圆 C: ' + (0, exports.geoCircleText)(p.circle) + '，给定圆上点 P=' + point + '。求圆在 P 处的切线方程。'
        : 'Circle C: ' + (0, exports.geoCircleText)(p.circle) + '. Given P=' + point + ' on the circle, find its tangent line at P.';
}
const normalBases = new Set(['1,0', '0,1', '3,4', '4,3', '5,12', '12,5']);
const bounded = (x, bound) => Number.isSafeInteger(x) && Math.abs(x) <= bound;
function planeAnalyticGeometryDerive(p) {
    if (![...p.l1, ...p.l2, ...p.circle, ...p.point].every(x => bounded(x, 10000)))
        return null;
    const [a, b, c] = p.l1.map(BigInt), [e, f, g] = p.l2.map(BigInt);
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[0]) {
        if (p.l1.length !== 3 || p.l2.length !== 3 || p.point.length !== 2 || p.circle.length || ![a, b, e, f].every(x => (0, exports.geoAbs)(x) <= 3n) || (!a && !b) || (!e && !f))
            return null;
        const det = a * f - b * e;
        if (!det)
            return null;
        const x = geoQ(b * g - c * f, det), y = geoQ(c * e - a * g, det);
        if (x[1] !== 1n || y[1] !== 1n || (0, exports.geoAbs)(x[0]) > 6n || (0, exports.geoAbs)(y[0]) > 6n)
            return null;
        const dx = BigInt(p.point[0]) - x[0], dy = BigInt(p.point[1]) - y[0], abs = [(0, exports.geoAbs)(dx), (0, exports.geoAbs)(dy)].sort((u, v) => u < v ? -1 : 1);
        if (![1n, 2n, 3n].some(k => abs[0] === 3n * k && abs[1] === 4n * k))
            return null;
        const d = geoSqrt(dx * dx + dy * dy);
        if (d === null)
            return null;
        return { answer: String(d), proof: 'det=' + det + '; P=(' + (0, exports.geoText)(x) + ',' + (0, exports.geoText)(y) + '); dx=' + dx + '; dy=' + dy + '; PQ^2=' + dx * dx + '+' + dy * dy + '=' + d * d + '; PQ=' + d,
            values: [x[0], y[0], dx, dy, d] };
    }
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[1]) {
        if (p.l1.length !== 3 || p.l2.length !== 3 || p.circle.length || p.point.length || !normalBases.has((0, exports.geoAbs)(a) + ',' + (0, exports.geoAbs)(b)) || (0, exports.geoAbs)(c) > 12n)
            return null;
        const lambda = geoQ(a ? e : f, a || b), N = geoSqrt(a * a + b * b);
        if (!N || lambda[1] !== 1n || ![-3n, -2n, 2n, 3n].includes(lambda[0]) || e !== lambda[0] * a || f !== lambda[0] * b)
            return null;
        const t = geoQ(g - lambda[0] * c, lambda[0] * N);
        if (t[1] !== 1n || !t[0] || (0, exports.geoAbs)(t[0]) > 6n)
            return null;
        const d = (0, exports.geoAbs)(t[0]);
        return { answer: String(d), proof: 'lambda=' + lambda[0] + '; normalized_c2=' + (0, exports.geoText)(geoQ(g, lambda[0])) + '; normal_length=' + N + '; distance=|' + (0, exports.geoText)(geoQ(g, lambda[0])) + '-(' + c + ')|/' + N + '=' + d, values: [d, N, c, g, lambda[0]] };
    }
    if (p.circle.length !== 3 || p.l2.length)
        return null;
    const [D, E, F] = p.circle.map(BigInt);
    if (D % 2n || E % 2n)
        return null;
    const h = -D / 2n, k = -E / 2n, r2 = h * h + k * k - F;
    if ((0, exports.geoAbs)(h) > 6n || (0, exports.geoAbs)(k) > 6n || r2 <= 0n)
        return null;
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[2]) {
        if (p.l1.length !== 3 || p.point.length || !normalBases.has((0, exports.geoAbs)(a) + ',' + (0, exports.geoAbs)(b)))
            return null;
        const N = geoSqrt(a * a + b * b), R = geoSqrt(r2);
        if (!N || !R)
            return null;
        const num = (0, exports.geoAbs)(a * h + b * k + c);
        if (num % N)
            return null;
        const d = num / N, s = geoSqrt(r2 - d * d);
        if (d <= 0n || d >= R || !s)
            return null;
        const triples = [[5n, 3n, 4n], [5n, 4n, 3n], [13n, 5n, 12n], [13n, 12n, 5n], [17n, 8n, 15n], [17n, 15n, 8n]];
        if (!triples.some(t => [1n, 2n].some(v => R === v * t[0] && d === v * t[1] && s === v * t[2])))
            return null;
        return { answer: String(2n * s), proof: 'center=(' + h + ',' + k + '); r^2=' + r2 + '; center_line_distance=|' + (a * h + b * k + c) + '|/' + N + '=' + d + '; half_chord^2=' + r2 + '-' + d * d + '=' + s * s + '; full_chord=2*' + s + '=' + 2n * s, values: [h, k, R, d, s] };
    }
    if (p.scope !== exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[3] || p.l1.length || p.point.length !== 2)
        return null;
    const [x, y] = p.point.map(BigInt), u = x - h, v = y - k;
    if ((0, exports.geoAbs)(u) > 6n || (0, exports.geoAbs)(v) > 6n || u * u + v * v !== r2 || r2 > 72n)
        return null;
    const answer = (0, exports.geoLineText)([u, v, -u * x - v * y]);
    return { answer, proof: 'center=(' + h + ',' + k + '); r^2=' + r2 + '; P_circle_substitution=' + String(x * x + y * y + D * x + E * y + F) + '; radius_vector=(' + u + ',' + v + '); tangent_normal=radius_vector; tangent=' + answer, values: [h, k, u, v, x, y] };
}
function planeAnalyticGeometryParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1500)
        return null;
    const line = /\((-?\d{1,5})\)\*x\+\((-?\d{1,5})\)\*y\+\((-?\d{1,5})\)=0/g;
    const lines = [...text.matchAll(line)].filter(m => m.index === 0 || text[m.index - 1] !== '+').map(m => m.slice(1).map(Number));
    const circle = text.match(/x\^2\+y\^2\+\((-?\d{1,5})\)\*x\+\((-?\d{1,5})\)\*y\+\((-?\d{1,5})\)=0/);
    const point = text.match(/[PQ]=\((-?\d{1,5}),(-?\d{1,5})\)/);
    const p = { scope, l1: lines[0] ?? [], l2: lines[1] ?? [], circle: circle ? circle.slice(1).map(Number) : [], point: point ? point.slice(1).map(Number) : [] };
    return planeAnalyticGeometryPrompt(p, lang) === text && planeAnalyticGeometryDerive(p) ? p : null;
}
function scalar(text) {
    const m = text.trim().match(/^([+-]?\d{1,6})(?:\/([+-]?\d{1,6}))?$/);
    if (!m || !BigInt(m[2] ?? 1))
        return null;
    const q = geoQ(BigInt(m[1]), BigInt(m[2] ?? 1));
    return (0, exports.geoAbs)(q[0]) <= 10000n && q[1] <= 10000n ? q : null;
}
function planeAnalyticGeometryOptionKey(text, scope) {
    if (typeof text !== 'string' || text.length > 180)
        return null;
    if (scope !== exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[3]) {
        const q = scalar(text);
        return q ? (0, exports.geoText)(q) : null;
    }
    const m = text.trim().match(/^\(([^)]+)\)\*x\+\(([^)]+)\)\*y\+\(([^)]+)\)=0$/);
    if (!m)
        return null;
    const qs = m.slice(1).map(scalar);
    if (qs.some(q => !q))
        return null;
    const [a, b, c] = qs;
    if (!a[0] && !b[0])
        return null;
    const pivot = a[0] ? a : b;
    return [a, b, c].map(q => (0, exports.geoText)((0, exports.geoDiv)(q, pivot))).join(',');
}
function planeAnalyticGeometryDistractors(p) {
    const d = planeAnalyticGeometryDerive(p);
    if (!d)
        return [];
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[0]) {
        const [, , dx, dy, r] = d.values;
        return [{ key: String(r * r), intent: 'report_squared_distance' }, { key: String((0, exports.geoAbs)(dx) + (0, exports.geoAbs)(dy)), intent: 'use_manhattan_distance' }, { key: String((0, exports.geoAbs)(dx)), intent: 'omit_vertical_displacement' }];
    }
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[1]) {
        const [r, N, c, g] = d.values;
        return [{ key: String(-r), intent: 'return_negative_distance' }, { key: (0, exports.geoText)(geoQ((0, exports.geoAbs)(g - c), N)), intent: 'subtract_constants_without_scale_normalization' }, { key: String(r * r), intent: 'report_squared_distance' }];
    }
    if (p.scope === exports.PLANE_ANALYTIC_GEOMETRY_SCOPES[2]) {
        const [, , R, distance, s] = d.values;
        return [{ key: String(s), intent: 'report_half_chord' }, { key: String(2n * R), intent: 'substitute_circle_diameter' }, { key: String(2n * (R - distance)), intent: 'subtract_lengths_instead_of_pythagoras' }];
    }
    const [, , u, v, x, y] = d.values;
    return [{ key: (0, exports.geoLineText)([-v, u, v * x - u * y]), intent: 'return_radius_normal_line' }, { key: (0, exports.geoLineText)([u, v, u * x + v * y]), intent: 'reverse_translation_sign' }, { key: (0, exports.geoLineText)([u, v, 0n]), intent: 'force_tangent_through_origin' }];
}
function solveSubjectPracticeMathPlaneAnalyticGeometry(candidate, context = {}) {
    const scope = planeAnalyticGeometryScopeFrom(context.questionPlan), parameters = planeAnalyticGeometryParametersFrom(candidate.prompt, scope, 'zh'), derived = parameters ? planeAnalyticGeometryDerive(parameters) : null, reasonCodes = [];
    if (!parameters || !derived)
        reasonCodes.push('plane_geometry_prompt_or_plan_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 72 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('plane_geometry_identity_mismatch');
    const options = candidate.options ?? [], keys = options.map(o => scope ? planeAnalyticGeometryOptionKey(o.text, scope) : null), expectedKey = derived && scope ? planeAnalyticGeometryOptionKey(derived.answer, scope) : null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('plane_geometry_invalid_or_duplicate_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(planeAnalyticGeometryParametersFrom(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('plane_geometry_' + lang + '_prompt_mismatch');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, scope ? planeAnalyticGeometryOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('plane_geometry_' + lang + '_options_mismatch');
    }
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : keys[i] === expectedKey ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('plane_geometry_answer_disagreement');
    const wrong = parameters ? planeAnalyticGeometryDistractors(parameters) : [], meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(x => x.optionId)).size !== 3 || new Set(meta.map(x => x.distractorIntent)).size !== 3 || meta.some(x => x.optionId === selectedOptionId || !wrong.some(w => w.intent === x.distractorIntent && scope && planeAnalyticGeometryOptionKey(w.key, scope) === keys[options.findIndex(o => o.id === x.optionId)])))
        reasonCodes.push('plane_geometry_distractor_intent_mismatch');
    const scopeId = parameters ? exports.PLANE_ANALYTIC_GEOMETRY_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.PLANE_ANALYTIC_GEOMETRY_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: exports.PLANE_ANALYTIC_GEOMETRY_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: derived?.answer ?? null, proof: derived?.proof ?? null, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.PLANE_ANALYTIC_GEOMETRY_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope: scope, reasonCodes: parameters ? [] : ['plane_geometry_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
