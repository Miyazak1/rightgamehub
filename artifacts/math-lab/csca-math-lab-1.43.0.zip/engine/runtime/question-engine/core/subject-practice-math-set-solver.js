"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SET_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_SET_SOLVER_VERSION = void 0;
exports.solveSubjectPracticeMathSet = solveSubjectPracticeMathSet;
exports.SUBJECT_PRACTICE_MATH_SET_SOLVER_VERSION = 'math-set-solver-v1';
exports.SUBJECT_PRACTICE_MATH_SET_SCOPE_VERSION = 'math-set-scope-v1';
const SCOPES = new Set(['finite_union', 'finite_intersection', 'finite_difference', 'finite_complement']);
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').replace(/[，]/g, ',').replace(/\s+/g, ' ').trim(); }
function scopeFrom(context) {
    const plan = record(context.questionPlan);
    const render = record(plan?.renderConstraints);
    const value = clean(render?.exactSetOperationScope);
    return clean(plan?.taskFamily) === 'math_finite_set_operation'
        && clean(plan?.planTemplate) === 'math_finite_set_operation_v1' && SCOPES.has(value) ? value : null;
}
function parseSet(text) {
    const match = clean(text).match(/\{([^{}]*)\}/);
    if (!match)
        return null;
    if (!match[1].trim())
        return [];
    const values = match[1].split(',').map((part) => Number(part.trim()));
    return values.every(Number.isInteger) ? [...new Set(values)].sort((a, b) => a - b) : null;
}
function namedSet(prompt, name) {
    const match = clean(prompt).match(new RegExp(`${name}\\s*=\\s*(\\{[^{}]*\\})`, 'i'));
    return match ? parseSet(match[1]) : null;
}
function expected(scope, universe, a, b) {
    const A = new Set(a);
    const B = new Set(b);
    if (scope === 'finite_union')
        return [...new Set([...a, ...b])].sort((x, y) => x - y);
    if (scope === 'finite_intersection')
        return a.filter((x) => B.has(x));
    if (scope === 'finite_difference')
        return a.filter((x) => !B.has(x));
    return universe.filter((x) => !A.has(x));
}
function same(left, right) { return Boolean(left && left.length === right.length && left.every((v, i) => v === right[i])); }
function solveSubjectPracticeMathSet(candidate, context = {}) {
    const scope = scopeFrom(context);
    const prompt = clean(candidate.prompt);
    const universe = namedSet(prompt, 'U');
    const a = namedSet(prompt, 'A');
    const b = namedSet(prompt, 'B');
    const parsed = Boolean(scope && universe && a && (scope === 'finite_complement' || b));
    const target = parsed ? expected(scope, universe, a, b ?? []) : [];
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const value = parseSet(option.text);
        const truth = parsed && same(value, target);
        return { optionId: option.id, verdict: value ? (truth ? 'true' : 'false') : 'unknown', semanticValue: value };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const agreesWithGenerator = selectedOptionId === candidate.correctAnswer;
    const reasonCodes = [];
    if (!scope)
        reasonCodes.push('math_set_scope_plan_contract_missing');
    if (!parsed)
        reasonCodes.push('math_set_prompt_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_set_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length ? 'math_set_multiple_true_options' : 'math_set_no_true_option');
    if (selectedOptionId && !agreesWithGenerator)
        reasonCodes.push('math_set_generator_disagreement');
    return {
        solverVersion: exports.SUBJECT_PRACTICE_MATH_SET_SOLVER_VERSION,
        status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_finite_set_operation',
        scopeId: parsed ? `math-basic-set-operation-v1:${scope}` : null,
        exactScope: scope,
        verificationScope: {
            scopeVersion: exports.SUBJECT_PRACTICE_MATH_SET_SCOPE_VERSION,
            scopeId: parsed ? `math-basic-set-operation-v1:${scope}` : null,
            matched: parsed,
            exactScope: scope,
            reasonCodes: parsed ? [] : ['math_set_verification_scope_not_matched']
        },
        optionVerdicts,
        trueOptionIds,
        selectedOptionId,
        uniqueAnswer: trueOptionIds.length === 1,
        agreesWithGenerator,
        expectedSet: target,
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes
    };
}
