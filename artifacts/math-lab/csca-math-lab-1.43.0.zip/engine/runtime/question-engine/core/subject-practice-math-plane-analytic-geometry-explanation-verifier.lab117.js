"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PLANE_ANALYTIC_GEOMETRY_EXPLANATION_VERSION = void 0;
exports.renderPlaneAnalyticGeometryExplanation = renderPlaneAnalyticGeometryExplanation;
exports.verifySubjectPracticeMathPlaneAnalyticGeometryExplanation = verifySubjectPracticeMathPlaneAnalyticGeometryExplanation;
const subject_practice_math_plane_analytic_geometry_solver_1 = require("./subject-practice-math-plane-analytic-geometry-solver.lab117.js");
exports.PLANE_ANALYTIC_GEOMETRY_EXPLANATION_VERSION = 'math-plane-analytic-geometry-explanation-v1-bound-bilingual';
function renderPlaneAnalyticGeometryExplanation(p, answer, option) {
    const derived = (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryDerive)(p);
    if (!derived)
        throw Error('invalid_geometry_explanation_parameters');
    const notes = {
        line_intersection_then_point_distance: ['联立方程确定唯一交点，再对两点的横纵坐标差使用距离公式。', 'Solve both equations for the unique intersection, then use both coordinate differences in the distance formula.'],
        parallel_lines_distance: [],
        circle_line_chord_length: ['配方确定圆心和半径，再求圆心到直线的距离，用勾股关系求半弦并乘以二。', 'Complete the squares to determine the center and radius, calculate the center-line distance, and double the half chord from Pythagoras.'],
        circle_tangent_at_point: ['先求圆心并核验点在圆上。半径向量是切线的法向量，代入切点确定常数项，兼容竖直切线。', 'Find the center and verify the point lies on the circle. The radius vector is a tangent normal; impose incidence at the point, including vertical tangents.']
    };
    if (p.scope === 'parallel_lines_distance') {
        const [distance, normalLength, c, g, lambda] = derived.values;
        const [a, b] = p.l1, [e, f] = p.l2, normalizedConstant = (0, subject_practice_math_plane_analytic_geometry_solver_1.geoText)((0, subject_practice_math_plane_analytic_geometry_solver_1.geoQ)(g, lambda));
        const normalRelation = '(' + e + ',' + f + ')=(' + lambda + ')*(' + a + ',' + b + ')';
        const normalizedLine = (0, subject_practice_math_plane_analytic_geometry_solver_1.geoLineText)([a, b, normalizedConstant]);
        const magnitude = 'sqrt((' + a + ')^2+(' + b + ')^2)=' + normalLength;
        const substitution = 'd=|' + normalizedConstant + '-(' + c + ')|/' + normalLength + '=' + distance + '>=0';
        notes.parallel_lines_distance = [
            '法向量满足 ' + normalRelation + '，lambda=' + lambda + '!=0，故两线平行。将 L2 的等式两边除以 (' + lambda + '): ' + normalizedLine + '，其 x、y 系数与 L1 一致。法向量长度为 ' + magnitude + '；距离代入式为 ' + substitution + '。',
            'The normals satisfy ' + normalRelation + '; lambda=' + lambda + '!=0 establishes parallelism. Dividing both sides of L2 by (' + lambda + '): ' + normalizedLine + ' matches the x and y coefficients of L1. The normal magnitude is ' + magnitude + '; substituting gives ' + substitution + '.'
        ];
    }
    return { zh: (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryPrompt)(p, 'zh') + ' ' + notes[p.scope][0] + ' ' + derived.proof + '; result=' + answer + '。对应选项 ' + option + '。',
        en: (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryPrompt)(p, 'en') + ' ' + notes[p.scope][1] + ' ' + derived.proof + '; result=' + answer + '. Option ' + option + '.' };
}
function verifySubjectPracticeMathPlaneAnalyticGeometryExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_plane_analytic_geometry_solver_1.solveSubjectPracticeMathPlaneAnalyticGeometry)(candidate, context), expected = solved.parameters && solved.expectedAnswer && solved.selectedOptionId ? renderPlaneAnalyticGeometryExplanation(solved.parameters, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh), enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('plane_geometry_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('plane_geometry_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('plane_geometry_explanation_en_mismatch');
    return { verifierVersion: exports.PLANE_ANALYTIC_GEOMETRY_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solved.scopeId, zhBound, enBound, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
