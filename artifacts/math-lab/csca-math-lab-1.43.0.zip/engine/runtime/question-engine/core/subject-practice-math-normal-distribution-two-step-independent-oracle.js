"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NORMAL_TWO_STEP_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathNormalTwoStepWithIndependentOracle = verifySubjectPracticeMathNormalTwoStepWithIndependentOracle;
// Independent grammar and probability-mass enumeration. No solver/generator helpers.
exports.NORMAL_TWO_STEP_ORACLE_VERSION = 'math-normal-distribution-two-step-oracle-v1-mass-enumeration';
const scopes = ['standardized_interval_from_cdf_values', 'symmetric_interval_from_one_tail_probability', 'empirical_asymmetric_interval_probability', 'empirical_tail_probability_to_threshold'];
function rational(n, d) {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || d <= 0)
        return null;
    let a = Math.abs(n), b = d;
    while (b) {
        const t = a % b;
        a = b;
        b = t;
    }
    return d / a === 1 ? String(n / a) : n / a + '/' + (d / a);
}
function option(t) { const m = typeof t === 'string' ? /^(-?)(\d{1,6})(?:\.(\d{1,4}))?$/.exec(t.trim()) : null; return m ? rational((m[1] ? -1 : 1) * (Number(m[2]) * 10 ** (m[3]?.length ?? 0) + Number(m[3] ?? 0)), 10 ** (m[3]?.length ?? 0)) : null; }
function parse(text, i, lang) {
    if (typeof text !== 'string' || text.length > 1600)
        return null;
    const zh = lang === 'zh', head = (zh ? /^X服从正态分布N\((-?\d+),(\d+)\)，第二参数为方差，记均值为mu、正标准差为sigma。/ : /^X has normal distribution N\((-?\d+),(\d+)\); the second parameter is the variance\. Write mu for its mean and sigma for its positive standard deviation\./).exec(text);
    if (!head)
        return null;
    const mu = Number(head[1]), variance = Number(head[2]);
    let s = text.slice(head[0].length);
    const empirical = zh ? '采用近似经验规律：P(|X-mu|<=sigma)约为0.68，P(|X-mu|<=2*sigma)约为0.95，P(|X-mu|<=3*sigma)约为0.997。' : 'Use the approximate empirical rule: P(|X-mu|<=sigma) is about 0.68, P(|X-mu|<=2*sigma) about 0.95, and P(|X-mu|<=3*sigma) about 0.997.';
    if (i === 2 || i === 3) {
        if (!s.startsWith(empirical))
            return null;
        s = s.slice(empirical.length);
    }
    let a = 0, b = 0, tail = 0, direction = 'left';
    if (i === 0) {
        const table = zh ? '给定标准正态累计概率近似值Phi(-2)=0.0228，Phi(-1)=0.1587，Phi(0)=0.5000，Phi(1)=0.8413，Phi(2)=0.9772。' : 'Given approximate standard normal cumulative values Phi(-2)=0.0228, Phi(-1)=0.1587, Phi(0)=0.5000, Phi(1)=0.8413, Phi(2)=0.9772. ';
        if (!s.startsWith(table))
            return null;
        s = s.slice(table.length);
    }
    if (i === 0 || i === 2) {
        const expressions = zh ? [/^先标准化端点，再用所给近似值求P\((-?\d+)<=X<=(-?\d+)\)。$/, /^先识别两个端点的标准差倍数，再分区求P\((-?\d+)<=X<=(-?\d+)\)的近似值。$/] : [/^Standardize the endpoints, then use the given approximations to find P\((-?\d+)<=X<=(-?\d+)\)\.$/, /^Identify the standard-deviation multiples of both endpoints, then partition the interval to approximate P\((-?\d+)<=X<=(-?\d+)\)\.$/];
        const m = expressions[i === 0 ? 0 : 1].exec(s);
        if (!m)
            return null;
        a = +m[1];
        b = +m[2];
    }
    else if (i === 1) {
        const m = (zh ? /^已知P\(X(<=|>=)(-?\d+)\)约为(0\.\d{4})。令y为(-?\d+)关于mu的对称点，先求y，再求X位于(-?\d+)与y之间的近似概率。$/ : /^Given P\(X(<=|>=)(-?\d+)\) is approximately (0\.\d{4})\. Let y be the reflection of (-?\d+) about mu\. Find y, then the approximate probability that X lies between (-?\d+) and y\.$/).exec(s);
        if (!m || m[2] !== m[4] || m[2] !== m[5])
            return null;
        a = +m[2];
        direction = m[1] === '<=' ? 'left' : 'right';
        tail = +m[3].slice(2);
    }
    else if (i === 3) {
        const m = (zh ? /^按该近似规律，P\(X(<=|>=)t\)约为(0\.\d{4})。先判断尾部对应的标准差倍数，再求近似阈值t。$/ : /^According to this approximate rule, P\(X(<=|>=)t\) is about (0\.\d{4})\. Infer the standard-deviation multiple from the tail, then find the approximate threshold t\.$/).exec(s);
        if (!m)
            return null;
        direction = m[1] === '<=' ? 'left' : 'right';
        tail = +m[2].slice(2);
    }
    else
        return null;
    return { mu, variance, a, b, tail, direction };
}
function enumerate(p, i) {
    if (p.mu < -20 || p.mu > 80)
        return null;
    const sigmas = Array.from({ length: 11 }, (_, n) => n + 2).filter(v => v * v === p.variance);
    if (sigmas.length !== 1)
        return null;
    const sigma = sigmas[0], coordinates = Array.from({ length: 7 }, (_, n) => ({ z: n - 3, x: p.mu + (n - 3) * sigma }));
    const za = coordinates.find(v => v.x === p.a)?.z, zb = coordinates.find(v => v.x === p.b)?.z;
    const cdfMass = [228, 1359, 3413, 3413, 1359, 228]; // tails and bands separated by -2,-1,0,1,2
    const empiricalMass = [15, 235, 1350, 3400, 3400, 1350, 235, 15]; // -infinity,-3,-2,-1,0,1,2,3,infinity
    const csum = (z) => cdfMass.slice(0, z + 3).reduce((a, b) => a + b, 0), esum = (z) => empiricalMass.slice(0, z + 4).reduce((a, b) => a + b, 0);
    let answer, errors, certificate, mode;
    if (i === 0 || i === 2) {
        if (za === undefined || zb === undefined)
            return null;
        const permitted = i === 0 ? ['-2,-1', '-2,1', '-1,2', '1,2'] : ['-3,-1', '-2,1', '-1,2', '1,3', '-3,2', '-2,3'];
        if (!permitted.includes(za + ',' + zb))
            return null;
        const mass = i === 0 ? cdfMass : empiricalMass, offset = i === 0 ? 3 : 4, segments = mass.slice(za + offset, zb + offset);
        answer = segments.reduce((a, b) => a + b, 0);
        const lower = (i === 0 ? csum : esum)(za), upper = (i === 0 ? csum : esum)(zb);
        errors = { omit_lower_cdf: upper, omit_upper_bound: 10000 - lower, use_complement: mass.reduce((a, b) => a + b, 0) - answer };
        certificate = { segments, coordinates: [p.a, p.b], standardCoordinates: [za, zb], massTotal: mass.reduce((a, b) => a + b, 0) };
        mode = i === 0 ? 'given_cdf_4dp_approximation' : 'empirical_68_95_997_approximation';
    }
    else if (i === 1) {
        if (za === undefined || ![1, 2].includes(Math.abs(za)) || p.direction !== (za < 0 ? 'left' : 'right'))
            return null;
        const q = csum(-Math.abs(za));
        if (p.tail !== q)
            return null;
        const reflected = coordinates.find(v => v.z === -za).x;
        if (Math.abs(reflected - p.mu) !== Math.abs(p.a - p.mu))
            return null;
        const regions = [q, 10000 - q - q, q];
        answer = regions[1];
        errors = { subtract_one_tail: regions[0] + regions[1], return_one_tail: regions[0], return_two_tails: regions[0] + regions[2] };
        certificate = { reflected, regions, massTotal: regions.reduce((a, b) => a + b, 0) };
        mode = 'given_cdf_4dp_approximation';
    }
    else {
        const matches = coordinates.filter(v => v.z !== 0 && Math.sign(v.z) === (p.direction === 'left' ? -1 : 1) && esum(-Math.abs(v.z)) === p.tail);
        if (matches.length !== 1)
            return null;
        const selected = matches[0], k = Math.abs(selected.z), sign = Math.sign(selected.z);
        answer = selected.x;
        // Derive the omitted-scale error from the independently enumerated signed coordinate.
        errors = { reverse_tail_direction: coordinates.find(v => v.z === -selected.z).x, use_variance_as_sigma: p.mu + sign * k * p.variance, omit_sigma_scale: p.mu + selected.z };
        certificate = { enumeratedThresholds: coordinates.filter(v => v.z !== 0), uniqueSolutionCount: 1, selected, massTotal: empiricalMass.reduce((a, b) => a + b, 0) };
        mode = 'empirical_68_95_997_approximate_threshold';
    }
    return { sigma, expected: rational(answer, i === 3 ? 1 : 10000), errors: Object.fromEntries(Object.entries(errors).map(([k, v]) => [k, rational(v, i === 3 ? 1 : 10000)])), mode, ...certificate };
}
function verifySubjectPracticeMathNormalTwoStepWithIndependentOracle(candidate, context = {}) {
    const p = context.questionPlan, r = p?.renderConstraints, s = p?.scenarioContract, scope = r?.exactNormalDistributionTwoStepScope, i = scopes.indexOf(scope), reasonCodes = [];
    const required = { topicCode: 'M-STAT-002', boundedIntegerParameters: true, meanMin: -20, meanMax: 80, sigmaMin: 2, sigmaMax: 12, secondNormalParameter: 'variance', minimumVisibleMoves: 2, probabilityMode: 'given_approximation_only', externalContextAllowed: false, requiresImage: false };
    const valid = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 77 && p?.targetDifficulty === 'medium' && p?.representationType === 'text' && p?.taskFamily === 'math_normal_distribution_two_step_reasoning' && p?.planTemplate === 'math_normal_distribution_two_step_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'normal_distribution_object' && s?.scenarioAction === scope && i >= 0;
    const parsed = valid ? parse(candidate.prompt, i, 'zh') : null, certificate = parsed ? enumerate(parsed, i) : null, expected = certificate?.expected ?? null;
    if (!certificate)
        reasonCodes.push('normal_two_step_oracle_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 77 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('normal_two_step_oracle_identity');
    const options = candidate.options ?? [], keys = options.map(o => option(o.text));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('normal_two_step_oracle_options');
    if (i !== 3 && options.some((o, j) => Number(o.text) < 0 || Number(o.text) > 1 || options.some((v, k) => j < k && Math.abs(Number(o.text) - Number(v.text)) <= 0.0002)))
        reasonCodes.push('normal_two_step_oracle_probability_precision');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parsed || JSON.stringify(parse(loc?.prompt ?? '', i, lang)) !== JSON.stringify(parsed))
            reasonCodes.push('normal_two_step_oracle_' + lang + '_stem');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, option(o.text)])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('normal_two_step_oracle_' + lang + '_options');
    }
    const optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : expected !== null && keys[j] === expected ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || candidate.correctAnswer !== selectedOptionId)
        reasonCodes.push('normal_two_step_oracle_answer');
    const meta = candidate.optionMetadata ?? [], errors = certificate?.errors ?? {};
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !Object.prototype.hasOwnProperty.call(errors, m.distractorIntent ?? '') || errors[m.distractorIntent ?? ''] !== keys[options.findIndex(o => o.id === m.optionId)]))
        reasonCodes.push('normal_two_step_oracle_error_intent');
    const scopeId = certificate ? 'math-medium-normal-distribution-two-step-v1:' + scope : null;
    return { oracleVersion: exports.NORMAL_TWO_STEP_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified', scopeId, scopeMatched: Boolean(certificate), selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, completeCertificate: Boolean(certificate && expected), certificate, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
