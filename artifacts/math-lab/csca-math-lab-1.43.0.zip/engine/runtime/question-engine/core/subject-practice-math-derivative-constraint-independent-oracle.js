"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DERIVATIVE_CONSTRAINT_ORACLE_VERSION = void 0;
exports.derivativeConstraintIndependentCalculation = derivativeConstraintIndependentCalculation;
exports.verifySubjectPracticeMathDerivativeConstraintWithIndependentOracle = verifySubjectPracticeMathDerivativeConstraintWithIndependentOracle;
// Intentionally independent: no Solver, generator, renderer or mathematical helper imports.
exports.DERIVATIVE_CONSTRAINT_ORACLE_VERSION = 'math-derivative-constraint-oracle-v1-complete-certificates';
const scopes = ['cubic_tangent_constraint_closed_interval_extremum', 'cubic_two_interval_monotonic_parameter_range', 'cubic_level_equation_closed_interval_root_count', 'cubic_extrema_gap_point_constraint_tangent_line'];
const object = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function fraction(a, b = 1n) { if (!b)
    throw Error('oracle_divisor'); if (b < 0n) {
    a = -a;
    b = -b;
} const gcd = (x, y) => y ? gcd(y, x % y) : x; const g = gcd(a < 0n ? -a : a, b); a /= g; b /= g; if (a > 10n ** 30n || a < -(10n ** 30n) || b > 10n ** 24n)
    throw Error('oracle_arithmetic_bound'); return [a, b]; }
const constant = (n) => fraction(BigInt(n)), add = (a, b) => fraction(a[0] * b[1] + b[0] * a[1], a[1] * b[1]), minus = (a) => fraction(-a[0], a[1]), subtract = (a, b) => add(a, minus(b)), times = (a, b) => fraction(a[0] * b[0], a[1] * b[1]), divide = (a, b) => fraction(a[0] * b[1], a[1] * b[0]);
const compare = (a, b) => a[0] * b[1] < b[0] * a[1] ? -1 : a[0] * b[1] > b[0] * a[1] ? 1 : 0, show = (a) => String(a[0]) + (a[1] === 1n ? '' : '/' + a[1]), square = (a) => times(a, a), cube = (a) => times(square(a), a), zero = constant(0);
function number(text) { if (typeof text !== 'string' || text.length > 32 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(text))
    throw Error('oracle_rational_syntax'); const z = text.split('/'); return fraction(BigInt(z[0]), BigInt(z[1] ?? '1')); }
function exactRoot(q, degree) { if (q[0] < 0n)
    throw Error('oracle_negative_root'); const find = (n) => { let hi = 1n; while (hi ** BigInt(degree) < n)
    hi *= 2n; let lo = 0n; while (lo <= hi) {
    const m = (lo + hi) / 2n, v = m ** BigInt(degree);
    if (v === n)
        return m;
    if (v < n)
        lo = m + 1n;
    else
        hi = m - 1n;
} throw Error('oracle_irrational_root'); }; return fraction(find(q[0]), find(q[1])); }
const bounded = (x) => x[0] >= -1000000n && x[0] <= 1000000n && x[1] <= 10000n, coord = (x) => bounded(x) && compare(x, constant(-8)) >= 0 && compare(x, constant(8)) <= 0;
const trim = (p) => { const a = p.slice(); while (a.length > 1 && !a[a.length - 1][0])
    a.pop(); return a; }, value = (p, x) => p.slice().reverse().reduce((a, c) => add(times(a, x), c), zero), derivative = (p) => trim(p.slice(1).map((a, j) => times(constant(j + 1), a)));
function dividePoly(a, b) { b = trim(b); if (b.length === 1 && !b[0][0])
    throw Error('oracle_zero_polynomial'); let r = trim(a), steps = 0; const q = Array.from({ length: Math.max(1, a.length - b.length + 1) }, () => zero); while (!(r.length === 1 && !r[0][0]) && r.length >= b.length) {
    if (++steps > 8)
        throw Error('oracle_polynomial_bound');
    const n = r.length - b.length, c = divide(r[r.length - 1], b[b.length - 1]);
    q[n] = add(q[n], c);
    for (let j = 0; j < b.length; j++)
        r[n + j] = subtract(r[n + j], times(c, b[j]));
    r = trim(r);
} return { q: trim(q), r }; }
function squareFree(p) { let a = trim(p), b = derivative(a), steps = 0; while (!(b.length === 1 && !b[0][0])) {
    if (++steps > 8)
        throw Error('oracle_gcd_bound');
    const r = dividePoly(a, b).r;
    a = b;
    b = r;
} const result = dividePoly(p, a); if (result.r.some(x => x[0]))
    throw Error('oracle_gcd_certificate'); return result.q; }
function sturmCount(p, l, u) { let sf = squareFree(p), endpoints = 0; for (const x of [l, u])
    if (!value(sf, x)[0]) {
        const d = dividePoly(sf, [minus(x), constant(1)]);
        if (d.r.some(z => z[0]))
            throw Error('oracle_endpoint_deflation');
        sf = d.q;
        endpoints++;
    } if (sf.length === 1)
    return { count: endpoints, chain: [sf.map(show)], endpoints }; const chain = [sf, derivative(sf)]; while (chain[chain.length - 1].length > 1) {
    const r = dividePoly(chain[chain.length - 2], chain[chain.length - 1]).r;
    if (r.length === 1 && !r[0][0])
        break;
    chain.push(r.map(minus));
    if (chain.length > 5)
        throw Error('oracle_sturm_bound');
} const variations = (x) => { const signs = chain.map(q => compare(value(q, x), zero)).filter(Boolean); return signs.slice(1).reduce((n, v, j) => n + (v !== signs[j] ? 1 : 0), 0); }; return { count: endpoints + variations(l) - variations(u), chain: chain.map(q => q.map(show)), endpoints }; }
function critical(c) { const A = c[3], B = c[2], C = c[1], center = divide(minus(B), times(constant(3), A)), radius = exactRoot(subtract(square(center), divide(C, times(constant(3), A))), 2); if (!radius[0])
    throw Error('oracle_repeated_critical'); const xs = [subtract(center, radius), add(center, radius)]; if (!xs.every(coord) || xs.some(x => value(derivative(c), x)[0]))
    throw Error('oracle_critical_certificate'); return xs; }
function extremum(c, l, u, mode) { const roots = critical(c); if (compare(l, u) >= 0 || !roots.some(x => compare(x, l) > 0 && compare(x, u) < 0))
    throw Error('oracle_domain'); const xs = [l, u, ...roots.filter(x => compare(x, l) >= 0 && compare(x, u) <= 0)], ys = xs.map(x => value(c, x)).sort(compare); return { answer: mode === 'maximum' ? ys[ys.length - 1] : ys[0], roots, points: xs.map(x => [show(x), show(value(c, x))]) }; }
function prompt(data, i, lang) {
    const d = data, zh = lang === 'zh';
    if (i === 0)
        return (zh ? '设三次函数 f(x)=A*x^3+B*x^2+C*x+D，其中 ' : 'Let f(x)=A*x^3+B*x^2+C*x+D, with ') + `A=(${d[0]}), B=(${d[1]}). ` + (zh ? '未知系数为 C,D；在 ' : 'C,D are unknown; at ') + `x=(${d[2]}), y=(${d[3]})*x+(${d[4]})` + (zh ? ' 是切线。求 ' : ' is the tangent. Find ') + `f(x), x in [${d[5]},${d[6]}]` + (zh ? ' 的' + (d[7] === 'maximum' ? '最大值' : '最小值') + '。' : ': the ' + d[7] + ' value.');
    if (i === 1)
        return (zh ? '实参数 p 的三次函数 ' : 'For real p, consider ') + `f_p(x)=A*((x-h)^3-3*p*(x-h))+d; A=(${d[0]}), h=(${d[1]}), d=(${d[2]}). I=[${d[3]},${d[4]}], J=[${d[5]},${d[6]}]. ` + (zh ? '当 A>0 时要求 I 上单调不减、J 上单调不增；A<0 时这两个方向互换。求 p 的全部取值范围。' : 'For A>0 require nondecreasing on I and nonincreasing on J; reverse both directions for A<0. Find all real p.');
    if (i === 2)
        return (zh ? '设三次函数 ' : 'Let ') + `f(x)=A*x^3+B*x^2+C*x+D; A=(${d[0]}), B=(${d[1]}), C=(${d[2]}), D=(${d[3]}). ` + (zh ? '求方程 ' : 'Count the distinct real roots of ') + `f(x)=(${d[4]}), x in [${d[5]},${d[6]}]` + (zh ? ' 在闭区间内的不同实根个数；重根只计一次。' : '; include endpoints and count each multiple root once.');
    return (zh ? '设 ' : 'Let ') + `f(x)=A*((x-h)^3-3*p*(x-h))+c; A=(${d[0]}), h=(${d[1]}), p>0. ` + (zh ? '未知量为 p,c。局部极大值减局部极小值为 ' : 'The unknowns are p,c. The local maximum minus local minimum is ') + `Delta=(${d[2]}); f((${d[3]}))=(${d[4]}). ` + (zh ? '求 ' : 'Find the tangent line at ') + `x=(${d[5]})` + (zh ? ' 处的切线方程。' : '.');
}
function parse(text, i, lang) { if (typeof text !== 'string' || text.length > 2400)
    throw Error('oracle_stem'); const data = [], pattern = /\(([-+]?\d+(?:\/[1-9]\d*)?)\)/g; let m; while ((m = pattern.exec(text)))
    data.push(m[1]); if (i < 3) {
    const re = /\[([-+]?\d+(?:\/[1-9]\d*)?),([-+]?\d+(?:\/[1-9]\d*)?)\]/g;
    while ((m = re.exec(text)))
        data.push(m[1], m[2]);
} if (i === 0)
    data.push(text.includes('最大值') || text.includes('maximum') ? 'maximum' : 'minimum'); if (data.length !== [8, 7, 7, 6][i] || prompt(data, i, lang) !== text)
    throw Error('oracle_stem_format'); return data; }
function option(text, i) { try {
    if (typeof text !== 'string' || text.length > 300)
        return null;
    if (i === 1) {
        const t = text.replace(/\s/g, ''), m = /^([[(])([-+]?\d+(?:\/[1-9]\d*)?),([-+]?\d+(?:\/[1-9]\d*)?)([\])])$/.exec(t);
        if (!m)
            return null;
        const a = number(m[2]), b = number(m[3]);
        return compare(a, b) > 0 || !compare(a, b) && (m[1] !== '[' || m[4] !== ']') ? null : m[1] + show(a) + ',' + show(b) + m[4];
    }
    if (i === 3) {
        const m = /^y=([-+]?\d+(?:\/[1-9]\d*)?)\*x\+\(([-+]?\d+(?:\/[1-9]\d*)?)\)$/.exec(text);
        return m ? 'y=' + show(number(m[1])) + '*x+(' + show(number(m[2])) + ')' : null;
    }
    const q = number(text);
    return i === 2 && (q[1] !== 1n || q[0] < 0n || q[0] > 6n) ? null : show(q);
}
catch {
    return null;
} }
function derivativeConstraintIndependentCalculation(data, i) {
    const v = data.slice(0, i === 0 ? 7 : undefined).map(number), A = v[0];
    if (v.length !== [7, 7, 7, 6][i] || !v.every(bounded) || A[1] !== 1n || !A[0] || A[0] < -4n || A[0] > 4n)
        throw Error('oracle_bounds');
    let answer, certificate;
    if (i === 0) {
        const [, B, t, m, n, l, u] = v;
        if (![t, l, u].every(coord) || !['maximum', 'minimum'].includes(data[7]))
            throw Error('oracle_coordinates');
        const rhsSlope = subtract(m, add(times(constant(3), times(A, square(t))), times(constant(2), times(B, t)))), rhsPoint = subtract(add(times(m, t), n), add(times(A, cube(t)), times(B, square(t)))), C = rhsSlope, D = subtract(rhsPoint, times(t, C)), c = [D, C, B, A];
        if (!c.every(bounded) || compare(value(derivative(c), t), m) || compare(value(c, t), add(times(m, t), n)))
            throw Error('oracle_tangent_system');
        const e = extremum(c, l, u, data[7]);
        answer = show(e.answer);
        certificate = { kind: 'linear_elimination_completed_square_all_extrema', coefficients: c.map(show), critical: e.roots.map(show), points: e.points };
    }
    else if (i === 1) {
        const [, h, , l, u, r, s] = v;
        if (![h, l, u, r, s].every(coord) || compare(l, u) >= 0 || compare(r, s) >= 0)
            throw Error('oracle_intervals');
        const distance = (x) => square(subtract(x, h)), projection = compare(h, l) < 0 ? l : compare(h, u) > 0 ? u : h, upper = distance(projection), lower = compare(distance(r), distance(s)) > 0 ? distance(r) : distance(s);
        if (compare(lower, zero) <= 0 || compare(lower, upper) >= 0)
            throw Error('oracle_degenerate_constraints');
        answer = '[' + show(lower) + ',' + show(upper) + ']';
        certificate = { kind: 'complete_square_bounds_on_two_closed_intervals', lower: show(lower), upper: show(upper), projection: show(projection), equalityIncluded: true, signOfA: compare(A, zero), outsideWitnesses: [show(subtract(lower, constant(1))), show(add(upper, constant(1)))] };
    }
    else if (i === 2) {
        const [, B, C, D, k, l, u] = v, c = [D, C, B, A], roots = critical(c);
        if (![l, u].every(coord) || compare(l, roots[0]) >= 0 || compare(roots[1], u) >= 0)
            throw Error('oracle_root_count_domain');
        const result = sturmCount([subtract(D, k), C, B, A], l, u);
        if (result.count < 0 || result.count > 3)
            throw Error('oracle_sturm_count');
        answer = String(result.count);
        certificate = { kind: 'square_free_sturm_complete_distinct_root_count', ...result };
    }
    else {
        const [, h, delta, s, y, t] = v;
        if (![h, s, t].every(coord) || compare(delta, zero) <= 0 || !compare(s, t))
            throw Error('oracle_gap_coordinates');
        const absA = fraction(A[0] < 0n ? -A[0] : A[0]), q = exactRoot(divide(delta, times(constant(4), absA)), 3), p = square(q);
        if (compare(q, zero) <= 0 || compare(q, constant(4)) > 0)
            throw Error('oracle_positive_parameter');
        const B = times(constant(-3), times(A, h)), C = times(constant(3), times(A, subtract(square(h), p))), withoutConstant = [zero, C, B, A], constantTerm = subtract(y, value(withoutConstant, s)), c = [constantTerm, C, B, A], localAt = [subtract(h, q), add(h, q)].map(x => value(c, x)).sort(compare);
        if (compare(subtract(localAt[1], localAt[0]), delta) || compare(value(c, s), y))
            throw Error('oracle_recovery_certificate');
        const m = value(derivative(c), t), b = subtract(value(c, t), times(m, t));
        if (!m[0] || ![m, b, ...c].every(bounded))
            throw Error('oracle_tangent_bounds');
        answer = 'y=' + show(m) + '*x+(' + show(b) + ')';
        certificate = { kind: 'unique_positive_cube_root_extrema_classification_and_tangent', sqrtParameter: show(q), parameter: show(p), coefficients: c.map(show), extrema: localAt.map(show), slope: show(m), intercept: show(b) };
    }
    return { answer, certificate };
}
function verifySubjectPracticeMathDerivativeConstraintWithIndependentOracle(candidate, context = {}) {
    const p = object(context.questionPlan), r = object(p?.renderConstraints), s = object(p?.scenarioContract), scope = String(r?.exactDerivativeConstraintScope ?? ''), i = scopes.indexOf(scope), required = { topicCode: 'M-CALC-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000, rationalDenominatorMax: 10000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false }, bound = i >= 0 && p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 71 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === 'math_derivative_constraint_reasoning' && p?.planTemplate === 'math_derivative_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'derivative_constraint_system' && s?.scenarioAction === scope, reasonCodes = [];
    let expectedAnswer = null, certificate = null, data = null;
    try {
        if (!bound)
            throw Error('oracle_exact_plan');
        data = parse(candidate.prompt, i, 'zh');
        const result = derivativeConstraintIndependentCalculation(data, i);
        expectedAnswer = result.answer;
        certificate = result.certificate;
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parse(candidate.localizations?.[lang]?.prompt ?? '', i, lang)) !== JSON.stringify(data))
                throw Error('oracle_translation_parameters');
    }
    catch (e) {
        reasonCodes.push(e instanceof Error ? e.message : 'oracle_unparsed');
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 71 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => option(o.text, i));
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(o => [o.id, option(o.text, i)])) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('oracle_' + lang + '_options');
    const trueOptionIds = opts.filter((_, j) => keys[j] !== null && keys[j] === expectedAnswer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('oracle_answer_disagreement');
    return { oracleVersion: exports.DERIVATIVE_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? (data ? 'disagreed' : 'unparsed') : 'verified', scopeMatched: bound && !!data, scopeId: bound && data ? 'math-hard-derivative-constraint-v1:' + scope : null, exactScope: scope, expectedAnswer, selectedOptionId, trueOptionIds, certificate, complete: !!certificate, completeCertificate: !!certificate, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
