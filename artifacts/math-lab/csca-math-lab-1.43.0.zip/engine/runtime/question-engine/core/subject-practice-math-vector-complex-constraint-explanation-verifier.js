"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VECTOR_COMPLEX_CONSTRAINT_EXPLANATION_VERSION = void 0;
exports.renderVectorComplexConstraintExplanation = renderVectorComplexConstraintExplanation;
exports.verifySubjectPracticeMathVectorComplexConstraintExplanation = verifySubjectPracticeMathVectorComplexConstraintExplanation;
const subject_practice_math_vector_complex_constraint_solver_1 = require("./subject-practice-math-vector-complex-constraint-solver");
exports.VECTOR_COMPLEX_CONSTRAINT_EXPLANATION_VERSION = 'math-vector-complex-constraint-explanation-v1-bound-bilingual';
function renderVectorComplexConstraintExplanation(p, answer, option) {
    const d = (0, subject_practice_math_vector_complex_constraint_solver_1.vectorComplexConstraintDerive)(p);
    if (!d || d.answer !== answer)
        throw Error('geometry_explanation_parameters');
    const i = subject_practice_math_vector_complex_constraint_solver_1.VECTOR_COMPLEX_CONSTRAINT_SCOPES.indexOf(p.scope);
    const zh = ["将三条模长和数量积关系展开为关于|u|平方、|v|平方及u·v的三个独立方程，求解后检查向量可实现性，再展开目标组合的模平方。", "设w=t+p，将夹角公式平方得到二次方程；逐根核对原数量积符号和端点开闭条件，确定唯一参数，再代入向量线性组合。", "设z=x+yi，两条模长方程相减得到一次方程，与实部关系联立求解，并回代两条原模长条件。分别计算商的分子与分母的模平方。", "将模及实部关系化为x、y的方程，列出两个完整候选并用虚部符号筛选。由单位模得到1/z为共轭，再展开三次项的实部。"];
    const en = ["Expand the three independent norm and dot-product relations into equations in |u| squared, |v| squared and u dot v. Solve and check realizability, then expand the target norm squared.", "Set w=t+p and square the angle equation. Check every root against the original dot-product sign and the precise interval endpoints before substituting into the vector combination.", "Write z=x+yi. Subtract the modulus equations and combine with the real-part equation. Check both original modulus conditions, then compute the numerator and denominator moduli squared.", "Solve the unit-modulus and real-part equations completely and select by the imaginary sign. Use the conjugate for 1/z and expand the real part of the cube."];
    return { zh: zh[i] + ' 本题给定参数依次为(' + p.data.join(',') + ')，逐步代入：' + d.steps.join('；') + '。故所求值为 ' + answer + '，选' + option + '。', en: en[i] + ' Given values in this problem are (' + p.data.join(',') + '). Explicit substitutions: ' + d.steps.join('; ') + '. The requested value is ' + answer + '; choose ' + option + '.' };
}
function verifySubjectPracticeMathVectorComplexConstraintExplanation(candidate, context = {}) { const s = (0, subject_practice_math_vector_complex_constraint_solver_1.solveSubjectPracticeMathVectorComplexConstraint)(candidate, context), e = s.status === 'verified' && s.parameters && s.expectedAnswer && s.selectedOptionId ? renderVectorComplexConstraintExplanation(s.parameters, s.expectedAnswer, s.selectedOptionId) : null, zhBound = !!e && candidate.explanation === e.zh && candidate.localizations?.zh?.explanation === e.zh, enBound = !!e && candidate.localizations?.en?.explanation === e.en, reasonCodes = zhBound && enBound ? [] : ['vector_complex_constraint_explanation_not_bound']; return { verifierVersion: exports.VECTOR_COMPLEX_CONSTRAINT_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: s.scopeId, zhBound, enBound, hardEvidence: s.hardEvidence, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' }; }
