"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticePhysicsNewtonForceWithIndependentOracle = verifySubjectPracticePhysicsNewtonForceWithIndependentOracle;
exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_INDEPENDENT_ORACLE_VERSION = 'physics-newton-basic-force-independent-oracle-v1-dimensional-reconstruction';
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/²/g, '^2').replace(/\s+/g, ' ').trim(); }
function scope(context) { const p = object(context.questionPlan), r = object(p?.renderConstraints), s = clean(r?.exactPhysicsNewtonForceScope); return clean(p?.taskFamily) === 'physics_newton_basic_force_calculation' && clean(p?.planTemplate) === 'physics_newton_basic_force_calculation_v1' && ['net_force_from_mass_acceleration', 'acceleration_from_net_force_mass', 'horizontal_opposed_forces_acceleration', 'single_axis_equilibrium_unknown_force'].includes(s) ? s : null; }
function n(t, label) { const m = clean(t).match(new RegExp(`${label}\\s*=\\s*([+-]?\\d+(?:\\.\\d+)?)`, 'i')); return m ? Number(m[1]) : null; }
function reconstruct(prompt, s) { if (!s)
    return null; const t = clean(prompt); if (s === 'net_force_from_mass_acceleration') {
    const m = n(t, 'm'), a = n(t, 'a');
    return m !== null && m > 0 && a !== null ? { parameters: { massKg: m, accelerationMps2: a }, dimension: 'force', value: Array.from({ length: Math.abs(Math.trunc(a)) }, () => m).reduce((x, y) => x + y, 0) * Math.sign(a) } : null;
} if (s === 'acceleration_from_net_force_mass') {
    const f = n(t, 'F_?net'), m = n(t, 'm');
    return f !== null && m !== null && m > 0 ? { parameters: { netForceN: f, massKg: m }, dimension: 'acceleration', value: f / m } : null;
} if (s === 'horizontal_opposed_forces_acceleration') {
    const right = n(t, 'F_?right'), left = n(t, 'F_?left'), m = n(t, 'm');
    return right !== null && left !== null && m !== null && m > 0 ? { parameters: { rightForceN: right, leftForceN: left, massKg: m }, dimension: 'acceleration', value: (right + (-left)) / m } : null;
} const known = n(t, 'F_?known'); return known !== null && known > 0 ? { parameters: { knownForceN: known }, dimension: 'force', value: known } : null; }
function value(text, dimension) { const m = clean(text).match(/^([+-]?\d+(?:\.\d+)?)\s*(N|m\s*\/\s*s\^?2)$/i); if (!m)
    return null; return (/^n$/i.test(m[2]) ? 'force' : 'acceleration') === dimension ? Number(m[1]) : null; }
function same(a, b) { return Math.abs(a - b) <= Math.max(1e-9, Math.abs(b) * 1e-9); }
function verifySubjectPracticePhysicsNewtonForceWithIndependentOracle(candidate, context = {}) { const exactScope = scope(context), reconstructed = reconstruct(candidate.prompt, exactScope), optionVerdicts = (candidate.options ?? []).map(o => { const parsed = reconstructed ? value(o.text, reconstructed.dimension) : null; return { optionId: o.id, verdict: parsed === null ? 'unknown' : same(parsed, reconstructed.value) ? 'true' : 'false' }; }); const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null, reasonCodes = []; if (!reconstructed)
    reasonCodes.push('physics_newton_force_oracle_prompt_or_plan_unparsed'); if (optionVerdicts.some(x => x.verdict === 'unknown'))
    reasonCodes.push('physics_newton_force_oracle_option_or_unit_unparsed'); if (trueOptionIds.length !== 1)
    reasonCodes.push('physics_newton_force_oracle_answer_not_unique'); if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('physics_newton_force_oracle_generator_disagreement'); const scopeId = reconstructed ? `physics-basic-newton-force-v1:${exactScope}` : null; return { oracleVersion: exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_INDEPENDENT_ORACLE_VERSION, status: reasonCodes.length ? (reconstructed ? 'disagreed' : 'abstained') : 'verified', scopeId, exactScope, parameters: reconstructed?.parameters ?? null, expectedDimension: reconstructed?.dimension ?? null, expectedSiValue: reconstructed?.value ?? null, scopeMatched: Boolean(reconstructed), optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
