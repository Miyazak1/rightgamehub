"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathSolidGeometryExplanation = verifySubjectPracticeMathSolidGeometryExplanation;
const subject_practice_math_solid_geometry_solver_1 = require("./subject-practice-math-solid-geometry-solver");
exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_EXPLANATION_VERIFIER_VERSION = 'math-solid-geometry-explanation-verifier-v1-bilingual-equations';
function verifySubjectPracticeMathSolidGeometryExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_solid_geometry_solver_1.solveSubjectPracticeMathSolidGeometry)(candidate, context), p = solver.parameters, v = solver.expectedValue;
    let equation = '', zhPrefix = '', enPrefix = '';
    if (p && v) {
        if ('r' in p) {
            equation = `V=πr^2h=π×${p.r}^2×${p.h}=${v.coefficient}π cm^3`;
            zhPrefix = '圆柱体积等于底面积乘高：';
            enPrefix = 'Cylinder volume is base area times height: ';
        }
        else if (solver.exactScope === 'cuboid_surface_area') {
            equation = `S=2(ab+ac+bc)=2×(${p.a}×${p.b}+${p.a}×${p.c}+${p.b}×${p.c})=${v.coefficient} cm^2`;
            zhPrefix = '长方体的三对相对面面积相等：';
            enPrefix = 'A cuboid has three pairs of equal opposite faces: ';
        }
        else if (solver.exactScope === 'cuboid_space_diagonal') {
            equation = `d=sqrt(a^2+b^2+c^2)=sqrt(${p.a}^2+${p.b}^2+${p.c}^2)=${v.coefficient} cm`;
            zhPrefix = '连续应用两次勾股定理：';
            enPrefix = 'Apply the Pythagorean theorem twice: ';
        }
        else {
            equation = `V=abc=${p.a}×${p.b}×${p.c}=${v.coefficient} cm^3`;
            zhPrefix = '长方体体积等于三条相邻棱长的乘积：';
            enPrefix = 'Cuboid volume is the product of three adjacent edge lengths: ';
        }
    }
    // Exact bounded explanations reject contradictory extra claims, not only missing numbers.
    const zhBound = Boolean(equation) && candidate.explanation === `${zhPrefix}${equation}。`
        && candidate.localizations?.zh?.explanation === candidate.explanation;
    const enBound = Boolean(equation) && candidate.localizations?.en?.explanation === `${enPrefix}${equation}.`;
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_solid_geometry_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('math_solid_geometry_explanation_zh_equation_not_bound');
    if (!enBound)
        reasonCodes.push('math_solid_geometry_explanation_en_equation_not_bound');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified',
        scopeId: solver.scopeId, zhBound, enBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
