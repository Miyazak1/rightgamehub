"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_SOLVER_VERSION = void 0;
exports.parseMathSequenceTwoConditionPrompt = parseMathSequenceTwoConditionPrompt;
exports.evaluateMathSequenceTwoCondition = evaluateMathSequenceTwoCondition;
exports.solveSubjectPracticeMathSequenceTwoCondition = solveSubjectPracticeMathSequenceTwoCondition;
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_SOLVER_VERSION = 'math-sequence-two-condition-solver-v1-algebraic-elimination';
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_SCOPE_VERSION = 'math-sequence-two-condition-scope-v1';
const SCOPES = new Set([
    'arithmetic_two_terms_target_term',
    'arithmetic_term_and_sum_target_term',
    'geometric_two_terms_target_term',
    'geometric_term_and_sum_target_term'
]);
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function clean(value) {
    return String(value ?? '').replace(/[−–—]/g, '-').replace(/[，]/g, ',').replace(/\s+/g, ' ').trim();
}
function scopeFrom(context) {
    const plan = record(context.questionPlan);
    const render = record(plan?.renderConstraints);
    const scope = clean(render?.exactSequenceTwoConditionScope);
    return clean(plan?.taskFamily) === 'math_sequence_two_condition_calculation'
        && clean(plan?.planTemplate) === 'math_sequence_two_condition_calculation_v1'
        && SCOPES.has(scope) ? scope : null;
}
function assignments(text, symbol) {
    const pattern = symbol === 'a' ? /a_?(\d+)\s*=\s*(-?\d+)/gi : /S_?(\d+)\s*=\s*(-?\d+)/gi;
    return [...clean(text).matchAll(pattern)].map((match) => ({ index: Number(match[1]), value: Number(match[2]) }));
}
function targetIndex(text) {
    const zh = clean(text).match(/求\s*a_?(\d+)/i);
    const en = clean(text).match(/find\s+(?:the\s+term\s+)?a_?(\d+)/i);
    return Number(zh?.[1] ?? en?.[1] ?? NaN);
}
function arithmeticSum(a1, d, n) { return n * (2 * a1 + (n - 1) * d) / 2; }
function geometricSum(a1, q, n) { return a1 * ((q ** n) - 1) / (q - 1); }
function parseMathSequenceTwoConditionPrompt(prompt, scope) {
    if (!scope)
        return null;
    const terms = assignments(prompt, 'a');
    const sums = assignments(prompt, 'S');
    const target = targetIndex(prompt);
    if (!Number.isInteger(target) || target < 2 || target > 10)
        return null;
    let a1 = null;
    let d = null;
    let q = null;
    if (scope === 'arithmetic_two_terms_target_term' && terms.length === 2) {
        const [left, right] = terms;
        const denominator = right.index - left.index;
        if (!denominator)
            return null;
        d = (right.value - left.value) / denominator;
        a1 = left.value - (left.index - 1) * d;
    }
    else if (scope === 'arithmetic_term_and_sum_target_term' && terms.length === 1 && sums.length === 1) {
        const term = terms[0];
        const sum = sums[0];
        const denominator = sum.index * (sum.index - 2 * term.index + 1);
        if (!denominator)
            return null;
        d = (2 * sum.value - 2 * sum.index * term.value) / denominator;
        a1 = term.value - (term.index - 1) * d;
    }
    else if (scope === 'geometric_two_terms_target_term' && terms.length === 2) {
        const [left, right] = terms;
        if (right.index !== left.index + 1 || left.value === 0 || right.value % left.value !== 0)
            return null;
        q = right.value / left.value;
        a1 = left.value / (q ** (left.index - 1));
    }
    else if (scope === 'geometric_term_and_sum_target_term' && terms.length === 1 && sums.length === 1) {
        const term = terms[0];
        const sum = sums[0];
        if (term.index !== 2 || sum.index !== 3 || term.value === 0)
            return null;
        const b = term.value;
        const discriminant = (b - sum.value) ** 2 - 4 * b * b;
        if (discriminant < 0 || !Number.isInteger(Math.sqrt(discriminant)))
            return null;
        const roots = [(-(b - sum.value) + Math.sqrt(discriminant)) / (2 * b), (-(b - sum.value) - Math.sqrt(discriminant)) / (2 * b)]
            .filter((value) => Number.isInteger(value) && ![-1, 0, 1].includes(value));
        if (new Set(roots).size !== 1)
            return null;
        q = roots[0];
        a1 = b / q;
    }
    else
        return null;
    if (!Number.isSafeInteger(a1) || a1 === 0)
        return null;
    if (scope.startsWith('arithmetic_') && (!Number.isSafeInteger(d) || d === 0))
        return null;
    if (scope.startsWith('geometric_') && (!Number.isSafeInteger(q) || [-1, 0, 1].includes(Number(q))))
        return null;
    const expectedValue = scope.startsWith('arithmetic_')
        ? Number(a1) + (target - 1) * Number(d)
        : Number(a1) * (Number(q) ** (target - 1));
    if (!Number.isSafeInteger(expectedValue))
        return null;
    return { scope, terms, sums, targetIndex: target, a1: Number(a1), d, q, expectedValue };
}
function evaluateMathSequenceTwoCondition(input) {
    const termValues = input.termIndices.map((index) => ({
        index,
        value: input.scope.startsWith('arithmetic_')
            ? input.a1 + (index - 1) * Number(input.d)
            : input.a1 * (Number(input.q) ** (index - 1))
    }));
    const sum = input.sumIndex
        ? { index: input.sumIndex, value: input.scope.startsWith('arithmetic_')
                ? arithmeticSum(input.a1, Number(input.d), input.sumIndex)
                : geometricSum(input.a1, Number(input.q), input.sumIndex) }
        : null;
    const expectedValue = input.scope.startsWith('arithmetic_')
        ? input.a1 + (input.targetIndex - 1) * Number(input.d)
        : input.a1 * (Number(input.q) ** (input.targetIndex - 1));
    return { termValues, sum, expectedValue };
}
function parseOption(text) { const value = Number(clean(text)); return Number.isSafeInteger(value) ? value : null; }
function solveSubjectPracticeMathSequenceTwoCondition(candidate, context = {}) {
    const exactScope = scopeFrom(context);
    const parameters = parseMathSequenceTwoConditionPrompt(candidate.prompt, exactScope);
    const expectedValue = parameters?.expectedValue ?? null;
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const value = parseOption(option.text);
        return { optionId: option.id, verdict: value === null ? 'unknown' : value === expectedValue ? 'true' : 'false', semanticValue: value };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!exactScope)
        reasonCodes.push('math_sequence_two_condition_scope_plan_contract_missing');
    if (!parameters)
        reasonCodes.push('math_sequence_two_condition_prompt_unparsed_or_non_unique');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_sequence_two_condition_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length ? 'math_sequence_two_condition_multiple_true_options' : 'math_sequence_two_condition_no_true_option');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_sequence_two_condition_generator_disagreement');
    const scopeId = parameters ? `math-medium-sequence-two-condition-v1:${exactScope}` : null;
    return {
        solverVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_SOLVER_VERSION,
        status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_sequence_two_condition_calculation',
        scopeId, exactScope, parameters, expectedValue,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope, reasonCodes: parameters ? [] : ['math_sequence_two_condition_verification_scope_not_matched'] },
        optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1,
        agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
