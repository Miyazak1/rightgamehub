"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VECTOR_COMPLEX_CONSTRAINT_ORACLE_VERSION = void 0;
exports.vectorComplexConstraintIndependentCalculation = vectorComplexConstraintIndependentCalculation;
exports.verifySubjectPracticeMathVectorComplexConstraintWithIndependentOracle = verifySubjectPracticeMathVectorComplexConstraintWithIndependentOracle;
// Independent visible-text parser and arithmetic; no runtime dependency on the Solver or generator.
exports.VECTOR_COMPLEX_CONSTRAINT_ORACLE_VERSION = 'math-vector-complex-constraint-oracle-v1-independent-real-branch-certificates';
const scopes = ["vector_gram_constraints_linear_combination_norm_squared", "vector_angle_interval_parameter_combination_norm_squared", "complex_two_moduli_real_constraint_quotient_norm_squared", "complex_unit_modulus_real_constraint_cubic_reciprocal_real_part"];
const abs = (n) => n < 0n ? -n : n;
class R {
    n;
    d;
    constructor(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || abs(a).toString(2).length > 512 || abs(b).toString(2).length > 512)
        throw Error('oracle_arithmetic_bound'); if (b < 0n) {
        a = -a;
        b = -b;
    } let x = abs(a), y = b; while (y) {
        const t = x % y;
        x = y;
        y = t;
    } this.n = a / x; this.d = b / x; }
    add(q) { return new R(this.n * q.d + q.n * this.d, this.d * q.d); }
    neg() { return new R(-this.n, this.d); }
    sub(q) { return this.add(q.neg()); }
    mul(q) { return new R(this.n * q.n, this.d * q.d); }
    div(q) { return new R(this.n * q.d, this.d * q.n); }
    sq() { return this.mul(this); }
    eq(q) { return this.n === q.n && this.d === q.d; }
    cmp(q) { const n = this.n * q.d - q.n * this.d; return n < 0n ? -1 : n > 0n ? 1 : 0; }
    toString() { return String(this.n) + (this.d === 1n ? '' : '/' + this.d); }
}
const z = new R(0), one = new R(1), two = new R(2), four = new R(4);
function read(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('oracle_rational_syntax'); const [a, b = '1'] = s.split('/'), q = new R(BigInt(a), BigInt(b)); if (abs(q.n) > 1000000000000n || q.d > 1000000000n)
    throw Error('oracle_input_bound'); return q; }
const object = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
const names = [['P', 'Q', 'R', 'a', 'b'], ['p', 'q', 'r', 's', 'c', 'L', 'H', 'lc', 'hc', 'a', 'b'], ['Ar', 'Ai', 'Br', 'Bi', 'R', 'S', 'm', 'n', 'h', 'Cr', 'Ci', 'Dr', 'Di'], ['a', 'b', 'c', 'sign', 'k']];
const startsZh = ['不共线的平面向量u、v满足 |u+v|^2=P，|2u-v|^2=Q，(u+2v)·(2u-v)=R。已知 ', '平面向量u=(t+p,q)、v=(r,s)的夹角余弦为c，实数t在区间L至H内；lc、hc分别取1表示包含对应端点，取0表示不含。已知 ', '复数z满足 |z-(Ar+Ai*i)|^2=R，|z-(Br+Bi*i)|^2=S，Re((m+n*i)z)=h，其中i^2=-1。已知 ', '复数z满足 |z|=1，Re((a+b*i)z)=c，sign*Im(z)>0，其中i^2=-1。已知 '];
const startsEn = ['Noncollinear plane vectors u,v satisfy |u+v|^2=P, |2u-v|^2=Q and (u+2v) dot (2u-v)=R. Given ', 'Plane vectors u=(t+p,q), v=(r,s) have angle cosine c. The real parameter t lies between L and H; lc,hc equal 1 for an included endpoint and 0 for an excluded endpoint. Given ', 'A complex number z satisfies |z-(Ar+Ai*i)|^2=R, |z-(Br+Bi*i)|^2=S and Re((m+n*i)z)=h, where i^2=-1. Given ', 'A complex number z satisfies |z|=1, Re((a+b*i)z)=c and sign*Im(z)>0, where i^2=-1. Given '];
const endsZh = ['求 |a*u+b*v|^2。', '先确定t，再求 |a*u+b*v|^2。', '求 |(z-(Cr+Ci*i))/(z-(Dr+Di*i))|^2，分母不得为零。', '求 Re(z^3+k/z)。'];
const endsEn = ['Find |a*u+b*v|^2.', 'Determine t and find |a*u+b*v|^2.', 'Find |(z-(Cr+Ci*i))/(z-(Dr+Di*i))|^2; the denominator must be nonzero.', 'Find Re(z^3+k/z).'];
const starts = { zh: startsZh, en: startsEn }, ends = { zh: endsZh, en: endsEn };
function parse(text, i, lang) { if (i < 0 || typeof text !== 'string' || text.length > 3000 || !text.startsWith(starts[lang][i]) || !text.endsWith('. ' + ends[lang][i]))
    throw Error('oracle_stem'); const middle = text.slice(starts[lang][i].length, -('. ' + ends[lang][i]).length), parts = middle.split(', '); if (parts.length !== names[i].length)
    throw Error('oracle_givens'); return parts.map((part, j) => { const m = part.match(/^([A-Za-z0-9]+)=\(([-+]?\d+(?:\/[1-9]\d*)?)\)$/); if (!m || m[1] !== names[i][j])
    throw Error('oracle_parameter_label'); read(m[2]); return m[2]; }); }
function eliminate(rows) { const a = rows.map(r => r.slice()), n = a.length; if (a.some(r => r.length !== n + 1))
    throw Error('oracle_linear_dimension'); const pivots = []; for (let c = 0; c < n; c++) {
    const pivot = a.findIndex((r, j) => j >= c && r[c].n !== 0n);
    if (pivot < 0)
        throw Error('oracle_singular_equations');
    [a[c], a[pivot]] = [a[pivot], a[c]];
    const d = a[c][c];
    pivots.push(String(d));
    a[c] = a[c].map(v => v.div(d));
    for (let j = 0; j < n; j++)
        if (j !== c) {
            const factor = a[j][c];
            a[j] = a[j].map((v, k) => v.sub(factor.mul(a[c][k])));
        }
} const solution = a.map(r => r[n]); for (const r of rows)
    if (!r.slice(0, n).reduce((s, v, j) => s.add(v.mul(solution[j])), z).eq(r[n]))
        throw Error('oracle_linear_round_trip'); return { solution, pivots }; }
function sqrt(q) { if (q.n < 0n)
    throw Error('oracle_negative_discriminant'); function root(x) { let low = 0n, high = x + 1n; while (high - low > 1n) {
    const mid = (low + high) / 2n;
    if (mid * mid <= x)
        low = mid;
    else
        high = mid;
} if (low * low !== x)
    throw Error('oracle_nonrational_construction'); return low; } return new R(root(q.n), root(q.d)); }
function roots(A, B, C) { if (!A.n) {
    if (!B.n)
        throw Error('oracle_degenerate_polynomial');
    return [C.neg().div(B)];
} const d = B.sq().sub(four.mul(A).mul(C)); if (d.n < 0n)
    return []; const s = sqrt(d), u = B.neg().sub(s).div(two.mul(A)), v = B.neg().add(s).div(two.mul(A)); return u.eq(v) ? [u] : [u, v]; }
const mul = (u, v) => [u[0].mul(v[0]).sub(u[1].mul(v[1])), u[0].mul(v[1]).add(u[1].mul(v[0]))];
const norm = (u) => u[0].sq().add(u[1].sq());
const div = (u, v) => { const d = norm(v); if (!d.n)
    throw Error('oracle_zero_complex_divisor'); const p = mul(u, [v[0], v[1].neg()]); return [p[0].div(d), p[1].div(d)]; };
const textPair = (u) => u.map(String);
function vectorComplexConstraintIndependentCalculation(data, i) {
    if (i < 0 || i > 3 || data.length !== names[i].length)
        throw Error('oracle_parameters');
    const v = data.map(read);
    let answer, certificate;
    if (i === 0) {
        const [P, Q, R0, a, b] = v;
        if (!a.n || !b.n)
            throw Error('oracle_target_coefficients');
        const base = [[1, 1, 2], [4, 1, -4], [2, -2, 3]].map(r => r.map(x => new R(x))), e = eliminate(base.map((r, j) => [...r, [P, Q, R0][j]])), [X, Y, Z] = e.solution;
        if (X.n <= 0n || Y.n <= 0n || X.mul(Y).sub(Z.sq()).n <= 0n)
            throw Error('oracle_impossible_gram');
        const weights = eliminate([0, 1, 2].map(j => [...base.map(r => r[j]), [a.sq(), b.sq(), two.mul(a).mul(b)][j]])).solution;
        if (weights.some(w => !w.n))
            throw Error('oracle_ineffective_condition');
        answer = weights.reduce((sum, w, j) => sum.add(w.mul([P, Q, R0][j])), z);
        if (answer.n <= 0n)
            throw Error('oracle_invalid_norm');
        certificate = { method: 'independent_gauss_jordan_and_dual_weights', gram: e.solution.map(String), pivots: e.pivots, targetWeights: weights.map(String), positiveGramDeterminant: String(X.mul(Y).sub(Z.sq())), complete: true };
    }
    else if (i === 1) {
        const [p, q, r, s, c, L, H, lc, hc, a, b] = v, K = r.sq().add(s.sq());
        if (!q.n || !K.n || c.n <= 0n || c.cmp(one) >= 0 || L.cmp(H) >= 0 || !['0', '1'].includes(String(lc)) || !['0', '1'].includes(String(hc)) || !a.n || !b.n)
            throw Error('oracle_angle_givens');
        const ratio = sqrt(one.sub(c.sq())).div(c), solutions = [];
        for (const sign of [one, one.neg()]) {
            const w = sign.mul(ratio), y = s.add(w.mul(r));
            if (!y.n)
                continue;
            const lambda = q.div(y);
            if (lambda.n <= 0n)
                continue;
            const x = lambda.mul(r.sub(w.mul(s))), t = x.sub(p), dot = x.mul(r).add(q.mul(s));
            if (dot.n <= 0n || !dot.sq().eq(c.sq().mul(K).mul(x.sq().add(q.sq()))))
                throw Error('oracle_angle_round_trip');
            solutions.push([t, x]);
        }
        solutions.sort((a0, b0) => a0[0].cmp(b0[0]));
        if (solutions.length !== 2 || solutions[0][0].eq(solutions[1][0]))
            throw Error('oracle_angle_incomplete_or_weak');
        const selected = solutions.filter(([t]) => (t.cmp(L) > 0 || lc.n === 1n && t.eq(L)) && (t.cmp(H) < 0 || hc.n === 1n && t.eq(H)));
        if (selected.length !== 1)
            throw Error('oracle_interval_nonunique');
        const target = (x) => norm([a.mul(x).add(b.mul(r)), a.mul(q).add(b.mul(s))]);
        answer = target(selected[0][1]);
        if (answer.n <= 0n || target(solutions[0][1]).eq(target(solutions[1][1])))
            throw Error('oracle_interval_ineffective');
        certificate = { method: 'two_oriented_directions_lambda_positive', ratio: String(ratio), allRealSolutions: solutions.map(textPair), selectedParameter: String(selected[0][0]), noOtherDirections: true, complete: true };
    }
    else if (i === 2) {
        const [Ar, Ai, Br, Bi, R0, S, m, n, h, Cr, Ci, Dr, Di] = v, dx = Br.sub(Ar), dy = Bi.sub(Ai), d2 = dx.sq().add(dy.sq());
        if (!d2.n || R0.n <= 0n || S.n <= 0n || !m.n || !n.n)
            throw Error('oracle_moduli_givens');
        const alpha = R0.sub(S).add(d2).div(two.mul(d2)), beta2 = R0.div(d2).sub(alpha.sq());
        if (beta2.n <= 0n)
            throw Error('oracle_moduli_intersection');
        const beta = sqrt(beta2), points = [one, one.neg()].map(sign => [Ar.add(alpha.mul(dx)).sub(sign.mul(beta).mul(dy)), Ai.add(alpha.mul(dy)).add(sign.mul(beta).mul(dx))]);
        for (const pt of points)
            if (!norm([pt[0].sub(Ar), pt[1].sub(Ai)]).eq(R0) || !norm([pt[0].sub(Br), pt[1].sub(Bi)]).eq(S))
                throw Error('oracle_modulus_round_trip');
        const selected = points.filter(pt => m.mul(pt[0]).sub(n.mul(pt[1])).eq(h));
        if (selected.length !== 1)
            throw Error('oracle_real_selector');
        const pt = selected[0], quotient = div([pt[0].sub(Cr), pt[1].sub(Ci)], [pt[0].sub(Dr), pt[1].sub(Di)]);
        answer = norm(quotient);
        if (answer.n <= 0n)
            throw Error('oracle_zero_target');
        certificate = { method: 'independent_two_modulus_orthogonal_parameterization', alpha: String(alpha), betaSquared: String(beta2), allTwoModulusSolutions: points.map(textPair), selectedComplex: textPair(pt), complexQuotient: textPair(quotient), complete: true };
    }
    else {
        const [a, b, c, sign, k] = v;
        if (!a.n || !b.n || !k.n || !['1', '-1'].includes(String(sign)))
            throw Error('oracle_unit_givens');
        const ws = roots(a.add(c), two.mul(b), c.sub(a)), points = ws.map(w => [one.sub(w.sq()).div(one.add(w.sq())), two.mul(w).div(one.add(w.sq()))]);
        if (a.neg().eq(c))
            points.push([one.neg(), z]);
        if (points.length !== 2 || points[0][1].n * points[1][1].n >= 0n)
            throw Error('oracle_complete_opposite_halfplanes');
        for (const pt of points)
            if (!norm(pt).eq(one) || !a.mul(pt[0]).sub(b.mul(pt[1])).eq(c))
                throw Error('oracle_unit_round_trip');
        const selected = points.filter(pt => pt[1].n * sign.n > 0n);
        if (selected.length !== 1)
            throw Error('oracle_sign_nonunique');
        const evaluate = (pt) => { const cube = mul(mul(pt, pt), pt), inverse = div([one, z], pt); return cube[0].add(k.mul(inverse[0])); };
        answer = evaluate(selected[0]);
        if (evaluate(points[0]).eq(evaluate(points[1])))
            throw Error('oracle_sign_ineffective');
        certificate = { method: 'rational_unit_circle_parameterization_and_complex_multiplication', parameterRoots: ws.map(String), omittedPointChecked: true, allComplexSolutions: points.map(textPair), selectedComplex: textPair(selected[0]), cube: textPair(mul(mul(selected[0], selected[0]), selected[0])), inverse: textPair(div([one, z], selected[0])), complete: true };
    }
    read(String(answer));
    return { answer: String(answer), certificate };
}
function option(text) { try {
    return String(read(text.trim()));
}
catch {
    return null;
} }
function verifySubjectPracticeMathVectorComplexConstraintWithIndependentOracle(candidate, context = {}) {
    const p = object(context.questionPlan), r = object(p?.renderConstraints), s = object(p?.scenarioContract), scope = String(r?.exactVectorComplexConstraintScope ?? ''), i = scopes.indexOf(scope), required = { topicCode: 'M-ALG-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
    const bound = i >= 0 && p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 73 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === 'math_vector_complex_constraint_reasoning' && p?.planTemplate === 'math_vector_complex_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'vector_complex_constraint_system' && s?.scenarioAction === scope;
    const reasonCodes = [];
    let expectedAnswer = null, certificate = null, data = null;
    try {
        if (!bound)
            throw Error('oracle_exact_plan');
        data = parse(candidate.prompt, i, 'zh');
        const d = vectorComplexConstraintIndependentCalculation(data, i);
        expectedAnswer = d.answer;
        certificate = d.certificate;
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parse(candidate.localizations?.[lang]?.prompt ?? '', i, lang)) !== JSON.stringify(data))
                throw Error('oracle_translation_parameters');
    }
    catch (e) {
        reasonCodes.push(e instanceof Error ? e.message : 'oracle_unparsed');
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 73 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => option(o.text));
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(o => [o.id, option(o.text)])) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('oracle_' + lang + '_options');
    const trueOptionIds = opts.filter((_, j) => keys[j] !== null && keys[j] === expectedAnswer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('oracle_answer_disagreement');
    return { oracleVersion: exports.VECTOR_COMPLEX_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? (data ? 'disagreed' : 'unparsed') : 'verified', scopeMatched: bound && !!data, scopeId: bound && data ? 'math-hard-vector-complex-constraint-v1:' + scope : null, exactScope: scope, expectedAnswer, selectedOptionId, trueOptionIds, certificate, complete: !!certificate, completeCertificate: !!certificate, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
