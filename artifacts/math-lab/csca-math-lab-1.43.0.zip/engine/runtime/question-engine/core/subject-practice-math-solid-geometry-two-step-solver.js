"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SOLID_GEOMETRY_TWO_STEP_CONSTRAINTS = exports.SOLID_GEOMETRY_TWO_STEP_SCOPES = exports.SOLID_GEOMETRY_TWO_STEP_SCOPE_VERSION = exports.SOLID_GEOMETRY_TWO_STEP_SOLVER_VERSION = exports.SOLID_GEOMETRY_TWO_STEP_TEMPLATE = exports.SOLID_GEOMETRY_TWO_STEP_FAMILY = void 0;
exports.solidGeometryTwoStepScopeFrom = solidGeometryTwoStepScopeFrom;
exports.solidGeometryTwoStepPrompt = solidGeometryTwoStepPrompt;
exports.solidGeometryTwoStepParametersFrom = solidGeometryTwoStepParametersFrom;
exports.solidGeometryTwoStepRadical = solidGeometryTwoStepRadical;
exports.solidGeometryTwoStepOptionKey = solidGeometryTwoStepOptionKey;
exports.solidGeometryTwoStepDerive = solidGeometryTwoStepDerive;
exports.solidGeometryTwoStepDistractors = solidGeometryTwoStepDistractors;
exports.solveSubjectPracticeMathSolidGeometryTwoStep = solveSubjectPracticeMathSolidGeometryTwoStep;
exports.SOLID_GEOMETRY_TWO_STEP_FAMILY = 'math_solid_geometry_two_step_calculation';
exports.SOLID_GEOMETRY_TWO_STEP_TEMPLATE = exports.SOLID_GEOMETRY_TWO_STEP_FAMILY + '_v1';
exports.SOLID_GEOMETRY_TWO_STEP_SOLVER_VERSION = 'math-solid-geometry-two-step-solver-v1-exact-dimensional';
exports.SOLID_GEOMETRY_TWO_STEP_SCOPE_VERSION = 'math-medium-solid-geometry-two-step-v1';
exports.SOLID_GEOMETRY_TWO_STEP_SCOPES = ['cuboid_volume_to_surface_area', 'cuboid_surface_area_to_space_diagonal',
    'cylinder_volume_to_total_surface_area', 'cone_radius_height_to_lateral_area'];
exports.SOLID_GEOMETRY_TWO_STEP_CONSTRAINTS = {
    topicCode: 'M-GEO-002', boundedIntegerParameters: true, maximumDimensionCm: 30,
    exactDimensionalArithmetic: true, completeSolidGeometryCertificate: true,
    externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2
};
const record = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
function solidGeometryTwoStepScopeFrom(value) {
    const p = record(value), r = record(p?.renderConstraints), s = record(p?.scenarioContract);
    const scope = r?.exactSolidGeometryTwoStepScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 74 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === exports.SOLID_GEOMETRY_TWO_STEP_FAMILY && p?.planTemplate === exports.SOLID_GEOMETRY_TWO_STEP_TEMPLATE
        && r?.questionType === 'single_choice' && Object.entries(exports.SOLID_GEOMETRY_TWO_STEP_CONSTRAINTS).every(([k, v]) => r?.[k] === v)
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'solid_geometry_two_step_object' && s?.scenarioAction === scope
        && exports.SOLID_GEOMETRY_TWO_STEP_SCOPES.includes(scope) ? scope : null;
}
function solidGeometryTwoStepPrompt(p, lang) {
    const [a, b, k] = p.values;
    switch (p.scope) {
        case 'cuboid_volume_to_surface_area': return lang === 'zh'
            ? `长方体的两条相邻棱长 a=${a} cm、b=${b} cm，体积 V=${k} cm^3。求总表面积 S（单位 cm^2）。`
            : `A cuboid has adjacent edges a=${a} cm and b=${b} cm and volume V=${k} cm^3. Find its total surface area S (in cm^2).`;
        case 'cuboid_surface_area_to_space_diagonal': return lang === 'zh'
            ? `长方体的两条相邻棱长 a=${a} cm、b=${b} cm，总表面积 S=${k} cm^2。求体对角线长度 d（单位 cm，保留精确根式）。`
            : `A cuboid has adjacent edges a=${a} cm and b=${b} cm and total surface area S=${k} cm^2. Find its space diagonal length d (in cm, keep radicals exact).`;
        case 'cylinder_volume_to_total_surface_area': return lang === 'zh'
            ? `直圆柱的底面半径 r=${a} cm，体积 V=${b}π cm^3。求包含两个底面的总表面积 S（单位 cm^2，保留 π）。`
            : `A right circular cylinder has base radius r=${a} cm and volume V=${b}π cm^3. Find its total surface area S including both bases (in cm^2, keep π exact).`;
        case 'cone_radius_height_to_lateral_area': return lang === 'zh'
            ? `直圆锥的底面半径 r=${a} cm，高 h=${b} cm。求不含底面的侧面积 A（单位 cm^2，保留 π 和精确根式）。`
            : `A right circular cone has base radius r=${a} cm and height h=${b} cm. Find its lateral area A excluding the base (in cm^2, keep π and radicals exact).`;
    }
}
function solidGeometryTwoStepParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 700)
        return null;
    const numbers = [...text.matchAll(/(?:a|b|r|h|V|S)=(\d+)/g)].map(m => Number(m[1]));
    const p = { scope, values: numbers };
    if (text !== solidGeometryTwoStepPrompt(p, lang) || !solidGeometryTwoStepDerive(p))
        return null;
    return p;
}
function solidGeometryTwoStepRadical(coefficient, radicand, pi, power) {
    let c = coefficient, n = radicand;
    for (let factor = 2; factor * factor <= n; factor++)
        while (n % (factor * factor) === 0) {
            c *= factor;
            n /= factor * factor;
        }
    return `${c}${n === 1 ? '' : `*sqrt(${n})`}${pi ? 'π' : ''} cm${power === 1 ? '' : '^2'}`;
}
function solidGeometryTwoStepOptionKey(text, scope) {
    if (typeof text !== 'string' || text.length > 120)
        return null;
    const m = text.trim().match(/^([1-9]\d{0,5})(?:\*sqrt\(([1-9]\d{0,8})\))?(π)? cm(\^2)?$/);
    if (!m)
        return null;
    const power = m[4] ? 2 : 1, pi = Boolean(m[3]), diagonal = scope === exports.SOLID_GEOMETRY_TWO_STEP_SCOPES[1];
    if (power !== (diagonal ? 1 : 2) || pi !== (scope.startsWith('cylinder_') || scope.startsWith('cone_')))
        return null;
    return `${BigInt(m[1]) ** 2n * BigInt(m[2] ?? '1')}:${pi ? 1 : 0}:${power}`;
}
function solidGeometryTwoStepDerive(p) {
    const [a, b, k] = p.values, index = exports.SOLID_GEOMETRY_TWO_STEP_SCOPES.indexOf(p.scope);
    const dimension = (n) => Number.isInteger(n) && n >= 1 && n <= 30;
    if (index < 0 || p.values.length !== (index < 2 ? 3 : 2) || !p.values.every(Number.isSafeInteger) || !dimension(a))
        return null;
    if (index < 2 && (!dimension(b) || k <= 0 || k > (index === 0 ? 27000 : 5400)))
        return null;
    if (index === 2 && (b <= 0 || b > 27000) || index === 3 && !dimension(b))
        return null;
    const c = index === 0 ? k / (a * b) : index === 1 ? (k / 2 - a * b) / (a + b) : index === 2 ? b / (a * a) : 0;
    if (index < 3 && !dimension(c))
        return null;
    const square = index === 1 ? a * a + b * b + c * c : index === 3 ? a * a + b * b : 1;
    const coefficient = index === 0 ? 2 * (a * b + a * c + b * c) : index === 2 ? 2 * a * a + 2 * a * c : index === 3 ? a : 1;
    const answer = solidGeometryTwoStepRadical(coefficient, square, index >= 2, index === 1 ? 1 : 2);
    const proof = index === 0 ? `c=V/(ab)=${k}/(${a}*${b})=${c} cm; S=2(ab+ac+bc)=2*(${a}*${b}+${a}*${c}+${b}*${c})=${answer}`
        : index === 1 ? `c=(S/2-ab)/(a+b)=(${k}/2-${a}*${b})/(${a}+${b})=${c} cm; d=sqrt(a^2+b^2+c^2)=sqrt(${a}^2+${b}^2+${c}^2)=${answer}`
            : index === 2 ? `h=V/(πr^2)=${b}π/(π*${a}^2)=${c} cm; S=2πr^2+2πrh=2π*${a}^2+2π*${a}*${c}=${answer}`
                : `l=sqrt(r^2+h^2)=sqrt(${a}^2+${b}^2)=${solidGeometryTwoStepRadical(1, square, false, 1)}; A=πrl=π*${a}*sqrt(${square})=${answer}`;
    return { answer, proof, intermediate: c, squaredLength: square };
}
function solidGeometryTwoStepDistractors(p) {
    const d = solidGeometryTwoStepDerive(p);
    if (!d)
        return [];
    const [a, b] = p.values, c = d.intermediate, items = [];
    const index = exports.SOLID_GEOMETRY_TWO_STEP_SCOPES.indexOf(p.scope);
    const add = (n, q, intent) => items.push({ key: solidGeometryTwoStepRadical(n, q, index >= 2, index === 1 ? 1 : 2), intent });
    if (index === 0) {
        add(a * b + a * c + b * c, 1, 'count_each_opposite_face_pair_once');
        add(2 * (a * c + b * c), 1, 'omit_both_base_faces');
        add(2 * a * b, 1, 'count_only_two_base_faces');
        add(a * b + 2 * a * c + 2 * b * c, 1, 'omit_one_base_face');
    }
    else if (index === 1) {
        add(1, a * a + b * b, 'use_base_diagonal');
        add(d.squaredLength, 1, 'omit_final_square_root');
        add(a + b + c, 1, 'use_edge_path_length');
        add(Math.max(a, b, c), 1, 'use_longest_edge');
    }
    else if (index === 2) {
        add(2 * a * c, 1, 'omit_both_cylinder_bases');
        add(a * a + 2 * a * c, 1, 'count_only_one_cylinder_base');
        add(2 * a * a, 1, 'omit_cylinder_lateral_area');
        add(8 * a * a + 4 * a * c, 1, 'use_diameter_as_surface_radius');
    }
    else {
        add(a * b, 1, 'use_height_as_slant_height');
        add(1, d.squaredLength, 'omit_radius_factor');
        add(a * d.squaredLength, 1, 'omit_slant_height_square_root');
        add(2 * a, d.squaredLength, 'use_diameter_in_sector_area');
    }
    const seen = new Set([solidGeometryTwoStepOptionKey(d.answer, p.scope)]);
    return items.filter(item => { const key = solidGeometryTwoStepOptionKey(item.key, p.scope); if (key === null || seen.has(key))
        return false; seen.add(key); return true; }).slice(0, 3);
}
function solveSubjectPracticeMathSolidGeometryTwoStep(candidate, context = {}) {
    const scope = solidGeometryTwoStepScopeFrom(context.questionPlan), parameters = solidGeometryTwoStepParametersFrom(candidate.prompt, scope, 'zh');
    const d = parameters ? solidGeometryTwoStepDerive(parameters) : null, reasonCodes = [];
    if (!scope || !parameters || !d)
        reasonCodes.push('solid_geometry_two_step_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 74 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('solid_geometry_two_step_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? solidGeometryTwoStepOptionKey(o.text, scope) : null), expectedKey = d && scope ? solidGeometryTwoStepOptionKey(d.answer, scope) : null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('solid_geometry_two_step_invalid_or_duplicate_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(solidGeometryTwoStepParametersFrom(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('solid_geometry_two_step_' + lang + '_prompt');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, scope ? solidGeometryTwoStepOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('solid_geometry_two_step_' + lang + '_options');
    }
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : expectedKey !== null && keys[i] === expectedKey ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('solid_geometry_two_step_answer');
    const wrong = parameters ? solidGeometryTwoStepDistractors(parameters) : [], meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3
        || meta.some(m => m.optionId === selectedOptionId || !wrong.some(w => w.intent === m.distractorIntent && scope && solidGeometryTwoStepOptionKey(w.key, scope) === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('solid_geometry_two_step_error_intent');
    const scopeId = parameters ? exports.SOLID_GEOMETRY_TWO_STEP_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.SOLID_GEOMETRY_TWO_STEP_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: exports.SOLID_GEOMETRY_TWO_STEP_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: d?.answer ?? null, proof: d?.proof ?? null, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.SOLID_GEOMETRY_TWO_STEP_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope: scope, reasonCodes: parameters ? [] : ['solid_geometry_two_step_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
