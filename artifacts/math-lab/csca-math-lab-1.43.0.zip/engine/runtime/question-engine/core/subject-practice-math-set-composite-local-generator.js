"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathSetCompositeLocalGenerator = createSubjectPracticeMathSetCompositeLocalGenerator;
const subject_practice_math_set_composite_solver_1 = require("./subject-practice-math-set-composite-solver");
const subject_practice_math_set_composite_independent_oracle_1 = require("./subject-practice-math-set-composite-independent-oracle");
const subject_practice_math_set_composite_explanation_verifier_1 = require("./subject-practice-math-set-composite-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_LOCAL_GENERATOR_VERSION = 'math-set-composite-local-generator-v2-distinct-distractor-intents';
const SCOPES = new Set(['union_then_intersection', 'intersection_then_union', 'difference_then_intersection', 'complement_then_union']);
function obj(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').trim(); }
function normalizedSeed(value) { const n = Number(value); return Number.isFinite(n) ? Math.abs(Math.trunc(n)) : 0; }
function scopeFrom(planValue, validate) {
    const plan = obj(planValue);
    const render = obj(plan?.renderConstraints);
    const scope = clean(render?.exactSetCompositeScope);
    return validate(planValue).valid && clean(plan?.taskFamily) === 'math_finite_set_composite_operation'
        && clean(plan?.planTemplate) === 'math_finite_set_composite_operation_v1' && SCOPES.has(scope) ? scope : null;
}
function rotate(values, shift) { return values.map((n) => ((n - 1 + shift) % 10) + 1).sort((a, b) => a - b); }
function union(a, b) { return [...new Set([...a, ...b])].sort((x, y) => x - y); }
function intersection(a, b) { const B = new Set(b); return a.filter((x) => B.has(x)); }
function difference(a, b) { const B = new Set(b); return a.filter((x) => !B.has(x)); }
function setText(values) { return `{${values.join(',')}}`; }
function uniqueAlternatives(alternatives) { const seen = new Set(); return alternatives.filter((alternative) => { const key = setText(alternative.values); if (seen.has(key))
    return false; seen.add(key); return true; }); }
function candidateFor(blueprint, seed, scope) {
    const u = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    const shift = seed % 10;
    const a = rotate([1, 2, 4, 7, 9], shift);
    const b = rotate([2, 3, 5, 7, 10], shift);
    const c = rotate([1, 3, 4, 6, 8, 10], shift);
    const result = (0, subject_practice_math_set_composite_solver_1.evaluateMathSetComposite)(scope, u, a, b, c);
    const first = scope === 'union_then_intersection' ? union(a, b) : scope === 'intersection_then_union' ? intersection(a, b) : scope === 'difference_then_intersection' ? difference(a, b) : difference(u, a);
    const wrongOrder = scope === 'union_then_intersection' ? union(a, intersection(b, c))
        : scope === 'intersection_then_union' ? intersection(a, union(b, c))
            : scope === 'difference_then_intersection' ? difference(a, intersection(b, c))
                : intersection(difference(u, a), b);
    const alternatives = uniqueAlternatives([
        { values: result, distractorIntent: null },
        { values: first, distractorIntent: 'stopped_after_first_operation' },
        { values: wrongOrder, distractorIntent: 'misapplied_operation_order' },
        { values: a, distractorIntent: 'used_set_a_only' },
        { values: b, distractorIntent: 'used_set_b_only' },
        { values: c, distractorIntent: 'used_set_c_only' },
        { values: u, distractorIntent: 'selected_universal_set' },
        { values: [], distractorIntent: 'selected_empty_set' }
    ]).slice(0, 4);
    if (alternatives.length !== 4 || setText(alternatives[0].values) !== setText(result))
        throw new Error('math_set_composite_generator_option_construction_failed');
    const correctIndex = seed % 4;
    const ordered = alternatives.slice(1);
    ordered.splice(correctIndex, 0, alternatives[0]);
    const ids = ['A', 'B', 'C', 'D'];
    const options = ordered.map((alternative, index) => ({ id: ids[index], text: setText(alternative.values) }));
    const zh = scope === 'union_then_intersection' ? '(A∪B)∩C' : scope === 'intersection_then_union' ? '(A∩B)∪C' : scope === 'difference_then_intersection' ? '(A\\B)∩C' : '(U中A的补集)∪B';
    const en = scope === 'union_then_intersection' ? '(A union B) intersection C' : scope === 'intersection_then_union' ? '(A intersection B) union C' : scope === 'difference_then_intersection' ? '(A minus B) intersection C' : 'the complement of A in U, union B';
    const prompt = `已知全集 U=${setText(u)}，集合 A=${setText(a)}，B=${setText(b)}，C=${setText(c)}。求${zh}。`;
    const promptEn = `Let U=${setText(u)}, A=${setText(a)}, B=${setText(b)}, and C=${setText(c)}. Find ${en}.`;
    const explanation = `先计算第一步集合运算，得到${setText(first)}；再完成${zh}的第二步运算，得到${setText(result)}。`;
    const explanationEn = `First complete the inner set operation to get ${setText(first)}; then apply the second operation in ${en} to obtain ${setText(result)}.`;
    return {
        subject: 'math', topicId: blueprint.topicId, blueprintId: blueprint.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice',
        prompt, options, correctAnswer: ids[correctIndex], explanation, knowledgeTags: ['集合', '有限集合复合运算', scope],
        optionMetadata: ordered.flatMap((alternative, index) => index === correctIndex ? [] : [{ optionId: ids[index], distractorIntent: alternative.distractorIntent ?? 'unclassified_set_operation_error', misconceptionTags: ['finite_set_composite_operation_error'] }]),
        localizations: { zh: { prompt, options, explanation, knowledgeTags: ['集合', '有限集合复合运算'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Sets', 'Composite finite-set operations'] } },
        syllabusVersion: blueprint.syllabusVersion
    };
}
function createSubjectPracticeMathSetCompositeLocalGenerator(ports) {
    return function generate(input) {
        const seed = normalizedSeed(input.seed);
        const exactScope = scopeFrom(input.questionPlan, ports.validate);
        const supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'medium' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice';
        if (!exactScope || !supported)
            return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_set_composite_local_generator_question_plan_not_supported'] };
        const candidate = candidateFor(input.blueprint, seed, exactScope);
        const context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_set_composite_solver_1.solveSubjectPracticeMathSetComposite)(candidate, context);
        const oracleEvidence = (0, subject_practice_math_set_composite_independent_oracle_1.verifySubjectPracticeMathSetCompositeWithIndependentOracle)(candidate, context);
        const explanationEvidence = (0, subject_practice_math_set_composite_explanation_verifier_1.verifySubjectPracticeMathSetCompositeExplanation)(candidate, context);
        const adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_set_composite_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
