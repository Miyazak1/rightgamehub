"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NORMAL_TWO_STEP_EXPLANATION_VERSION = void 0;
exports.renderNormalTwoStepExplanation = renderNormalTwoStepExplanation;
exports.verifySubjectPracticeMathNormalTwoStepExplanation = verifySubjectPracticeMathNormalTwoStepExplanation;
const subject_practice_math_normal_distribution_two_step_solver_1 = require("./subject-practice-math-normal-distribution-two-step-solver");
exports.NORMAL_TWO_STEP_EXPLANATION_VERSION = 'math-normal-distribution-two-step-explanation-v1-bound-bilingual';
function renderNormalTwoStepExplanation(p, answer, option) {
    const d = (0, subject_practice_math_normal_distribution_two_step_solver_1.normalTwoStepDerive)(p);
    if (!d)
        throw Error('normal_two_step_invalid_explanation_parameters');
    return { zh: (0, subject_practice_math_normal_distribution_two_step_solver_1.normalTwoStepPrompt)(p, 'zh') + ' 先由方差取正平方根得到标准差，再按给定概率与对称性或经验规律计算。这里只对题给近似数值进行精确有理数运算，结果不是精确正态积分或精确分位点。 ' + d.proof + '; result=' + answer + '。对应选项 ' + option + '。',
        en: (0, subject_practice_math_normal_distribution_two_step_solver_1.normalTwoStepPrompt)(p, 'en') + ' Take the positive square root of the variance, then use the supplied probabilities with symmetry or the empirical rule. Rational arithmetic is exact only for the given approximations, not for the Gaussian integral or an exact quantile. ' + d.proof + '; result=' + answer + '. Option ' + option + '.' };
}
function verifySubjectPracticeMathNormalTwoStepExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_normal_distribution_two_step_solver_1.solveSubjectPracticeMathNormalTwoStep)(candidate, context), expected = solved.parameters && solved.expectedAnswer && solved.selectedOptionId ? renderNormalTwoStepExplanation(solved.parameters, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh), enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('normal_two_step_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('normal_two_step_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('normal_two_step_explanation_en_mismatch');
    return { verifierVersion: exports.NORMAL_TWO_STEP_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solved.scopeId, zhBound, enBound, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
