"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VECTOR_COMPLEX_TWO_STEP_EXPLANATION_VERSION = void 0;
exports.renderVectorComplexTwoStepExplanation = renderVectorComplexTwoStepExplanation;
exports.verifySubjectPracticeMathVectorComplexTwoStepExplanation = verifySubjectPracticeMathVectorComplexTwoStepExplanation;
const subject_practice_math_vector_complex_two_step_solver_1 = require("./subject-practice-math-vector-complex-two-step-solver");
exports.VECTOR_COMPLEX_TWO_STEP_EXPLANATION_VERSION = 'math-vector-complex-two-step-explanation-v1-bound-bilingual';
function renderVectorComplexTwoStepExplanation(p, answer, option) {
    const d = (0, subject_practice_math_vector_complex_two_step_solver_1.vectorComplexTwoStepDerive)(p);
    if (!d)
        throw Error('invalid_vector_complex_explanation_parameters');
    const notes = {
        vector_linear_combination_norm_squared: ['先逐坐标进行数乘与加法，再将所得两个坐标分别平方后相加；所求是模的平方，不再开方。', 'Combine the scaled vector coordinates, then sum their squares. The requested value is the squared norm, not its square root.'],
        vector_perpendicular_parameter: ['将垂直条件写成数量积为零，再解关于 t 的一次方程；t 的系数非零，故在所有实数中解唯一。', 'Set the dot product equal to zero, then solve the linear equation in t. Its nonzero coefficient proves uniqueness over all real numbers.'],
        complex_multiply_then_add: ['先按 i^2=-1 展开复数乘积，再分别相加实部与虚部，保留交叉项及其符号。', 'Expand the complex product using i^2=-1, then add the real and imaginary parts of z3, retaining both cross terms.'],
        complex_affine_equation: ['先移项得到 z1*z=z3-z2，再乘除数的共轭并除以模平方；除数非零保证复数解唯一。', 'Isolate z1*z=z3-z2, multiply by the conjugate of the divisor, and divide by its squared modulus. A nonzero divisor proves a unique complex solution.']
    };
    return { zh: (0, subject_practice_math_vector_complex_two_step_solver_1.vectorComplexTwoStepPrompt)(p, 'zh') + ' ' + notes[p.scope][0] + ' ' + d.proof + '; result=' + answer + '。对应选项 ' + option + '。',
        en: (0, subject_practice_math_vector_complex_two_step_solver_1.vectorComplexTwoStepPrompt)(p, 'en') + ' ' + notes[p.scope][1] + ' ' + d.proof + '; result=' + answer + '. Option ' + option + '.' };
}
function verifySubjectPracticeMathVectorComplexTwoStepExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_vector_complex_two_step_solver_1.solveSubjectPracticeMathVectorComplexTwoStep)(candidate, context), expected = solved.parameters && solved.expectedAnswer !== null && solved.selectedOptionId ? renderVectorComplexTwoStepExplanation(solved.parameters, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh), enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('vector_complex_two_step_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('vector_complex_two_step_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('vector_complex_two_step_explanation_en_mismatch');
    return { verifierVersion: exports.VECTOR_COMPLEX_TWO_STEP_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solved.scopeId, zhBound, enBound, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
