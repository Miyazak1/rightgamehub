"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NORMAL_BASIC_CONSTRAINTS = exports.MATH_NORMAL_DISTRIBUTION_BASIC_SCOPES = exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_SOLVER_VERSION = void 0;
exports.normalRational = normalRational;
exports.normalRationalText = normalRationalText;
exports.normalScopeFrom = normalScopeFrom;
exports.normalParametersFrom = normalParametersFrom;
exports.normalValue = normalValue;
exports.parseNormalOption = parseNormalOption;
exports.solveSubjectPracticeMathNormalDistributionBasic = solveSubjectPracticeMathNormalDistributionBasic;
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_SOLVER_VERSION = 'math-normal-distribution-basic-solver-v1-exact-and-approximate';
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_SCOPE_VERSION = 'math-normal-distribution-basic-scope-v1';
exports.MATH_NORMAL_DISTRIBUTION_BASIC_SCOPES = ['normal_parameter_identification', 'normal_standardization_z_score', 'normal_symmetry_probability', 'normal_empirical_interval_probability'];
exports.NORMAL_BASIC_CONSTRAINTS = {
    topicCode: 'M-STAT-002', minimumMean: -20, maximumMean: 80, minimumSigma: 1, maximumSigma: 12,
    integerParametersRequired: true, integerVisibleThresholdRequired: true, oneVisibleTarget: true,
    secondNormalParameter: 'variance', empiricalRuleApproximateRequired: true,
    externalContextAllowed: false, requiresImage: false, finalAnswerShape: 'one_unique_rational_with_exact_or_stated_approximate_semantics'
};
function normalRational(n, d = 1) {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || d <= 0)
        throw new Error('normal_invalid_rational');
    let a = Math.abs(n), b = d;
    while (b) {
        const r = a % b;
        a = b;
        b = r;
    }
    return { numerator: n / a, denominator: d / a };
}
function normalRationalText(v) { return v.denominator === 1 ? String(v.numerator) : v.numerator + '/' + v.denominator; }
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function normalScopeFrom(value) {
    const p = object(value), r = object(p?.renderConstraints), s = r?.exactNormalDistributionScope, scenario = object(p?.scenarioContract);
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.representationType === 'text' && r?.questionType === 'single_choice'
        && scenario?.scenarioMode === 'abstract' && scenario?.scenarioEntity === 'normal_distribution_object' && scenario?.scenarioAction === s
        && p?.subject === 'math' && p?.topicId === 77 && p?.targetDifficulty === 'basic'
        && p?.taskFamily === 'math_normal_distribution_basic_concepts' && p?.planTemplate === 'math_normal_distribution_basic_concepts_v1'
        && Object.entries(exports.NORMAL_BASIC_CONSTRAINTS).every(([k, v]) => r?.[k] === v)
        && exports.MATH_NORMAL_DISTRIBUTION_BASIC_SCOPES.includes(s) ? s : null;
}
function normalParametersFrom(text, scope, lang) {
    if (!scope)
        return null;
    const prefix = lang === 'zh'
        ? /^(?:设|已知)连续随机变量 X 服从正态分布 N\((-?\d+), (\d+)\)，其中第二个参数为方差。(.+)$/
        : /^(?:Let X have|Assume X has) a continuous normal distribution N\((-?\d+), (\d+)\), where the second parameter is the variance\. (.+)$/;
    const m = String(text ?? '').match(prefix);
    if (!m)
        return null;
    const mu = Number(m[1]), variance = Number(m[2]), sigma = Math.sqrt(variance), tail = m[3];
    if (!Number.isInteger(mu) || mu < -20 || mu > 80 || !Number.isInteger(sigma) || sigma < 1 || sigma > 12)
        return null;
    const base = { scope, mu, variance, sigma };
    if (scope === 'normal_parameter_identification') {
        const targets = lang === 'zh' ? ['求 X 的均值。', '求 X 的方差。', '求 X 的正标准差。'] : ['Find the mean of X.', 'Find the variance of X.', 'Find the positive standard deviation of X.'];
        const index = targets.indexOf(tail);
        return index < 0 ? null : { ...base, target: ['mean', 'variance', 'standard_deviation'][index] };
    }
    if (scope === 'normal_standardization_z_score') {
        const z = tail.match(lang === 'zh' ? /^对阈值 x=(-?\d+)，求标准化值 z=\(x-mu\)\/sigma。$/ : /^For the threshold x=(-?\d+), find the standardized value z=\(x-mu\)\/sigma\.$/);
        if (!z)
            return null;
        const x = Number(z[1]), twiceZ = 2 * (x - mu) / sigma;
        return Number.isSafeInteger(x) && [-6, -4, -2, -1, 0, 1, 2, 4, 6].includes(twiceZ) ? { ...base, target: 'z', x } : null;
    }
    if (scope === 'normal_symmetry_probability') {
        const s = tail.match(lang === 'zh' ? /^求概率 P\(X(<=|>=|<|>)(-?\d+)\)。$/ : /^Find the probability P\(X(<=|>=|<|>)(-?\d+)\)\.$/);
        return s && Number(s[2]) === mu ? { ...base, target: 'symmetry', x: mu, comparison: s[1] } : null;
    }
    // The plus sign on the upper bound is mandatory; parse it explicitly, never a symmetric-looking minus.
    const exactEmpirical = tail.match(lang === 'zh'
        ? /^已知经验规律：P\(mu-([123])\*sigma<=X<=mu\+([123])\*sigma\)≈(68|95|99\.7)%。求事件 (.+) 的近似概率。$/
        : /^Use the empirical approximation: P\(mu-([123])\*sigma<=X<=mu\+([123])\*sigma\)≈(68|95|99\.7)%\. Find the approximate probability of (.+)\.$/);
    if (!exactEmpirical)
        return null;
    const k = Number(exactEmpirical[1]);
    if (exactEmpirical[1] !== exactEmpirical[2] || exactEmpirical[3] !== ['68', '95', '99.7'][k - 1])
        return null;
    const lower = mu - k * sigma, upper = mu + k * sigma;
    const events = [lower + '<=X<=' + upper, 'X<' + lower + (lang === 'zh' ? ' 或 ' : ' or ') + 'X>' + upper, 'X<' + lower, 'X>' + upper];
    const index = events.indexOf(exactEmpirical[4]);
    return index < 0 ? null : { ...base, target: ['central', 'outside', 'left', 'right'][index], k, lower, upper };
}
function normalValue(p) {
    if (p.target === 'mean')
        return normalRational(p.mu);
    if (p.target === 'variance')
        return normalRational(p.variance);
    if (p.target === 'standard_deviation')
        return normalRational(p.sigma);
    if (p.target === 'z')
        return normalRational(p.x - p.mu, p.sigma);
    if (p.target === 'symmetry')
        return normalRational(1, 2);
    const central = [680, 950, 997][p.k - 1];
    return p.target === 'central' ? normalRational(central, 1000) : normalRational(1000 - central, p.target === 'outside' ? 1000 : 2000);
}
function parseNormalOption(text) {
    const m = String(text ?? '').match(/^(-?(?:0|[1-9]\d{0,5}))(?:\/([1-9]\d{0,5}))?$/);
    return m ? normalRational(Number(m[1]), Number(m[2] ?? 1)) : null;
}
function solveSubjectPracticeMathNormalDistributionBasic(c, context = {}) {
    const exactScope = normalScopeFrom(context.questionPlan), parameters = normalParametersFrom(c.prompt, exactScope, 'zh');
    const expectedValue = parameters ? normalValue(parameters) : null, reasonCodes = [];
    if (!parameters)
        reasonCodes.push('math_normal_basic_prompt_or_plan_outside_scope');
    if (c.subject !== 'math' || c.topicId !== 77 || c.designedDifficulty !== 'basic' || c.questionType !== 'single_choice')
        reasonCodes.push('math_normal_basic_identity_mismatch');
    for (const lang of ['zh', 'en']) {
        if (!parameters || JSON.stringify(normalParametersFrom(c.localizations?.[lang]?.prompt ?? '', exactScope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('math_normal_basic_' + lang + '_parameters_or_target_mismatch');
        if (JSON.stringify(c.localizations?.[lang]?.options) !== JSON.stringify(c.options))
            reasonCodes.push('math_normal_basic_' + lang + '_options_mismatch');
    }
    const options = c.options ?? [], values = options.map(o => parseNormalOption(o.text));
    const probability = parameters && ['symmetry', 'central', 'outside', 'left', 'right'].includes(parameters.target);
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: values[i], verdict: !values[i] ? 'unknown' : JSON.stringify(values[i]) === JSON.stringify(expectedValue) ? 'true' : 'false' }));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id))
        || values.some(v => !v || (probability && (v.numerator < 0 || v.numerator > v.denominator)))
        || new Set(values.map(v => JSON.stringify(v))).size !== 4)
        reasonCodes.push('math_normal_basic_invalid_or_duplicate_options');
    const trueOptionIds = optionVerdicts.filter(v => v.verdict === 'true').map(v => v.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_normal_basic_answer_not_unique');
    if (selectedOptionId !== c.correctAnswer)
        reasonCodes.push('math_normal_basic_generator_disagreement');
    const metadata = c.optionMetadata ?? [], wrongIds = options.filter(o => o.id !== c.correctAnswer).map(o => o.id);
    if (metadata.length !== 3 || new Set(metadata.map(m => m.optionId)).size !== 3 || new Set(metadata.map(m => m.distractorIntent)).size !== 3
        || metadata.some(m => !wrongIds.includes(m.optionId) || !m.distractorIntent?.trim()))
        reasonCodes.push('math_normal_basic_duplicate_or_missing_distractor_intent');
    const scopeId = parameters ? 'math-basic-normal-distribution-v1:' + exactScope : null;
    return { solverVersion: exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_SOLVER_VERSION,
        status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_normal_distribution_basic_concepts', scopeId, exactScope, parameters, expectedValue,
        approximation: exactScope === 'normal_empirical_interval_probability',
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope, reasonCodes: parameters ? [] : ['math_normal_basic_scope_not_matched'] },
        optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === c.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
