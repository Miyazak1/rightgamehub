"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathInequalityWithIndependentOracle = verifySubjectPracticeMathInequalityWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_INDEPENDENT_ORACLE_VERSION = 'math-inequality-independent-oracle-v1';
function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function normalize(value) { return String(value ?? '').replace(/[≥]/g, '>=').replace(/[≤]/g, '<=').replace(/[−–—]/g, '-').replace(/\s+/g, ' ').trim(); }
function scope(context) {
    const plan = object(context.questionPlan);
    const render = object(plan?.renderConstraints);
    const value = normalize(render?.exactInequalityScope);
    return String(plan?.taskFamily ?? '') === 'math_linear_inequality_solution'
        && String(plan?.planTemplate ?? '') === 'math_linear_inequality_solution_v1'
        && ['linear_gt_positive', 'linear_lt_positive', 'linear_gt_negative', 'linear_le_negative'].includes(value) ? value : null;
}
function relationTruth(left, relation, right) { return relation === '>' ? left > right : relation === '<' ? left < right : relation === '>=' ? left >= right : left <= right; }
function promptPredicate(prompt) {
    const match = normalize(prompt).match(/(-?\d+)x\s*([+-])\s*(\d+)\s*(>=|<=|>|<)\s*(-?\d+)/i);
    if (!match)
        return null;
    const a = Number(match[1]);
    const b = Number(match[3]) * (match[2] === '-' ? -1 : 1);
    const relation = match[4];
    const rhs = Number(match[5]);
    return (x) => relationTruth(a * x + b, relation, rhs);
}
function optionPredicate(text) {
    const match = normalize(text).match(/^x\s*(>=|<=|>|<)\s*(-?\d+)$/i);
    if (!match)
        return null;
    const relation = match[1];
    const boundary = Number(match[2]);
    return (x) => relationTruth(x, relation, boundary);
}
function verifySubjectPracticeMathInequalityWithIndependentOracle(candidate, context = {}) {
    const exactScope = scope(context);
    const expected = promptPredicate(candidate.prompt);
    const probes = Array.from({ length: 81 }, (_, i) => i - 40);
    const parsed = Boolean(exactScope && expected);
    const optionVerdicts = (candidate.options ?? []).map((option) => { const actual = optionPredicate(option.text); const truth = Boolean(parsed && actual && probes.every((x) => actual(x) === expected(x))); return { optionId: option.id, verdict: actual ? (truth ? 'true' : 'false') : 'unknown' }; });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!parsed)
        reasonCodes.push('math_inequality_oracle_prompt_or_plan_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_inequality_oracle_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_inequality_oracle_answer_not_unique');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_inequality_oracle_generator_disagreement');
    return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_INDEPENDENT_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'disagreed' : 'abstained') : 'verified', scopeId: parsed ? `math-basic-linear-inequality-v1:${exactScope}` : null, exactScope, scopeMatched: parsed, optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
