"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.functionCompositionIntervalText = exports.FUNCTION_COMPOSITION_CONSTRAINTS = exports.FUNCTION_COMPOSITION_SCOPES = exports.FUNCTION_COMPOSITION_SCOPE_VERSION = exports.FUNCTION_COMPOSITION_SOLVER_VERSION = exports.FUNCTION_COMPOSITION_TEMPLATE = exports.FUNCTION_COMPOSITION_FAMILY = void 0;
exports.fq = fq;
exports.normalizeFunctionSegments = normalizeFunctionSegments;
exports.parseFunctionCompositionIntervals = parseFunctionCompositionIntervals;
exports.functionCompositionScopeFrom = functionCompositionScopeFrom;
exports.functionCompositionPrompt = functionCompositionPrompt;
exports.functionCompositionParametersValid = functionCompositionParametersValid;
exports.functionCompositionParametersFrom = functionCompositionParametersFrom;
exports.functionCompositionDerive = functionCompositionDerive;
exports.solveSubjectPracticeMathFunctionComposition = solveSubjectPracticeMathFunctionComposition;
exports.FUNCTION_COMPOSITION_FAMILY = 'math_function_composition_piecewise_reasoning';
exports.FUNCTION_COMPOSITION_TEMPLATE = exports.FUNCTION_COMPOSITION_FAMILY + '_v1';
exports.FUNCTION_COMPOSITION_SOLVER_VERSION = 'math-function-composition-solver-v1-exact-rational';
exports.FUNCTION_COMPOSITION_SCOPE_VERSION = 'math-hard-function-composition-v1';
exports.FUNCTION_COMPOSITION_SCOPES = ['quadratic_composition_closed_interval_range', 'piecewise_quadratic_interval_range', 'restricted_quadratic_inverse_fraction_domain', 'piecewise_affine_monotonic_parameter'];
exports.FUNCTION_COMPOSITION_CONSTRAINTS = { topicCode: 'M-FUNC-001', boundedIntegerParameters: true, integerInputAbsoluteMax: 12, quadraticScaleAbsoluteMax: 4, maximumConstructionAttempts: 128, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function fq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
    throw Error('zero_denominator'); if (b < 0n) {
    a = -a;
    b = -b;
} let x = a < 0n ? -a : a, y = b; while (y) {
    const t = x % y;
    x = y;
    y = t;
} return { n: a / x, d: b / x }; }
const add = (a, b) => fq(a.n * b.d + b.n * a.d, a.d * b.d), neg = (a) => fq(-a.n, a.d), sub = (a, b) => add(a, neg(b)), mul = (a, b) => fq(a.n * b.n, a.d * b.d), div = (a, b) => fq(a.n * b.d, a.d * b.n);
const cmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0;
const txt = (a) => String(a.n) + (a.d === 1n ? '' : '/' + a.d), valid = (s) => cmp(s.lo, s.hi) < 0 || cmp(s.lo, s.hi) === 0 && s.lc && s.hc;
const segment = (l, r, lc = true, hc = true) => ({ lo: fq(l), hi: fq(r), lc, hc });
function normalizeFunctionSegments(ss) { const out = []; for (const s of ss.filter(valid).map(x => ({ ...x })).sort((x, y) => cmp(x.lo, y.lo) || Number(y.lc) - Number(x.lc))) {
    const p = out[out.length - 1];
    if (!p || cmp(s.lo, p.hi) > 0 || cmp(s.lo, p.hi) === 0 && !p.hc && !s.lc) {
        out.push(s);
        continue;
    }
    const c = cmp(s.hi, p.hi);
    if (c > 0) {
        p.hi = s.hi;
        p.hc = s.hc;
    }
    else if (!c)
        p.hc = p.hc || s.hc;
} return out; }
const functionCompositionIntervalText = (ss) => normalizeFunctionSegments(ss).map(s => (s.lc ? '[' : '(') + txt(s.lo) + ',' + txt(s.hi) + (s.hc ? ']' : ')')).join(' U ') || 'empty';
exports.functionCompositionIntervalText = functionCompositionIntervalText;
function parseFunctionCompositionIntervals(text) { if (text === 'empty')
    return []; if (typeof text !== 'string' || text.length > 400)
    return null; const out = []; for (const t of text.split(' U ')) {
    const m = /^([[(])(-?\d+(?:\/[1-9]\d*)?),\s*(-?\d+(?:\/[1-9]\d*)?)([\])])$/.exec(t);
    if (!m)
        return null;
    const q = (s) => { const [n, d = '1'] = s.split('/'); return fq(BigInt(n), BigInt(d)); };
    const s = { lo: q(m[2]), hi: q(m[3]), lc: m[1] === '[', hc: m[4] === ']' };
    if (!valid(s) || [s.lo, s.hi].some(x => x.n < -1000000n || x.n > 1000000n || x.d > 256n))
        return null;
    out.push(s);
} return out.length <= 2 ? normalizeFunctionSegments(out) : null; }
const contains = (s, x) => (cmp(x, s.lo) > 0 || cmp(x, s.lo) === 0 && s.lc) && (cmp(x, s.hi) < 0 || cmp(x, s.hi) === 0 && s.hc);
function image(a, h, k, s) { const f = (x) => add(mul(fq(a), mul(sub(x, fq(h)), sub(x, fq(h)))), fq(k)); const pairs = [{ v: f(s.lo), closed: s.lc }, { v: f(s.hi), closed: s.hc }, ...(contains(s, fq(h)) ? [{ v: fq(k), closed: true }] : [])]; pairs.sort((x, y) => cmp(x.v, y.v)); const lo = pairs[0].v, hi = pairs[pairs.length - 1].v; return { lo, hi, lc: pairs.some(p => !cmp(p.v, lo) && p.closed), hc: pairs.some(p => !cmp(p.v, hi) && p.closed) }; }
function partition(domain, critical, predicate) { const xs = [domain.lo, ...critical.filter(x => cmp(x, domain.lo) > 0 && cmp(x, domain.hi) < 0), domain.hi].sort(cmp).filter((x, j, a) => !j || cmp(x, a[j - 1])); const out = []; for (let j = 0; j < xs.length; j++) {
    const x = xs[j];
    if (contains(domain, x) && predicate(x))
        out.push({ lo: x, hi: x, lc: true, hc: true });
    if (j + 1 < xs.length && predicate(div(add(x, xs[j + 1]), fq(2))))
        out.push({ lo: x, hi: xs[j + 1], lc: false, hc: false });
} return normalizeFunctionSegments(out); }
const rec = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
function functionCompositionScopeFrom(value) { const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactFunctionCompositionScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 68 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.FUNCTION_COMPOSITION_FAMILY && p?.planTemplate === exports.FUNCTION_COMPOSITION_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.FUNCTION_COMPOSITION_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'function_composition_piecewise_system' && s?.scenarioAction === scope && exports.FUNCTION_COMPOSITION_SCOPES.includes(scope) ? scope : null; }
const square = (v, a, h, k) => '(' + a + ')*(' + v + '-(' + h + '))^2+(' + k + ')';
function functionCompositionPrompt(p, lang) {
    const d = p.data, i = exports.FUNCTION_COMPOSITION_SCOPES.indexOf(p.scope), q = (l, r) => '[' + l + ',' + r + ']';
    const lead = lang === 'zh' ? '以下变量均为实数，区间括号表示端点是否包含。' : 'All variables are real; brackets specify endpoint inclusion. ';
    if (i === 0)
        return lead + 'g(x)=' + square('x', d[0], d[1], d[2]) + '; f(u)=' + square('u', d[3], d[4], d[5]) + '; x in ' + q(d[6], d[7]) + '. ' + (lang === 'zh' ? '求复合函数 f(g(x)) 的全部取值。' : 'Find the full range of f(g(x)).');
    if (i === 1)
        return lead + 'F(x)={' + square('x', d[0], d[1], d[2]) + ' for x in [' + d[6] + ',' + d[7] + '); ' + square('x', d[3], d[4], d[5]) + ' for x in ' + q(d[7], d[8]) + '}. ' + (lang === 'zh' ? '求分段函数 F 的全部取值。' : 'Find the full range of the piecewise function F.');
    if (i === 2)
        return lead + 'f(u)=' + square('u', d[0], d[1], d[2]) + ' restricted to u in ' + q(d[3], d[4]) + '; g(x)=((' + d[5] + ')*x+(' + d[6] + '))/(x-(' + d[7] + ')); x in ' + q(d[8], d[9]) + '. ' + (lang === 'zh' ? '求反函数复合 f^(-1)(g(x)) 的定义域。' : 'Find the domain of the inverse composition f^(-1)(g(x)).');
    return lead + 'F_t(x)={((' + d[0] + ')*t+(' + d[1] + '))*x+(' + d[2] + ') for x in [' + d[6] + ',' + d[7] + '); ((' + d[3] + ')*t+(' + d[4] + '))*x+(' + d[5] + ') for x in ' + q(d[7], d[8]) + '}; t in ' + q(d[9], d[10]) + '. ' + (lang === 'zh' ? '求使 F_t 在整个区间严格' + (d[11] === 1 ? '递增' : '递减') + '的全部 t。' : 'Find all t making F_t strictly ' + (d[11] === 1 ? 'increasing' : 'decreasing') + ' on the whole interval.');
}
function functionCompositionParametersValid(p) {
    const d = p.data, i = exports.FUNCTION_COMPOSITION_SCOPES.indexOf(p.scope);
    if (i < 0 || d.length !== [8, 9, 10, 12][i] || !d.every((x, j) => Number.isInteger(x) && Math.abs(x) <= (i === 0 && j === 4 ? 64 : 12)))
        return false;
    const scale = (a) => a !== 0 && Math.abs(a) <= 4, vertex = (h) => Math.abs(h) <= 6;
    if (i === 0) {
        const [a, h, k, b, v, , l, r] = d;
        if (!scale(a) || !scale(b) || !vertex(h) || !(l < h && h < r))
            return false;
        const inner = image(a, h, k, segment(l, r)), n = fq(v - k, a);
        if (cmp(fq(v), inner.lo) <= 0 || cmp(fq(v), inner.hi) >= 0 || n.n <= 0n)
            return false;
        const sn = BigInt(Math.floor(Math.sqrt(Number(n.n)))), sd = BigInt(Math.floor(Math.sqrt(Number(n.d))));
        return sn * sn === n.n && sd * sd === n.d && sd <= 16n && ([sub(fq(h), fq(sn, sd)), add(fq(h), fq(sn, sd))].some(x => cmp(x, fq(l)) > 0 && cmp(x, fq(r)) < 0));
    }
    if (i === 1)
        return scale(d[0]) && scale(d[3]) && vertex(d[1]) && vertex(d[4]) && d[6] < d[7] && d[7] < d[8];
    if (i === 2)
        return scale(d[0]) && vertex(d[1]) && d[3] < d[4] && (d[4] <= d[1] || d[3] >= d[1]) && d[5] * d[7] + d[6] !== 0 && d[8] < d[9];
    return d[0] !== 0 && d[3] !== 0 && d[6] < d[7] && d[7] < d[8] && d[9] < d[10] && [1, -1].includes(d[11]);
}
function functionCompositionParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1800)
        return null;
    const i = exports.FUNCTION_COMPOSITION_SCOPES.indexOf(scope);
    const sq = '\\((-?\\d+)\\)\\*\\([xu]-\\((-?\\d+)\\)\\)\\^2\\+\\((-?\\d+)\\)';
    let m, d;
    if (i === 0) {
        m = new RegExp('g\\(x\\)=' + sq + '; f\\(u\\)=' + sq + '; x in \\[(-?\\d+),(-?\\d+)\\]').exec(text);
        if (!m)
            return null;
        d = m.slice(1).map(Number);
    }
    else if (i === 1) {
        m = new RegExp('F\\(x\\)=\\{' + sq + ' for x in \\[(-?\\d+),(-?\\d+)\\); ' + sq + ' for x in \\[(-?\\d+),(-?\\d+)\\]').exec(text);
        if (!m || m[5] !== m[9])
            return null;
        d = [...m.slice(1, 4), ...m.slice(6, 9), m[4], m[5], m[10]].map(Number);
    }
    else if (i === 2) {
        m = new RegExp('f\\(u\\)=' + sq + ' restricted to u in \\[(-?\\d+),(-?\\d+)\\]; g\\(x\\)=\\(\\((-?\\d+)\\)\\*x\\+\\((-?\\d+)\\)\\)\\/\\(x-\\((-?\\d+)\\)\\); x in \\[(-?\\d+),(-?\\d+)\\]').exec(text);
        if (!m)
            return null;
        d = m.slice(1).map(Number);
    }
    else {
        m = /F_t\(x\)=\{\(\((-?\d+)\)\*t\+\((-?\d+)\)\)\*x\+\((-?\d+)\) for x in \[(-?\d+),(-?\d+)\); \(\((-?\d+)\)\*t\+\((-?\d+)\)\)\*x\+\((-?\d+)\) for x in \[(-?\d+),(-?\d+)\]\}; t in \[(-?\d+),(-?\d+)\]/.exec(text);
        if (!m || m[5] !== m[9])
            return null;
        d = [...m.slice(1, 4), ...m.slice(6, 9), m[4], m[5], m[10], m[11], m[12]].map(Number);
        d.push(/严格递增|strictly increasing/.test(text) ? 1 : -1);
    }
    const p = { scope, data: d };
    return functionCompositionParametersValid(p) && functionCompositionPrompt(p, lang) === text ? p : null;
}
function functionCompositionDerive(p) {
    if (!functionCompositionParametersValid(p))
        return null;
    const d = p.data, i = exports.FUNCTION_COMPOSITION_SCOPES.indexOf(p.scope);
    let result, relaxed = [], steps = [];
    const fmt = exports.functionCompositionIntervalText;
    if (i === 0) {
        const [a, h, k, b, v, w, l, r] = d, inner = image(a, h, k, segment(l, r));
        result = [image(b, v, w, inner)];
        const evalQ = (a, h, k, x) => a * (x - h) ** 2 + k;
        const ends = [evalQ(b, v, w, evalQ(a, h, k, l)), evalQ(b, v, w, evalQ(a, h, k, r))];
        relaxed = [[segment(Math.min(...ends), Math.max(...ends))], [image(b, v, w, segment(l, r))]];
        steps = ['g(' + l + ')=' + evalQ(a, h, k, l), 'g(' + r + ')=' + evalQ(a, h, k, r), 'g(D)=' + fmt([inner]), 'f vertex u=' + v + ', f(u)=' + w, 'f(g(D))=' + fmt(result)];
    }
    else if (i === 1) {
        const [a, h, k, b, v, w, l, c, r] = d, x = image(a, h, k, segment(l, c, true, false)), y = image(b, v, w, segment(c, r));
        result = normalizeFunctionSegments([x, y]);
        relaxed = [[x], [y]];
        steps = ['left domain=[' + l + ',' + c + ')', 'left image=' + fmt([x]), 'right domain=[' + c + ',' + r + ']', 'right image=' + fmt([y]), 'union=' + fmt(result)];
    }
    else if (i === 2) {
        const [a, h, k, jl, jr, b, q, pole, l, r] = d, allowed = image(a, h, k, segment(jl, jr));
        const roots = [allowed.lo, allowed.hi].flatMap(y => cmp(fq(b), y) ? [div(add(mul(y, fq(pole)), fq(q)), sub(y, fq(b)))] : []);
        const predicate = (x) => { if (!cmp(x, fq(pole)))
            return false; return contains(allowed, div(add(mul(fq(b), x), fq(q)), sub(x, fq(pole)))); };
        result = partition(segment(l, r), [fq(pole), ...roots], predicate);
        relaxed = [partition(segment(l, r), [fq(pole)], x => !!cmp(x, fq(pole))), partition(segment(-24, 24), [fq(pole), ...roots], predicate)];
        steps = ['inverse exists on [' + jl + ',' + jr + ']', 'domain(f^-1)=' + fmt([allowed]), 'g(x) in ' + fmt([allowed]) + '; x!=' + pole, 'critical x=' + roots.map(txt).join(','), 'intersect [' + l + ',' + r + ']=' + fmt(result)];
    }
    else {
        const [a, b, c, A, B, C, l, m, r, tl, tr, dir] = d;
        const forms = [[a * dir, b * dir, true], [A * dir, B * dir, true], [(A - a) * m * dir, ((B - b) * m + C - c) * dir, false]];
        const roots = forms.flatMap(([s, k]) => s ? [fq(-k, s)] : []);
        const solve = (omit) => partition(segment(tl, tr), roots, t => forms.every(([s, k, strict], j) => j === omit || (strict ? cmp(add(mul(fq(s), t), fq(k)), fq(0)) > 0 : cmp(add(mul(fq(s), t), fq(k)), fq(0)) >= 0)));
        result = solve(-1);
        relaxed = forms.map((_, j) => solve(j));
        steps = ['left slope sign: ' + a + 't+(' + b + ')', 'right slope sign: ' + A + 't+(' + B + ')', 'jump at ' + m + ': (' + forms[2][0] + ')t+(' + forms[2][1] + ')>=0', 'direction=' + dir + '; T=[' + tl + ',' + tr + ']', 'joint=' + fmt(result)];
    }
    const answer = fmt(result), effective = relaxed.map(x => ({ relaxedSet: fmt(x), witnessSet: fmt(x) === answer ? 'empty' : 'symmetric difference between ' + fmt(x) + ' and ' + answer })).filter(x => x.witnessSet !== 'empty');
    if (!result.length || result.length > 2 || result.some(x => cmp(x.lo, x.hi) === 0) || effective.length < 2 || !parseFunctionCompositionIntervals(answer))
        return null;
    const flip = (first) => { const copy = result.map(x => ({ ...x })); if (first)
        copy[0].lc = !copy[0].lc;
    else
        copy[copy.length - 1].hc = !copy[copy.length - 1].hc; return fmt(copy); };
    const reflected = fmt(result.map(x => ({ lo: neg(x.hi), hi: neg(x.lo), lc: x.hc, hc: x.lc })));
    const errors = [{ intent: 'reverse_lower_endpoint_attainment', text: flip(true) }, { intent: 'reverse_upper_endpoint_attainment', text: flip(false) }, { intent: 'reverse_output_or_parameter_sign', text: reflected }].map(e => ({ ...e, key: e.text }));
    if (new Set([answer, ...errors.map(e => e.key)]).size !== 4)
        return null;
    const proof = 'parameters=' + d.join(',') + '; ' + steps.join('; '), hardEvidence = { version: 'function-composition-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 3, reasoningSteps: 4, quantitativeRelations: 2, effectiveConstraints: effective, sourceSet: steps[0], domain: steps[steps.length - 2], answer, visibleProof: proof, studentCalibrated: false };
    return { answer, text: answer, errors, proof, hardEvidence };
}
function solveSubjectPracticeMathFunctionComposition(candidate, context = {}) { const scope = functionCompositionScopeFrom(context.questionPlan), parameters = functionCompositionParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? functionCompositionDerive(parameters) : null, reasonCodes = []; if (!d)
    reasonCodes.push('function_composition_outside_hard_scope'); if (candidate.subject !== 'math' || candidate.topicId !== 68 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
    reasonCodes.push('function_composition_identity'); const options = candidate.options ?? [], keys = options.map(o => { const a = parseFunctionCompositionIntervals(o.text); return a ? (0, exports.functionCompositionIntervalText)(a) : null; }); if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
    reasonCodes.push('function_composition_options'); for (const lang of ['zh', 'en']) {
    const l = candidate.localizations?.[lang];
    if (!parameters || JSON.stringify(functionCompositionParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
        reasonCodes.push('function_composition_' + lang + '_stem');
    if (JSON.stringify(l?.options?.map(o => { const a = parseFunctionCompositionIntervals(o.text); return [o.id, a ? (0, exports.functionCompositionIntervalText)(a) : null]; })) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
        reasonCodes.push('function_composition_' + lang + '_options');
} const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null; if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('function_composition_answer'); const meta = candidate.optionMetadata ?? []; if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
    reasonCodes.push('function_composition_error_intent'); const scopeId = parameters ? exports.FUNCTION_COMPOSITION_SCOPE_VERSION + ':' + scope : null; return { solverVersion: exports.FUNCTION_COMPOSITION_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.FUNCTION_COMPOSITION_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.FUNCTION_COMPOSITION_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['function_composition_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
