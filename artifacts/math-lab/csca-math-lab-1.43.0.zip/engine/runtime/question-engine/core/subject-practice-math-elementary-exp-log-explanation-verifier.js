"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ELEMENTARY_EXP_LOG_EXPLANATION_VERSION = void 0;
exports.renderElementaryExpLogExplanation = renderElementaryExpLogExplanation;
exports.verifySubjectPracticeMathElementaryExpLogExplanation = verifySubjectPracticeMathElementaryExpLogExplanation;
const subject_practice_math_elementary_exp_log_solver_1 = require("./subject-practice-math-elementary-exp-log-solver");
exports.ELEMENTARY_EXP_LOG_EXPLANATION_VERSION = 'math-elementary-exp-log-explanation-v1-bound-bilingual';
function renderElementaryExpLogExplanation(p, answer, option) {
    let proof = 'b=' + (0, subject_practice_math_elementary_exp_log_solver_1.elBase)(p) + '; a=' + p.a + '; c=' + p.c + '; affine=' + (0, subject_practice_math_elementary_exp_log_solver_1.elAffine)(p);
    if (p.scope === subject_practice_math_elementary_exp_log_solver_1.ELEMENTARY_EXP_LOG_SCOPES[0])
        proof += '; (b^' + p.k + ')^(' + p.r + ')=b^(' + p.k * p.r + ')'
            + '; ' + (0, subject_practice_math_elementary_exp_log_solver_1.elAffine)(p) + '=' + p.k * p.r + '; x=(' + p.k * p.r + '-(' + p.c + '))/(' + p.a + ')=' + answer
            + '; substitution: ' + p.a + '*(' + answer + ')+(' + p.c + ')=' + p.k * p.r + '; b>0,b!=1:injective';
    else if (p.scope === subject_practice_math_elementary_exp_log_solver_1.ELEMENTARY_EXP_LOG_SCOPES[2])
        proof += '; d=' + p.d + '; interval=[' + p.l + ', ' + p.u + ']'
            + '; direction=' + ((p.a > 0) !== p.reciprocal ? 'increasing' : 'decreasing')
            + '; exponent(' + p.l + ')=' + (p.a * p.l + p.c) + '; exponent(' + p.u + ')=' + (p.a * p.u + p.c)
            + '; f(' + p.l + ')=' + (0, subject_practice_math_elementary_exp_log_solver_1.elShow)((0, subject_practice_math_elementary_exp_log_solver_1.elAdd)((0, subject_practice_math_elementary_exp_log_solver_1.elPower)(p, p.a * p.l + p.c), (0, subject_practice_math_elementary_exp_log_solver_1.elRat)(p.d)))
            + '; f(' + p.u + ')=' + (0, subject_practice_math_elementary_exp_log_solver_1.elShow)((0, subject_practice_math_elementary_exp_log_solver_1.elAdd)((0, subject_practice_math_elementary_exp_log_solver_1.elPower)(p, p.a * p.u + p.c), (0, subject_practice_math_elementary_exp_log_solver_1.elRat)(p.d))) + '; continuous=true; both_endpoints_attained=true';
    else {
        const threshold = (0, subject_practice_math_elementary_exp_log_solver_1.elShow)((0, subject_practice_math_elementary_exp_log_solver_1.elPower)(p, p.r)), zero = (0, subject_practice_math_elementary_exp_log_solver_1.elShow)((0, subject_practice_math_elementary_exp_log_solver_1.elRat)(-p.c, p.a)), root = (0, subject_practice_math_elementary_exp_log_solver_1.elShow)((0, subject_practice_math_elementary_exp_log_solver_1.elThreshold)(p));
        proof += '; domain: ' + (0, subject_practice_math_elementary_exp_log_solver_1.elAffine)(p) + '>0; x' + (p.a > 0 ? '>' : '<') + zero
            + '; b^(' + p.r + ')=' + threshold + '; threshold_x=(' + threshold + '-(' + p.c + '))/(' + p.a + ')=' + root;
        if (p.scope === subject_practice_math_elementary_exp_log_solver_1.ELEMENTARY_EXP_LOG_SCOPES[1])
            proof += '; ' + (0, subject_practice_math_elementary_exp_log_solver_1.elAffine)(p) + '=' + threshold
                + '; substitution: ' + p.a + '*(' + root + ')+(' + p.c + ')=' + threshold + '>0';
        else
            proof += '; log_relation=' + p.op + p.r + '; base_direction=' + (p.reciprocal ? 'decreasing' : 'increasing')
                + '; argument_relation=' + (p.op.startsWith('>') !== p.reciprocal ? '>' : '<') + (p.op.endsWith('=') ? '=' : '') + threshold
                + '; divide_by_a=' + p.a + '; reverse_on_negative_a=' + (p.a < 0) + '; intersect_positive_argument_domain=true'
                + '; zero=' + zero + ':excluded; threshold=' + root + ':' + (p.op.endsWith('=') ? 'included' : 'excluded');
    }
    proof += '; result=' + answer;
    return { zh: '先确定定义条件和转换关系，再用精确运算检验结论：' + proof + '。对应选项 ' + option + '。',
        en: 'Establish the domain and transformation, then check the conclusion using exact arithmetic: ' + proof + '. Option ' + option + '.' };
}
function verifySubjectPracticeMathElementaryExpLogExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_elementary_exp_log_solver_1.solveSubjectPracticeMathElementaryExpLog)(candidate, context), p = solved.parameters;
    const expected = p && solved.expectedAnswer && solved.selectedOptionId ? renderElementaryExpLogExplanation(p, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh);
    const enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('elementary_exp_log_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('elementary_exp_log_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('elementary_exp_log_explanation_en_mismatch');
    return { verifierVersion: exports.ELEMENTARY_EXP_LOG_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified',
        scopeId: solved.scopeId, zhBound, enBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
