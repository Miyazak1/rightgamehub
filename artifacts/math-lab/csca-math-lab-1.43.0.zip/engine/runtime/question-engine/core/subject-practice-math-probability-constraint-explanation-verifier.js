"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROBABILITY_CONSTRAINT_EXPLANATION_VERSION = void 0;
exports.renderProbabilityConstraintExplanation = renderProbabilityConstraintExplanation;
exports.verifySubjectPracticeMathProbabilityConstraintExplanation = verifySubjectPracticeMathProbabilityConstraintExplanation;
const subject_practice_math_probability_constraint_solver_1 = require("./subject-practice-math-probability-constraint-solver");
exports.PROBABILITY_CONSTRAINT_EXPLANATION_VERSION = 'math-probability-constraint-explanation-v1-bound-bilingual';
function renderProbabilityConstraintExplanation(p, answer, option) {
    const d = (0, subject_practice_math_probability_constraint_solver_1.probabilityConstraintDerive)(p);
    if (!d || d.answer !== answer)
        throw Error('geometry_explanation_parameters');
    const i = subject_practice_math_probability_constraint_solver_1.PROBABILITY_CONSTRAINT_SCOPES.indexOf(p.scope);
    const zh = ["先确定无放回等可能有序样本数，选择互不相邻的红球位置，再给各位置分配带编号的球，合并计数求概率。", "按三色出现次数作互斥分类，减去首尾同色排列，再分配各色球编号，以完整样本空间为分母。", "分别计算两盒样本空间，按红球数分配 (1,2) 和 (2,1) 分情况，利用独立性相乘再相加。", "按最小和最大编号分类，结合和的上下界约束中间编号，再按奇偶性计数；各类互斥，用全部三张卡片组合数作分母。"], en = ["Count the uniform ordered sample space without replacement. Select separated red positions, assign distinct ball labels, and divide the favorable count by the full total.", "Partition by positive color occupancies. Subtract equal-endpoint arrangements, assign distinct labels, and divide by the complete sample space.", "Count each box sample space. Split the red allocation into (1,2) and (2,1), multiply by independence within each case, then add the disjoint cases.", "Partition by the minimum and maximum card. Bound the middle card using both sum limits, count the required parity, and divide by all three-card subsets."];
    return { zh: zh[i] + ' 本题给定参数依次为(' + p.data.join(',') + ')，逐步代入：' + d.steps.join('；') + '。故所求值为 ' + answer + '，选' + option + '。', en: en[i] + ' Given values in this problem are (' + p.data.join(',') + '). Explicit substitutions: ' + d.steps.join('; ') + '. The requested value is ' + answer + '; choose ' + option + '.' };
}
function verifySubjectPracticeMathProbabilityConstraintExplanation(candidate, context = {}) { const s = (0, subject_practice_math_probability_constraint_solver_1.solveSubjectPracticeMathProbabilityConstraint)(candidate, context), e = s.status === 'verified' && s.parameters && s.expectedAnswer && s.selectedOptionId ? renderProbabilityConstraintExplanation(s.parameters, s.expectedAnswer, s.selectedOptionId) : null, zhBound = !!e && candidate.explanation === e.zh && candidate.localizations?.zh?.explanation === e.zh, enBound = !!e && candidate.localizations?.en?.explanation === e.en, reasonCodes = zhBound && enBound ? [] : ['probability_constraint_explanation_not_bound']; return { verifierVersion: exports.PROBABILITY_CONSTRAINT_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: s.scopeId, zhBound, enBound, hardEvidence: s.hardEvidence, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' }; }
