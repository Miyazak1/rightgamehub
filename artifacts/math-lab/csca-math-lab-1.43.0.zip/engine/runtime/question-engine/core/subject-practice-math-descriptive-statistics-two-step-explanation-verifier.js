"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_TWO_STEP_EXPLANATION_VERSION = void 0;
exports.renderStatisticsTwoStepExplanation = renderStatisticsTwoStepExplanation;
exports.verifySubjectPracticeMathStatisticsTwoStepExplanation = verifySubjectPracticeMathStatisticsTwoStepExplanation;
const subject_practice_math_descriptive_statistics_two_step_solver_1 = require("./subject-practice-math-descriptive-statistics-two-step-solver");
exports.STATISTICS_TWO_STEP_EXPLANATION_VERSION = 'math-descriptive-statistics-two-step-explanation-v1-bound-bilingual';
function renderStatisticsTwoStepExplanation(p, answer, option) {
    const d = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepDerive)(p);
    if (!d)
        throw Error('statistics_two_step_invalid_explanation_parameters');
    const isMean = p.scope === 'missing_frequency_from_total_to_weighted_mean';
    return { zh: (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepPrompt)(p, 'zh') + ' 先用给定约束解出唯一未知数，然后按完整数据计算。' + (isMean ? '各数值按频数计入，总和除以总频数。' : '总体方差等于平方的平均数减去平均数的平方，不使用 n-1。') + ' ' + d.proof + '; result=' + answer + '。对应选项 ' + option + '。',
        en: (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepPrompt)(p, 'en') + ' Solve the constraint for the unique unknown, then calculate using the completed data. ' + (isMean ? 'Repeat each value by its frequency and divide the total by the total frequency.' : 'Population variance is the mean of squares minus the square of the mean; do not use n-1.') + ' ' + d.proof + '; result=' + answer + '. Option ' + option + '.' };
}
function verifySubjectPracticeMathStatisticsTwoStepExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.solveSubjectPracticeMathStatisticsTwoStep)(candidate, context), expected = solved.parameters && solved.expectedAnswer && solved.selectedOptionId ? renderStatisticsTwoStepExplanation(solved.parameters, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh), enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('statistics_two_step_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('statistics_two_step_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('statistics_two_step_explanation_en_mismatch');
    return { verifierVersion: exports.STATISTICS_TWO_STEP_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solved.scopeId, zhBound, enBound, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
