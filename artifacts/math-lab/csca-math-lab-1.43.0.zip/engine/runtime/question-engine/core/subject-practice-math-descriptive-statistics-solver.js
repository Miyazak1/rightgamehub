"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_TARGETS = exports.MATH_DESCRIPTIVE_STATISTICS_SCOPES = exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_SOLVER_VERSION = void 0;
exports.statisticsRational = statisticsRational;
exports.statisticsRationalText = statisticsRationalText;
exports.statisticsScopeFrom = statisticsScopeFrom;
exports.statisticsDataFrom = statisticsDataFrom;
exports.statisticsValue = statisticsValue;
exports.parseStatisticsOption = parseStatisticsOption;
exports.solveSubjectPracticeMathDescriptiveStatistics = solveSubjectPracticeMathDescriptiveStatistics;
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_SOLVER_VERSION = 'math-descriptive-statistics-solver-v1-exact-rational';
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_SCOPE_VERSION = 'math-descriptive-statistics-scope-v1';
exports.MATH_DESCRIPTIVE_STATISTICS_SCOPES = ['arithmetic_mean', 'median', 'population_variance', 'population_standard_deviation'];
function statisticsRational(numerator, denominator = 1) {
    if (!Number.isSafeInteger(numerator) || !Number.isSafeInteger(denominator) || denominator <= 0)
        throw new Error('statistics_invalid_rational');
    let a = Math.abs(numerator), b = denominator;
    while (b) {
        const r = a % b;
        a = b;
        b = r;
    }
    return { numerator: numerator / a, denominator: denominator / a };
}
function statisticsRationalText(value) {
    return value.denominator === 1 ? String(value.numerator) : `${value.numerator}/${value.denominator}`;
}
function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function statisticsScopeFrom(value) {
    const plan = object(value), r = object(plan?.renderConstraints), scope = r?.exactStatisticsScope;
    return plan?.subject === 'math' && plan?.targetDifficulty === 'basic'
        && plan?.taskFamily === 'math_descriptive_statistics_direct_calculation'
        && plan?.planTemplate === 'math_descriptive_statistics_direct_calculation_v1'
        && r?.minimumDataCount === 3 && r?.maximumDataCount === 8 && r?.minimumDataValue === -20 && r?.maximumDataValue === 50
        && r?.integerParametersRequired === true && r?.oneDirectStatisticTarget === true && r?.externalContextAllowed === false
        && r?.varianceDenominator === 'n' && r?.standardDeviationPerfectSquareRequired === true
        && r?.finalAnswerShape === 'one_unique_exact_rational'
        && exports.MATH_DESCRIPTIVE_STATISTICS_SCOPES.includes(scope) ? scope : null;
}
exports.STATISTICS_TARGETS = {
    arithmetic_mean: ['算术平均数', 'arithmetic mean'], median: ['中位数', 'median'],
    population_variance: ['总体方差（分母为 n）', 'population variance (denominator n)'],
    population_standard_deviation: ['总体标准差（方差的分母为 n）', 'population standard deviation (variance denominator n)']
};
// A closed bilingual grammar binds the whole visible task, not just a few numbers.
function statisticsDataFrom(text, scope, language) {
    if (!scope)
        return null;
    const pattern = language === 'zh'
        ? /^(?:给定以下数据|一组观测数据为)：\[(-?\d+(?:, -?\d+){2,7})\]，共 n=(\d+) 个数。求这组数据的(.+)。$/
        : /^(?:The data are|A dataset contains) \[(-?\d+(?:, -?\d+){2,7})\], with n=(\d+) values\. Find the (.+) of this dataset\.$/;
    const m = String(text ?? '').match(pattern);
    if (!m || m[3] !== exports.STATISTICS_TARGETS[scope][language === 'zh' ? 0 : 1])
        return null;
    const data = m[1].split(', ').map(Number);
    return data.length === Number(m[2]) && data.every(x => Number.isInteger(x) && x >= -20 && x <= 50) ? data : null;
}
function statisticsValue(data, scope) {
    const n = data.length, sum = data.reduce((a, b) => a + b, 0);
    if (scope === 'arithmetic_mean')
        return statisticsRational(sum, n);
    if (scope === 'median') {
        const sorted = [...data].sort((a, b) => a - b), middle = Math.floor(n / 2);
        return n % 2 ? statisticsRational(sorted[middle]) : statisticsRational(sorted[middle - 1] + sorted[middle], 2);
    }
    // Sum exact squared deviations without a floating-point mean.
    const variance = statisticsRational(data.reduce((s, x) => s + (n * x - sum) ** 2, 0), n ** 3);
    if (scope === 'population_variance')
        return variance;
    if (variance.denominator !== 1)
        return null;
    const root = Math.sqrt(variance.numerator);
    return Number.isSafeInteger(root) ? statisticsRational(root) : null;
}
function parseStatisticsOption(text) {
    const m = String(text ?? '').match(/^(-?(?:0|[1-9]\d{0,8}))(?:\/([1-9]\d{0,5}))?$/);
    if (!m)
        return null;
    return statisticsRational(Number(m[1]), Number(m[2] ?? 1));
}
function solveSubjectPracticeMathDescriptiveStatistics(candidate, context = {}) {
    const exactScope = statisticsScopeFrom(context.questionPlan), parameters = statisticsDataFrom(candidate.prompt, exactScope, 'zh');
    const expectedValue = parameters && exactScope ? statisticsValue(parameters, exactScope) : null;
    const parsed = expectedValue !== null, reasonCodes = [];
    if (!parsed)
        reasonCodes.push('math_descriptive_statistics_prompt_or_plan_outside_scope');
    if (candidate.subject !== 'math' || candidate.questionType !== 'single_choice' || candidate.designedDifficulty !== 'basic')
        reasonCodes.push('math_descriptive_statistics_identity_mismatch');
    for (const lang of ['zh', 'en']) {
        const translated = statisticsDataFrom(candidate.localizations?.[lang]?.prompt ?? '', exactScope, lang);
        if (!translated || JSON.stringify(translated) !== JSON.stringify(parameters))
            reasonCodes.push(`math_descriptive_statistics_${lang}_parameters_or_target_mismatch`);
        if (JSON.stringify(candidate.localizations?.[lang]?.options) !== JSON.stringify(candidate.options))
            reasonCodes.push(`math_descriptive_statistics_${lang}_options_mismatch`);
    }
    const options = candidate.options ?? [];
    const optionVerdicts = options.map(o => {
        const value = parseStatisticsOption(o.text);
        return { optionId: o.id, semanticValue: value, verdict: !value ? 'unknown' : JSON.stringify(value) === JSON.stringify(expectedValue) ? 'true' : 'false' };
    });
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !'ABCD'.split('').includes(o.id))
        || optionVerdicts.some(o => o.verdict === 'unknown') || new Set(optionVerdicts.map(o => JSON.stringify(o.semanticValue))).size !== 4)
        reasonCodes.push('math_descriptive_statistics_invalid_or_duplicate_options');
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_descriptive_statistics_answer_not_unique');
    if (selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_descriptive_statistics_generator_disagreement');
    const scopeId = parsed ? `math-basic-descriptive-statistics-v1:${exactScope}` : null;
    return { solverVersion: exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_SOLVER_VERSION,
        status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_descriptive_statistics_direct_calculation', scopeId, exactScope, parameters, expectedValue,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['math_descriptive_statistics_scope_not_matched'] },
        optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
