"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_TWO_STEP_CONSTRAINTS = exports.STATISTICS_TWO_STEP_SCOPES = exports.STATISTICS_TWO_STEP_SCOPE_VERSION = exports.STATISTICS_TWO_STEP_SOLVER_VERSION = exports.STATISTICS_TWO_STEP_TEMPLATE = exports.STATISTICS_TWO_STEP_FAMILY = void 0;
exports.statisticsTwoStepScopeFrom = statisticsTwoStepScopeFrom;
exports.statisticsTwoStepFraction = statisticsTwoStepFraction;
exports.statisticsTwoStepOptionKey = statisticsTwoStepOptionKey;
exports.statisticsTwoStepPrompt = statisticsTwoStepPrompt;
exports.statisticsTwoStepDerive = statisticsTwoStepDerive;
exports.statisticsTwoStepParametersFrom = statisticsTwoStepParametersFrom;
exports.statisticsTwoStepDistractors = statisticsTwoStepDistractors;
exports.solveSubjectPracticeMathStatisticsTwoStep = solveSubjectPracticeMathStatisticsTwoStep;
exports.STATISTICS_TWO_STEP_FAMILY = 'math_descriptive_statistics_two_step_calculation';
exports.STATISTICS_TWO_STEP_TEMPLATE = exports.STATISTICS_TWO_STEP_FAMILY + '_v1';
exports.STATISTICS_TWO_STEP_SOLVER_VERSION = 'math-descriptive-statistics-two-step-solver-v1-exact-rational';
exports.STATISTICS_TWO_STEP_SCOPE_VERSION = 'math-medium-descriptive-statistics-two-step-v1';
exports.STATISTICS_TWO_STEP_SCOPES = [
    'missing_value_from_mean_to_population_variance', 'missing_frequency_from_total_to_weighted_mean',
    'missing_frequency_from_mean_to_population_variance', 'affine_mean_constraint_to_population_variance'
];
exports.STATISTICS_TWO_STEP_CONSTRAINTS = {
    topicCode: 'M-STAT-001', boundedIntegerParameters: true, dataCountMin: 3, dataCountMax: 8,
    dataValueMin: -10, dataValueMax: 20, frequencyMin: 1, frequencyMax: 6, frequencyTableTotalMax: 18,
    affineShiftMin: -10, affineShiftMax: 10, transformedValueAbsoluteMax: 70,
    exactRationalArithmetic: true, populationDenominator: 'n', minimumVisibleMoves: 2,
    inferredUnknownMustBeUnique: true, externalContextAllowed: false, requiresImage: false
};
const record = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function statisticsTwoStepScopeFrom(value) {
    const p = record(value), r = record(p?.renderConstraints), s = record(p?.scenarioContract), scope = r?.exactStatisticsTwoStepScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 76 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === exports.STATISTICS_TWO_STEP_FAMILY && p?.planTemplate === exports.STATISTICS_TWO_STEP_TEMPLATE
        && r?.questionType === 'single_choice' && Object.entries(exports.STATISTICS_TWO_STEP_CONSTRAINTS).every(([k, v]) => r?.[k] === v)
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'bounded_two_step_statistics_object' && s?.scenarioAction === scope
        && exports.STATISTICS_TWO_STEP_SCOPES.includes(scope) ? scope : null;
}
function statisticsTwoStepFraction(n, d = 1) {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || d === 0)
        return null;
    if (d < 0) {
        n = -n;
        d = -d;
    }
    let a = Math.abs(n), b = d;
    while (b) {
        const t = a % b;
        a = b;
        b = t;
    }
    return d / a === 1 ? String(n / a) : `${n / a}/${d / a}`;
}
function statisticsTwoStepOptionKey(text) {
    const m = typeof text === 'string' ? /^(-?\d{1,8})(?:\/([1-9]\d{0,8}))?$/.exec(text.trim()) : null;
    return m ? statisticsTwoStepFraction(+m[1], +(m[2] ?? 1)) : null;
}
const pair = (s) => s.split('/').map(Number).concat(1).slice(0, 2);
const sum = (v) => v.reduce((a, b) => a + b, 0);
function statisticsTwoStepPrompt(p, lang) {
    const v = p.values.join(','), f = p.frequencies.join(','), i = exports.STATISTICS_TWO_STEP_SCOPES.indexOf(p.scope);
    if (i === 0)
        return lang === 'zh'
            ? `数据为 [${v},t]，其中 t 是 [-10,20] 内的整数，平均数为 ${p.known}。先确定 t，再求这组数据的总体方差（分母为数据总数 n）。`
            : `The data are [${v},t], where t is an integer in [-10,20], and their mean is ${p.known}. Determine t, then find the population variance (denominator: the total count n).`;
    if (i === 1 || i === 2)
        return lang === 'zh'
            ? `三个不同数值为 [${v}]，对应频数为 [${f},k]，其中 k 是 [1,6] 内的整数，${i === 1 ? '总频数' : '平均数'}为 ${p.known}。先确定 k，再求${i === 1 ? '加权平均数' : '总体方差（分母为总频数 n）'}。`
            : `Three distinct values are [${v}], with respective frequencies [${f},k], where k is an integer in [1,6], and the ${i === 1 ? 'total frequency' : 'mean'} is ${p.known}. Determine k, then find the ${i === 1 ? 'weighted mean' : 'population variance (denominator: the total frequency n)'}.`;
    return lang === 'zh'
        ? `原数据 x 为 [${v}]。令 y=a*x+b，其中 b=${p.shift}，a 是集合 {-3,-2,-1,1,2,3} 中的未知数，y 的平均数为 ${p.known}。先确定 a，再求 y 的总体方差（分母为数据总数 n）。`
        : `The original x data are [${v}]. Let y=a*x+b, where b=${p.shift}, a is unknown in {-3,-2,-1,1,2,3}, and the mean of y is ${p.known}. Determine a, then find the population variance of y (denominator: the total count n).`;
}
function statisticsTwoStepDerive(p) {
    const i = exports.STATISTICS_TWO_STEP_SCOPES.indexOf(p.scope), v = p.values, f = p.frequencies;
    if (i < 0 || !v.every(x => Number.isInteger(x) && x >= -10 && x <= 20) || !Number.isInteger(p.shift) || p.shift < -10 || p.shift > 10
        || statisticsTwoStepOptionKey(p.known) !== p.known || (i !== 3 && p.shift !== 0))
        return null;
    const [kn, kd] = pair(p.known);
    let unknown, data, inference;
    if (i === 0) {
        if (v.length < 2 || v.length > 7 || f.length)
            return null;
        unknown = (kn * (v.length + 1) - sum(v) * kd) / kd;
        if (!Number.isInteger(unknown) || unknown < -10 || unknown > 20)
            return null;
        data = [...v, unknown];
        inference = `t=(${kn}*${data.length}-${sum(v)}*${kd})/${kd}=${unknown}`;
    }
    else if (i === 1 || i === 2) {
        if (v.length !== 3 || new Set(v).size !== 3 || f.length !== 2 || !f.every(x => Number.isInteger(x) && x >= 1 && x <= 6))
            return null;
        const n0 = sum(f), w0 = v[0] * f[0] + v[1] * f[1];
        if (i === 1) {
            if (kd !== 1)
                return null;
            unknown = kn - n0;
            inference = `k=${kn}-(${f[0]}+${f[1]})=${unknown}`;
        }
        else {
            const denominator = kd * v[2] - kn;
            if (!denominator)
                return null;
            unknown = (kn * n0 - kd * w0) / denominator;
            inference = `k=(${kn}*${n0}-${kd}*${w0})/(${kd}*${v[2]}-${kn})=${unknown}`;
        }
        if (!Number.isInteger(unknown) || unknown < 1 || unknown > 6)
            return null;
        data = v.flatMap((x, j) => Array(f.concat(unknown)[j]).fill(x));
    }
    else {
        if (v.length < 3 || v.length > 8 || f.length || sum(v) === 0 || new Set(v).size < 2)
            return null;
        unknown = (kn - p.shift * kd) * v.length / (kd * sum(v));
        if (![-3, -2, -1, 1, 2, 3].includes(unknown))
            return null;
        data = v.map(x => unknown * x + p.shift);
        if (data.some(x => Math.abs(x) > 70))
            return null;
        inference = `a=(${kn}-${p.shift}*${kd})*${v.length}/(${kd}*${sum(v)})=${unknown}`;
    }
    const n = data.length, s = sum(data), q = sum(data.map(x => x * x)), vn = n * q - s * s;
    const answer = statisticsTwoStepFraction(i === 1 ? s : vn, i === 1 ? n : n * n);
    if (!answer)
        return null;
    const proof = `${inference}; data=[${data.join(',')}]; n=${n}; sum=${s}; sumSquares=${q}; ${i === 1 ? `mean=${s}/${n}=${answer}` : `populationVariance=(${n}*${q}-${s}^2)/${n}^2=${answer}`}`;
    return { unknown, data, n, sum: s, sumSquares: q, varianceNumerator: vn, answer, proof };
}
function statisticsTwoStepParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1400)
        return null;
    const i = exports.STATISTICS_TWO_STEP_SCOPES.indexOf(scope), lists = [...text.matchAll(/\[(-?\d+(?:,-?\d+)*)(?:,[tk])?\]/g)];
    const known = (lang === 'zh' ? /(?:平均数|总频数)为 (-?\d+(?:\/\d+)?)/ : /(?:mean|total frequency|mean of y) is (-?\d+(?:\/\d+)?)/).exec(text)?.[1];
    if (!known || !lists.length)
        return null;
    const p = { scope, values: lists[0][1].split(',').map(Number), frequencies: i === 1 || i === 2 ? (lists[1]?.[1] ?? '').split(',').map(Number) : [], known, shift: i === 3 ? Number(/b=(-?\d+)/.exec(text)?.[1]) : 0 };
    return text === statisticsTwoStepPrompt(p, lang) && statisticsTwoStepDerive(p) ? p : null;
}
function statisticsTwoStepDistractors(p) {
    const d = statisticsTwoStepDerive(p);
    if (!d)
        return [];
    const raw = p.scope === exports.STATISTICS_TWO_STEP_SCOPES[1]
        ? [[sum(p.values), 3, 'ignore_frequencies'], [d.sum, 1, 'omit_mean_denominator'], [p.values[0] * p.frequencies[0] + p.values[1] * p.frequencies[1], sum(p.frequencies), 'omit_unknown_frequency_group']]
        : [[d.varianceNumerator, d.n * (d.n - 1), 'use_sample_variance'], [d.sumSquares, d.n, 'omit_centering'], [d.varianceNumerator, d.n, 'omit_variance_denominator']];
    const seen = new Set([d.answer]);
    return raw.flatMap(([n, z, intent]) => { const key = statisticsTwoStepFraction(n, z); if (key === null || seen.has(key))
        return []; seen.add(key); return [{ key, intent }]; });
}
function solveSubjectPracticeMathStatisticsTwoStep(candidate, context = {}) {
    const scope = statisticsTwoStepScopeFrom(context.questionPlan), parameters = statisticsTwoStepParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? statisticsTwoStepDerive(parameters) : null, reasonCodes = [];
    if (!scope || !parameters || !d)
        reasonCodes.push('statistics_two_step_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 76 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('statistics_two_step_identity');
    const options = candidate.options ?? [], keys = options.map(o => statisticsTwoStepOptionKey(o.text)), expectedKey = d?.answer ?? null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('statistics_two_step_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(statisticsTwoStepParametersFrom(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('statistics_two_step_' + lang + '_prompt');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, statisticsTwoStepOptionKey(o.text)])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('statistics_two_step_' + lang + '_options');
    }
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : expectedKey !== null && keys[i] === expectedKey ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('statistics_two_step_answer');
    const wrong = parameters ? statisticsTwoStepDistractors(parameters) : [], meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !wrong.some(w => w.intent === m.distractorIntent && w.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('statistics_two_step_error_intent');
    const scopeId = parameters ? exports.STATISTICS_TWO_STEP_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.STATISTICS_TWO_STEP_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.STATISTICS_TWO_STEP_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expectedKey, proof: d?.proof ?? null, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.STATISTICS_TWO_STEP_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope: scope, reasonCodes: parameters ? [] : ['statistics_two_step_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
