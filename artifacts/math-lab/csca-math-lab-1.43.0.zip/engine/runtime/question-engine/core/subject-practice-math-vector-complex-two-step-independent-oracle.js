"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VECTOR_COMPLEX_TWO_STEP_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathVectorComplexTwoStepWithIndependentOracle = verifySubjectPracticeMathVectorComplexTwoStepWithIndependentOracle;
// Independent grammar, rational arithmetic and certificates. No Solver/generator imports.
exports.VECTOR_COMPLEX_TWO_STEP_ORACLE_VERSION = 'math-vector-complex-two-step-oracle-v1-independent-certificates';
const scopes = ['vector_linear_combination_norm_squared', 'vector_perpendicular_parameter', 'complex_multiply_then_add', 'complex_affine_equation'];
const abs = (n) => n < 0n ? -n : n;
class R {
    n;
    d;
    constructor(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
        throw Error('zero denominator'); if (b < 0n) {
        a = -a;
        b = -b;
    } let g = abs(a), h = b; while (h) {
        [g, h] = [h, g % h];
    } this.n = a / g; this.d = b / g; }
    add(b) { return new R(this.n * b.d + b.n * this.d, this.d * b.d); }
    sub(b) { return new R(this.n * b.d - b.n * this.d, this.d * b.d); }
    mul(b) { return new R(this.n * b.n, this.d * b.d); }
    div(b) { return new R(this.n * b.d, this.d * b.n); }
    eq(b) { return this.n === b.n && this.d === b.d; }
    toString() { return String(this.n) + (this.d === 1n ? '' : '/' + this.d); }
}
const num = '(-?\\d{1,5})', vp = '\\(' + num + ',' + num + '\\)', zp = '\\(' + num + '\\)\\+\\(' + num + '\\)i';
function parse(text, scope, lang) {
    if (typeof text !== 'string' || text.length > 1600)
        return null;
    const i = scopes.indexOf(scope);
    if (i < 0)
        return null;
    const patterns = lang === 'zh' ? [
        '平面向量 a=' + vp + '，b=' + vp + '。求 \\|\\(' + num + '\\)a\\+\\(' + num + '\\)b\\|\\^2。',
        '平面向量 a=' + vp + '，b=' + vp + '，c=' + vp + '。若 \\(a\\+t\\*b\\) 与 c 垂直，求实数 t。',
        '复数 z1=' + zp + '，z2=' + zp + '，z3=' + zp + '，其中 i\\^2=-1。求 z1\\*z2\\+z3。',
        '复数 z1=' + zp + '，z2=' + zp + '，z3=' + zp + '，其中 i\\^2=-1。解方程 z1\\*z\\+z2=z3，求复数 z。'
    ] : [
        'Plane vectors a=' + vp + ' and b=' + vp + '\\. Find \\|\\(' + num + '\\)a\\+\\(' + num + '\\)b\\|\\^2\\.',
        'Plane vectors a=' + vp + ', b=' + vp + ', c=' + vp + '\\. If \\(a\\+t\\*b\\) is perpendicular to c, find the real number t\\.',
        'Complex numbers z1=' + zp + ', z2=' + zp + ', z3=' + zp + ', where i\\^2=-1\\. Find z1\\*z2\\+z3\\.',
        'Complex numbers z1=' + zp + ', z2=' + zp + ', z3=' + zp + ', where i\\^2=-1\\. Solve z1\\*z\\+z2=z3 for the complex number z\\.'
    ];
    const m = text.match(new RegExp('^' + patterns[i] + '$'));
    if (!m)
        return null;
    const v = m.slice(1).map(BigInt);
    return v.length === 6 && v.every(n => abs(n) <= 10000n) ? v : null;
}
const complex = (re, im) => '(' + re + ')+(' + im + ')i';
const key = (values) => values.length === 1 ? String(values[0]) : complex(values[0], values[1]);
function option(text, isComplex) {
    if (typeof text !== 'string' || text.length > 160)
        return null;
    const items = isComplex ? text.trim().match(/^\(([^)]+)\)\+\(([^)]+)\)i$/)?.slice(1) : [text.trim()];
    if (!items)
        return null;
    const out = [];
    for (const item of items) {
        const m = item.match(/^([+-]?\d{1,6})(?:\/([+-]?\d{1,6}))?$/);
        if (!m || !BigInt(m[2] ?? 1))
            return null;
        const r = new R(BigInt(m[1]), BigInt(m[2] ?? 1));
        if (abs(r.n) > 10000n || r.d > 10000n)
            return null;
        out.push(r);
    }
    return out;
}
function certificate(v, scope) {
    const i = scopes.indexOf(scope), [x, y, u, w, r, s] = v;
    if (abs(x) > 6n || abs(y) > 6n || abs(u) > (i === 3 ? 12n : 6n) || abs(w) > (i === 3 ? 12n : 6n))
        return null;
    const wrong = [], add = (q, intent) => wrong.push({ key: key(q), intent });
    let answer, proof;
    if (i === 0) {
        if ((!x && !y) || (!u && !w) || x * w - y * u === 0n || ![1n, 2n, 3n].includes(abs(r)) || ![1n, 2n, 3n].includes(abs(s)))
            return null;
        // Gram identity is independent of the Solver's component-combination implementation.
        const gramAA = x * x + y * y, gramAB = x * u + y * w, gramBB = u * u + w * w, result = r * r * gramAA + 2n * r * s * gramAB + s * s * gramBB;
        answer = [new R(result)];
        proof = { method: 'complete_gram_identity', gram: [gramAA, gramAB, gramBB].map(String), crossTerm: String(2n * r * s * gramAB), result: String(result), complete: true };
        add([new R(r * r * gramAA + s * s * gramBB)], 'omit_combination_cross_term');
        add([new R(r * r * gramAA)], 'omit_second_scaled_vector');
        add([new R(r * r * gramAA - 2n * r * s * gramAB + s * s * gramBB)], 'subtract_second_vector');
        add([new R((r * x + s * u) ** 2n)], 'omit_vertical_component_square');
        add([new R(r * gramAA + s * gramBB)], 'replace_squared_coefficients_by_coefficients');
    }
    else if (i === 1) {
        if (v.some(n => abs(n) > 6n) || (!x && !y) || (!u && !w) || (!r && !s))
            return null;
        const A = x * r + y * s, B = u * r + w * s;
        if (!B)
            return null;
        answer = [new R(-A, B)];
        proof = { method: 'option_substitution_and_nonzero_linear_coefficient', constant: String(A), coefficient: String(B), allRealUniqueness: true, complete: true };
        add([new R(A, B)], 'reverse_linear_solution_sign');
        if (A)
            add([new R(-B, A)], 'invert_linear_solution_ratio');
        add([new R(-(x * u + y * w), B)], 'use_a_dot_b_instead_of_a_dot_c');
        add([new R(-(A + r * r + s * s), B)], 'add_c_to_parameterized_vector');
        add([new R(-A - B, B)], 'replace_t_by_t_plus_one');
    }
    else if (i === 2) {
        if (!y || !w || abs(r) > 12n || abs(s) > 12n || (!r && !s))
            return null;
        const matrix = [[new R(x), new R(-y)], [new R(y), new R(x)]], input = [new R(u), new R(w)];
        const product = matrix.map(row => row.reduce((acc, entry, j) => acc.add(entry.mul(input[j])), new R(0)));
        answer = [product[0].add(new R(r)), product[1].add(new R(s))];
        proof = { method: 'real_matrix_complex_multiplication_then_translation', matrix: matrix.map(row => row.map(String)), product: product.map(String), translation: [r, s].map(String), complete: true };
        add([new R(x * u + y * w + r), answer[1]], 'use_i_squared_positive_one');
        add(product, 'omit_addition_of_z3');
        add([answer[0], new R(x * w + s)], 'omit_second_imaginary_cross_product');
        add([product[0].sub(new R(r)), product[1].sub(new R(s))], 'subtract_z3_instead_of_add');
        add([answer[0], new R(y * u + s)], 'omit_first_imaginary_cross_product');
    }
    else if (i === 3) {
        if (!x || !y || (!u && !w) || abs(r) > 12n || abs(s) > 12n)
            return null;
        // Eliminate the real part from the two original equations (no conjugate formula).
        const row1 = [new R(x), new R(-y), new R(r - u)], row2 = [new R(y), new R(x), new R(s - w)];
        const factor = row2[0].div(row1[0]), pivot = row2[1].sub(factor.mul(row1[1]));
        if (!pivot.n)
            return null;
        const imag = row2[2].sub(factor.mul(row1[2])).div(pivot), real = row1[2].sub(row1[1].mul(imag)).div(row1[0]);
        answer = [real, imag];
        const D = x * x + y * y, A = r - u, B = s - w;
        proof = { method: 'independent_real_system_row_elimination', determinant: String(D), secondPivot: String(pivot), allComplexUniqueness: true, complete: true };
        add([new R((r + u) * x + (s + w) * y, D), new R((s + w) * x - (r + u) * y, D)], 'move_z2_with_wrong_sign');
        add([new R(r * x + s * y, D), new R(s * x - r * y, D)], 'omit_subtraction_of_z2');
        add([new R(r * x + s * y - u * D, D), new R(s * x - r * y - w * D, D)], 'divide_z3_but_not_z2');
        add([new R(A * x - B * y, D), new R(B * x + A * y, D)], 'multiply_without_conjugating_divisor');
        add([real, new R(-imag.n, imag.d)], 'reverse_imaginary_numerator');
        add([new R(A * x + B * y), new R(B * x - A * y)], 'omit_squared_modulus_denominator');
    }
    else
        return null;
    if (answer.some(q => abs(q.n) > 10000n || q.d > 10000n))
        return null;
    return { answer, wrong, proof };
}
function verifySubjectPracticeMathVectorComplexTwoStepWithIndependentOracle(candidate, context = {}) {
    const p = context.questionPlan, r = p?.renderConstraints, s = p?.scenarioContract, scope = String(r?.exactVectorComplexTwoStepScope ?? ''), reasonCodes = [];
    const contract = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 73 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === 'math_vector_complex_two_step_calculation' && p?.planTemplate === 'math_vector_complex_two_step_calculation_v1' && r?.questionType === 'single_choice' && r?.topicCode === 'M-ALG-001'
        && r?.boundedIntegerParameters === true && r?.exactRationalArithmetic === true && r?.maximumAbsoluteValue === 10000 && r?.completeVectorComplexCertificate === true && r?.maximumVisibleObjects === 3
        && r?.externalContextAllowed === false && r?.requiresImage === false && r?.minimumVisibleMoves === 2
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'vector_or_complex_two_step_object' && s?.scenarioAction === scope && scopes.includes(scope);
    const values = contract ? parse(candidate.prompt, scope, 'zh') : null, cert = values ? certificate(values, scope) : null;
    if (!contract || !values || !cert)
        reasonCodes.push('vector_complex_two_step_oracle_outside_contract');
    if (candidate.subject !== 'math' || candidate.topicId !== 73 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('vector_complex_two_step_oracle_identity');
    const isComplex = scope.startsWith('complex_'), options = candidate.options ?? [], parsed = options.map(o => option(o.text, isComplex)), keys = parsed.map(q => q ? key(q) : null);
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang], other = loc ? parse(loc.prompt ?? '', scope, lang) : null;
        if (!values || !other || String(other) !== String(values))
            reasonCodes.push('vector_complex_two_step_oracle_' + lang + '_prompt');
        if (!loc?.options || JSON.stringify(loc.options.map(o => { const q = option(o.text, isComplex); return [o.id, q ? key(q) : null]; })) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('vector_complex_two_step_oracle_' + lang + '_options');
    }
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('vector_complex_two_step_oracle_duplicate_or_invalid_options');
    const optionCertificates = [];
    const optionVerdicts = options.map((o, i) => {
        const q = parsed[i];
        let correct = false;
        if (cert && values && q) {
            if (scope === scopes[1]) {
                const [x, y, u, w, r, s] = values, t = q[0], zero = new R(0), dot = new R(x).add(t.mul(new R(u))).mul(new R(r)).add(new R(y).add(t.mul(new R(w))).mul(new R(s)));
                correct = dot.eq(zero);
                optionCertificates.push({ optionId: o.id, perpendicularResidual: String(dot), satisfies: correct });
            }
            else if (scope === scopes[3]) {
                const [x, y, u, w, r, s] = values, re = new R(x).mul(q[0]).sub(new R(y).mul(q[1])).add(new R(u)).sub(new R(r));
                const im = new R(y).mul(q[0]).add(new R(x).mul(q[1])).add(new R(w)).sub(new R(s));
                correct = re.n === 0n && im.n === 0n;
                optionCertificates.push({ optionId: o.id, realResidual: String(re), imaginaryResidual: String(im), satisfies: correct });
            }
            else
                correct = key(q) === key(cert.answer);
        }
        return { optionId: o.id, semanticValue: keys[i], verdict: !q ? 'unknown' : correct ? 'true' : 'false' };
    });
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || candidate.correctAnswer !== selectedOptionId)
        reasonCodes.push('vector_complex_two_step_oracle_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !cert?.wrong.some(w => w.intent === m.distractorIntent && w.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('vector_complex_two_step_oracle_error_intent');
    return { oracleVersion: exports.VECTOR_COMPLEX_TWO_STEP_ORACLE_VERSION, status: reasonCodes.length ? (cert ? 'conflict' : 'unparsed') : 'verified',
        scopeId: cert ? 'math-medium-vector-complex-two-step-v1:' + scope : null, scopeMatched: Boolean(cert), selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        completeCertificate: Boolean(cert) && reasonCodes.length === 0, certificate: cert?.proof ?? null, optionCertificates, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
