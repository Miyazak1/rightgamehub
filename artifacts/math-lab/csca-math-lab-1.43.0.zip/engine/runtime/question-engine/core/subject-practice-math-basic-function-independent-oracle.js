"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathBasicFunctionWithIndependentOracle = verifySubjectPracticeMathBasicFunctionWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_INDEPENDENT_ORACLE_VERSION = 'math-basic-function-independent-oracle-v1';
function objectFrom(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function exactScope(context) {
    const plan = objectFrom(context.questionPlan);
    const render = objectFrom(plan?.renderConstraints);
    const scope = String(render?.exactBasicFunctionScope ?? '');
    return String(plan?.taskFamily ?? '') === 'math_basic_function_property'
        && String(plan?.planTemplate ?? '') === 'math_basic_function_property_v1'
        && ['linear_monotonicity', 'quadratic_axis', 'rational_domain_exclusion', 'polynomial_parity'].includes(scope) ? scope : null;
}
function normalized(text) { return String(text ?? '').replace(/\s+/g, '').replace(/−/g, '-'); }
function target(scope, promptValue) {
    const prompt = normalized(promptValue);
    if (scope === 'linear_monotonicity') {
        const match = prompt.match(/f\(x\)=([+-]?\d*)x/);
        if (!match)
            return null;
        const slope = match[1] === '' || match[1] === '+' ? 1 : match[1] === '-' ? -1 : Number(match[1]);
        return slope > 0 ? 'inc' : slope < 0 ? 'dec' : null;
    }
    if (scope === 'quadratic_axis') {
        const match = prompt.match(/\(x([+-])(\d+)\)\^?2/);
        if (!match)
            return null;
        return match[1] === '-' ? Number(match[2]) : -Number(match[2]);
    }
    if (scope === 'rational_domain_exclusion') {
        const match = prompt.match(/\/\(x([+-])(\d+)\)/);
        if (!match)
            return null;
        return match[1] === '-' ? Number(match[2]) : -Number(match[2]);
    }
    const powers = [...prompt.matchAll(/[+-]?\d*x\^(\d+)/g)].map((match) => Number(match[1]));
    if (!powers.length)
        return null;
    return powers.every((power) => power % 2 === 1) ? 'odd' : powers.every((power) => power % 2 === 0) ? 'even' : 'neither';
}
function optionValue(scope, optionValue) {
    const text = normalized(optionValue);
    if (scope === 'linear_monotonicity')
        return /单调递增|increasing/i.test(text) ? 'inc' : /单调递减|decreasing/i.test(text) ? 'dec' : /常数|constant/i.test(text) ? 'constant' : /不具有单调性|notmonotonic/i.test(text) ? 'none' : null;
    if (scope === 'quadratic_axis') {
        const match = text.match(/x=(-?\d+)/i);
        return match ? Number(match[1]) : null;
    }
    if (scope === 'rational_domain_exclusion') {
        const match = text.match(/(?:\\|∖|去掉|except)\{?(-?\d+)\}?|x[≠!=]+(-?\d+)/i);
        return match ? Number(match[1] ?? match[2]) : /全体实数|allreal|^R$/i.test(text) ? 'all' : null;
    }
    return /非奇非偶|neither/i.test(text) ? 'neither' : /偶函数|evenfunction/i.test(text) ? 'even' : /奇函数|oddfunction/i.test(text) ? 'odd' : /常数|constant/i.test(text) ? 'constant' : null;
}
function verifySubjectPracticeMathBasicFunctionWithIndependentOracle(candidate, context = {}) {
    const scope = exactScope(context);
    const expected = scope ? target(scope, candidate.prompt) : null;
    const parsed = scope !== null && expected !== null;
    const optionVerdicts = (candidate.options ?? []).map((option) => { const value = scope ? optionValue(scope, option.text) : null; return { optionId: option.id, verdict: value === null ? 'unknown' : value === expected ? 'true' : 'false' }; });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!parsed)
        reasonCodes.push('math_basic_function_oracle_prompt_or_plan_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_basic_function_oracle_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_basic_function_oracle_answer_not_unique');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_basic_function_oracle_generator_disagreement');
    return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_INDEPENDENT_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'disagreed' : 'abstained') : 'verified', scopeId: parsed ? `math-basic-function-property-v1:${scope}` : null, exactScope: scope, scopeMatched: parsed, optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
