"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathSequenceTwoConditionWithIndependentOracle = verifySubjectPracticeMathSequenceTwoConditionWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_INDEPENDENT_ORACLE_VERSION = 'math-sequence-two-condition-independent-oracle-v1-bounded-enumeration';
function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ' ').trim(); }
function scopeFrom(context) {
    const plan = object(context.questionPlan);
    const render = object(plan?.renderConstraints);
    const scope = clean(render?.exactSequenceTwoConditionScope);
    return clean(plan?.taskFamily) === 'math_sequence_two_condition_calculation'
        && clean(plan?.planTemplate) === 'math_sequence_two_condition_calculation_v1'
        && ['arithmetic_two_terms_target_term', 'arithmetic_term_and_sum_target_term', 'geometric_two_terms_target_term', 'geometric_term_and_sum_target_term'].includes(scope)
        ? scope : null;
}
function assignments(text, symbol) {
    const pattern = symbol === 'a' ? /a_?(\d+)\s*=\s*(-?\d+)/gi : /S_?(\d+)\s*=\s*(-?\d+)/gi;
    return [...clean(text).matchAll(pattern)].map((match) => ({ index: Number(match[1]), value: Number(match[2]) }));
}
function targetIndex(text) { const match = clean(text).match(/(?:求|find\s+(?:the\s+term\s+)?)\s*a_?(\d+)/i); return Number(match?.[1] ?? NaN); }
function term(a1, step, index, geometric) { let value = a1; for (let i = 1; i < index; i += 1)
    value = geometric ? value * step : value + step; return value; }
function sum(a1, step, n, geometric) { let total = 0; for (let i = 1; i <= n; i += 1)
    total += term(a1, step, i, geometric); return total; }
function matches(prompt, a1, step, geometric) {
    return assignments(prompt, 'a').every((item) => term(a1, step, item.index, geometric) === item.value)
        && assignments(prompt, 'S').every((item) => sum(a1, step, item.index, geometric) === item.value);
}
function verifySubjectPracticeMathSequenceTwoConditionWithIndependentOracle(candidate, context = {}) {
    const scope = scopeFrom(context);
    const geometric = Boolean(scope?.startsWith('geometric_'));
    const target = targetIndex(candidate.prompt);
    const solutions = [];
    if (scope && Number.isInteger(target)) {
        for (let a1 = -24; a1 <= 24; a1 += 1)
            for (let step = -6; step <= 6; step += 1) {
                if (a1 === 0 || step === 0 || (geometric && Math.abs(step) === 1))
                    continue;
                if (matches(candidate.prompt, a1, step, geometric))
                    solutions.push({ a1, step, targetValue: term(a1, step, target, geometric) });
            }
    }
    const targetValues = [...new Set(solutions.map((item) => item.targetValue))];
    const expectedValue = targetValues.length === 1 ? targetValues[0] : null;
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const value = Number(clean(option.text));
        const valid = Number.isSafeInteger(value);
        return { optionId: option.id, verdict: !valid ? 'unknown' : value === expectedValue ? 'true' : 'false' };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!scope || !Number.isInteger(target))
        reasonCodes.push('math_sequence_two_condition_oracle_prompt_or_plan_unparsed');
    if (solutions.length !== 1 || targetValues.length !== 1)
        reasonCodes.push('math_sequence_two_condition_oracle_parameter_solution_not_unique');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_sequence_two_condition_oracle_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_sequence_two_condition_oracle_answer_not_unique');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_sequence_two_condition_oracle_generator_disagreement');
    return {
        oracleVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_INDEPENDENT_ORACLE_VERSION,
        status: reasonCodes.length ? (scope ? 'disagreed' : 'abstained') : 'verified',
        scopeId: scope && solutions.length === 1 && targetValues.length === 1 ? `math-medium-sequence-two-condition-v1:${scope}` : null,
        exactScope: scope, enumeratedSolutionCount: solutions.length, expectedValue, scopeMatched: Boolean(scope && solutions.length === 1 && targetValues.length === 1),
        optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        independentFromPrimarySolver: true, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
