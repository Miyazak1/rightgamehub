"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathNormalDistributionBasicWithIndependentOracle = verifySubjectPracticeMathNormalDistributionBasicWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_INDEPENDENT_ORACLE_VERSION = 'math-normal-distribution-basic-independent-oracle-v1-affine-and-partition';
// Deliberately no primary parser, Solver, generator or arithmetic-helper imports.
const scopes = ['normal_parameter_identification', 'normal_standardization_z_score', 'normal_symmetry_probability', 'normal_empirical_interval_probability'];
function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function read(text, scope, english) {
    const prefix = (english ? ['Let X have a continuous normal distribution N(', 'Assume X has a continuous normal distribution N('] : ['设连续随机变量 X 服从正态分布 N(', '已知连续随机变量 X 服从正态分布 N(']).find(p => text.startsWith(p));
    if (!prefix)
        return null;
    const separator = english ? '), where the second parameter is the variance. ' : ')，其中第二个参数为方差。';
    const chunks = text.slice(prefix.length).split(separator);
    if (chunks.length !== 2)
        return null;
    const numbers = chunks[0].split(', ');
    if (numbers.length !== 2 || !/^-?\d+$/.test(numbers[0]) || !/^\d+$/.test(numbers[1]))
        return null;
    const mu = Number(numbers[0]), variance = Number(numbers[1]);
    let sigma = 0;
    for (let i = 1; i <= 12; i++)
        if (i * i === variance)
            sigma = i;
    if (!Number.isInteger(mu) || mu < -20 || mu > 80 || !sigma)
        return null;
    const body = chunks[1], base = { mu, variance, sigma };
    if (scope === scopes[0]) {
        const words = english ? ['Find the mean of X.', 'Find the variance of X.', 'Find the positive standard deviation of X.'] : ['求 X 的均值。', '求 X 的方差。', '求 X 的正标准差。'];
        const at = words.indexOf(body);
        return at < 0 ? null : { ...base, target: ['mean', 'variance', 'sd'][at] };
    }
    if (scope === scopes[1]) {
        const start = english ? 'For the threshold x=' : '对阈值 x=', end = english ? ', find the standardized value z=(x-mu)/sigma.' : '，求标准化值 z=(x-mu)/sigma。';
        if (!body.startsWith(start) || !body.endsWith(end))
            return null;
        const xText = body.slice(start.length, -end.length);
        if (!/^-?\d+$/.test(xText))
            return null;
        const x = Number(xText);
        if (![-6, -4, -2, -1, 0, 1, 2, 4, 6].some(t => 2 * x === 2 * mu + sigma * t))
            return null;
        return { ...base, target: 'z', x };
    }
    if (scope === scopes[2]) {
        for (const op of ['<', '<=', '>', '>=']) {
            const exact = english ? 'Find the probability P(X' + op + mu + ').' : '求概率 P(X' + op + mu + ')。';
            if (body === exact)
                return { ...base, target: 'symmetry', x: mu, op };
        }
        return null;
    }
    if (scope !== scopes[3])
        return null;
    // Enumerate the finite admissible approximation/event grammar independently.
    for (let k = 1; k <= 3; k++) {
        const percent = k === 1 ? '68' : k === 2 ? '95' : '99.7', a = mu - k * sigma, b = mu + k * sigma;
        const premise = (english ? 'Use the empirical approximation: ' : '已知经验规律：') + 'P(mu-' + k + '*sigma<=X<=mu+' + k + '*sigma)≈' + percent + (english ? '%. Find the approximate probability of ' : '%。求事件 ');
        const events = [a + '<=X<=' + b, 'X<' + a + (english ? ' or ' : ' 或 ') + 'X>' + b, 'X<' + a, 'X>' + b];
        for (let i = 0; i < events.length; i++)
            if (body === premise + events[i] + (english ? '.' : ' 的近似概率。'))
                return { ...base, target: ['central', 'outside', 'left', 'right'][i], k, a, b };
    }
    return null;
}
function fraction(text) {
    const p = text.split('/');
    return p.length <= 2 && /^-?(0|[1-9][0-9]{0,5})$/.test(p[0]) && (p.length === 1 || /^[1-9][0-9]{0,5}$/.test(p[1])) ? [Number(p[0]), p.length === 2 ? Number(p[1]) : 1] : null;
}
function answerHolds(v, f) {
    const [n, d] = v;
    if (f.target === 'mean')
        return n === f.mu * d;
    if (f.target === 'variance')
        return n === f.variance * d;
    if (f.target === 'sd')
        return n > 0 && n * n === f.variance * d * d;
    if (f.target === 'z')
        return f.mu * d + f.sigma * n === f.x * d;
    if (f.target === 'symmetry')
        return n * 2 === d && f.x === f.mu;
    // Probability mass in ten-thousandths; total = left + center + right.
    const center = f.k === 1 ? 6800 : f.k === 2 ? 9500 : 9970, tail = (10000 - center) / 2;
    const count = f.target === 'central' ? center : f.target === 'outside' ? tail + tail : tail;
    return n * 10000 === d * count;
}
function verifySubjectPracticeMathNormalDistributionBasicWithIndependentOracle(c, context = {}) {
    const p = obj(context.questionPlan), r = obj(p?.renderConstraints), scope = String(r?.exactNormalDistributionScope ?? ''), scenario = obj(p?.scenarioContract);
    const validPlan = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.representationType === 'text' && r?.questionType === 'single_choice'
        && scenario?.scenarioMode === 'abstract' && scenario?.scenarioEntity === 'normal_distribution_object' && scenario?.scenarioAction === scope
        && p?.subject === 'math' && p?.topicId === 77 && p?.targetDifficulty === 'basic' && p?.taskFamily === 'math_normal_distribution_basic_concepts' && p?.planTemplate === 'math_normal_distribution_basic_concepts_v1'
        && r?.topicCode === 'M-STAT-002' && r?.minimumMean === -20 && r?.maximumMean === 80 && r?.minimumSigma === 1 && r?.maximumSigma === 12
        && r?.integerParametersRequired === true && r?.integerVisibleThresholdRequired === true && r?.oneVisibleTarget === true && r?.secondNormalParameter === 'variance'
        && r?.empiricalRuleApproximateRequired === true && r?.externalContextAllowed === false && r?.requiresImage === false
        && r?.finalAnswerShape === 'one_unique_rational_with_exact_or_stated_approximate_semantics' && scopes.includes(scope);
    const facts = validPlan ? read(c.prompt, scope, false) : null, reasons = [];
    if (!facts)
        reasons.push('math_normal_basic_oracle_outside_scope');
    if (c.subject !== 'math' || c.topicId !== 77 || c.questionType !== 'single_choice' || c.designedDifficulty !== 'basic')
        reasons.push('math_normal_basic_oracle_identity_mismatch');
    for (const lang of ['zh', 'en']) {
        if (!facts || JSON.stringify(read(c.localizations?.[lang]?.prompt ?? '', scope, lang === 'en')) !== JSON.stringify(facts))
            reasons.push('math_normal_basic_oracle_' + lang + '_visible_task_mismatch');
        if (JSON.stringify(c.localizations?.[lang]?.options) !== JSON.stringify(c.options))
            reasons.push('math_normal_basic_oracle_' + lang + '_options_mismatch');
    }
    const options = c.options ?? [], values = options.map(o => fraction(o.text)), probability = facts && ['symmetry', 'central', 'outside', 'left', 'right'].includes(facts.target);
    const duplicate = values.some((v, i) => v && values.slice(0, i).some(w => w && v[0] * w[1] === w[0] * v[1]));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || duplicate || values.some(v => !v || (probability && (v[0] < 0 || v[0] > v[1]))))
        reasons.push('math_normal_basic_oracle_invalid_options');
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, verdict: !values[i] ? 'unknown' : facts && answerHolds(values[i], facts) ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (trueOptionIds.length !== 1 || selectedOptionId !== c.correctAnswer)
        reasons.push('math_normal_basic_oracle_answer_disagreement');
    const metadata = c.optionMetadata ?? [];
    if (metadata.length !== 3 || new Set(metadata.map(x => x.optionId)).size !== 3 || new Set(metadata.map(x => x.distractorIntent)).size !== 3 || metadata.some(x => x.optionId === c.correctAnswer || !options.some(o => o.id === x.optionId) || !x.distractorIntent?.trim()))
        reasons.push('math_normal_basic_oracle_distractor_metadata_invalid');
    return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_INDEPENDENT_ORACLE_VERSION,
        status: reasons.length ? (facts ? 'disagreed' : 'abstained') : 'verified',
        scopeId: facts ? 'math-basic-normal-distribution-v1:' + scope : null, exactScope: scope, scopeMatched: Boolean(facts),
        optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === c.correctAnswer, independentFromPrimarySolver: true,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes: reasons };
}
