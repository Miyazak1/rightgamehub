"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathVectorComplexWithIndependentOracle = verifySubjectPracticeMathVectorComplexWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_INDEPENDENT_ORACLE_VERSION = 'math-vector-complex-independent-oracle-v1-bounded-enumeration';
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/[，]/g, ',').replace(/\s+/g, ' ').trim(); }
function scope(context) { const p = object(context.questionPlan), r = object(p?.renderConstraints), s = clean(r?.exactVectorComplexScope); return clean(p?.taskFamily) === 'math_vector_complex_direct_calculation' && clean(p?.planTemplate) === 'math_vector_complex_direct_calculation_v1' && ['vector_coordinate_addition', 'vector_dot_product', 'complex_addition_subtraction', 'complex_modulus'].includes(s) ? s : null; }
function pair(text, label) { const m = clean(text).match(new RegExp(`${label}\\s*=\\s*\\(\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\\)`, 'i')); return m ? { x: +m[1], y: +m[2] } : null; }
function n(text, label) { const m = clean(text).match(new RegExp(`${label}\\s*=\\s*(-?\\d+)`, 'i')); return m ? +m[1] : null; }
function parse(prompt, s) { if (!s)
    return null; const t = clean(prompt); if (s.startsWith('vector_')) {
    const a = pair(t, 'a'), b = pair(t, 'b');
    return a && b ? { a, b } : null;
} const x1 = n(t, 'x_?1'), y1 = n(t, 'y_?1'); if (s === 'complex_modulus')
    return x1 !== null && y1 !== null ? { z1: { x: x1, y: y1 } } : null; const x2 = n(t, 'x_?2'), y2 = n(t, 'y_?2'); return [x1, y1, x2, y2].every(v => v !== null) ? { z1: { x: x1, y: y1 }, z2: { x: x2, y: y2 }, subtract: /z_?1\s*-\s*z_?2/i.test(t) } : null; }
function rootByEnumeration(square) { for (let k = 0; k <= 50; k += 1)
    if (k * k === square)
        return k; return null; }
function wanted(s, p) { if (s === 'vector_coordinate_addition')
    return { x: p.a.x + p.b.x, y: p.a.y + p.b.y }; if (s === 'vector_dot_product') {
    let total = 0;
    for (const [u, v] of [[p.a.x, p.b.x], [p.a.y, p.b.y]])
        total += u * v;
    return total;
} if (s === 'complex_addition_subtraction') {
    const sign = p.subtract ? -1 : 1;
    return { x: p.z1.x + sign * p.z2.x, y: p.z1.y + sign * p.z2.y };
} return rootByEnumeration(p.z1.x * p.z1.x + p.z1.y * p.z1.y); }
function parsePair(value) { const t = clean(value).replace(/\s/g, ''); let m = t.match(/^\((-?\d+),(-?\d+)\)$/); if (m)
    return { x: +m[1], y: +m[2] }; m = t.match(/^(-?\d+)([+-]\d+)i$/i); return m ? { x: +m[1], y: +m[2] } : null; }
function same(a, b) { return typeof a === 'number' && typeof b === 'number' ? a === b : a && b && a.x === b.x && a.y === b.y; }
function verifySubjectPracticeMathVectorComplexWithIndependentOracle(candidate, context = {}) { const exactScope = scope(context), parameters = parse(candidate.prompt, exactScope), parsed = Boolean(exactScope && parameters), expectedValue = parsed ? wanted(exactScope, parameters) : null, pairAnswer = exactScope === 'vector_coordinate_addition' || exactScope === 'complex_addition_subtraction'; const optionVerdicts = (candidate.options ?? []).map(o => { const value = pairAnswer ? parsePair(o.text) : Number(clean(o.text)), valid = pairAnswer ? value !== null : Number.isSafeInteger(value); return { optionId: o.id, verdict: !valid ? 'unknown' : same(value, expectedValue) ? 'true' : 'false' }; }); const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null, reasonCodes = []; if (!parsed || expectedValue === null)
    reasonCodes.push('math_vector_complex_oracle_prompt_or_plan_unparsed'); if (optionVerdicts.some(x => x.verdict === 'unknown'))
    reasonCodes.push('math_vector_complex_oracle_option_unparsed'); if (trueOptionIds.length !== 1)
    reasonCodes.push('math_vector_complex_oracle_answer_not_unique'); if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('math_vector_complex_oracle_generator_disagreement'); return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_INDEPENDENT_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'disagreed' : 'abstained') : 'verified', scopeId: parsed ? `math-basic-vector-complex-v1:${exactScope}` : null, exactScope, parameters, expectedValue, scopeMatched: parsed, optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
