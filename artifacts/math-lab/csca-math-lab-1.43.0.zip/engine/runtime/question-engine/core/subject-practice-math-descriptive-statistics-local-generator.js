"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathDescriptiveStatisticsLocalGenerator = createSubjectPracticeMathDescriptiveStatisticsLocalGenerator;
const subject_practice_math_descriptive_statistics_solver_1 = require("./subject-practice-math-descriptive-statistics-solver");
const subject_practice_math_descriptive_statistics_independent_oracle_1 = require("./subject-practice-math-descriptive-statistics-independent-oracle");
const subject_practice_math_descriptive_statistics_explanation_verifier_1 = require("./subject-practice-math-descriptive-statistics-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_LOCAL_GENERATOR_VERSION = 'math-descriptive-statistics-local-generator-v1-bounded-data';
function randomFor(seed) {
    let state = ((seed % 4294967296) ^ 0x6d2b79f5) || 0x9e3779b9;
    return (max) => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return (state >>> 0) % max; };
}
function candidateFor(b, seed, scope) {
    const salt = { arithmetic_mean: 0, median: 101, population_variance: 211, population_standard_deviation: 307 }[scope];
    const random = randomFor((seed % 4294967296 + salt) % 4294967296);
    for (let attempt = 0; attempt < 64; attempt++) {
        let data;
        if (scope === 'population_standard_deviation') {
            // Several exact-square shapes, not an approximate rounded square root.
            const shapes = [[-1, -1, 1, 1], [-1, -7, 1, 7], [-1, -1, -5, 1, 1, 5], [-3, -1, 0, 1, 3], [-1, -1, -1, -1, 1, 1, 1, 1]];
            const offsets = shapes[random(shapes.length)], scale = 1 + random(3), center = -5 + random(35);
            data = offsets.map(x => center + scale * x);
            if (data.some(x => x < -20 || x > 50))
                continue;
        }
        else if (scope === 'population_variance') {
            // Keep the basic/light calculation profile honest: a short dataset with
            // integer mean and small deviations, even when its values are translated.
            const shapes = [[-2, -1, 0, 1, 2], [-1, -1, 0, 0, 1, 1], [-2, -1, 1, 2], [-3, -1, 0, 1, 3], [-2, -1, -1, 0, 1, 1, 2], [-2, -1, -1, 0, 0, 1, 1, 2]];
            const center = -10 + random(50);
            data = shapes[random(shapes.length)].map(x => center + x);
        }
        else {
            data = Array.from({ length: 3 + random(6) }, () => -20 + random(71));
        }
        for (let i = data.length - 1; i > 0; i--) {
            const j = random(i + 1);
            [data[i], data[j]] = [data[j], data[i]];
        }
        const n = data.length, sum = data.reduce((a, x) => a + x, 0), squareSum = data.reduce((a, x) => a + x * x, 0);
        const mean = (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sum, n), variance = (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(n * squareSum - sum * sum, n * n), sorted = [...data].sort((a, b) => a - b);
        const middle = Math.floor(n / 2), median = n % 2 ? (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sorted[middle]) : (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sorted[middle - 1] + sorted[middle], 2);
        const sigma = variance.denominator === 1 && Number.isInteger(Math.sqrt(variance.numerator)) ? Math.sqrt(variance.numerator) : null;
        if (scope === 'population_standard_deviation' && sigma === null)
            continue;
        const correct = scope === 'arithmetic_mean' ? mean : scope === 'median' ? median : scope === 'population_variance' ? variance : (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sigma);
        const wrong = scope === 'arithmetic_mean' ? [
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sum), intent: 'omitted_count_division' }, { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sum, n - 1), intent: 'used_one_fewer_observation' },
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sum - data[n - 1], n), intent: 'omitted_last_value_from_sum' }, { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(Math.abs(sum), n), intent: 'discarded_mean_sign' },
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sorted[0] + sorted[n - 1], 2), intent: 'used_midrange_instead_of_mean' }, { value: median, intent: 'used_median_instead_of_mean' }
        ] : scope === 'median' ? [
            { value: n % 2 ? (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(data[middle]) : (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(data[middle - 1] + data[middle], 2), intent: 'used_unsorted_middle_positions' },
            { value: mean, intent: 'used_mean_instead_of_median' }, { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sorted[n - 1] - sorted[0]), intent: 'used_range_instead_of_median' },
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sorted[0]), intent: 'used_minimum_instead_of_median' }, { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sorted[n - 1]), intent: 'used_maximum_instead_of_median' }
        ] : scope === 'population_variance' ? [
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(variance.numerator * n, variance.denominator * (n - 1)), intent: 'used_sample_denominator_n_minus_one' },
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(squareSum, n), intent: 'omitted_centering_at_mean' }, { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(variance.numerator * n, variance.denominator), intent: 'omitted_count_division' },
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(variance.numerator, variance.denominator * n), intent: 'divided_by_count_twice' }
        ] : [
            { value: variance, intent: 'reported_variance_without_square_root' }, { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(-sigma), intent: 'used_negative_square_root' },
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sorted[n - 1] - sorted[0]), intent: 'used_range_instead_of_standard_deviation' },
            { value: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(Math.abs(sum), n), intent: 'used_absolute_mean_instead_of_deviation' }
        ];
        const alternatives = [{ value: correct, intent: '' }], used = new Set([(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(correct)]);
        for (const item of wrong)
            if (!used.has((0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(item.value))) {
                used.add((0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(item.value));
                alternatives.push(item);
                if (alternatives.length === 4)
                    break;
            }
        if (alternatives.length !== 4)
            continue;
        const answerIndex = seed % 4, ordered = alternatives.slice(1);
        ordered.splice(answerIndex, 0, alternatives[0]);
        const correctAnswer = 'ABCD'[answerIndex], options = ordered.map((x, i) => ({ id: 'ABCD'[i], text: (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(x.value) }));
        const prompt = `${seed % 2 ? '一组观测数据为' : '给定以下数据'}：[${data.join(', ')}]，共 n=${n} 个数。求这组数据的${subject_practice_math_descriptive_statistics_solver_1.STATISTICS_TARGETS[scope][0]}。`;
        const promptEn = `${seed % 2 ? 'A dataset contains' : 'The data are'} [${data.join(', ')}], with n=${n} values. Find the ${subject_practice_math_descriptive_statistics_solver_1.STATISTICS_TARGETS[scope][1]} of this dataset.`;
        const sumExpression = data.map(x => `(${x})`).join('+');
        const meanEquation = `mean=(${sumExpression})/${n}=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(mean)}`;
        let equation, zhPrefix, enPrefix;
        if (scope === 'arithmetic_mean') {
            equation = meanEquation;
            zhPrefix = '数据之和除以个数：';
            enPrefix = 'Divide the data sum by the count: ';
        }
        else if (scope === 'median') {
            const indices = n % 2 ? `${middle + 1}` : `${middle},${middle + 1}`;
            const operation = n % 2 ? `${sorted[middle]}` : `(${sorted[middle - 1]}+(${sorted[middle]}))/2`;
            equation = `sorted=[${sorted.join(', ')}]; positions=${indices}; median=${operation}=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(median)}`;
            zhPrefix = '按从小到大排序，取中间位置：';
            enPrefix = 'Sort in ascending order and use the central position(s): ';
        }
        else {
            const deviations = data.map(x => `(${x}-(${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(mean)}))^2`).join('+');
            equation = `${meanEquation}; variance=(${deviations})/${n}=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(variance)}`;
            if (scope === 'population_standard_deviation')
                equation += `; standard_deviation=sqrt(${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(variance)})=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(correct)}`;
            zhPrefix = '总体方差用平方离差之和除以 n，标准差取非负平方根：';
            enPrefix = 'Population variance divides the squared-deviation sum by n; standard deviation is its nonnegative square root: ';
        }
        const explanation = `${zhPrefix}${equation}。对应选项 ${correctAnswer}。`, explanationEn = `${enPrefix}${equation}. Option ${correctAnswer}.`;
        return { subject: 'math', topicId: b.topicId, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options, correctAnswer, explanation,
            knowledgeTags: ['数据的数字特征', scope], optionMetadata: ordered.flatMap((x, i) => x.intent ? [{ optionId: 'ABCD'[i], distractorIntent: x.intent, misconceptionTags: [x.intent] }] : []),
            localizations: { zh: { prompt, options, explanation, knowledgeTags: ['数据的数字特征'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Descriptive statistics'] } }, syllabusVersion: b.syllabusVersion };
    }
    throw new Error('math_descriptive_statistics_bounded_generation_exhausted');
}
function createSubjectPracticeMathDescriptiveStatisticsLocalGenerator(ports) {
    return function generate(input) {
        const seed = Number.isSafeInteger(input.seed) ? Math.abs(input.seed) : 0, exactScope = (0, subject_practice_math_descriptive_statistics_solver_1.statisticsScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_LOCAL_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        if (!exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.difficulty !== 'basic' || b.questionType !== 'single_choice')
            return { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['math_descriptive_statistics_local_generator_question_plan_not_supported'] };
        const candidate = candidateFor(b, seed, exactScope), context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_descriptive_statistics_solver_1.solveSubjectPracticeMathDescriptiveStatistics)(candidate, context), oracleEvidence = (0, subject_practice_math_descriptive_statistics_independent_oracle_1.verifySubjectPracticeMathDescriptiveStatisticsWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_descriptive_statistics_explanation_verifier_1.verifySubjectPracticeMathDescriptiveStatisticsExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null,
            solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
            reasonCodes: verified ? [] : ['math_descriptive_statistics_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
