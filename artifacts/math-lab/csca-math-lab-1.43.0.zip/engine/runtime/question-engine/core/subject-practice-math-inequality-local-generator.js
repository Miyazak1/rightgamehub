"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathInequalityLocalGenerator = createSubjectPracticeMathInequalityLocalGenerator;
const subject_practice_math_inequality_solver_1 = require("./subject-practice-math-inequality-solver");
const subject_practice_math_inequality_independent_oracle_1 = require("./subject-practice-math-inequality-independent-oracle");
const subject_practice_math_inequality_explanation_verifier_1 = require("./subject-practice-math-inequality-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_LOCAL_GENERATOR_VERSION = 'math-inequality-local-generator-v1';
const SCOPES = new Set(['linear_gt_positive', 'linear_lt_positive', 'linear_gt_negative', 'linear_le_negative']);
function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').trim(); }
function seedValue(value) { const n = Number(value); return Number.isFinite(n) ? Math.abs(Math.trunc(n)) : 0; }
function scopeFrom(planValue, validate) { const plan = object(planValue); const render = object(plan?.renderConstraints); const scope = clean(render?.exactInequalityScope); return validate(planValue).valid && clean(plan?.taskFamily) === 'math_linear_inequality_solution' && clean(plan?.planTemplate) === 'math_linear_inequality_solution_v1' && SCOPES.has(scope) ? scope : null; }
function flip(relation) { return relation === '>' ? '<' : relation === '<' ? '>' : relation === '>=' ? '<=' : '>='; }
function candidateFor(blueprint, seed, scope) {
    const negative = scope.includes('negative');
    const coefficient = (2 + seed % 4) * (negative ? -1 : 1);
    const boundary = (seed % 9) - 4;
    const relation = scope.includes('_lt_') ? '<' : scope.includes('_le_') ? '<=' : '>';
    const offset = ((seed * 3) % 11) - 5;
    const rhs = coefficient * boundary + offset;
    const answerRelation = negative ? flip(relation) : relation;
    const expression = `${coefficient}x ${offset < 0 ? '-' : '+'} ${Math.abs(offset)} ${relation} ${rhs}`;
    const answer = `x ${answerRelation} ${boundary}`;
    const alternatives = [answer, `x ${flip(answerRelation)} ${boundary}`, `x ${answerRelation} ${boundary + 1}`, `x ${flip(answerRelation)} ${boundary - 1}`];
    const correctIndex = seed % 4;
    const ordered = alternatives.slice(1);
    ordered.splice(correctIndex, 0, alternatives[0]);
    const ids = ['A', 'B', 'C', 'D'];
    const options = ordered.map((text, index) => ({ id: ids[index], text }));
    const signSentence = negative ? '因为除以负数，不等号方向改变。' : '因为除以正数，不等号方向不变。';
    const prompt = `解不等式：${expression}。`;
    const promptEn = `Solve the inequality: ${expression}.`;
    const explanation = `移项后得 ${coefficient}x ${relation} ${coefficient * boundary}。${signSentence}所以 ${answer}。`;
    const explanationEn = `Isolate the x-term to get ${coefficient}x ${relation} ${coefficient * boundary}. ${negative ? 'Dividing by a negative number reverses the inequality sign.' : 'Dividing by a positive number keeps the inequality sign.'} Therefore ${answer}.`;
    const distractorDescriptor = (text, index) => {
        const descriptors = new Map([
            [`x ${flip(answerRelation)} ${boundary}`, ['kept_or_reversed_the_wrong_inequality_direction', ['inequality_direction_rule_error']]],
            [`x ${answerRelation} ${boundary + 1}`, ['shifted_the_solution_boundary_up_by_one', ['linear_inequality_boundary_error']]],
            [`x ${flip(answerRelation)} ${boundary - 1}`, ['used_both_wrong_direction_and_boundary', ['inequality_direction_rule_error', 'linear_inequality_boundary_error']]]
        ]);
        const descriptor = descriptors.get(text) ?? [`incorrect_linear_inequality_result_${index + 1}`, ['linear_inequality_transformation_error']];
        return { optionId: ids[index], distractorIntent: String(descriptor[0]), misconceptionTags: descriptor[1] };
    };
    return { subject: 'math', topicId: blueprint.topicId, blueprintId: blueprint.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options, correctAnswer: ids[correctIndex], explanation, knowledgeTags: ['不等式', '一元一次不等式', scope], optionMetadata: ordered.flatMap((text, index) => index === correctIndex ? [] : [distractorDescriptor(text, index)]), localizations: { zh: { prompt, options, explanation, knowledgeTags: ['不等式', '一元一次不等式'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Inequalities', 'Linear inequality'] } }, syllabusVersion: blueprint.syllabusVersion };
}
function createSubjectPracticeMathInequalityLocalGenerator(ports) { return function generate(input) { const seed = seedValue(input.seed); const exactScope = scopeFrom(input.questionPlan, ports.validate); const supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'basic' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice'; if (!exactScope || !supported)
    return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_inequality_local_generator_question_plan_not_supported'] }; const candidate = candidateFor(input.blueprint, seed, exactScope); const context = { questionPlan: input.questionPlan }; const solverEvidence = (0, subject_practice_math_inequality_solver_1.solveSubjectPracticeMathInequality)(candidate, context); const oracleEvidence = (0, subject_practice_math_inequality_independent_oracle_1.verifySubjectPracticeMathInequalityWithIndependentOracle)(candidate, context); const explanationEvidence = (0, subject_practice_math_inequality_explanation_verifier_1.verifySubjectPracticeMathInequalityExplanation)(candidate, context); const adherence = ports.adherenceFor(input.questionPlan, candidate); const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId; return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_inequality_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] }; }; }
