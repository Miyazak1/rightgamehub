"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.INTERVAL_SET_PARAMETER_ORACLE_VERSION = void 0;
exports.independentIntervalSetCertificate = independentIntervalSetCertificate;
exports.verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle = verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle;
// Intentionally no dependency on the main parser, interval algebra, generator or expected answer.
exports.INTERVAL_SET_PARAMETER_ORACLE_VERSION = 'math-interval-set-parameter-oracle-v1-critical-partition';
const scopes = ['translated_interval_subset_two_component_union', 'translated_interval_disjoint_two_component_union', 'translated_interval_meets_relative_complement', 'translated_interval_union_covers_target'];
const conditions = ['A(t) subset (B1 U B2)', 'A(t) intersect (B1 U B2) = empty', 'A(t) subset U and A(t) intersect (U \\ (B1 U B2)) != empty', '(D1 U D2) subset (C U A(t)) and A(t) subset U'];
function parseSegment(s) {
    const m = /^([[(])(-?\d{1,3}),(-?\d{1,3})([\])])$/.exec(s);
    if (!m)
        return null;
    const v = { left: +m[2], right: +m[3], leftIn: m[1] === '[', rightIn: m[4] === ']' };
    return v.left < v.right || (v.left === v.right && v.leftIn && v.rightIn) ? v : null;
}
const format = (s) => (s.leftIn ? '[' : '(') + s.left + ',' + s.right + (s.rightIn ? ']' : ')');
function parseVisible(text, scope, language) {
    const prefix = language === 'zh' ? '实参数t属于T。区间端点的开闭按括号确定；所有集合均为实数集。' : 'The parameter t is real and belongs to T. Brackets specify endpoint inclusion; all sets are real sets.';
    const suffix = (language === 'zh' ? '求使下列条件同时成立的全部t：' : 'Find all t satisfying the following conditions: ') + conditions[scope] + '.';
    if (typeof text !== 'string' || !text.startsWith(prefix) || !text.endsWith(suffix))
        return null;
    const data = text.slice(prefix.length, -suffix.length), m = /^T=(.+); A\(t\)=([[(])t\+\((-?\d+)\),t\+\((-?\d+)\)([\])]); ([BD])1=(.+); [BD]2=(.+)\.$/.exec(data);
    if (!m || m[6] !== (scope === 3 ? 'D' : 'B'))
        return null;
    const tail = m[8].split('; '), T = parseSegment(m[1]), b1 = parseSegment(m[7]), b2 = parseSegment(tail[0]), U = tail[1]?.startsWith('U=') ? parseSegment(tail[1].slice(2)) : null, C = tail[2]?.startsWith('C=') ? parseSegment(tail[2].slice(2)) : null;
    const a = { left: +m[3], right: +m[4], leftIn: m[2] === '[', rightIn: m[5] === ']' };
    if (!T || !b1 || !b2 || tail.length !== (scope < 2 ? 1 : scope === 2 ? 2 : 3) || (scope >= 2 && !U) || (scope === 3 && !C))
        return null;
    const p = { scope, T, A: a, B: [b1, b2], U, C };
    const fixed = [T, b1, b2, ...(U ? [U] : []), ...(C ? [C] : [])];
    if (fixed.some(s => s.left < -24 || s.right > 24 || s.left >= s.right) || !T.leftIn || !T.rightIn || a.left < -6 || a.right > 6 || a.right - a.left < 1 || a.right - a.left > 12 || [b1, b2].some(s => s.right - s.left < 2 || s.right - s.left > 12) || b2.left - b1.right < 2 || b2.left - b1.right > 10)
        return null;
    // Reconstruct only from this independently parsed syntax, including every optional field.
    const expected = 'T=' + format(T) + '; A(t)=' + (a.leftIn ? '[' : '(') + 't+(' + a.left + '),t+(' + a.right + ')' + (a.rightIn ? ']' : ')') + '; ' + m[6] + '1=' + format(b1) + '; ' + m[6] + '2=' + format(b2) + (U ? '; U=' + format(U) : '') + (C ? '; C=' + format(C) : '') + '.';
    return data === expected ? p : null;
}
const member = (x, s, scale) => (x > s.left * scale || x === s.left * scale && s.leftIn) && (x < s.right * scale || x === s.right * scale && s.rightIn);
const unique = (xs) => Array.from(new Set(xs)).sort((a, b) => a - b);
function cells(points) { const p = unique(points), r = []; for (let i = 0; i < p.length; i++) {
    r.push(p[i]);
    if (i + 1 < p.length)
        r.push((p[i] + p[i + 1]) / 2);
} return r; }
function evaluate(p, t2) {
    // t2 is twice t. x4 endpoints and their midpoints are exact integers; no tolerance.
    const moved = { left: t2 + 2 * p.A.left, right: t2 + 2 * p.A.right, leftIn: p.A.leftIn, rightIn: p.A.rightIn };
    const fixed = [...p.B, ...(p.U ? [p.U] : []), ...(p.C ? [p.C] : [])], events = unique([2 * moved.left, 2 * moved.right, ...fixed.flatMap(s => [4 * s.left, 4 * s.right])]), xs = cells([events[0] - 4, ...events, events[events.length - 1] + 4]);
    let subsetUnion = true, hit1 = false, hit2 = false, inU = true, hitComplement = false, covered = true, bInU = true, residualPoints = 0, coversPart = false;
    for (const x4 of xs) {
        const a = member(x4, moved, 2), b1 = member(x4, p.B[0], 4), b2 = member(x4, p.B[1], 4), b = b1 || b2, u = p.U ? member(x4, p.U, 4) : false, c = p.C ? member(x4, p.C, 4) : false;
        if (a && !b)
            subsetUnion = false;
        if (a && b1)
            hit1 = true;
        if (a && b2)
            hit2 = true;
        if (a && !u)
            inU = false;
        if (a && u && !b)
            hitComplement = true;
        if (b && !c && !a)
            covered = false;
        if (b && !u)
            bInU = false;
        if (b && !c)
            residualPoints++;
        if (b && c)
            coversPart = true;
    }
    const inside = member(t2, p.T, 2);
    let truth = false, relaxed = [];
    if (p.scope === 0) {
        truth = subsetUnion;
        // Relax opposite endpoint inequalities, retaining the other endpoint/contact condition.
        const lower = p.B.some(b => moved.left > 2 * b.left || moved.left === 2 * b.left && (!moved.leftIn || b.leftIn));
        const upper = p.B.some(b => moved.right < 2 * b.right || moved.right === 2 * b.right && (!moved.rightIn || b.rightIn));
        relaxed = [upper, lower];
    }
    else if (p.scope === 1) {
        truth = !hit1 && !hit2;
        relaxed = [!hit1, !hit2];
    }
    else if (p.scope === 2) {
        truth = inU && hitComplement;
        relaxed = [inU, hitComplement];
    }
    else {
        truth = inU && covered;
        relaxed = [inU, covered];
    }
    return { truth: inside && truth, relaxed: relaxed.map(v => inside && v), bInU, coversPart, residualPoints };
}
function join(pieces) {
    const out = [];
    for (const s of pieces.sort((a, b) => a.left - b.left || Number(b.leftIn) - Number(a.leftIn))) {
        const prev = out[out.length - 1];
        if (!prev || s.left > prev.right || s.left === prev.right && !s.leftIn && !prev.rightIn) {
            out.push({ ...s });
            continue;
        }
        if (s.right > prev.right) {
            prev.right = s.right;
            prev.rightIn = s.rightIn;
        }
        else if (s.right === prev.right)
            prev.rightIn = prev.rightIn || s.rightIn;
    }
    return out;
}
const encode = (ss) => join(ss).map(format).join(' U ') || 'empty';
function optionParse(text) {
    if (text === 'empty')
        return [];
    if (typeof text !== 'string' || text.length > 300)
        return null;
    const ss = text.split(' U ').map(parseSegment);
    return ss.length <= 4 && ss.every(s => s && Math.abs(s.left) <= 100 && Math.abs(s.right) <= 100) ? join(ss) : null;
}
function independentIntervalSetCertificate(p) {
    const fixed = [...p.B, ...(p.U ? [p.U] : []), ...(p.C ? [p.C] : [])];
    const critical = unique([p.T.left, p.T.right, ...fixed.flatMap(s => [s.left - p.A.left, s.left - p.A.right, s.right - p.A.left, s.right - p.A.right])].filter(t => t >= p.T.left && t <= p.T.right));
    const parts = [];
    for (let j = 0; j < critical.length; j++) {
        const t = critical[j], v = evaluate(p, 2 * t);
        parts.push({ kind: 'point', lo: t, hi: t, t2: 2 * t, truth: v.truth, relaxed: v.relaxed });
        if (j + 1 < critical.length) {
            const r = critical[j + 1], w = evaluate(p, t + r);
            parts.push({ kind: 'open', lo: t, hi: r, t2: t + r, truth: w.truth, relaxed: w.relaxed });
        }
    }
    const accepted = join(parts.filter(c => c.truth).map(c => ({ left: c.lo, right: c.hi, leftIn: c.kind === 'point', rightIn: c.kind === 'point' }))), answer = encode(accepted), witnesses = [0, 1].map(k => parts.find(c => c.relaxed[k] && !c.truth)?.t2 ?? null);
    // Count connected components of transformed x sets independently by endpoint cells.
    const xevents = unique(fixed.flatMap(s => [s.left, s.right])), atoms = [];
    for (let j = 0; j < xevents.length; j++) {
        for (const point of [true, false]) {
            if (!point && j + 1 === xevents.length)
                continue;
            const l = xevents[j], r = point ? l : xevents[j + 1], x = point ? l : (l + r) / 2, b = p.B.some(s => member(x, s, 1)), u = p.U ? member(x, p.U, 1) : false, c = p.C ? member(x, p.C, 1) : false, ok = p.scope === 2 ? u && !b : p.scope === 3 ? b && !c : b;
            if (ok)
                atoms.push({ left: l, right: r, leftIn: point, rightIn: point });
        }
    }
    const transformed = join(atoms), v = evaluate(p, 2 * p.T.left), validHard = answer !== 'empty' && answer !== format(p.T) && witnesses.every(x => x !== null) && (p.scope === 0 ? accepted.length === 2 : p.scope === 1 ? accepted.length >= 2 : p.scope === 2 ? transformed.length >= 2 && v.bInU : transformed.length === 2 && v.bInU && v.coversPart);
    return { version: 'interval-critical-partition-certificate-v1', criticalValues: critical, parts, completeCertificate: parts.length === 2 * critical.length - 1, orderInvariant: 'Between consecutive endpoint-difference events, every moving/fixed endpoint order and all set predicates are constant.', representativeScale: 2, xEndpointScale: 4, answer, effectiveConstraintWitnessesTwiceT: witnesses, transformedSet: encode(transformed), validHard };
}
function verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle(candidate, context = {}) {
    const plan = context.questionPlan, r = plan?.renderConstraints, idx = scopes.indexOf(r?.exactIntervalSetParameterScope), reasonCodes = [];
    const expectedConstraints = { topicCode: 'M-SET-001', boundedIntegerParameters: true, fixedEndpointMin: -24, fixedEndpointMax: 24, movingOffsetMin: -6, movingOffsetMax: 6, maximumConstructionAttempts: 128, parameterDomain: 'bounded_real_interval', minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
    const matched = idx >= 0 && plan?.schemaVersion === 'subject-practice-question-plan-v1' && plan?.policyVersion === 'subject-practice-question-plan-policy-v1' && plan?.subject === 'math' && plan?.topicId === 66 && plan?.targetDifficulty === 'hard' && plan?.representationType === 'text' && plan?.taskFamily === 'math_interval_set_parameter_reasoning' && plan?.planTemplate === 'math_interval_set_parameter_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(expectedConstraints).every(([k, v]) => r?.[k] === v) && plan?.scenarioContract?.scenarioMode === 'abstract' && plan?.scenarioContract?.scenarioEntity === 'parameterized_interval_set_system' && plan?.scenarioContract?.scenarioAction === scopes[idx];
    const p = matched ? parseVisible(candidate.prompt, idx, 'zh') : null, cert = p ? independentIntervalSetCertificate(p) : null;
    if (!p || !cert?.completeCertificate || !cert?.validHard)
        reasonCodes.push('interval_oracle_incomplete_or_degenerate');
    if (candidate.subject !== 'math' || candidate.topicId !== 66 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('interval_oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => { const a = optionParse(o.text); return a ? encode(a) : null; });
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('interval_oracle_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!p || JSON.stringify(parseVisible(l?.prompt ?? '', idx, lang)) !== JSON.stringify(p))
            reasonCodes.push('interval_oracle_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => { const v = optionParse(o.text); return [o.id, v ? encode(v) : null]; })) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('interval_oracle_' + lang + '_options');
    }
    const trueOptionIds = opts.filter((o, j) => cert && keys[j] === cert.answer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('interval_oracle_answer');
    if (cert) {
        const answer = optionParse(cert.answer);
        const left = answer.map(s => ({ ...s })), right = answer.map(s => ({ ...s }));
        if (left.length)
            left[0].leftIn = !left[0].leftIn;
        if (right.length)
            right[right.length - 1].rightIn = !right[right.length - 1].rightIn;
        const complement = cert.parts.filter(c => !c.truth).map(c => ({ left: c.lo, right: c.hi, leftIn: c.kind === 'point', rightIn: c.kind === 'point' }));
        const errors = { reverse_left_contact_inclusion: encode(left), reverse_right_contact_inclusion: encode(right), negate_required_set_predicate: encode(complement) };
        const meta = candidate.optionMetadata ?? [];
        if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || errors[m.distractorIntent ?? ''] !== keys[opts.findIndex(o => o.id === m.optionId)]))
            reasonCodes.push('interval_oracle_error_intent');
    }
    return { oracleVersion: exports.INTERVAL_SET_PARAMETER_ORACLE_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: p ? 'math-hard-interval-set-parameter-v1:' + scopes[idx] : null, scopeMatched: !!p, completeCertificate: !!cert?.completeCertificate && !!cert.validHard, certificate: cert, expectedAnswer: cert?.answer ?? null, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
