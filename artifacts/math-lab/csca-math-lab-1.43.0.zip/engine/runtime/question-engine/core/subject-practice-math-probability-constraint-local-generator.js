"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROBABILITY_CONSTRAINT_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathProbabilityConstraintLocalGenerator = createSubjectPracticeMathProbabilityConstraintLocalGenerator;
const math_lab_diversity_parameter_bank_1 = require("./math-lab-diversity-parameter-bank");
const subject_practice_math_probability_constraint_solver_1 = require("./subject-practice-math-probability-constraint-solver");
const subject_practice_math_probability_constraint_independent_oracle_1 = require("./subject-practice-math-probability-constraint-independent-oracle");
const subject_practice_math_probability_constraint_explanation_verifier_1 = require("./subject-practice-math-probability-constraint-explanation-verifier");
exports.PROBABILITY_CONSTRAINT_GENERATOR_VERSION = 'math-probability-constraint-generator-v1-bounded';
function createSubjectPracticeMathProbabilityConstraintLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, scope = (0, subject_practice_math_probability_constraint_solver_1.probabilityConstraintScopeFrom)(input.questionPlan), b = input.blueprint, common = { generatorVersion: scope === subject_practice_math_probability_constraint_solver_1.PROBABILITY_CONSTRAINT_SCOPES[0] ? exports.PROBABILITY_CONSTRAINT_GENERATOR_VERSION + ':' + math_lab_diversity_parameter_bank_1.DIVERSITY_BANK_VERSION : exports.PROBABILITY_CONSTRAINT_GENERATOR_VERSION, seed, exactScope: scope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false }, unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['probability_constraint_local_plan_not_supported'] };
        if (!validSeed || !scope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 75 || b.topicCode !== 'M-PROB-001' || b.difficulty !== 'hard' || b.questionType !== 'single_choice')
            return unsupported;
        for (let attempt = 0; attempt < 256; attempt++) {
            const i = subject_practice_math_probability_constraint_solver_1.PROBABILITY_CONSTRAINT_SCOPES.indexOf(scope);
            let state = ((seed + 1) * 2654435761 + attempt * 2246822519) >>> 0;
            const next = (max) => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return (state >>> 0) % max; };
            let values;
            if (i === 0) {
                values = (0, math_lab_diversity_parameter_bank_1.diversityParameters)(scope, seed, attempt).map(Number);
            }
            else if (i === 1) {
                values = [1 + next(6), 1 + next(6), 1 + next(6), 4 + next(2)];
            }
            else if (i === 2) {
                const R1 = 2 + next(11), R2 = 2 + next(11);
                values = [R1, 2 + next(Math.min(11, 17 - R1)), R2, 2 + next(Math.min(11, 17 - R2))];
            }
            else {
                const N = 8 + next(5), L = 7 + next(N), U = L + 3 + next(Math.max(1, 3 * N - 4 - L - 3));
                values = [N, L, U, 3 + next(N - 4)];
            }
            const data = values.map(String);
            const p = { scope, data }, d = (0, subject_practice_math_probability_constraint_solver_1.probabilityConstraintDerive)(p);
            if (!d)
                continue;
            const choices = d.errors.map(e => ({ text: e.text, intent: e.intent })), correctAnswer = 'ABCD'[Math.floor(seed / 4) % 4];
            choices.splice('ABCD'.indexOf(correctAnswer), 0, { text: d.answer, intent: '' });
            const options = choices.map((e, j) => ({ id: 'ABCD'[j], text: e.text })), prompt = (0, subject_practice_math_probability_constraint_solver_1.probabilityConstraintPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_probability_constraint_solver_1.probabilityConstraintPrompt)(p, 'en'), explanation = (0, subject_practice_math_probability_constraint_explanation_verifier_1.renderProbabilityConstraintExplanation)(p, d.answer, correctAnswer), tags = ['古典概型', '多约束有限样本计数', scope];
            const candidate = { subject: 'math', topicId: 75, blueprintId: input.blueprint.id, sourceType: 'ai', designedDifficulty: 'hard', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: tags, optionMetadata: choices.flatMap((e, j) => e.intent ? [{ optionId: 'ABCD'[j], distractorIntent: e.intent, misconceptionTags: [e.intent] }] : []), localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: tags }, en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Classical probability', 'Constrained finite counting', scope] } }, syllabusVersion: input.blueprint.syllabusVersion };
            const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_probability_constraint_solver_1.solveSubjectPracticeMathProbabilityConstraint)(candidate, context), oracleEvidence = (0, subject_practice_math_probability_constraint_independent_oracle_1.verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_probability_constraint_explanation_verifier_1.verifySubjectPracticeMathProbabilityConstraintExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate), verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.expectedAnswer === oracleEvidence.expectedAnswer && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
            return { ...common, parameterAttempts: attempt + 1, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
        }
        return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts: 256 };
    };
}
