"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PLANE_ANALYTIC_GEOMETRY_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathPlaneAnalyticGeometryWithIndependentOracle = verifySubjectPracticeMathPlaneAnalyticGeometryWithIndependentOracle;
// Deliberately self-contained: no generator, solver, parser or answer helper imports.
exports.PLANE_ANALYTIC_GEOMETRY_ORACLE_VERSION = 'math-plane-analytic-geometry-oracle-v1-independent-elimination';
const scopes = ['line_intersection_then_point_distance', 'parallel_lines_distance', 'circle_line_chord_length', 'circle_tangent_at_point'];
const abs = (n) => n < 0n ? -n : n;
function gcd(a, b) { a = abs(a); b = abs(b); while (b) {
    [a, b] = [b, a % b];
} return a; }
class R {
    n;
    d;
    constructor(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
        throw Error('zero denominator'); if (b < 0n) {
        a = -a;
        b = -b;
    } const g = gcd(a, b); this.n = a / g; this.d = b / g; }
    add(b) { return new R(this.n * b.d + b.n * this.d, this.d * b.d); }
    sub(b) { return new R(this.n * b.d - b.n * this.d, this.d * b.d); }
    mul(b) { return new R(this.n * b.n, this.d * b.d); }
    div(b) { return new R(this.n * b.d, this.d * b.n); }
    sq() { return this.mul(this); }
    eq(b) { return this.n === b.n && this.d === b.d; }
    toString() { return String(this.n) + (this.d === 1n ? '' : '/' + this.d); }
}
function root(n) { if (n < 0n)
    return null; let left = 0n, right = n + 1n; while (right - left > 1n) {
    const mid = (left + right) / 2n;
    if (mid * mid > n)
        right = mid;
    else
        left = mid;
} return left * left === n ? left : null; }
function sqrt(q) { const a = root(q.n), b = root(q.d); return a === null || b === null ? null : new R(a, b); }
const num = '(-?\\d{1,5})', ln = '\\(' + num + '\\)\\*x\\+\\(' + num + '\\)\\*y\\+\\(' + num + '\\)=0';
const circ = 'x\\^2\\+y\\^2\\+\\(' + num + '\\)\\*x\\+\\(' + num + '\\)\\*y\\+\\(' + num + '\\)=0';
const pt = '\\(' + num + ',' + num + '\\)';
function parse(text, scope, lang) {
    const i = scopes.indexOf(scope);
    if (i < 0 || typeof text !== 'string' || text.length > 1500)
        return null;
    const patterns = lang === 'zh' ? [
        '两直线 L1: ' + ln + ' 与 L2: ' + ln + ' 交于 P，给定 Q=' + pt + '。求距离 PQ。',
        '给定两直线 L1: ' + ln + ' 与 L2: ' + ln + '。先确认平行并统一系数尺度，再求两线间距离。',
        '圆 C: ' + circ + ' 与直线 L: ' + ln + ' 相交于两点。求所截弦的全长。',
        '圆 C: ' + circ + '，给定圆上点 P=' + pt + '。求圆在 P 处的切线方程。'
    ] : [
        'Lines L1: ' + ln + ' and L2: ' + ln + ' intersect at P\\. Given Q=' + pt + ', find the distance PQ\\.',
        'Given lines L1: ' + ln + ' and L2: ' + ln + ', verify parallelism and normalize the coefficients, then find their distance\\.',
        'Circle C: ' + circ + ' intersects line L: ' + ln + ' at two points\\. Find the full chord length\\.',
        'Circle C: ' + circ + '\\. Given P=' + pt + ' on the circle, find its tangent line at P\\.'
    ];
    const m = text.match(new RegExp('^' + patterns[i] + '$'));
    if (!m)
        return null;
    const values = m.slice(1).map(BigInt);
    return values.every(n => abs(n) <= 10000n) ? values : null;
}
function option(text, line) {
    if (typeof text !== 'string' || text.length > 180)
        return null;
    const items = line ? text.trim().match(/^\(([^)]+)\)\*x\+\(([^)]+)\)\*y\+\(([^)]+)\)=0$/)?.slice(1) : [text.trim()];
    if (!items)
        return null;
    const out = [];
    for (const item of items) {
        const m = item.match(/^([+-]?\d{1,6})(?:\/([+-]?\d{1,6}))?$/);
        if (!m || !BigInt(m[2] ?? 1))
            return null;
        const q = new R(BigInt(m[1]), BigInt(m[2] ?? 1));
        if (abs(q.n) > 10000n || q.d > 10000n)
            return null;
        out.push(q);
    }
    if (line) {
        const pivot = out[0].n ? out[0] : out[1];
        if (!pivot.n)
            return null;
        return out.map(x => x.div(pivot));
    }
    return out;
}
const key = (qs) => qs.map(String).join(',');
const bases = new Set(['1,0', '0,1', '3,4', '4,3', '5,12', '12,5']);
function lineCircle(D, E, F, line) {
    const [a, b, c] = line;
    if (!a.n && !b.n)
        return null;
    // An entire line is P0+t*V. The resulting quadratic covers ALL intersections.
    const px = a.n ? new R(0).sub(c).div(a) : new R(0), py = a.n ? new R(0) : new R(0).sub(c).div(b), vx = b, vy = new R(0).sub(a);
    const A = vx.sq().add(vy.sq()), B = px.mul(vx).add(py.mul(vy)).mul(new R(2)).add(vx.mul(new R(D))).add(vy.mul(new R(E)));
    const C = px.sq().add(py.sq()).add(px.mul(new R(D))).add(py.mul(new R(E))).add(new R(F));
    const discriminant = B.sq().sub(A.mul(C).mul(new R(4))), rad = sqrt(discriminant);
    if (!rad)
        return null;
    const t1 = new R(0).sub(B).sub(rad).div(A.mul(new R(2))), t2 = new R(0).sub(B).add(rad).div(A.mul(new R(2)));
    return { A, B, C, discriminant, points: [[px.add(vx.mul(t1)), py.add(vy.mul(t1))], [px.add(vx.mul(t2)), py.add(vy.mul(t2))]] };
}
function certificate(v, scope) {
    const i = scopes.indexOf(scope), wrong = [];
    let answer = null;
    let proof = {};
    if (i === 0) {
        const [a, b, c, d, e, f, qx, qy] = v;
        if ((!a && !b) || (!d && !e) || [a, b, d, e].some(x => abs(x) > 3n))
            return null;
        // Gaussian row elimination, independent of the Solver's determinant quotient.
        let row1 = [a, b, -c].map(n => new R(n)), row2 = [d, e, -f].map(n => new R(n));
        if (!row1[0].n)
            [row1, row2] = [row2, row1];
        if (!row1[0].n)
            return null;
        const factor = row2[0].div(row1[0]), pivot = row2[1].sub(factor.mul(row1[1]));
        if (!pivot.n)
            return null;
        const y = row2[2].sub(factor.mul(row1[2])).div(pivot), x = row1[2].sub(row1[1].mul(y)).div(row1[0]);
        if (x.d !== 1n || y.d !== 1n || abs(x.n) > 6n || abs(y.n) > 6n || a * x.n + b * y.n + c !== 0n || d * x.n + e * y.n + f !== 0n)
            return null;
        const dx = qx - x.n, dy = qy - y.n;
        if (![1n, 2n, 3n].some(k => (abs(dx) === 3n * k && abs(dy) === 4n * k) || (abs(dx) === 4n * k && abs(dy) === 3n * k)))
            return null;
        const distance = sqrt(new R(dx * dx + dy * dy));
        if (!distance)
            return null;
        answer = [distance];
        wrong.push({ key: String(distance.sq()), intent: 'report_squared_distance' }, { key: String(abs(dx) + abs(dy)), intent: 'use_manhattan_distance' }, { key: String(abs(dx)), intent: 'omit_vertical_displacement' });
        proof = { method: 'independent_row_elimination', point: [String(x), String(y)], secondPivot: String(pivot), equationsVerified: true, distanceSquared: String(distance.sq()) };
    }
    else if (i === 1) {
        const [a, b, c, d, e, f] = v;
        if (!bases.has(abs(a) + ',' + abs(b)) || abs(c) > 12n || a * e !== b * d)
            return null;
        const lambda = a ? new R(d, a) : new R(e, b), N = root(a * a + b * b);
        if (!N || lambda.d !== 1n || ![-3n, -2n, 2n, 3n].includes(lambda.n))
            return null;
        const separation = new R(f).div(lambda).sub(new R(c)).div(new R(N));
        if (separation.d !== 1n || !separation.n || abs(separation.n) > 6n)
            return null;
        const px = a ? new R(-c, a) : new R(0), py = a ? new R(0) : new R(-c, b), den = new R(d * d + e * e);
        const step = new R(d).mul(px).add(new R(e).mul(py)).add(new R(f)).div(den), fx = px.sub(new R(d).mul(step)), fy = py.sub(new R(e).mul(step));
        if (!new R(d).mul(fx).add(new R(e).mul(fy)).add(new R(f)).eq(new R(0)))
            return null;
        const distance = sqrt(px.sub(fx).sq().add(py.sub(fy).sq()));
        if (!distance || !distance.n)
            return null;
        answer = [distance];
        wrong.push({ intent: 'v117_added_normalized_constants', key: String(new R(abs(c*lambda.n+f),N*abs(lambda.n))) }, { intent:'v117_reported_half_separation',key:String(distance.div(new R(2))) }, { intent:'v117_reported_double_separation',key:String(distance.mul(new R(2))) }, {key:String(new R(-distance.n,distance.d)),intent:'return_negative_distance'}, { key: String(new R(abs(f - c), N)), intent: 'subtract_constants_without_scale_normalization' }, { key: String(distance.sq()), intent: 'report_squared_distance' });
        proof = { method: 'independent_perpendicular_foot', point: [String(px), String(py)], foot: [String(fx), String(fy)], parallelCrossProduct: '0', distanceSquared: String(distance.sq()), completeParallelLines: true };
    }
    else {
        const [D, E, F] = v;
        if (D % 2n || E % 2n)
            return null;
        const h = -D / 2n, k = -E / 2n, r2 = h * h + k * k - F;
        if (abs(h) > 6n || abs(k) > 6n || r2 <= 0n)
            return null;
        if (i === 2) {
            const [a, b, c] = v.slice(3);
            if (!bases.has(abs(a) + ',' + abs(b)))
                return null;
            const norm = root(a * a + b * b), radius = root(r2);
            if (!norm || !radius)
                return null;
            const distance = new R(abs(a * h + b * k + c), norm);
            if (distance.d !== 1n || distance.n <= 0n || distance.n >= radius)
                return null;
            const half = root(r2 - distance.n * distance.n);
            if (!half)
                return null;
            if (![[5n, 3n, 4n], [5n, 4n, 3n], [13n, 5n, 12n], [13n, 12n, 5n], [17n, 8n, 15n], [17n, 15n, 8n]].some(t => [1n, 2n].some(s => radius === s * t[0] && distance.n === s * t[1] && half === s * t[2])))
                return null;
            const all = lineCircle(D, E, F, [a, b, c].map(n => new R(n)));
            if (!all || all.discriminant.n <= 0n)
                return null;
            const [p, q] = all.points, L = sqrt(p[0].sub(q[0]).sq().add(p[1].sub(q[1]).sq()));
            if (!L || L.n <= 0n)
                return null;
            answer = [L];
            wrong.push({ key: String(L.div(new R(2))), intent: 'report_half_chord' }, { key: String(2n * radius), intent: 'substitute_circle_diameter' }, { key: String(2n * (radius - distance.n)), intent: 'subtract_lengths_instead_of_pythagoras' });
            proof = { method: 'complete_line_parameterization_quadratic_roots', quadratic: [String(all.A), String(all.B), String(all.C)], discriminant: String(all.discriminant), intersections: all.points.map(p => p.map(String)), distanceSquared: String(L.sq()) };
        }
        else if (i === 3) {
            const [x, y] = v.slice(3), u = x - h, w = y - k;
            if (abs(u) > 6n || abs(w) > 6n || u * u + w * w !== r2 || r2 > 72n || x * x + y * y + D * x + E * y + F !== 0n)
                return null;
            // Answer is selected below by discriminant and incidence, NOT from this normal vector.
            const lineKey = (xs) => { const qs = xs.map(n => new R(n)), pivot = qs[0].n ? qs[0] : qs[1]; return key(qs.map(q => q.div(pivot))); };
            wrong.push({ key: lineKey([-w, u, w * x - u * y]), intent: 'return_radius_normal_line' }, { key: lineKey([u, w, u * x + w * y]), intent: 'reverse_translation_sign' }, { key: lineKey([u, w, 0n]), intent: 'force_tangent_through_origin' });
            proof = { method: 'line_substitution_double_root_at_given_point', circle: [D, E, F].map(String), point: [x, y].map(String) };
        }
        else
            return null;
    }
    return { answer, wrong, proof };
}
function verifySubjectPracticeMathPlaneAnalyticGeometryWithIndependentOracle(candidate, context = {}) {
    const p = context.questionPlan, r = p?.renderConstraints, s = p?.scenarioContract, scope = String(r?.exactPlaneAnalyticGeometryScope ?? ''), reasonCodes = [];
    const contract = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 72 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === 'math_plane_analytic_geometry_relation' && p?.planTemplate === 'math_plane_analytic_geometry_relation_v1' && r?.questionType === 'single_choice' && r?.topicCode === 'M-GEO-001' && r?.boundedIntegerParameters === true && r?.exactRationalArithmetic === true && r?.maximumAbsoluteValue === 10000 && r?.completeAnalyticGeometryCertificate === true && r?.externalContextAllowed === false && r?.requiresImage === false && r?.minimumVisibleMoves === 2
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'plane_line_circle_object' && s?.scenarioAction === scope && scopes.includes(scope);
    const values = contract ? parse(candidate.prompt, scope, 'zh') : null, cert = values ? certificate(values, scope) : null;
    if (!contract || !values || !cert)
        reasonCodes.push('plane_geometry_oracle_outside_contract');
    if (candidate.subject !== 'math' || candidate.topicId !== 72 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('plane_geometry_oracle_identity');
    const line = scope === scopes[3], options = candidate.options ?? [], parsed = options.map(o => option(o.text, line)), keys = parsed.map(q => q ? key(q) : null);
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        const other = loc ? parse(loc.prompt ?? '', scope, lang) : null;
        if (!values || !other || String(other) !== String(values))
            reasonCodes.push('plane_geometry_oracle_' + lang + '_prompt');
        if (!loc?.options || JSON.stringify(loc.options.map(o => { const v = option(o.text, line); return [o.id, v ? key(v) : null]; })) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('plane_geometry_oracle_' + lang + '_options');
    }
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('plane_geometry_oracle_duplicate_or_invalid_options');
    const proofs = [];
    const optionVerdicts = options.map((o, i) => {
        const q = parsed[i];
        let correct = false;
        if (cert && values && q) {
            if (!line)
                correct = Boolean(cert.answer && q[0].eq(cert.answer[0]));
            else {
                const [D, E, F, x, y] = values, intersections = lineCircle(D, E, F, q), incidence = q[0].mul(new R(x)).add(q[1].mul(new R(y))).add(q[2]).eq(new R(0));
                correct = Boolean(incidence && intersections && intersections.discriminant.n === 0n && intersections.points[0][0].eq(new R(x)) && intersections.points[0][1].eq(new R(y)));
                proofs.push({ optionId: o.id, incidence, discriminant: intersections ? String(intersections.discriminant) : null, doubleRootAtPoint: correct });
            }
        }
        return { optionId: o.id, semanticValue: keys[i], verdict: !q ? 'unknown' : correct ? 'true' : 'false' };
    });
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || candidate.correctAnswer !== selectedOptionId)
        reasonCodes.push('plane_geometry_oracle_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !cert?.wrong.some(w => w.intent === m.distractorIntent && w.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('plane_geometry_oracle_error_intent');
    return { oracleVersion: exports.PLANE_ANALYTIC_GEOMETRY_ORACLE_VERSION, status: reasonCodes.length ? (cert ? 'conflict' : 'unparsed') : 'verified',
        scopeId: cert ? 'math-medium-plane-analytic-geometry-v1:' + scope : null, scopeMatched: Boolean(cert), selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        completeCertificate: Boolean(cert) && reasonCodes.length === 0, certificate: cert?.proof ?? null, tangentOptionCertificates: proofs, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
