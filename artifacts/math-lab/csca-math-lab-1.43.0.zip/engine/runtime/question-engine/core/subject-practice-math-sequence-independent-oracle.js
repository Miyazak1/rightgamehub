"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathSequenceWithIndependentOracle = verifySubjectPracticeMathSequenceWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_INDEPENDENT_ORACLE_VERSION = 'math-sequence-independent-oracle-v1';
function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function normalized(value) { return String(value ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ' ').trim(); }
function exactScope(context) {
    const plan = object(context.questionPlan);
    const render = object(plan?.renderConstraints);
    const scope = normalized(render?.exactSequenceScope);
    return normalized(plan?.taskFamily) === 'math_basic_sequence_direct_calculation'
        && normalized(plan?.planTemplate) === 'math_basic_sequence_direct_calculation_v1'
        && ['arithmetic_explicit_term', 'geometric_explicit_term', 'arithmetic_partial_sum', 'geometric_partial_sum'].includes(scope) ? scope : null;
}
function parameter(text, symbol) { const match = normalized(text).match(new RegExp(`${symbol}\\s*=\\s*(-?\\d+)`, 'i')); return match ? Number.parseInt(match[1], 10) : null; }
function parse(prompt, scope) {
    if (!scope)
        return null;
    const text = normalized(prompt);
    const a1 = parameter(text, 'a_?1');
    const d = parameter(text, 'd');
    const q = parameter(text, 'q');
    const tokens = [...text.matchAll(scope.endsWith('partial_sum') ? /S_?(\d+)/gi : /a_?(\d+)/gi)];
    const n = tokens.length ? Number.parseInt(tokens[tokens.length - 1][1], 10) : null;
    if (a1 === null || n === null || n < 2)
        return null;
    if (scope.startsWith('arithmetic_') && (d === null || d === 0))
        return null;
    if (scope.startsWith('geometric_') && (q === null || [0, 1, -1].includes(q)))
        return null;
    return { a1, d, q, n };
}
function repeatedProduct(base, exponent) { let value = 1; for (let index = 0; index < exponent; index += 1)
    value *= base; return value; }
function expected(scope, p) {
    if (scope === 'arithmetic_explicit_term') {
        let value = p.a1;
        for (let i = 1; i < p.n; i += 1)
            value += Number(p.d);
        return value;
    }
    if (scope === 'geometric_explicit_term')
        return p.a1 * repeatedProduct(Number(p.q), p.n - 1);
    if (scope === 'arithmetic_partial_sum') {
        let term = p.a1;
        let sum = 0;
        for (let i = 0; i < p.n; i += 1) {
            sum += term;
            term += Number(p.d);
        }
        return sum;
    }
    let term = p.a1;
    let sum = 0;
    for (let i = 0; i < p.n; i += 1) {
        sum += term;
        term *= Number(p.q);
    }
    return sum;
}
function verifySubjectPracticeMathSequenceWithIndependentOracle(candidate, context = {}) {
    const scope = exactScope(context);
    const parameters = parse(candidate.prompt, scope);
    const parsed = Boolean(scope && parameters);
    const wanted = parsed ? expected(scope, parameters) : null;
    const optionVerdicts = (candidate.options ?? []).map((option) => { const value = Number(normalized(option.text)); const valid = Number.isSafeInteger(value); return { optionId: option.id, verdict: !valid ? 'unknown' : value === wanted ? 'true' : 'false' }; });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!parsed)
        reasonCodes.push('math_sequence_oracle_prompt_or_plan_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_sequence_oracle_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_sequence_oracle_answer_not_unique');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_sequence_oracle_generator_disagreement');
    return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_INDEPENDENT_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'disagreed' : 'abstained') : 'verified', scopeId: parsed ? `math-basic-sequence-v1:${scope}` : null, exactScope: scope, parameters, expectedValue: wanted, scopeMatched: parsed, optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
