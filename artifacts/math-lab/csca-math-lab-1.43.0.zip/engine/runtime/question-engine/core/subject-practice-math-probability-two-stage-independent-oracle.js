"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROBABILITY_TWO_STAGE_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathProbabilityTwoStageWithIndependentOracle = verifySubjectPracticeMathProbabilityTwoStageWithIndependentOracle;
// Deliberately independent: no Solver, generator, reducer or explanation imports.
exports.PROBABILITY_TWO_STAGE_ORACLE_VERSION = 'math-probability-two-stage-oracle-v1-labelled-enumeration';
const scopes = ['without_replacement_both_target', 'without_replacement_one_of_each', 'independent_two_boxes_both_target', 'independent_two_boxes_at_least_one_target'];
function rational(a, b) {
    if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b) || b < 1 || a < 0 || a > b)
        return null;
    for (let factor = Math.min(a, b); factor >= 2; factor--)
        if (a % factor === 0 && b % factor === 0) {
            a /= factor;
            b /= factor;
            break;
        }
    if (a === 0)
        return '0';
    return b === 1 ? String(a) : a + '/' + b;
}
function option(s) { const m = typeof s === 'string' ? /^(0|[1-9]\d{0,5})(?:\/([1-9]\d{0,5}))?$/.exec(s.trim()) : null; return m ? rational(+m[1], +(m[2] ?? 1)) : null; }
function parse(text, index, lang) {
    if (typeof text !== 'string' || text.length > 1000)
        return null;
    const introductions = lang === 'zh' ? ['进行如下等可能抽取实验。', '考察下面的随机抽取过程。', '一次抽取实验按下列规则进行。', '按以下规则进行两次抽取。']
        : ['Consider this uniform sampling experiment. ', 'Examine the following random selection process. ', 'An experiment follows the rules below. ', 'Carry out two draws according to these rules. '];
    const variant = introductions.findIndex(x => text.startsWith(x));
    if (variant < 0)
        return null;
    const body = text.slice(introductions[variant].length);
    const expressions = lang === 'zh' ? [
        /^一个盒中有 R=(\d+) 个红球和 B=(\d+) 个蓝球；每个球都有不同编号。依次抽取两个球，每次从剩余球中等可能抽取一个，不放回。求两个球都是红球的概率。$/,
        /^一个盒中有 R=(\d+) 个红球和 B=(\d+) 个蓝球；每个球都有不同编号。依次抽取两个球，每次从剩余球中等可能抽取一个，不放回。求恰好一个红球、一个蓝球（不计先后）的概率。$/,
        /^甲盒有 R1=(\d+) 个红球和 B1=(\d+) 个蓝球，乙盒有 R2=(\d+) 个红球和 B2=(\d+) 个蓝球；每个球都有不同编号。从每盒各等可能抽取一个球，两盒的抽取相互独立。求两个球都是红球的概率。$/,
        /^甲盒有 R1=(\d+) 个红球和 B1=(\d+) 个蓝球，乙盒有 R2=(\d+) 个红球和 B2=(\d+) 个蓝球；每个球都有不同编号。从每盒各等可能抽取一个球，两盒的抽取相互独立。求至少一个球是红球（包括两个都是红球）的概率。$/
    ]
        : [
            /^One box contains R=(\d+) red balls and B=(\d+) blue balls; every ball has a distinct label\. Draw two balls successively, each time uniformly from the remaining balls, without replacement\. Find the probability of both balls being red\.$/,
            /^One box contains R=(\d+) red balls and B=(\d+) blue balls; every ball has a distinct label\. Draw two balls successively, each time uniformly from the remaining balls, without replacement\. Find the probability of exactly one red and one blue ball, in either order\.$/,
            /^Box I contains R1=(\d+) red balls and B1=(\d+) blue balls; box II contains R2=(\d+) red balls and B2=(\d+) blue balls\. Every ball has a distinct label\. Draw one ball uniformly from each box; the two selections are independent\. Find the probability of both balls being red\.$/,
            /^Box I contains R1=(\d+) red balls and B1=(\d+) blue balls; box II contains R2=(\d+) red balls and B2=(\d+) blue balls\. Every ball has a distinct label\. Draw one ball uniformly from each box; the two selections are independent\. Find the probability of at least one red ball, including the case of two red balls\.$/
        ];
    const match = expressions[index]?.exec(body);
    if (!match)
        return null;
    const counts = match.slice(1).map(Number);
    return counts.every(n => Number.isInteger(n) && n >= 2 && n <= 12) ? { counts, variant } : null;
}
function enumerate(counts, oneBox, withReplacement = false) {
    const [r, b, u, v] = counts, n = r + b, m = oneBox ? n : u + v;
    const first = Array.from({ length: n }, (_, id) => ({ id, red: id < r })), second = oneBox ? first : Array.from({ length: m }, (_, id) => ({ id, red: id < u }));
    let total = 0, both = 0, none = 0, one = 0, redBlue = 0, firstRed = 0, secondRed = 0;
    for (const a of first)
        for (const z of second) {
            if (oneBox && !withReplacement && a.id === z.id)
                continue;
            total++;
            if (a.red)
                firstRed++;
            if (z.red)
                secondRed++;
            if (a.red && z.red)
                both++;
            else if (!a.red && !z.red)
                none++;
            else
                one++;
            if (a.red && !z.red)
                redBlue++;
        }
    return { total, both, none, one, redBlue, firstRed, secondRed, atLeastOne: both + one };
}
function verifySubjectPracticeMathProbabilityTwoStageWithIndependentOracle(candidate, context = {}) {
    const p = context.questionPlan, r = p?.renderConstraints, s = p?.scenarioContract, scope = r?.exactProbabilityTwoStageScope, index = scopes.indexOf(scope), reasonCodes = [];
    const required = { topicCode: 'M-PROB-001', boundedIntegerParameters: true, minimumColourCount: 2, maximumColourCount: 12, exactRationalArithmetic: true,
        completeLabelledSampleSpaceCertificate: true, drawCountExactly: 2, externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
    const planValid = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 75 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === 'math_classical_probability_two_stage_calculation' && p?.planTemplate === 'math_classical_probability_two_stage_calculation_v1'
        && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v)
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'finite_two_stage_probability_experiment' && s?.scenarioAction === scope && index >= 0;
    const parsed = planValid ? parse(candidate.prompt, index, 'zh') : null;
    if (!parsed)
        reasonCodes.push('probability_two_stage_oracle_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 75 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('probability_two_stage_oracle_identity');
    const certificate = parsed ? enumerate(parsed.counts, index < 2) : null;
    const favourable = certificate ? (index === 0 || index === 2 ? certificate.both : index === 1 ? certificate.one : certificate.atLeastOne) : null;
    const expected = certificate && favourable !== null ? rational(favourable, certificate.total) : null;
    if (certificate && (certificate.total > (index < 2 ? 552 : 576) || certificate.both + certificate.none + certificate.one !== certificate.total || !expected || expected === '0' || expected === '1'))
        reasonCodes.push('probability_two_stage_oracle_incomplete_sample_space');
    const options = candidate.options ?? [], keys = options.map(o => option(o.text));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('probability_two_stage_oracle_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parsed || JSON.stringify(parse(loc?.prompt ?? '', index, lang)) !== JSON.stringify(parsed))
            reasonCodes.push('probability_two_stage_oracle_' + lang + '_stem');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, option(o.text)])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('probability_two_stage_oracle_' + lang + '_options');
    }
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : expected !== null && keys[i] === expected ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(v => v.verdict === 'true').map(v => v.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || candidate.correctAnswer !== selectedOptionId)
        reasonCodes.push('probability_two_stage_oracle_answer');
    const errors = {};
    if (parsed && certificate) {
        const e = certificate, rep = index < 2 ? enumerate(parsed.counts, true, true) : null;
        if (index === 0 && rep) {
            errors.assume_replacement = rational(rep.both, rep.total);
            errors.forget_red_count_decrement = rational(rep.both, e.total);
            errors.forget_total_decrement = rational(e.both, rep.total);
            errors.target_blue_instead = rational(e.none, e.total);
        }
        if (index === 1 && rep) {
            errors.count_only_one_order = rational(e.redBlue, e.total);
            errors.assume_replacement = rational(rep.one, rep.total);
            errors.require_both_red = rational(e.both, e.total);
            errors.require_both_blue = rational(e.none, e.total);
        }
        if (index >= 2) {
            errors.ignore_second_box = rational(e.firstRed, e.total);
            errors.ignore_first_box = rational(e.secondRed, e.total);
            errors.require_both_blue = rational(e.none, e.total);
            errors.require_red_then_blue = rational(e.redBlue, e.total);
            errors.use_at_least_one = rational(e.atLeastOne, e.total);
            errors.require_both_red = rational(e.both, e.total);
            errors.exclude_both_red = rational(e.one, e.total);
            errors.use_no_red = rational(e.none, e.total);
        }
    }
    const metadata = candidate.optionMetadata ?? [];
    if (metadata.length !== 3 || new Set(metadata.map(m => m.optionId)).size !== 3 || new Set(metadata.map(m => m.distractorIntent)).size !== 3
        || metadata.some(m => m.optionId === selectedOptionId || !Object.prototype.hasOwnProperty.call(errors, m.distractorIntent ?? '') || errors[m.distractorIntent ?? ''] === null
            || errors[m.distractorIntent ?? ''] !== keys[options.findIndex(o => o.id === m.optionId)]))
        reasonCodes.push('probability_two_stage_oracle_error_intent');
    const scopeId = parsed ? 'math-medium-probability-two-stage-v1:' + scope : null;
    return { oracleVersion: exports.PROBABILITY_TWO_STAGE_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        scopeId, scopeMatched: Boolean(parsed), selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        completeCertificate: Boolean(certificate && expected), certificate: certificate ? { ...certificate, favourable, probability: expected, independentlyEnumerated: true } : null,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
