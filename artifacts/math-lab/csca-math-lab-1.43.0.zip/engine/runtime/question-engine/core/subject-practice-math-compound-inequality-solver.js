"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.intervalSetText = exports.intervalText = exports.COMPOUND_INEQUALITY_CONSTRAINTS = exports.COMPOUND_INEQUALITY_SCOPES = exports.COMPOUND_INEQUALITY_SCOPE_VERSION = exports.COMPOUND_INEQUALITY_SOLVER_VERSION = exports.COMPOUND_INEQUALITY_TEMPLATE = exports.COMPOUND_INEQUALITY_FAMILY = void 0;
exports.compoundInequalityScopeFrom = compoundInequalityScopeFrom;
exports.normalizeIntervals = normalizeIntervals;
exports.intervalIntersect = intervalIntersect;
exports.intervalSubtract = intervalSubtract;
exports.parseIntervalSet = parseIntervalSet;
exports.compoundInequalityParametersValid = compoundInequalityParametersValid;
exports.compoundInequalityPrompt = compoundInequalityPrompt;
exports.compoundInequalityParametersFrom = compoundInequalityParametersFrom;
exports.compoundInequalityDerive = compoundInequalityDerive;
exports.solveSubjectPracticeMathCompoundInequality = solveSubjectPracticeMathCompoundInequality;
exports.COMPOUND_INEQUALITY_FAMILY = 'math_compound_inequality_constraint_reasoning';
exports.COMPOUND_INEQUALITY_TEMPLATE = exports.COMPOUND_INEQUALITY_FAMILY + '_v1';
exports.COMPOUND_INEQUALITY_SOLVER_VERSION = 'math-compound-inequality-solver-v1-exact-intervals';
exports.COMPOUND_INEQUALITY_SCOPE_VERSION = 'math-hard-compound-inequality-v1';
exports.COMPOUND_INEQUALITY_SCOPES = [
    'quadratic_and_fraction_conjunction', 'absolute_band_and_fraction_conjunction',
    'quadratic_domain_implies_absolute_bound', 'fraction_domain_implies_absolute_separation'
];
exports.COMPOUND_INEQUALITY_CONSTRAINTS = { topicCode: 'M-INEQ-001', boundedIntegerParameters: true,
    coefficientScaleAbsoluteMax: 5, criticalPointMin: -12, criticalPointMax: 12, domainEndpointMin: -24, domainEndpointMax: 24,
    maximumConstructionAttempts: 128, parameterDomain: 'bounded_real_interval',
    minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2,
    externalContextAllowed: false, requiresImage: false };
const rec = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function compoundInequalityScopeFrom(value) {
    const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactCompoundInequalityScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 67 && p?.targetDifficulty === 'hard' && p?.representationType === 'text'
        && p?.taskFamily === exports.COMPOUND_INEQUALITY_FAMILY && p?.planTemplate === exports.COMPOUND_INEQUALITY_TEMPLATE
        && r?.questionType === 'single_choice' && Object.entries(exports.COMPOUND_INEQUALITY_CONSTRAINTS).every(([k, v]) => r?.[k] === v)
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'compound_inequality_constraint_system' && s?.scenarioAction === scope
        && exports.COMPOUND_INEQUALITY_SCOPES.includes(scope) ? scope : null;
}
const valid = (s) => s.lo < s.hi || s.lo === s.hi && s.lc && s.hc;
const num = (v) => v === Infinity ? '+inf' : v === -Infinity ? '-inf' : String(v === 0 ? 0 : v);
const intervalText = (s) => (s.lc ? '[' : '(') + num(s.lo) + ',' + num(s.hi) + (s.hc ? ']' : ')');
exports.intervalText = intervalText;
function normalizeIntervals(ss) {
    const out = [];
    for (const s of ss.filter(valid).map(s => ({ ...s })).sort((a, b) => a.lo - b.lo || Number(b.lc) - Number(a.lc))) {
        const p = out[out.length - 1];
        if (!p || s.lo > p.hi || s.lo === p.hi && !s.lc && !p.hc) {
            out.push(s);
            continue;
        }
        if (s.hi > p.hi) {
            p.hi = s.hi;
            p.hc = s.hc;
        }
        else if (s.hi === p.hi)
            p.hc = p.hc || s.hc;
    }
    return out;
}
const intervalSetText = (ss) => normalizeIntervals(ss).map(exports.intervalText).join(' U ') || 'empty';
exports.intervalSetText = intervalSetText;
function intervalIntersect(a, b) {
    return normalizeIntervals(a.flatMap(x => b.map(y => ({ lo: Math.max(x.lo, y.lo), hi: Math.min(x.hi, y.hi),
        lc: x.lo > y.lo ? x.lc : y.lo > x.lo ? y.lc : x.lc && y.lc, hc: x.hi < y.hi ? x.hc : y.hi < x.hi ? y.hc : x.hc && y.hc }))));
}
function intervalSubtract(a, b) {
    let out = normalizeIntervals(a);
    for (const y of normalizeIntervals(b))
        out = out.flatMap(x => {
            const z = intervalIntersect([x], [y])[0];
            return !z ? [x] :
                [{ lo: x.lo, hi: z.lo, lc: x.lc, hc: !z.lc }, { lo: z.hi, hi: x.hi, lc: !z.hc, hc: x.hc }].filter(valid);
        });
    return normalizeIntervals(out);
}
const all = [{ lo: -Infinity, hi: Infinity, lc: false, hc: false }];
function parseIntervalSet(text) {
    if (text === 'empty')
        return [];
    if (typeof text !== 'string' || text.length > 400)
        return null;
    const out = [];
    for (const part of text.split(' U ')) {
        const m = /^([[(])(-?\d{1,3}(?:\/[1-9]\d?)?),(-?\d{1,3}(?:\/[1-9]\d?)?)([\])])$/.exec(part);
        if (!m)
            return null;
        // Registered boundaries are integer rationals. Accept equivalent integer fractions exactly.
        const n = (s) => { const [a, b = 1] = s.split('/').map(Number); return a % b === 0 ? a / b : NaN; };
        const s = { lo: n(m[2]), hi: n(m[3]), lc: m[1] === '[', hc: m[4] === ']' };
        if (!Number.isSafeInteger(s.lo) || !Number.isSafeInteger(s.hi) || Math.abs(s.lo) > 100 || Math.abs(s.hi) > 100 || !valid(s))
            return null;
        out.push(s);
    }
    return out.length <= 4 ? normalizeIntervals(out) : null;
}
const relations = ['<', '<=', '>', '>='];
function roots(q) {
    if (![q.a, q.b, q.c].every(Number.isSafeInteger) || !q.a || Math.abs(q.a) > 5)
        return null;
    const d = q.b * q.b - 4 * q.a * q.c, s = Math.sqrt(d);
    if (d <= 0 || !Number.isSafeInteger(s))
        return null;
    const r = [(-q.b - s) / (2 * q.a), (-q.b + s) / (2 * q.a)].sort((a, b) => a - b);
    return r.every(x => Number.isSafeInteger(x) && Math.abs(x) <= 12) ? r : null;
}
function compoundInequalityParametersValid(p) {
    const i = exports.COMPOUND_INEQUALITY_SCOPES.indexOf(p.scope);
    const seg = (s) => s && [s.lo, s.hi].every(Number.isSafeInteger) && s.lo >= -24 && s.hi <= 24 && s.lo < s.hi && typeof s.lc === 'boolean' && typeof s.hc === 'boolean';
    if (i < 0 || !seg(p.D) || !!p.Q !== (i === 0 || i === 2) || !!p.F !== (i === 0 || i === 1 || i === 3) || !!p.band !== (i === 1) || !!p.T !== (i >= 2))
        return false;
    if (p.Q && (!roots(p.Q) || !relations.includes(p.Q.rel)))
        return false;
    if (p.F && (![p.F.k, p.F.z, p.F.p].every(Number.isSafeInteger) || !p.F.k || Math.abs(p.F.k) > 5 || Math.abs(p.F.z) > 12 || Math.abs(p.F.p) > 12 || p.F.z === p.F.p || !relations.includes(p.F.rel)))
        return false;
    if (p.band && (![p.band.c, p.band.l, p.band.u].every(Number.isSafeInteger) || Math.abs(p.band.c) > 12 || p.band.l < 1 || p.band.l >= p.band.u || p.band.u > 8 || typeof p.band.lc !== 'boolean' || typeof p.band.hc !== 'boolean'))
        return false;
    return i < 2 ? p.radius === null && p.universal === null : !!p.T && seg(p.T) && Number.isSafeInteger(p.radius) && p.radius >= 1 && p.radius <= 8 && (i === 2 ? ['<', '<='] : ['>', '>=']).includes(p.universal ?? '');
}
const polynomial = (q) => '(' + q.a + ')*x^2+(' + q.b + ')*x+(' + q.c + ')' + q.rel + '0';
const fraction = (f) => '(' + f.k + ')*(x-(' + f.z + '))/(x-(' + f.p + '))' + f.rel + '0';
const leads = { zh: '所有变量均为实数，区间括号表示端点是否包含。', en: 'All variables are real; brackets specify endpoint inclusion.' };
const asks = [
    ['求同时满足上述条件的全部x。', 'Find all x satisfying all these conditions.'],
    ['求同时满足上述条件的全部x。', 'Find all x satisfying all these conditions.'],
    ['令S为D中满足上述不等式的x的集合。求T中使S内每个x均满足下列条件的全部t：', 'Let S be the set of x in D satisfying the inequality above. Find all t in T such that every x in S satisfies: '],
    ['令S为D中满足上述不等式的x的集合。求T中使S内每个x均满足下列条件的全部t：', 'Let S be the set of x in D satisfying the inequality above. Find all t in T such that every x in S satisfies: ']
];
function compoundInequalityPrompt(p, lang) {
    const i = exports.COMPOUND_INEQUALITY_SCOPES.indexOf(p.scope);
    const data = ['D=' + (0, exports.intervalText)(p.D), ...(p.T ? ['T=' + (0, exports.intervalText)(p.T)] : []), ...(p.Q ? ['Q: ' + polynomial(p.Q)] : []),
        ...(p.F ? ['F: ' + fraction(p.F)] : []), ...(p.band ? ['B: ' + p.band.l + (p.band.lc ? ' <= ' : ' < ') + '|x-(' + p.band.c + ')|' + (p.band.hc ? ' <= ' : ' < ') + p.band.u] : [])].join('; ') + '.';
    return leads[lang] + data + asks[i][lang === 'zh' ? 0 : 1] + (i >= 2 ? '|x-t|' + p.universal + p.radius + '.' : '');
}
function compoundInequalityParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1800)
        return null;
    const one = (name) => { const m = new RegExp(name + '=([\\[(]-?\\d+,-?\\d+[\\])])').exec(text), ss = m ? parseIntervalSet(m[1]) : null; return ss?.length === 1 ? ss[0] : null; };
    const D = one('D');
    if (!D)
        return null;
    const q = /Q: \((-?\d+)\)\*x\^2\+\((-?\d+)\)\*x\+\((-?\d+)\)(<=|>=|<|>)0/.exec(text);
    const f = /F: \((-?\d+)\)\*\(x-\((-?\d+)\)\)\/\(x-\((-?\d+)\)\)(<=|>=|<|>)0/.exec(text);
    const b = /B: (\d+) (<=|<) \|x-\((-?\d+)\)\| (<=|<) (\d+)/.exec(text);
    const u = /\|x-t\|(<=|>=|<|>)(\d+)\.$/.exec(text);
    const p = { scope, D, T: one('T'),
        Q: q ? { a: +q[1], b: +q[2], c: +q[3], rel: q[4] } : null,
        F: f ? { k: +f[1], z: +f[2], p: +f[3], rel: f[4] } : null,
        band: b ? { c: +b[3], l: +b[1], u: +b[5], lc: b[2] === '<=', hc: b[4] === '<=' } : null,
        radius: u ? +u[2] : null, universal: u ? u[1] : null };
    return compoundInequalityParametersValid(p) && compoundInequalityPrompt(p, lang) === text ? p : null;
}
function quadraticSet(q) {
    const [lo, hi] = roots(q), inclusive = q.rel.endsWith('='), outside = (q.rel.startsWith('>')) === (q.a > 0);
    return outside ? [{ lo: -Infinity, hi: lo, lc: false, hc: inclusive }, { lo: hi, hi: Infinity, lc: inclusive, hc: false }] : [{ lo, hi, lc: inclusive, hc: inclusive }];
}
function fractionSet(f) {
    const lo = Math.min(f.z, f.p), hi = Math.max(f.z, f.p), inclusive = f.rel.endsWith('=');
    const lc = inclusive && lo === f.z, hc = inclusive && hi === f.z, outside = (f.rel.startsWith('>')) === (f.k > 0);
    return outside ? [{ lo: -Infinity, hi: lo, lc: false, hc: lc }, { lo: hi, hi: Infinity, lc: hc, hc: false }] : [{ lo, hi, lc, hc }];
}
function bandSet(b, omit = null) {
    const outer = omit === 'upper' ? all : [{ lo: b.c - b.u, hi: b.c + b.u, lc: b.hc, hc: b.hc }];
    const inner = omit === 'lower' ? [] : [{ lo: b.c - b.l, hi: b.c + b.l, lc: !b.lc, hc: !b.lc }];
    return intervalSubtract(outer, inner);
}
function parameterSet(source, p) {
    if (!source.length)
        return [p.T];
    if (p.universal.startsWith('<')) {
        const l = source[0], h = source[source.length - 1], closed = p.universal === '<=';
        return intervalIntersect([p.T], [{ lo: h.hi - p.radius, hi: l.lo + p.radius, lc: closed || !h.hc, hc: closed || !l.lc }]);
    }
    const forbidden = source.map(s => ({ lo: s.lo - p.radius, hi: s.hi + p.radius, lc: p.universal === '>' && s.lc, hc: p.universal === '>' && s.hc }));
    return intervalSubtract([p.T], forbidden);
}
function compoundInequalityDerive(p) {
    if (!compoundInequalityParametersValid(p))
        return null;
    const i = exports.COMPOUND_INEQUALITY_SCOPES.indexOf(p.scope), D = [p.D], q = p.Q ? quadraticSet(p.Q) : all, f = p.F ? fractionSet(p.F) : all, b = p.band ? bandSet(p.band) : all;
    let source, answer, relaxed, steps;
    if (i < 2) {
        const first = i === 0 ? q : b;
        source = intervalIntersect(D, first);
        answer = intervalIntersect(source, f);
        relaxed = [intervalIntersect(D, first), intervalIntersect(D, f)];
        if (p.band)
            relaxed.push(intervalIntersect(intervalIntersect(D, bandSet(p.band, 'lower')), f), intervalIntersect(intervalIntersect(D, bandSet(p.band, 'upper')), f));
        steps = ['first=' + (0, exports.intervalSetText)(first), 'fraction=' + (0, exports.intervalSetText)(f), 'intersectD=' + (0, exports.intervalSetText)(source), 'joint=' + (0, exports.intervalSetText)(answer)];
    }
    else {
        const base = i === 2 ? q : f;
        source = intervalIntersect(D, base);
        if (!source.length)
            return null;
        answer = parameterSet(source, p);
        relaxed = [parameterSet(D, p), parameterSet(base, p)];
        steps = ['sourceInequality=' + (0, exports.intervalSetText)(base), 'S=' + (0, exports.intervalSetText)(source), 'forall x in S: |x-t|' + p.universal + p.radius, 'intersectT=' + (0, exports.intervalSetText)(answer)];
    }
    const domain = i < 2 ? D : [p.T], key = (0, exports.intervalSetText)(answer);
    if (!answer.length || answer.some(s => s.lo === s.hi) || answer.length > 4 || key === (0, exports.intervalSetText)(domain))
        return null;
    const effective = relaxed.map(s => ({ relaxedSet: (0, exports.intervalSetText)(s), witnessSet: (0, exports.intervalSetText)(intervalSubtract(s, answer)) }));
    // Removing constraints enlarges source S in quantified problems, hence can shrink the answer.
    if (i >= 2)
        effective.forEach((e, j) => e.witnessSet = (0, exports.intervalSetText)(normalizeIntervals([...intervalSubtract(answer, relaxed[j]), ...intervalSubtract(relaxed[j], answer)])));
    if (effective.some(e => e.witnessSet === 'empty'))
        return null;
    const proof = 'D=' + (0, exports.intervalText)(p.D) + '; T=' + (p.T ? (0, exports.intervalText)(p.T) : 'none') + '; ' + (p.Q ? 'Q=' + polynomial(p.Q) + '; ' : '') + (p.F ? 'F=' + fraction(p.F) + '; ' : '') + (p.band ? 'absoluteBand=' + p.band.l + (p.band.lc ? ' <= ' : ' < ') + '|x-(' + p.band.c + ')|' + (p.band.hc ? ' <= ' : ' < ') + p.band.u + '; ' : '') + steps.join('; ');
    const hardEvidence = { version: 'compound-inequality-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 3, reasoningSteps: 4, quantitativeRelations: 2, effectiveConstraints: effective, sourceSet: (0, exports.intervalSetText)(source), domain: (0, exports.intervalSetText)(domain), answer: key, visibleProof: proof, studentCalibrated: false };
    const flip = (left) => { const a = answer.map(s => ({ ...s })); if (left)
        a[0].lc = !a[0].lc;
    else
        a[a.length - 1].hc = !a[a.length - 1].hc; return (0, exports.intervalSetText)(a); };
    const errors = [{ intent: 'reverse_left_contact_inclusion', text: flip(true) }, { intent: 'reverse_right_contact_inclusion', text: flip(false) }, { intent: 'negate_required_set_predicate', text: (0, exports.intervalSetText)(intervalSubtract(domain, answer)) }].map(e => ({ ...e, key: e.text }));
    if (new Set([key, ...errors.map(e => e.key)]).size !== 4)
        return null;
    return { answer: key, text: key, errors, proof, hardEvidence };
}
function solveSubjectPracticeMathCompoundInequality(candidate, context = {}) {
    const scope = compoundInequalityScopeFrom(context.questionPlan), parameters = compoundInequalityParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? compoundInequalityDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('compound_inequality_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 67 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('compound_inequality_identity');
    const options = candidate.options ?? [], keys = options.map(o => { const a = parseIntervalSet(o.text); return a ? (0, exports.intervalSetText)(a) : null; });
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('compound_inequality_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(compoundInequalityParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('compound_inequality_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => { const a = parseIntervalSet(o.text); return [o.id, a ? (0, exports.intervalSetText)(a) : null]; })) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('compound_inequality_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('compound_inequality_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('compound_inequality_error_intent');
    const scopeId = parameters ? exports.COMPOUND_INEQUALITY_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.COMPOUND_INEQUALITY_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.COMPOUND_INEQUALITY_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.COMPOUND_INEQUALITY_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['compound_inequality_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
