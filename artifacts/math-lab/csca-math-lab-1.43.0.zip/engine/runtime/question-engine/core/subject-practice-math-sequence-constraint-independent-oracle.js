"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEQUENCE_CONSTRAINT_ORACLE_VERSION = void 0;
exports.sequenceConstraintIndependentCalculation = sequenceConstraintIndependentCalculation;
exports.verifySubjectPracticeMathSequenceConstraintWithIndependentOracle = verifySubjectPracticeMathSequenceConstraintWithIndependentOracle;
exports.SEQUENCE_CONSTRAINT_ORACLE_VERSION = 'math-sequence-constraint-oracle-v1-complete-discrete-certificates';
const scopes = ['arithmetic_term_sum_positive_window_sum', 'arithmetic_two_terms_partial_sum_threshold_index', 'geometric_two_terms_partial_sum_threshold_index', 'affine_recurrence_two_terms_partial_sum'];
function frac(n, d = 1n) { if (!d || n.toString(2).replace('-', '').length > 512 || d.toString(2).replace('-', '').length > 512)
    throw Error('oracle_arithmetic_bound'); if (d < 0n) {
    n = -n;
    d = -d;
} let a = n < 0n ? -n : n, b = d; while (b) {
    const t = a % b;
    a = b;
    b = t;
} return [n / a, d / a]; }
const num = (n) => frac(BigInt(n)), plus = (a, b) => frac(a[0] * b[1] + b[0] * a[1], a[1] * b[1]), minus = (a, b) => frac(a[0] * b[1] - b[0] * a[1], a[1] * b[1]), mul = (a, b) => frac(a[0] * b[0], a[1] * b[1]), div = (a, b) => frac(a[0] * b[1], a[1] * b[0]);
const cmp = (a, b) => a[0] * b[1] < b[0] * a[1] ? -1 : a[0] * b[1] > b[0] * a[1] ? 1 : 0, show = (a) => String(a[0]) + (a[1] === 1n ? '' : '/' + a[1]), zero = num(0), one = num(1);
const bounded = (a) => a[0] >= -1000000000000n && a[0] <= 1000000000000n && a[1] <= 1000000000n;
function read(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('oracle_rational'); const [n, d = '1'] = s.split('/'), r = frac(BigInt(n), BigInt(d)); if (!bounded(r))
    throw Error('oracle_visible_bounds'); return r; }
function idx(a, max) { if (a[1] !== 1n || a[0] < 1n || a[0] > BigInt(max))
    throw Error('oracle_index'); return Number(a[0]); }
const object = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function parse(text, i, lang) {
    if (typeof text !== 'string' || text.length > 2200 || i < 0)
        throw Error('oracle_stem');
    const zh = lang === 'zh', r = '([-+]?\\d+(?:/[1-9]\\d*)?)', escape = (s) => s.replace(/[$.*+?^{}()|[\]\\]/g, '\\$&');
    const prefix = i < 2 ? (zh ? '设等差数列，S_n为前n项和。已知 ' : 'For an arithmetic sequence, S_n is the sum of its first n terms. Given ') : i === 2 ? (zh ? '设公比q>1的等比数列，S_n为前n项和。已知 ' : 'For a geometric sequence with q>1, S_n is the sum of its first n terms. Given ') : (zh ? '设递推数列a_(n+1)=q*a_n+c，c未知。已知 ' : 'Let a_(n+1)=q*a_n+c, where c is unknown. Given ');
    const names = [['r', 'a_r', 'm', 'S_m', 'L', 'U'], ['r', 'a_r', 's', 'a_s', 'T'], ['r', 'a_r', 'a_(r+2)', 'T'], ['q', 'a_1', 'k', 'a_k', 'N']][i];
    let tail;
    if (i === 0)
        tail = escape(zh ? '求整数索引L<=i<=U中所有a_i>0的项之和。' : 'Find the sum of all positive terms a_i>0 with integer indices L<=i<=U.');
    else if (i === 3)
        tail = escape(zh ? '求前N项之和S_N。' : 'Find S_N, the sum of the first N terms.');
    else
        tail = escape(zh ? '求使' : 'Find the smallest positive integer n satisfying ') + escape(' S_n') + '(>=|>)' + escape('T' + (zh ? '成立的最小正整数n。' : '.'));
    const pattern = '^' + escape(prefix) + names.map(n => escape(n + '=(') + r + escape(')')).join(escape(', ')) + escape('. ') + tail + '$', m = new RegExp(pattern).exec(text);
    if (!m)
        throw Error('oracle_stem_grammar');
    const data = m.slice(1);
    if (i === 1 || i === 2)
        data[data.length - 1] = data[data.length - 1] === '>=' ? 'ge' : 'gt';
    return data;
}
function geometricTerm(a, q, n) { let x = a; for (let j = 1; j < n; j++)
    x = mul(x, q); return x; }
function arithmeticRecovery(r, u, s, v) { const row1 = [one, num(r - 1), u], row2 = [one, num(s - 1), v], factor = div(row2[0], row1[0]), coefficient = minus(row2[1], mul(factor, row1[1])); if (!coefficient[0])
    throw Error('oracle_dependent_parameters'); const d = div(minus(row2[2], mul(factor, row1[2])), coefficient); return { a: minus(row1[2], mul(row1[1], d)), d }; }
function exactSquareRoot(q) { if (q[0] < 0n)
    throw Error('oracle_negative_square'); function integerRoot(n) { if (n < 2n)
    return n; let x = n, y = (x + 1n) / 2n; while (y < x) {
    x = y;
    y = (x + n / x) / 2n;
} if (x * x !== n)
    throw Error('oracle_irrational_ratio'); return x; } return frac(integerRoot(q[0]), integerRoot(q[1])); }
function sequenceConstraintIndependentCalculation(data, i) {
    if (i < 0 || data.length !== [6, 6, 5, 5][i])
        throw Error('oracle_parameter_count');
    const values = data.slice(0, i === 1 ? 5 : i === 2 ? 4 : undefined).map(read);
    let answer = zero, certificate;
    if (i === 0) {
        const r = idx(values[0], 12), m = idx(values[2], 12), l = idx(values[4], 32), u = idx(values[5], 32);
        if (l >= u)
            throw Error('oracle_window');
        let coefficient = zero;
        for (let j = 1; j <= m; j++)
            coefficient = plus(coefficient, num(j - 1));
        const denominator = minus(coefficient, mul(num(m), num(r - 1)));
        if (!denominator[0])
            throw Error('oracle_dependent_parameters');
        const d = div(minus(values[3], mul(num(m), values[1])), denominator), a = minus(values[1], mul(num(r - 1), d));
        if (!d[0] || !bounded(a) || !bounded(d))
            throw Error('oracle_degenerate_parameters');
        let term = a, positive = 0, negative = 0;
        const entries = [];
        for (let j = 1; j <= u + 1; j++) {
            if (j >= l && j <= u) {
                const included = cmp(term, zero) > 0;
                entries.push({ index: j, value: show(term), included });
                if (included) {
                    answer = plus(answer, term);
                    positive++;
                }
                if (cmp(term, zero) < 0)
                    negative++;
            }
            term = plus(term, d);
        }
        if (positive < 2 || negative < 2)
            throw Error('oracle_sign_structure');
        certificate = { kind: 'independent_linear_elimination_complete_integer_window', a1: show(a), d: show(d), determinant: show(denominator), entries, positive, negative };
    }
    else if (i === 1 || i === 2) {
        const geo = i === 2, r = idx(values[0], geo ? 4 : 12), s = geo ? r + 2 : idx(values[2], 12), u = values[1], v = geo ? values[2] : values[3], t = geo ? values[3] : values[4], relation = data[geo ? 4 : 5];
        let a, d;
        if (geo) {
            if (u[0] <= 0n)
                throw Error('oracle_nonpositive_observed_term');
            d = exactSquareRoot(div(v, u));
            if (cmp(d, one) <= 0)
                throw Error('oracle_ratio_branch');
            a = div(u, geometricTerm(one, d, r));
            if (cmp(geometricTerm(a, d, r + 2), v))
                throw Error('oracle_geometric_round_trip');
        }
        else {
            ({ a, d } = arithmeticRecovery(r, u, s, v));
        }
        if (cmp(a, zero) <= 0 || cmp(d, geo ? one : zero) <= 0 || cmp(t, zero) <= 0 || !bounded(a) || !bounded(d) || !['ge', 'gt'].includes(relation))
            throw Error('oracle_monotone_domain');
        const entries = [];
        let term = a, total = zero, n = 0;
        for (let j = 1; j <= (geo ? 24 : 32); j++) {
            total = plus(total, term);
            const meets = cmp(total, t) >= (relation === 'ge' ? 0 : 1);
            entries.push({ index: j, term: show(term), sum: show(total), meets });
            if (meets) {
                n = j;
                break;
            }
            term = geo ? mul(term, d) : plus(term, d);
        }
        if (n <= Math.max(r, s) || n < (geo ? 5 : 4))
            throw Error('oracle_minimum_index_or_hard_structure');
        answer = num(n);
        certificate = { kind: 'independent_recurrence_complete_first_hit', a1: show(a), step: show(d), uniqueParameterBranch: geo ? 'positive square root q>1' : 'nonzero two-row determinant', allTermsPositive: true, allSumsStrictlyIncreasing: true, relation, threshold: show(t), entries, allEarlierFailed: entries.slice(0, -1).every(e => !e.meets), firstHit: n };
    }
    else {
        const q = values[0], a = values[1], k = idx(values[2], 6), n = idx(values[4], 16);
        if (k < 3 || n < k + 2 || !q[0] || !cmp(q, one))
            throw Error('oracle_recurrence_domain');
        let alpha = one, beta = zero;
        for (let j = 1; j < k; j++) {
            alpha = mul(q, alpha);
            beta = plus(mul(q, beta), one);
        }
        if (!beta[0])
            throw Error('oracle_ambiguous_constant');
        const c = div(minus(values[3], mul(alpha, a)), beta);
        if (!c[0] || !bounded(c) || !plus(a, div(c, minus(q, one)))[0])
            throw Error('oracle_degenerate_recurrence');
        let term = a, total = zero;
        const entries = [];
        for (let j = 1; j <= n; j++) {
            total = plus(total, term);
            entries.push({ index: j, term: show(term), prefixSum: show(total) });
            if (j === k && cmp(term, values[3]))
                throw Error('oracle_kth_term');
            term = plus(mul(q, term), c);
        }
        answer = total;
        certificate = { kind: 'independent_affine_coefficient_recurrence_and_full_sum', a1: show(a), q: show(q), c: show(c), alphaK: show(alpha), betaK: show(beta), entries };
    }
    if (!bounded(answer))
        throw Error('oracle_answer_bound');
    return { answer: show(answer), certificate };
}
function option(text, i) { try {
    const x = read(text.trim());
    return (i === 1 || i === 2) && (x[1] !== 1n || x[0] <= 0n) ? null : show(x);
}
catch {
    return null;
} }
function verifySubjectPracticeMathSequenceConstraintWithIndependentOracle(candidate, context = {}) {
    const p = object(context.questionPlan), r = object(p?.renderConstraints), s = object(p?.scenarioContract), scope = String(r?.exactSequenceConstraintScope ?? ''), i = scopes.indexOf(scope), required = { topicCode: 'M-SEQ-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
    const bound = i >= 0 && p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 70 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === 'math_sequence_constraint_reasoning' && p?.planTemplate === 'math_sequence_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'sequence_constraint_system' && s?.scenarioAction === scope;
    const reasonCodes = [];
    let expectedAnswer = null, certificate = null, data = null;
    try {
        if (!bound)
            throw Error('oracle_exact_plan');
        data = parse(candidate.prompt, i, 'zh');
        const d = sequenceConstraintIndependentCalculation(data, i);
        expectedAnswer = d.answer;
        certificate = d.certificate;
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parse(candidate.localizations?.[lang]?.prompt ?? '', i, lang)) !== JSON.stringify(data))
                throw Error('oracle_translation_parameters');
    }
    catch (e) {
        reasonCodes.push(e instanceof Error ? e.message : 'oracle_unparsed');
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 70 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => option(o.text, i));
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(o => [o.id, option(o.text, i)])) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('oracle_' + lang + '_options');
    const trueOptionIds = opts.filter((_, j) => keys[j] !== null && keys[j] === expectedAnswer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('oracle_answer_disagreement');
    return { oracleVersion: exports.SEQUENCE_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? (data ? 'disagreed' : 'unparsed') : 'verified', scopeMatched: bound && !!data, scopeId: bound && data ? 'math-hard-sequence-constraint-v1:' + scope : null, exactScope: scope, expectedAnswer, selectedOptionId, trueOptionIds, certificate, complete: !!certificate, completeCertificate: !!certificate, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
