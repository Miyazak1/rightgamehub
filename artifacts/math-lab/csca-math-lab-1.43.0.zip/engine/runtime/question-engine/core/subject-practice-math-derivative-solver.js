"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_SOLVER_VERSION = void 0;
exports.solveSubjectPracticeMathDerivative = solveSubjectPracticeMathDerivative;
const subject_practice_math_derivative_tool_verifier_1 = require("./subject-practice-math-derivative-tool-verifier");
exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_SOLVER_VERSION = 'subject-practice-math-derivative-solver-v1-direct-polynomial-value';
exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_SCOPE_VERSION = 'subject-practice-math-derivative-scope-v1';
function recordFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? value
        : null;
}
function exactScope(questionPlan) {
    const plan = recordFrom(questionPlan);
    const constraints = recordFrom(plan?.renderConstraints);
    return String(plan?.schemaVersion) === 'subject-practice-question-plan-v1'
        && String(plan?.policyVersion) === 'subject-practice-question-plan-policy-v1'
        && String(plan?.subject).toLowerCase() === 'math'
        && String(plan?.taskFamily) === 'derivative_direct_evaluation'
        && String(plan?.planTemplate) === 'math_derivative_condition_chain_v1'
        && String(plan?.targetDifficulty).toLowerCase() === 'basic'
        && String(constraints?.exactDerivativeScope) === 'direct_polynomial_value'
        ? 'direct_polynomial_value'
        : null;
}
function solveSubjectPracticeMathDerivative(candidate, context = {}) {
    const scope = exactScope(context.questionPlan);
    const scopeId = scope ? `math-basic-derivative-v1:${scope}` : null;
    const verification = (0, subject_practice_math_derivative_tool_verifier_1.verifySubjectPracticeMathDerivativeToolCandidate)({
        candidate,
        taskFamily: 'derivative_direct_evaluation',
        questionPlan: context.questionPlan
    });
    const reasonCodes = [...verification.reasonCodes];
    if (!scope)
        reasonCodes.push('math_derivative_solver_plan_scope_mismatch');
    return {
        solverVersion: exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_SOLVER_VERSION,
        status: scope ? verification.status : 'unparsed',
        taskFamily: 'derivative_direct_evaluation',
        scopeId,
        canonicalTask: scope && verification.parsed
            ? {
                kind: scope,
                expression: verification.normalizedExpression,
                point: verification.evaluationPoint,
                expectedValue: verification.expectedValue
            }
            : null,
        selectedOptionId: verification.selectedOptionId,
        trueOptionIds: verification.trueOptionIds,
        uniqueAnswer: verification.trueOptionIds.length === 1,
        agreesWithGenerator: verification.agreesWithGenerator,
        verificationScope: {
            scopeVersion: exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_SCOPE_VERSION,
            scopeId,
            matched: Boolean(scope && verification.parsed),
            exactScope: scope,
            reasonCodes: scope ? [] : ['math_derivative_solver_plan_scope_mismatch']
        },
        evidenceBoundary: 'visible_prompt_and_options_only',
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes: Array.from(new Set(reasonCodes))
    };
}
