"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathVectorComplexExplanation = verifySubjectPracticeMathVectorComplexExplanation;
const subject_practice_math_vector_complex_solver_1 = require("./subject-practice-math-vector-complex-solver");
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_EXPLANATION_VERIFIER_VERSION = 'math-vector-complex-explanation-verifier-v1-bilingual-parameter-bound';
function compact(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ''); }
function has(text, label, value) { return new RegExp(`${label}=${String(value).replace('-', '\\-')}(?:[^0-9]|$)`, 'i').test(text); }
function resultText(value, scope) { if (typeof value === 'number')
    return String(value); return scope === 'complex_addition_subtraction' ? `${value.x}${value.y >= 0 ? '+' : ''}${value.y}i` : `(${value.x},${value.y})`; }
function verifySubjectPracticeMathVectorComplexExplanation(candidate, context = {}) { const solver = (0, subject_practice_math_vector_complex_solver_1.solveSubjectPracticeMathVectorComplex)(candidate, context), p = solver.parameters, zh = compact(candidate.localizations?.zh?.explanation ?? candidate.explanation), en = compact(candidate.localizations?.en?.explanation), scope = solver.exactScope, required = []; if (p?.a)
    required.push(['a_x', p.a.x], ['a_y', p.a.y], ['b_x', p.b.x], ['b_y', p.b.y]); if (p?.z1)
    required.push(['x_1', p.z1.x], ['y_1', p.z1.y]); if (p?.z2)
    required.push(['x_2', p.z2.x], ['y_2', p.z2.y]); const zhParametersBound = Boolean(p && required.every(([l, v]) => has(zh, l, v))), enParametersBound = Boolean(p && required.every(([l, v]) => has(en, l, v))), expected = solver.expectedValue, conclusion = expected === null ? '' : resultText(expected, scope), zhConclusionBound = Boolean(conclusion && zh.includes(conclusion)), enConclusionBound = Boolean(conclusion && en.includes(conclusion)); const formulaBound = scope === 'vector_coordinate_addition' ? /(a_x\+b_x|坐标分别相加|addcorrespondingcoordinates)/i.test(`${zh}${en}`) : scope === 'vector_dot_product' ? /(a_xb_x\+a_yb_y|数量积|dotproduct)/i.test(`${zh}${en}`) : scope === 'complex_addition_subtraction' ? /(实部|虚部|realparts|imaginaryparts)/i.test(`${zh}${en}`) : /(x_1\^2\+y_1\^2|模|modulus)/i.test(`${zh}${en}`); const reasonCodes = []; if (solver.status !== 'verified')
    reasonCodes.push('math_vector_complex_explanation_primary_solver_not_verified'); if (!zhParametersBound)
    reasonCodes.push('math_vector_complex_explanation_zh_parameters_not_bound'); if (!enParametersBound)
    reasonCodes.push('math_vector_complex_explanation_en_parameters_not_bound'); if (!zhConclusionBound)
    reasonCodes.push('math_vector_complex_explanation_zh_conclusion_missing_or_wrong'); if (!enConclusionBound)
    reasonCodes.push('math_vector_complex_explanation_en_conclusion_missing_or_wrong'); if (!formulaBound)
    reasonCodes.push('math_vector_complex_explanation_formula_missing'); return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solver.scopeId, zhParametersBound, enParametersBound, zhConclusionBound, enConclusionBound, formulaBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
