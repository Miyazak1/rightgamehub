"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathDescriptiveStatisticsExplanation = verifySubjectPracticeMathDescriptiveStatisticsExplanation;
const subject_practice_math_descriptive_statistics_solver_1 = require("./subject-practice-math-descriptive-statistics-solver");
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_EXPLANATION_VERIFIER_VERSION = 'math-descriptive-statistics-explanation-verifier-v1-bilingual-equations';
function verifySubjectPracticeMathDescriptiveStatisticsExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_descriptive_statistics_solver_1.solveSubjectPracticeMathDescriptiveStatistics)(candidate, context), data = solver.parameters;
    let equation = '', zhPrefix = '', enPrefix = '';
    if (data && solver.expectedValue) {
        const n = data.length, sum = data.reduce((s, x) => s + x, 0), mean = (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(sum, n);
        const meanEquation = `mean=(${data.map(x => `(${x})`).join('+')})/${n}=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(mean)}`;
        if (solver.exactScope === 'arithmetic_mean') {
            equation = meanEquation;
            zhPrefix = '数据之和除以个数：';
            enPrefix = 'Divide the data sum by the count: ';
        }
        else if (solver.exactScope === 'median') {
            const sorted = [...data].sort((a, b) => a - b), mid = Math.floor(n / 2);
            const positions = n % 2 ? `${mid + 1}` : `${mid},${mid + 1}`;
            const operation = n % 2 ? `${sorted[mid]}` : `(${sorted[mid - 1]}+(${sorted[mid]}))/2`;
            equation = `sorted=[${sorted.join(', ')}]; positions=${positions}; median=${operation}=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(solver.expectedValue)}`;
            zhPrefix = '按从小到大排序，取中间位置：';
            enPrefix = 'Sort in ascending order and use the central position(s): ';
        }
        else {
            const variance = (0, subject_practice_math_descriptive_statistics_solver_1.statisticsRational)(data.reduce((s, x) => s + (x * n - sum) ** 2, 0), n ** 3);
            equation = `${meanEquation}; variance=(${data.map(x => `(${x}-(${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(mean)}))^2`).join('+')})/${n}=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(variance)}`;
            if (solver.exactScope === 'population_standard_deviation')
                equation += `; standard_deviation=sqrt(${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(variance)})=${(0, subject_practice_math_descriptive_statistics_solver_1.statisticsRationalText)(solver.expectedValue)}`;
            zhPrefix = '总体方差用平方离差之和除以 n，标准差取非负平方根：';
            enPrefix = 'Population variance divides the squared-deviation sum by n; standard deviation is its nonnegative square root: ';
        }
    }
    const zhBound = Boolean(equation) && candidate.explanation === `${zhPrefix}${equation}。对应选项 ${solver.selectedOptionId}。` && candidate.localizations?.zh?.explanation === candidate.explanation;
    const enBound = Boolean(equation) && candidate.localizations?.en?.explanation === `${enPrefix}${equation}. Option ${solver.selectedOptionId}.`;
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_descriptive_statistics_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('math_descriptive_statistics_explanation_zh_not_bound');
    if (!enBound)
        reasonCodes.push('math_descriptive_statistics_explanation_en_not_bound');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified',
        scopeId: solver.scopeId, zhBound, enBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
