"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_SCOPE_VERSION = exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_SOLVER_VERSION = void 0;
exports.solveSubjectPracticePhysicsNewtonForce = solveSubjectPracticePhysicsNewtonForce;
exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_SOLVER_VERSION = 'physics-newton-basic-force-solver-v1-typed-quantities';
exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_SCOPE_VERSION = 'physics-basic-newton-force-scope-v1';
const SCOPES = new Set(['net_force_from_mass_acceleration', 'acceleration_from_net_force_mass', 'horizontal_opposed_forces_acceleration', 'single_axis_equilibrium_unknown_force']);
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/²/g, '^2').replace(/，/g, ',').replace(/\s+/g, ' ').trim(); }
function scopeFrom(context) { const p = object(context.questionPlan), r = object(p?.renderConstraints), s = clean(r?.exactPhysicsNewtonForceScope); return clean(p?.taskFamily) === 'physics_newton_basic_force_calculation' && clean(p?.planTemplate) === 'physics_newton_basic_force_calculation_v1' && clean(p?.targetDifficulty).toLowerCase() === 'basic' && SCOPES.has(s) ? s : null; }
function numberAfter(text, label) { const m = clean(text).match(new RegExp(`${label}\\s*=\\s*([+-]?\\d+(?:\\.\\d+)?)`, 'i')); return m ? Number(m[1]) : null; }
function parametersFrom(prompt, scope) { if (!scope)
    return null; const t = clean(prompt); if (scope === 'net_force_from_mass_acceleration') {
    const massKg = numberAfter(t, 'm'), accelerationMps2 = numberAfter(t, 'a');
    return massKg !== null && massKg > 0 && accelerationMps2 !== null ? { massKg, accelerationMps2 } : null;
} if (scope === 'acceleration_from_net_force_mass') {
    const netForceN = numberAfter(t, 'F_?net'), massKg = numberAfter(t, 'm');
    return netForceN !== null && massKg !== null && massKg > 0 ? { netForceN, massKg } : null;
} if (scope === 'horizontal_opposed_forces_acceleration') {
    const rightForceN = numberAfter(t, 'F_?right'), leftForceN = numberAfter(t, 'F_?left'), massKg = numberAfter(t, 'm');
    return rightForceN !== null && leftForceN !== null && massKg !== null && massKg > 0 ? { rightForceN, leftForceN, massKg } : null;
} const knownForceN = numberAfter(t, 'F_?known'); return knownForceN !== null && knownForceN > 0 ? { knownForceN } : null; }
function expectedFor(scope, p) { if (scope === 'net_force_from_mass_acceleration')
    return { dimension: 'force', value: p.massKg * p.accelerationMps2 }; if (scope === 'acceleration_from_net_force_mass')
    return { dimension: 'acceleration', value: p.netForceN / p.massKg }; if (scope === 'horizontal_opposed_forces_acceleration')
    return { dimension: 'acceleration', value: (p.rightForceN - p.leftForceN) / p.massKg }; return { dimension: 'force', value: p.knownForceN }; }
function optionValue(text, dimension) { const t = clean(text); const m = t.match(/^([+-]?\d+(?:\.\d+)?)\s*(N|m\s*\/\s*s\^?2)$/i); if (!m)
    return null; const optionDimension = /^n$/i.test(m[2]) ? 'force' : 'acceleration'; return optionDimension === dimension ? Number(m[1]) : null; }
function same(a, b) { return Math.abs(a - b) <= Math.max(1e-9, Math.abs(b) * 1e-9); }
function solveSubjectPracticePhysicsNewtonForce(candidate, context = {}) { const exactScope = scopeFrom(context), parameters = parametersFrom(candidate.prompt, exactScope), parsed = Boolean(exactScope && parameters), expected = parsed ? expectedFor(exactScope, parameters) : null; const optionVerdicts = (candidate.options ?? []).map(o => { const value = expected ? optionValue(o.text, expected.dimension) : null; return { optionId: o.id, verdict: value === null ? 'unknown' : same(value, expected.value) ? 'true' : 'false', dimension: value === null ? null : expected.dimension, siValue: value }; }); const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null, reasonCodes = []; if (!exactScope)
    reasonCodes.push('physics_newton_force_scope_plan_contract_missing'); if (!parameters)
    reasonCodes.push('physics_newton_force_prompt_unparsed'); if (optionVerdicts.some(x => x.verdict === 'unknown'))
    reasonCodes.push('physics_newton_force_option_or_unit_unparsed'); if (trueOptionIds.length !== 1)
    reasonCodes.push(trueOptionIds.length ? 'physics_newton_force_multiple_true_options' : 'physics_newton_force_no_true_option'); if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('physics_newton_force_generator_disagreement'); const scopeId = parsed ? `physics-basic-newton-force-v1:${exactScope}` : null; return { solverVersion: exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_SOLVER_VERSION, status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified', taskFamily: 'physics_newton_basic_force_calculation', scopeId, exactScope, parameters, expectedDimension: expected?.dimension ?? null, expectedSiValue: expected?.value ?? null, verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['physics_newton_force_verification_scope_not_matched'] }, optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
