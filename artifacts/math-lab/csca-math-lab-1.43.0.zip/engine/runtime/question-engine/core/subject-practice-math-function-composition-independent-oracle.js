"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FUNCTION_COMPOSITION_ORACLE_VERSION = void 0;
exports.functionCompositionOracleCalculation = functionCompositionOracleCalculation;
exports.verifySubjectPracticeMathFunctionCompositionWithIndependentOracle = verifySubjectPracticeMathFunctionCompositionWithIndependentOracle;
exports.FUNCTION_COMPOSITION_ORACLE_VERSION = 'math-function-composition-oracle-v1-real-critical-partition';
const scopes = ['quadratic_composition_closed_interval_range', 'piecewise_quadratic_interval_range', 'restricted_quadratic_inverse_fraction_domain', 'piecewise_affine_monotonic_parameter'];
const r = (n, d = 1) => { let x = BigInt(n), y = BigInt(d); if (!y)
    throw Error('oracle_zero_divisor'); if (y < 0n) {
    x = -x;
    y = -y;
} let a = x < 0n ? -x : x, b = y; while (b) {
    const z = a % b;
    a = b;
    b = z;
} return [x / a, y / a]; };
const plus = (a, b) => r(a[0] * b[1] + b[0] * a[1], a[1] * b[1]), minus = (a, b) => r(a[0] * b[1] - b[0] * a[1], a[1] * b[1]), times = (a, b) => r(a[0] * b[0], a[1] * b[1]), over = (a, b) => r(a[0] * b[1], a[1] * b[0]);
const order = (a, b) => a[0] * b[1] < b[0] * a[1] ? -1 : a[0] * b[1] > b[0] * a[1] ? 1 : 0, show = (x) => x[0] + (x[1] === 1n ? '' : '/' + x[1]);
function merge(input) { const list = input.filter(x => order(x.l, x.r) < 0 || order(x.l, x.r) === 0 && x.left && x.right).sort((a, b) => order(a.l, b.l) || Number(b.left) - Number(a.left)); const out = []; for (const s of list) {
    const t = out[out.length - 1];
    if (!t || order(t.r, s.l) < 0 || !order(t.r, s.l) && !t.right && !s.left) {
        out.push({ ...s });
        continue;
    }
    if (order(s.r, t.r) > 0) {
        t.r = s.r;
        t.right = s.right;
    }
    else if (!order(s.r, t.r))
        t.right = t.right || s.right;
} return out; }
const format = (v) => merge(v).map(x => (x.left ? '[' : '(') + show(x.l) + ',' + show(x.r) + (x.right ? ']' : ')')).join(' U ') || 'empty';
function decodeOption(s) { if (s === 'empty')
    return s; if (typeof s !== 'string' || s.length > 400)
    return null; const pieces = s.split(' U '); if (pieces.length > 2)
    return null; const out = []; for (const item of pieces) {
    const m = /^([[(])(-?\d+(?:\/[1-9]\d*)?),\s*(-?\d+(?:\/[1-9]\d*)?)([\])])$/.exec(item);
    if (!m)
        return null;
    const read = (v) => { const [n, d = '1'] = v.split('/'); return r(BigInt(n), BigInt(d)); }, l = read(m[2]), h = read(m[3]);
    if ([l, h].some(v => v[0] < -1000000n || v[0] > 1000000n || v[1] > 256n) || order(l, h) > 0 || !order(l, h) && (m[1] !== '[' || m[4] !== ']'))
        return null;
    out.push({ l, r: h, left: m[1] === '[', right: m[4] === ']' });
} return format(out); }
// Parse only the visible mathematical clauses; the answer and generator metadata are never inputs.
const square = (v, a, h, k) => '(' + a + ')*(' + v + '-(' + h + '))^2+(' + k + ')';
function oraclePrompt(p, lang) {
    const d = p.data, i = scopes.indexOf(p.scope), q = (l, r) => '[' + l + ',' + r + ']';
    const lead = lang === 'zh' ? '以下变量均为实数，区间括号表示端点是否包含。' : 'All variables are real; brackets specify endpoint inclusion. ';
    if (i === 0)
        return lead + 'g(x)=' + square('x', d[0], d[1], d[2]) + '; f(u)=' + square('u', d[3], d[4], d[5]) + '; x in ' + q(d[6], d[7]) + '. ' + (lang === 'zh' ? '求复合函数 f(g(x)) 的全部取值。' : 'Find the full range of f(g(x)).');
    if (i === 1)
        return lead + 'F(x)={' + square('x', d[0], d[1], d[2]) + ' for x in [' + d[6] + ',' + d[7] + '); ' + square('x', d[3], d[4], d[5]) + ' for x in ' + q(d[7], d[8]) + '}. ' + (lang === 'zh' ? '求分段函数 F 的全部取值。' : 'Find the full range of the piecewise function F.');
    if (i === 2)
        return lead + 'f(u)=' + square('u', d[0], d[1], d[2]) + ' restricted to u in ' + q(d[3], d[4]) + '; g(x)=((' + d[5] + ')*x+(' + d[6] + '))/(x-(' + d[7] + ')); x in ' + q(d[8], d[9]) + '. ' + (lang === 'zh' ? '求反函数复合 f^(-1)(g(x)) 的定义域。' : 'Find the domain of the inverse composition f^(-1)(g(x)).');
    return lead + 'F_t(x)={((' + d[0] + ')*t+(' + d[1] + '))*x+(' + d[2] + ') for x in [' + d[6] + ',' + d[7] + '); ((' + d[3] + ')*t+(' + d[4] + '))*x+(' + d[5] + ') for x in ' + q(d[7], d[8]) + '}; t in ' + q(d[9], d[10]) + '. ' + (lang === 'zh' ? '求使 F_t 在整个区间严格' + (d[11] === 1 ? '递增' : '递减') + '的全部 t。' : 'Find all t making F_t strictly ' + (d[11] === 1 ? 'increasing' : 'decreasing') + ' on the whole interval.');
}
function readStem(text, index) {
    if (typeof text !== 'string' || text.length > 1800)
        return null;
    const clauses = text.slice(0, text.lastIndexOf('. '));
    const c = [...clauses.matchAll(/\((-?\d+)\)/g)].map(m => Number(m[1])), intervals = [...clauses.matchAll(/\[(-?\d+),(-?\d+)[\])]/g)].map(m => [Number(m[1]), Number(m[2])]);
    if (c.length !== 6 || intervals.length !== [1, 2, 2, 3][index])
        return null;
    let v;
    if (index === 0) {
        if (!text.includes('g(x)=') || !text.includes('f(u)=') || !text.includes('f(g(x))'))
            return null;
        v = [...c, ...intervals[0]];
    }
    else if (index === 1) {
        if (!text.includes('F(x)={') || intervals[0][1] !== intervals[1][0])
            return null;
        v = [...c, ...intervals[0], intervals[1][1]];
    }
    else if (index === 2) {
        if (!text.includes('restricted to u in ') || !text.includes('f^(-1)(g(x))'))
            return null;
        v = [...c.slice(0, 3), ...intervals[0], ...c.slice(3), ...intervals[1]];
    }
    else {
        if (!text.includes('F_t(x)={') || intervals[0][1] !== intervals[1][0] || !/严格递增|严格递减|strictly increasing|strictly decreasing/.test(text))
            return null;
        v = [...c, ...intervals[0], intervals[1][1], ...intervals[2], /严格递增|strictly increasing/.test(text) ? 1 : -1];
    }
    return v.every((x, j) => Number.isInteger(x) && Math.abs(x) <= (index === 0 && j === 4 ? 64 : 12)) && ['zh', 'en'].some(lang => oraclePrompt({ scope: scopes[index], data: v }, lang) === text) ? v : null;
}
function cuts(lo, hi, extra) { return [lo, hi, ...extra.filter(x => order(x, lo) > 0 && order(x, hi) < 0)].sort(order).filter((x, j, a) => !j || order(x, a[j - 1])); }
function testCells(lo, hi, extra, test) { const xs = cuts(lo, hi, extra), out = [], samples = []; for (let j = 0; j < xs.length; j++) {
    const x = xs[j];
    samples.push(show(x));
    if (test(x))
        out.push({ l: x, r: x, left: true, right: true });
    if (j + 1 < xs.length) {
        const mid = over(plus(x, xs[j + 1]), r(2));
        samples.push(show(mid));
        if (test(mid))
            out.push({ l: x, r: xs[j + 1], left: false, right: false });
    }
} return { set: merge(out), critical: xs.map(show), representatives: samples }; }
function quadratic(a, h, k, x) { return plus(times(r(a), times(minus(x, r(h)), minus(x, r(h)))), r(k)); }
function imageCells(lo, hi, left, right, extra, evalAt) { const xs = cuts(r(lo), r(hi), extra), out = []; for (let j = 0; j < xs.length; j++) {
    const included = (j !== 0 || left) && (j !== xs.length - 1 || right), y = evalAt(xs[j]);
    if (included)
        out.push({ l: y, r: y, left: true, right: true });
    if (j + 1 < xs.length) {
        const z = evalAt(xs[j + 1]);
        if (order(y, z) === 0)
            throw Error('oracle_nonmonotone_partition');
        out.push({ l: order(y, z) < 0 ? y : z, r: order(y, z) < 0 ? z : y, left: false, right: false });
    }
} return { set: merge(out), critical: xs.map(show) }; }
function differingPoint(a, b) { const edges = [...a, ...b].flatMap(x => [x.l, x.r]).sort(order); if (!edges.length)
    return null; const member = (list, x) => list.some(s => (order(x, s.l) > 0 || !order(x, s.l) && s.left) && (order(x, s.r) < 0 || !order(x, s.r) && s.right)); const xs = cuts(edges[0], edges[edges.length - 1], edges); for (let j = 0; j < xs.length; j++) {
    if (member(a, xs[j]) !== member(b, xs[j]))
        return show(xs[j]);
    if (j + 1 < xs.length) {
        const mid = over(plus(xs[j], xs[j + 1]), r(2));
        if (member(a, mid) !== member(b, mid))
            return show(mid);
    }
} return null; }
function functionCompositionOracleCalculation(index, d) {
    let set = [], critical = [], representatives = [], relaxed = [];
    if (index === 0) {
        const [a, h, k, b, v, w, l, u] = d;
        if (!a || !b || Math.abs(a) > 4 || Math.abs(b) > 4 || Math.abs(h) > 6 || !(l < h && h < u))
            return null;
        const sq = r(v - k, a);
        if (sq[0] <= 0n)
            return null;
        const n = BigInt(Math.floor(Math.sqrt(Number(sq[0])))), den = BigInt(Math.floor(Math.sqrt(Number(sq[1]))));
        if (n * n !== sq[0] || den * den !== sq[1] || den > 16n)
            return null;
        const root = r(n, den), extra = [r(h), minus(r(h), root), plus(r(h), root)];
        if (!extra.slice(1).some(x => order(x, r(l)) > 0 && order(x, r(u)) < 0))
            return null;
        const proof = imageCells(l, u, true, true, extra, x => quadratic(b, v, w, quadratic(a, h, k, x)));
        set = proof.set;
        critical = proof.critical;
        const f = (x) => quadratic(b, v, w, quadratic(a, h, k, x)), ends = [f(r(l)), f(r(u))].sort(order);
        relaxed = [[{ l: ends[0], r: ends[1], left: true, right: true }], imageCells(l, u, true, true, [r(v)], x => quadratic(b, v, w, x)).set];
    }
    else if (index === 1) {
        const [a, h, k, b, v, w, l, c, u] = d;
        if (!a || !b || Math.abs(a) > 4 || Math.abs(b) > 4 || Math.abs(h) > 6 || Math.abs(v) > 6 || !(l < c && c < u))
            return null;
        const x = imageCells(l, c, true, false, [r(h)], z => quadratic(a, h, k, z)), y = imageCells(c, u, true, true, [r(v)], z => quadratic(b, v, w, z));
        set = merge([...x.set, ...y.set]);
        critical = [...x.critical, ...y.critical];
        relaxed = [x.set, y.set];
        if (format(set) === format(x.set) || format(set) === format(y.set))
            return null;
    }
    else if (index === 2) {
        const [a, h, k, jl, jr, b, q, p, l, u] = d;
        if (!a || Math.abs(a) > 4 || Math.abs(h) > 6 || !(jl < jr && (jr <= h || jl >= h) && l < u) || b * p + q === 0)
            return null;
        const ends = [quadratic(a, h, k, r(jl)), quadratic(a, h, k, r(jr))].sort(order), roots = ends.flatMap(y => order(y, r(b)) ? [over(plus(times(y, r(p)), r(q)), minus(y, r(b)))] : []);
        const predicate = (x) => { if (!order(x, r(p)))
            return false; const y = over(plus(times(r(b), x), r(q)), minus(x, r(p))); return order(y, ends[0]) >= 0 && order(y, ends[1]) <= 0; };
        const proof = testCells(r(l), r(u), [r(p), ...roots], predicate);
        set = proof.set;
        critical = proof.critical;
        representatives = proof.representatives;
        relaxed = [testCells(r(l), r(u), [r(p)], x => !!order(x, r(p))).set, testCells(r(-24), r(24), [r(p), ...roots], predicate).set];
    }
    else if (index === 3) {
        const [a, b, c, A, B, C, l, m, u, tl, tr, dir] = d;
        if (!a || !A || !(l < m && m < u && tl < tr) || ![1, -1].includes(dir))
            return null;
        const coeff = [[a, b, true], [A, B, true], [(A - a) * m, (B - b) * m + C - c, false]], roots = coeff.flatMap(([s, k]) => s ? [r(-k, s)] : []);
        const solve = (omit) => testCells(r(tl), r(tr), roots, t => coeff.every(([s, k, strict], j) => { if (j === omit)
            return true; const sign = order(times(r(dir), plus(times(r(s), t), r(k))), r(0)); return strict ? sign > 0 : sign >= 0; }));
        const proof = solve(-1);
        set = proof.set;
        critical = proof.critical;
        representatives = proof.representatives;
        relaxed = coeff.map((_, j) => solve(j).set);
    }
    else
        return null;
    const answer = format(set), effectiveConstraintWitnesses = relaxed.map(x => differingPoint(set, x));
    if (!set.length || set.length > 2 || !decodeOption(answer) || effectiveConstraintWitnesses.filter(x => x !== null).length < 2)
        return null;
    return { answer, criticalPoints: critical, representatives, effectiveConstraintWitnesses, completeRealPartition: true, partitionArgument: index < 2 ? 'Between consecutive domain boundaries, quadratic vertices and outer-vertex preimages, each composed factor has a fixed order; endpoint images and attained singletons cover every continuous monotone piece.' : 'The sign of every nonzero affine factor is constant on each open cell; all roots, poles and bounded-domain endpoints are checked separately.', studentCalibrated: false };
}
function verifySubjectPracticeMathFunctionCompositionWithIndependentOracle(candidate, context = {}) { const plan = context.questionPlan, rc = plan?.renderConstraints, scope = rc?.exactFunctionCompositionScope, index = scopes.indexOf(scope), reasonCodes = []; const identity = plan?.subject === 'math' && plan?.topicId === 68 && plan?.targetDifficulty === 'hard' && plan?.taskFamily === 'math_function_composition_piecewise_reasoning' && plan?.planTemplate === 'math_function_composition_piecewise_reasoning_v1' && plan?.scenarioContract?.scenarioAction === scope && plan?.scenarioContract?.scenarioMode === 'abstract' && plan?.scenarioContract?.scenarioEntity === 'function_composition_piecewise_system' && candidate.subject === 'math' && candidate.topicId === 68 && candidate.designedDifficulty === 'hard' && candidate.questionType === 'single_choice'; const constraints = { topicCode: 'M-FUNC-001', boundedIntegerParameters: true, integerInputAbsoluteMax: 12, quadraticScaleAbsoluteMax: 4, maximumConstructionAttempts: 128, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false }; const contract = identity && plan?.schemaVersion === 'subject-practice-question-plan-v1' && plan?.policyVersion === 'subject-practice-question-plan-policy-v1' && plan?.representationType === 'text' && rc?.questionType === 'single_choice' && Object.entries(constraints).every(([k, v]) => rc?.[k] === v); const parameters = contract && index >= 0 ? readStem(candidate.prompt, index) : null; let proof = null; try {
    if (parameters)
        proof = functionCompositionOracleCalculation(index, parameters);
}
catch {
    reasonCodes.push('function_composition_oracle_partition_invalid');
} if (!proof)
    reasonCodes.push('function_composition_oracle_unparsed'); for (const lang of ['zh', 'en'])
    if (!parameters || JSON.stringify(readStem(candidate.localizations?.[lang]?.prompt ?? '', index)) !== JSON.stringify(parameters))
        reasonCodes.push('function_composition_oracle_localization'); const options = candidate.options ?? [], keys = options.map(o => decodeOption(o.text)); if (options.length !== 4 || keys.includes(null) || new Set(keys).size !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)))
    reasonCodes.push('function_composition_oracle_options'); for (const lang of ['zh', 'en']) {
    if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(o => [o.id, decodeOption(o.text)])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
        reasonCodes.push('function_composition_oracle_localized_options');
} const optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === proof?.answer ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null; if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('function_composition_oracle_answer'); return { oracleVersion: exports.FUNCTION_COMPOSITION_ORACLE_VERSION, status: reasonCodes.length ? 'conflict' : 'verified', taskFamily: 'math_function_composition_piecewise_reasoning', scopeId: parameters ? 'math-hard-function-composition-v1:' + scope : null, exactScope: scope, scopeMatched: !!parameters, completeCertificate: !!proof, certificate: proof, expectedAnswer: proof?.answer ?? null, selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, partitionEvidence: proof, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
