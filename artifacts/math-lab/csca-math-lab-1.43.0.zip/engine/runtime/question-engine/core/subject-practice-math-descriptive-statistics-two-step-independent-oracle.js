"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_TWO_STEP_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathStatisticsTwoStepWithIndependentOracle = verifySubjectPracticeMathStatisticsTwoStepWithIndependentOracle;
// Independent visible-text parser, bounded search and pair-distance variance.
// No imports from the solver, generator, explanation verifier or their helpers.
exports.STATISTICS_TWO_STEP_ORACLE_VERSION = 'math-descriptive-statistics-two-step-oracle-v1-bounded-enumeration';
const scopes = ['missing_value_from_mean_to_population_variance', 'missing_frequency_from_total_to_weighted_mean', 'missing_frequency_from_mean_to_population_variance', 'affine_mean_constraint_to_population_variance'];
function frac(n, d = 1) {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || d <= 0)
        return null;
    let a = Math.abs(n), b = d;
    while (b !== 0) {
        const remainder = a % b;
        a = b;
        b = remainder;
    }
    n /= a;
    d /= a;
    return d === 1 ? String(n) : n + '/' + d;
}
function option(s) { const m = typeof s === 'string' ? /^(-?\d{1,8})(?:\/([1-9]\d{0,8}))?$/.exec(s.trim()) : null; return m ? frac(+m[1], +(m[2] ?? 1)) : null; }
function parse(s, i, lang) {
    if (typeof s !== 'string' || s.length > 1400)
        return null;
    const expressions = lang === 'zh' ? [
        /^数据为 \[(-?\d+(?:,-?\d+)*),t\]，其中 t 是 \[-10,20\] 内的整数，平均数为 (-?\d+(?:\/\d+)?)。先确定 t，再求这组数据的总体方差（分母为数据总数 n）。$/,
        /^三个不同数值为 \[(-?\d+(?:,-?\d+)*)\]，对应频数为 \[(\d+,\d+),k\]，其中 k 是 \[1,6\] 内的整数，总频数为 (-?\d+(?:\/\d+)?)。先确定 k，再求加权平均数。$/,
        /^三个不同数值为 \[(-?\d+(?:,-?\d+)*)\]，对应频数为 \[(\d+,\d+),k\]，其中 k 是 \[1,6\] 内的整数，平均数为 (-?\d+(?:\/\d+)?)。先确定 k，再求总体方差（分母为总频数 n）。$/,
        /^原数据 x 为 \[(-?\d+(?:,-?\d+)*)\]。令 y=a\*x\+b，其中 b=(-?\d+)，a 是集合 \{-3,-2,-1,1,2,3\} 中的未知数，y 的平均数为 (-?\d+(?:\/\d+)?)。先确定 a，再求 y 的总体方差（分母为数据总数 n）。$/
    ] : [
        /^The data are \[(-?\d+(?:,-?\d+)*),t\], where t is an integer in \[-10,20\], and their mean is (-?\d+(?:\/\d+)?)\. Determine t, then find the population variance \(denominator: the total count n\)\.$/,
        /^Three distinct values are \[(-?\d+(?:,-?\d+)*)\], with respective frequencies \[(\d+,\d+),k\], where k is an integer in \[1,6\], and the total frequency is (-?\d+(?:\/\d+)?)\. Determine k, then find the weighted mean\.$/,
        /^Three distinct values are \[(-?\d+(?:,-?\d+)*)\], with respective frequencies \[(\d+,\d+),k\], where k is an integer in \[1,6\], and the mean is (-?\d+(?:\/\d+)?)\. Determine k, then find the population variance \(denominator: the total frequency n\)\.$/,
        /^The original x data are \[(-?\d+(?:,-?\d+)*)\]\. Let y=a\*x\+b, where b=(-?\d+), a is unknown in \{-3,-2,-1,1,2,3\}, and the mean of y is (-?\d+(?:\/\d+)?)\. Determine a, then find the population variance of y \(denominator: the total count n\)\.$/
    ];
    const m = expressions[i]?.exec(s);
    if (!m)
        return null;
    const values = m[1].split(',').map(Number), frequencies = i === 1 || i === 2 ? m[2].split(',').map(Number) : [], shift = i === 3 ? +m[2] : 0, known = m[i === 0 ? 2 : 3];
    if (values.some(v => !Number.isInteger(v) || v < -10 || v > 20) || option(known) !== known)
        return null;
    if (i === 0 && (values.length < 2 || values.length > 7))
        return null;
    if ((i === 1 || i === 2) && (values.length !== 3 || new Set(values).size !== 3 || frequencies.some(f => f < 1 || f > 6)))
        return null;
    if (i === 3 && (values.length < 3 || values.length > 8 || Math.abs(shift) > 10 || values.every(v => v === values[0]) || values.reduce((a, b) => a + b, 0) === 0))
        return null;
    return { values, frequencies, shift, known };
}
function enumerate(p, i) {
    const answers = [];
    const trials = i === 0 ? Array.from({ length: 31 }, (_, j) => j - 10) : i === 3 ? [-3, -2, -1, 1, 2, 3] : [1, 2, 3, 4, 5, 6];
    for (const unknown of trials) {
        let data = [];
        if (i === 0)
            data = [...p.values, unknown];
        else if (i === 3)
            data = p.values.map(x => unknown * x + p.shift);
        else
            for (let j = 0; j < 3; j++)
                for (let k = 0; k < (j === 2 ? unknown : p.frequencies[j]); k++)
                    data.push(p.values[j]);
        if (data.some(v => Math.abs(v) > 70) || data.length > 18)
            continue;
        let total = 0;
        for (const v of data)
            total += v;
        const matches = i === 1 ? String(data.length) === p.known : frac(total, data.length) === p.known;
        if (matches)
            answers.push({ unknown, data });
    }
    if (answers.length !== 1)
        return null;
    const { unknown, data } = answers[0];
    let pairSquares = 0, total = 0, squares = 0;
    for (let a = 0; a < data.length; a++) {
        total += data[a];
        squares += data[a] * data[a];
        for (let b = a + 1; b < data.length; b++)
            pairSquares += (data[a] - data[b]) ** 2;
    }
    const n = data.length, expected = frac(i === 1 ? total : pairSquares, i === 1 ? n : n * n);
    const errors = i === 1 ? {
        ignore_frequencies: frac(p.values.reduce((a, b) => a + b, 0), 3), omit_mean_denominator: frac(total),
        omit_unknown_frequency_group: frac(data.slice(0, p.frequencies[0] + p.frequencies[1]).reduce((a, b) => a + b, 0), p.frequencies[0] + p.frequencies[1])
    } : { use_sample_variance: frac(pairSquares, n * (n - 1)), omit_centering: frac(squares, n), omit_variance_denominator: frac(pairSquares, n) };
    return { unknown, data, total, squares, pairSquares, n, expected, errors, enumeratedUnknownCount: trials.length, uniqueSolutionCount: answers.length };
}
function verifySubjectPracticeMathStatisticsTwoStepWithIndependentOracle(candidate, context = {}) {
    const p = context.questionPlan, r = p?.renderConstraints, s = p?.scenarioContract, scope = r?.exactStatisticsTwoStepScope, i = scopes.indexOf(scope), reasonCodes = [];
    const required = { topicCode: 'M-STAT-001', boundedIntegerParameters: true, dataCountMin: 3, dataCountMax: 8, dataValueMin: -10, dataValueMax: 20, frequencyMin: 1, frequencyMax: 6, frequencyTableTotalMax: 18, affineShiftMin: -10, affineShiftMax: 10, transformedValueAbsoluteMax: 70, exactRationalArithmetic: true, populationDenominator: 'n', minimumVisibleMoves: 2, inferredUnknownMustBeUnique: true, externalContextAllowed: false, requiresImage: false };
    const planValid = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 76 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === 'math_descriptive_statistics_two_step_calculation' && p?.planTemplate === 'math_descriptive_statistics_two_step_calculation_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v)
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'bounded_two_step_statistics_object' && s?.scenarioAction === scope && i >= 0;
    const parsed = planValid ? parse(candidate.prompt, i, 'zh') : null, certificate = parsed ? enumerate(parsed, i) : null, expected = certificate?.expected ?? null;
    if (!certificate)
        reasonCodes.push('statistics_two_step_oracle_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 76 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('statistics_two_step_oracle_identity');
    const options = candidate.options ?? [], keys = options.map(o => option(o.text));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('statistics_two_step_oracle_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parsed || JSON.stringify(parse(loc?.prompt ?? '', i, lang)) !== JSON.stringify(parsed))
            reasonCodes.push('statistics_two_step_oracle_' + lang + '_stem');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, option(o.text)])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('statistics_two_step_oracle_' + lang + '_options');
    }
    const optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : expected !== null && keys[j] === expected ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(v => v.verdict === 'true').map(v => v.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || candidate.correctAnswer !== selectedOptionId)
        reasonCodes.push('statistics_two_step_oracle_answer');
    const meta = candidate.optionMetadata ?? [], errors = certificate?.errors ?? {};
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !Object.prototype.hasOwnProperty.call(errors, m.distractorIntent ?? '') || errors[m.distractorIntent ?? ''] === null || errors[m.distractorIntent ?? ''] !== keys[options.findIndex(o => o.id === m.optionId)]))
        reasonCodes.push('statistics_two_step_oracle_error_intent');
    const scopeId = certificate ? 'math-medium-descriptive-statistics-two-step-v1:' + scope : null;
    return { oracleVersion: exports.STATISTICS_TWO_STEP_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified', scopeId, scopeMatched: Boolean(certificate), selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, completeCertificate: Boolean(certificate && expected), certificate, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
