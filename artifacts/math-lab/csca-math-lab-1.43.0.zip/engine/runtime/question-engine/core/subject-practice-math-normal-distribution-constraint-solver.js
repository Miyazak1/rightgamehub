"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NORMAL_DISTRIBUTION_CONSTRAINT_NAMES = exports.scmp = exports.sdiv = exports.smul = exports.ssub = exports.sadd = exports.stxt = exports.NORMAL_DISTRIBUTION_CONSTRAINT_CONSTRAINTS = exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES = exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPE_VERSION = exports.NORMAL_DISTRIBUTION_CONSTRAINT_SOLVER_VERSION = exports.NORMAL_DISTRIBUTION_CONSTRAINT_TEMPLATE = exports.NORMAL_DISTRIBUTION_CONSTRAINT_FAMILY = void 0;
exports.sq = sq;
exports.sn = sn;
exports.normalDistributionConstraintScopeFrom = normalDistributionConstraintScopeFrom;
exports.normalDistributionConstraintPrompt = normalDistributionConstraintPrompt;
exports.normalDistributionConstraintParametersFrom = normalDistributionConstraintParametersFrom;
exports.normalDistributionConstraintOptionKey = normalDistributionConstraintOptionKey;
exports.normalDistributionConstraintDerive = normalDistributionConstraintDerive;
exports.solveSubjectPracticeMathNormalDistributionConstraint = solveSubjectPracticeMathNormalDistributionConstraint;
exports.NORMAL_DISTRIBUTION_CONSTRAINT_FAMILY = 'math_normal_distribution_constraint_reasoning';
exports.NORMAL_DISTRIBUTION_CONSTRAINT_TEMPLATE = exports.NORMAL_DISTRIBUTION_CONSTRAINT_FAMILY + '_v1';
exports.NORMAL_DISTRIBUTION_CONSTRAINT_SOLVER_VERSION = 'math-normal-distribution-constraint-solver-v1-given-probability';
exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPE_VERSION = 'math-hard-normal-distribution-constraint-v1';
exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES = ["two_standardized_positions_interval_probability", "affine_absolute_value_interval_probability", "interval_union_difference_probability", "empirical_affine_two_tail_threshold_combination"];
exports.NORMAL_DISTRIBUTION_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-STAT-002', boundedIntegerAndHalfIntegerParameters: true, maximumConstructionAttempts: 256, maximumEnumeratedParameterCompletions: 4096, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function sq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
    throw Error('zero_denominator'); if (b < 0n) {
    a = -a;
    b = -b;
} if (a.toString(2).length > 512 || b.toString(2).length > 512)
    throw Error('statistics_arithmetic_bound'); let x = a < 0n ? -a : a, y = b; while (y)
    [x, y] = [y, x % y]; return { n: a / (x || 1n), d: b / (x || 1n) }; }
const stxt = (v) => String(v.n) + (v.d === 1n ? '' : '/' + v.d), sadd = (a, b) => sq(a.n * b.d + b.n * a.d, a.d * b.d), ssub = (a, b) => sq(a.n * b.d - b.n * a.d, a.d * b.d), smul = (a, b) => sq(a.n * b.n, a.d * b.d), sdiv = (a, b) => sq(a.n * b.d, a.d * b.n), scmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0;
exports.stxt = stxt, exports.sadd = sadd, exports.ssub = ssub, exports.smul = smul, exports.sdiv = sdiv, exports.scmp = scmp;
function sn(s) { if (typeof s !== 'string' || s.length > 128 || !/^[-+]?\d+(?:\/[1-9]\d*|\.\d{1,8})?$/.test(s))
    throw Error('invalid_rational'); if (s.includes('.')) {
    const negative = s.startsWith('-'), [whole, frac] = s.replace(/^[-+]/, '').split('.');
    return sq((negative ? -1n : 1n) * BigInt(whole + frac), 10n ** BigInt(frac.length));
} const [n, d = '1'] = s.split('/'); return sq(BigInt(n), BigInt(d)); }
const equal = (a, b) => (0, exports.scmp)(a, b) === 0, zero = sq(0), one = sq(1);
const obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function normalDistributionConstraintScopeFrom(value) { const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactNormalDistributionConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 77 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.NORMAL_DISTRIBUTION_CONSTRAINT_FAMILY && p?.planTemplate === exports.NORMAL_DISTRIBUTION_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.NORMAL_DISTRIBUTION_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'normal_distribution_constraint_system' && s?.scenarioAction === scope && exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
exports.NORMAL_DISTRIBUTION_CONSTRAINT_NAMES = [["u", "z1", "v", "z2", "left", "right"], ["mu", "variance", "a", "b", "c", "r"], ["mu", "variance", "Aleft", "Aright", "Bleft", "Bright", "Cleft", "Cright"], ["mu", "variance", "a", "b", "tailL", "tailR"]];
const startsZh = ["X服从正态分布，均值mu、标准差sigma未知，sigma>0。两个精确标准化关系为(u-mu)/sigma=z1及(v-mu)/sigma=z2，求P(left<=X<=right)。", "X服从均值mu、方差variance的正态分布，Y=aX+b，求P(|Y-c|<=r)。", "X服从均值mu、方差variance的正态分布。A=[Aleft,Aright]，B=[Bleft,Bright]，C=[Cleft,Cright]，求X属于(A并B)去掉C的概率。", "X服从均值mu、方差variance的正态分布，Y=aX+b。利用给定经验规律，P(Y<l)约为tailL，P(Y>u)约为tailR，求2l+u的近似值。"];
const startsEn = ["X is normal with unknown mean mu and positive standard deviation sigma. The exact standardized relations are (u-mu)/sigma=z1 and (v-mu)/sigma=z2. Find P(left<=X<=right).", "X is normal with mean mu and variance variance. Let Y=aX+b. Find P(|Y-c|<=r).", "X is normal with mean mu and variance variance. Let A=[Aleft,Aright], B=[Bleft,Bright], C=[Cleft,Cright]. Find the probability that X belongs to (A union B) minus C.", "X is normal with mean mu and variance variance. Let Y=aX+b. Under the supplied empirical rule, P(Y<l) is approximately tailL and P(Y>u) is approximately tailR. Find the approximate value of 2l+u."];
const suffixesZh = [" 给定标准正态累计概率近似值：Phi(-2)=0.0228，Phi(-1)=0.1587，Phi(0)=0.5000，Phi(1)=0.8413，Phi(2)=0.9772。仅按此表求近似概率。", " 给定经验规律：均值左右1、2、3个标准差内的概率分别约为68%、95%、99.7%；阈值及最终结果均为该规律下的近似值。"];
const suffixesEn = [" Given approximate standard normal cumulative probabilities: Phi(-2)=0.0228, Phi(-1)=0.1587, Phi(0)=0.5000, Phi(1)=0.8413, Phi(2)=0.9772. Use this table for approximate probabilities.", " Given empirical rule: probabilities within 1, 2, 3 standard deviations of the mean are approximately 68%, 95%, 99.7%. Thresholds and the final result are approximate under this rule."];
function normalDistributionConstraintPrompt(p, lang) { const i = exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES.indexOf(p.scope), variant = p.data.join(';').length % 3; const lead = lang === 'zh' ? ['计算问题：', '概率模型：', '请分析：'][variant] : ['Calculation: ', 'Probability model: ', 'Analyze: '][variant]; return lead + (lang === 'zh' ? startsZh : startsEn)[i] + (lang === 'zh' ? '参数：' : ' Parameters: ') + exports.NORMAL_DISTRIBUTION_CONSTRAINT_NAMES[i].map((n, j) => n + '=(' + p.data[j] + ')').join('; ') + (lang === 'zh' ? suffixesZh : suffixesEn)[i === 3 ? 1 : 0]; }
function normalDistributionConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 4000)
    return null; const data = [...text.matchAll(/=\(([^()]*)\)/g)].map(m => m[1]), p = { scope, data }; return data.length === exports.NORMAL_DISTRIBUTION_CONSTRAINT_NAMES[exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES.indexOf(scope)].length && normalDistributionConstraintPrompt(p, lang) === text ? p : null; }
function normalDistributionConstraintOptionKey(text, scope) { try {
    const q = sn(text.trim());
    return scope !== exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES[3] && (q.n < 0n || (0, exports.scmp)(q, sq(1)) > 0) ? null : (0, exports.stxt)(q);
}
catch {
    return null;
} }
const cdf = [228, 1587, 5000, 8413, 9772], grid = [-2, -1, 0, 1, 2];
const asInt = (s, lo, hi) => { const q = sn(s); if (q.d !== 1n || q.n < BigInt(lo) || q.n > BigInt(hi))
    throw Error('integer_domain'); return Number(q.n); };
const idx = (x) => { const j = grid.findIndex(z => (0, exports.scmp)(x, sq(z)) === 0); if (j < 0)
    throw Error('cdf_grid'); return j; };
const num = (x) => Number(x.n) / Number(x.d);
const rootVariance = (s) => { const v = asInt(s, 4, 64), r = Math.sqrt(v); if (!Number.isInteger(r) || r < 2 || r > 8)
    throw Error('variance_domain'); return r; };
function basic(p) {
    const i = exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES.indexOf(p.scope), d = p.data;
    if (i < 0 || d.length !== exports.NORMAL_DISTRIBUTION_CONSTRAINT_NAMES[i].length)
        throw Error('scope_data');
    let mu = 0, sigma = 0, lo = 0, hi = 0, bands = [], answer, steps = [], errors = [];
    const error = (intent, value) => { const key = (0, exports.stxt)(value); if (i !== 3 && (value.n < 0n || (0, exports.scmp)(value, sq(1)) > 0))
        return; errors.push({ intent, text: key, key }); };
    const probability = (left, right) => { const l = idx(left), u = idx(right); if (l >= u)
        throw Error('interval_order'); return { l, u, units: cdf[u] - cdf[l] }; };
    if (i === 0) {
        const u = asInt(d[0], -36, 56), z1 = asInt(d[1], -2, 2), v = asInt(d[2], -36, 56), z2 = asInt(d[3], -2, 2);
        if (z1 >= z2)
            throw Error('standardized_order');
        const s = sq(v - u, z2 - z1), m = (0, exports.ssub)(sq(u), (0, exports.smul)(sq(z1), s));
        if (s.d !== 1n || s.n < 2n || s.n > 8n || m.d !== 1n || m.n < -20n || m.n > 40n)
            throw Error('recovered_domain');
        mu = Number(m.n);
        sigma = Number(s.n);
        const left = sn(d[4]), right = sn(d[5]), q = probability((0, exports.sdiv)((0, exports.ssub)(left, m), s), (0, exports.sdiv)((0, exports.ssub)(right, m), s));
        lo = q.l;
        hi = q.u;
        bands = Array.from({ length: hi - lo }, (_, j) => lo + j);
        answer = (0, exports.stxt)(sq(q.units, 10000));
        steps = ['sigma=(v-u)/(z2-z1)=' + sigma, 'mu=u-z1*sigma=' + mu, 'standardized interval=[' + grid[lo] + ',' + grid[hi] + ']', 'given cumulative difference=(' + cdf[hi] + '-' + cdf[lo] + ')/10000; probability approximately ' + answer];
    }
    else {
        mu = asInt(d[0], -20, 40);
        sigma = rootVariance(d[1]);
        if (i === 1) {
            const a = asInt(d[2], -3, 3), b = asInt(d[3], -12, 12), c = sn(d[4]), r = sn(d[5]);
            if (![-3, -2, 2, 3].includes(a) || r.n <= 0n || (0, exports.scmp)(c, sq(a * mu + b)) === 0)
                throw Error('affine_event_domain');
            let x0 = (0, exports.sdiv)((0, exports.ssub)((0, exports.ssub)(c, r), sq(b)), sq(a)), x1 = (0, exports.sdiv)((0, exports.ssub)((0, exports.sadd)(c, r), sq(b)), sq(a));
            if (a < 0)
                [x0, x1] = [x1, x0];
            const q = probability((0, exports.sdiv)((0, exports.ssub)(x0, sq(mu)), sq(sigma)), (0, exports.sdiv)((0, exports.ssub)(x1, sq(mu)), sq(sigma)));
            lo = q.l;
            hi = q.u;
            bands = Array.from({ length: hi - lo }, (_, j) => lo + j);
            answer = (0, exports.stxt)(sq(q.units, 10000));
            steps = ['Y interval=[' + (0, exports.stxt)((0, exports.ssub)(c, r)) + ',' + (0, exports.stxt)((0, exports.sadd)(c, r)) + ']', 'inverse affine X interval=[' + (0, exports.stxt)(x0) + ',' + (0, exports.stxt)(x1) + ']; a=' + a, 'sigma=sqrt(' + d[1] + ')=' + sigma + '; standardized interval=[' + grid[lo] + ',' + grid[hi] + ']', 'given cumulative difference=(' + cdf[hi] + '-' + cdf[lo] + ')/10000; probability approximately ' + answer];
        }
        else if (i === 2) {
            const indices = d.slice(2).map(s => idx((0, exports.sdiv)((0, exports.ssub)(sn(s), sq(mu)), sq(sigma)))), [a0, a1, b0, b1, c0, c1] = indices;
            if (a0 >= a1 || b0 >= b1 || c0 >= c1)
                throw Error('interval_order');
            const mask = (l, u, j) => j >= l && j < u, A = grid.slice(0, 4).map((_, j) => mask(a0, a1, j)), B = grid.slice(0, 4).map((_, j) => mask(b0, b1, j)), C = grid.slice(0, 4).map((_, j) => mask(c0, c1, j));
            if (!A.some((a, j) => a && !B[j] && !C[j]) || !B.some((b, j) => b && !A[j] && !C[j]) || !C.some((c, j) => c && (A[j] || B[j])))
                throw Error('ineffective_event');
            bands = A.flatMap((a, j) => (a || B[j]) && !C[j] ? [j] : []);
            const mass = (js) => js.reduce((sum, j) => sum + cdf[j + 1] - cdf[j], 0);
            answer = (0, exports.stxt)(sq(mass(bands), 10000));
            lo = Math.min(a0, b0);
            hi = Math.max(a1, b1);
            error('omit_exclusion_interval', sq(mass(A.flatMap((a, j) => a || B[j] ? [j] : [])), 10000));
            error('omit_interval_A', sq(mass(B.flatMap((b, j) => b && !C[j] ? [j] : [])), 10000));
            error('omit_interval_B', sq(mass(A.flatMap((a, j) => a && !C[j] ? [j] : [])), 10000));
            error('double_count_overlap', sq(mass(A.flatMap((a, j) => a && !C[j] ? [j] : [])) + mass(B.flatMap((b, j) => b && !C[j] ? [j] : [])), 10000));
            steps = ['sigma=sqrt(' + d[1] + ')=' + sigma + '; standardized endpoints=' + indices.map(j => grid[j]).join(','), 'union membership=' + A.map((a, j) => a || B[j] ? 1 : 0).join(','), 'remove C; disjoint elementary bands=' + bands.map(j => '[' + grid[j] + ',' + grid[j + 1] + ']').join('+'), 'sum supplied band masses=' + mass(bands) + '/10000; probability approximately ' + answer];
        }
        else {
            const a = asInt(d[2], -3, 3), b = asInt(d[3], -12, 12);
            if (![-3, -2, 2, 3].includes(a))
                throw Error('affine_coefficient');
            const tails = ['4/25', '1/40', '3/2000'], kL = tails.indexOf((0, exports.stxt)(sn(d[4]))) + 1, kR = tails.indexOf((0, exports.stxt)(sn(d[5]))) + 1, m = a * mu + b, s = Math.abs(a) * sigma;
            if (!kL || !kR || kL === kR || kR === 2 * kL || !m)
                throw Error('tail_domain');
            const l = m - kL * s, u = m + kR * s;
            answer = String(2 * l + u);
            error('swap_unequal_tails', sq(3 * m + (kL - 2 * kR) * s));
            error('wrong_lower_tail_side', sq(3 * m + (kR + 2 * kL) * s));
            error('omit_affine_shift', sq(3 * a * mu + (kR - 2 * kL) * s));
            error('variance_as_standard_deviation', sq(3 * m + (kR - 2 * kL) * Math.abs(a) * sigma * sigma));
            error('signed_standard_deviation', sq(3 * m + (kR - 2 * kL) * a * sigma));
            steps = ['meanY=a*mu+b=' + m + '; sigmaY=|a|*sqrt(variance)=' + s, 'empirical tail multiples kL=' + kL + '; kR=' + kR, 'empirical thresholds l=' + l + '; u=' + u, '2*l+u approximately ' + answer + ' under the supplied empirical rule'];
        }
    }
    if (i !== 3) {
        const q = sn(answer);
        error('use_upper_cumulative_only', sq(cdf[hi], 10000));
        error('complement_event', (0, exports.ssub)(sq(1), q));
        error('halve_probability_again', (0, exports.sdiv)(q, sq(2)));
        error('use_lower_cumulative_only', sq(cdf[lo], 10000));
        error('add_cumulative_values', sq(cdf[hi] + cdf[lo], 10000));
    }
    const coefficients = Array(5).fill(0);
    for (const j of bands) {
        coefficients[j]--;
        coefficients[j + 1]++;
    }
    const errorBound = i === 3 ? 0 : coefficients.reduce((sum, k) => sum + Math.abs(k), 0) / 20000;
    errors = errors.filter((e, j, all) => e.key !== answer && all.findIndex(x => x.key === e.key) === j && (i === 3 || Math.abs(num(sn(e.key)) - num(sn(answer))) > 2 * errorBound)).slice(0, 3);
    if (errors.length !== 3)
        throw Error('distractor_collision');
    return { answer, mu, sigma, lower: lo, upper: hi, bands, steps: [...steps, 'all visible conditions substituted; unique answer in the given approximate model; CDF error bound=' + errorBound], errors };
}
function normalDistributionConstraintDerive(p) {
    try {
        const out = basic(p), i = exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES.indexOf(p.scope);
        const witnesses = [];
        const find = (omitted, variants) => { for (const data of variants) {
            try {
                const alt = basic({ scope: p.scope, data });
                if (alt.answer !== out.answer) {
                    witnesses.push({ omitted, completion: data, differentAnswer: alt.answer });
                    return;
                }
            }
            catch { }
        } throw Error('ineffective_' + omitted); };
        const change = (j, v) => p.data.map((x, k) => j === k ? v : x);
        if (i === 0) {
            const givenUnits = (x) => { const j = grid.findIndex(z => (0, exports.scmp)(x, sq(z)) === 0); if (j >= 0)
                return [Math.max(0, cdf[j] - 1), Math.min(10000, cdf[j] + 1)]; const below = grid.filter(z => (0, exports.scmp)(sq(z), x) < 0).length; return [below === 0 ? 0 : cdf[below - 1] - 1, below === 5 ? 10000 : cdf[below] + 1]; };
            for (let omit = 0; omit < 2; omit++) {
                let witness = null;
                for (let m = -20; m <= 40 && !witness; m++)
                    for (let s = 2; s <= 8 && !witness; s++) {
                        const eq = [m + Number(p.data[1]) * s === Number(p.data[0]), m + Number(p.data[3]) * s === Number(p.data[2])];
                        if (eq[omit] || !eq[1 - omit])
                            continue;
                        const L = givenUnits((0, exports.sdiv)((0, exports.ssub)(sn(p.data[4]), sq(m)), sq(s))), U = givenUnits((0, exports.sdiv)((0, exports.ssub)(sn(p.data[5]), sq(m)), sq(s))), bounds = [Math.max(0, U[0] - L[1]), Math.min(10000, U[1] - L[0])], answerUnits = num(sn(out.answer)) * 10000;
                        if (bounds[1] < answerUnits - 2 || bounds[0] > answerUnits + 2)
                            witness = { omitted: omit === 0 ? 'first_standardized_position' : 'second_standardized_position', completion: [String(m), String(s)], differentAnswer: 'probability_units_in[' + bounds.join(',') + ']' };
                    }
                if (!witness)
                    throw Error('position_counterexample');
                witnesses.push(witness);
            }
            const events = [];
            for (let l = -2; l < 2; l++)
                for (let u = l + 1; u <= 2; u++) {
                    const d = [...p.data];
                    d[4] = String(out.mu + l * out.sigma);
                    d[5] = String(out.mu + u * out.sigma);
                    events.push(d);
                }
            find('requested_interval', events);
        }
        else if (i === 1) {
            find('distribution_location', [-2, -1, 1, 2].map(k => change(0, String(out.mu + k * out.sigma))));
            find('affine_shift', [-2, -1, 1, 2].map(k => change(3, String(Number(p.data[3]) + k * Number(p.data[2]) * out.sigma))));
            find('absolute_event_location', [-2, -1, 1, 2].map(k => change(4, (0, exports.stxt)((0, exports.sadd)(sn(p.data[4]), sq(k * Math.abs(Number(p.data[2])) * out.sigma))))));
        }
        else if (i === 2) {
            for (const intent of ['omit_interval_A', 'omit_interval_B', 'omit_exclusion_interval']) {
                const variant = out.errors.find(e => e.intent === intent);
                if (!variant)
                    throw Error('event_witness');
                witnesses.push({ omitted: intent, completion: p.data.slice(), differentAnswer: variant.key });
            }
        }
        else {
            find('transformed_location', [-1, 1].map(k => change(0, String(out.mu + k))));
            find('transformed_scale', [-1, 1].map(k => change(1, String((out.sigma + k) ** 2))));
            find('tail_levels', ['4/25', '1/40', '3/2000'].flatMap(x => [change(4, x), change(5, x)]));
        }
        const certificate = { method: 'bounded_exact_coordinate_recovery_and_complete_probability_partition', complete: true, examined: i === 0 ? 427 : i === 2 ? 4 : 3, domainSizes: i === 0 ? [61, 7] : [4], completions: [p.data], selected: p.data, bands: out.bands, approximate: true };
        const hardEvidence = { version: 'normal-distribution-constraint-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 3, reasoningSteps: out.steps.length, quantitativeRelations: 2, groups: witnesses.map(w => w.omitted), effectiveConstraints: witnesses, completeNormalCertificate: certificate, criticalPoints: out.bands, answer: out.answer, visibleProof: out.steps.join('; '), studentCalibrated: false };
        return { answer: out.answer, text: out.answer, errors: out.errors, steps: out.steps, proof: out.steps.join('; '), hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathNormalDistributionConstraint(candidate, context = {}) {
    const scope = normalDistributionConstraintScopeFrom(context.questionPlan), parameters = normalDistributionConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? normalDistributionConstraintDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('normal_distribution_constraint_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 77 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('normal_distribution_constraint_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? normalDistributionConstraintOptionKey(o.text, scope) : null);
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('normal_distribution_constraint_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(normalDistributionConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('normal_distribution_constraint_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, scope ? normalDistributionConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('normal_distribution_constraint_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('normal_distribution_constraint_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('normal_distribution_constraint_error_intent');
    const scopeId = parameters ? exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.NORMAL_DISTRIBUTION_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.NORMAL_DISTRIBUTION_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['normal_distribution_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
