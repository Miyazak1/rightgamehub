"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MATH_SOLID_GEOMETRY_SCOPES = exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_SOLVER_VERSION = void 0;
exports.solidGeometryRecord = solidGeometryRecord;
exports.solidGeometryScopeFrom = solidGeometryScopeFrom;
exports.solidGeometryParametersFrom = solidGeometryParametersFrom;
exports.solidGeometryValue = solidGeometryValue;
exports.parseSolidGeometryOption = parseSolidGeometryOption;
exports.solveSubjectPracticeMathSolidGeometry = solveSubjectPracticeMathSolidGeometry;
exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_SOLVER_VERSION = 'math-solid-geometry-solver-v1-bounded-dimensional';
exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_SCOPE_VERSION = 'math-solid-geometry-scope-v1';
exports.MATH_SOLID_GEOMETRY_SCOPES = ['cuboid_volume', 'cuboid_surface_area', 'cuboid_space_diagonal', 'cylinder_volume'];
function solidGeometryRecord(v) {
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
}
function solidGeometryScopeFrom(plan) {
    const p = solidGeometryRecord(plan), r = solidGeometryRecord(p?.renderConstraints);
    const s = r?.exactSolidGeometryScope;
    return p?.taskFamily === 'math_solid_geometry_direct_calculation'
        && p?.planTemplate === 'math_solid_geometry_direct_calculation_v1'
        && p?.subject === 'math' && p?.targetDifficulty === 'basic'
        && r?.maximumDimensionCm === 30 && r?.integerParametersRequired === true
        && r?.oneDirectSolidMeasurementTarget === true && r?.externalContextAllowed === false
        && r?.finalAnswerShape === 'one_unique_dimensioned_integer_or_pi_multiple'
        && exports.MATH_SOLID_GEOMETRY_SCOPES.includes(s) ? s : null;
}
// Closed grammar: reject extra conditions, changed units and a different visible target.
// This verifier certifies only this bounded family, not arbitrary spatial geometry prose.
function solidGeometryParametersFrom(text, scope, language) {
    if (!scope)
        return null;
    const t = String(text ?? '').trim();
    const targetZh = { cuboid_volume: '体积', cuboid_surface_area: '总表面积', cuboid_space_diagonal: '体对角线长度', cylinder_volume: '体积' }[scope];
    const targetEn = { cuboid_volume: 'volume', cuboid_surface_area: 'total surface area', cuboid_space_diagonal: 'space diagonal length', cylinder_volume: 'volume' }[scope];
    const pattern = scope === 'cylinder_volume'
        ? language === 'zh'
            ? /^(?:一个直圆柱|已知一直圆柱)的底面半径 r=(\d+) cm，高 h=(\d+) cm。求它的体积（保留 π）。$/
            : /^(?:A right circular cylinder|Consider a right circular cylinder) has base radius r=(\d+) cm and height h=(\d+) cm\. Find its volume \(leave π exact\)\.$/
        : language === 'zh'
            ? new RegExp(`^(?:一个长方体|已知一长方体)的三条相邻棱长为 a=(\\d+) cm、b=(\\d+) cm、c=(\\d+) cm。求它的${targetZh}。$`)
            : new RegExp(`^(?:A cuboid|Consider a cuboid) has three adjacent edge lengths a=(\\d+) cm, b=(\\d+) cm, c=(\\d+) cm\\. Find its ${targetEn}\\.$`);
    const match = t.match(pattern);
    if (!match)
        return null;
    const values = match.slice(1).map(Number);
    if (!values.every(n => Number.isInteger(n) && n >= 1 && n <= 30))
        return null;
    return scope === 'cylinder_volume' ? { r: values[0], h: values[1] } : { a: values[0], b: values[1], c: values[2] };
}
function solidGeometryValue(p, scope) {
    if ('r' in p)
        return { coefficient: p.r * p.r * p.h, pi: true, power: 3 };
    if (scope === 'cuboid_surface_area')
        return { coefficient: 2 * (p.a * p.b + p.a * p.c + p.b * p.c), pi: false, power: 2 };
    if (scope === 'cuboid_space_diagonal')
        return { coefficient: Math.sqrt(p.a ** 2 + p.b ** 2 + p.c ** 2), pi: false, power: 1 };
    return { coefficient: p.a * p.b * p.c, pi: false, power: 3 };
}
function parseSolidGeometryOption(text) {
    const m = String(text ?? '').trim().match(/^(\d+)(π)? cm(?:\^([23]))?$/);
    if (!m || !Number.isSafeInteger(Number(m[1])) || Number(m[1]) <= 0)
        return null;
    return { coefficient: Number(m[1]), pi: Boolean(m[2]), power: Number(m[3] ?? 1) };
}
function optionsWellFormed(options) {
    return options.length === 4 && new Set(options.map(o => o.id)).size === 4
        && options.every(o => ['A', 'B', 'C', 'D'].includes(o.id))
        && new Set(options.map(o => JSON.stringify(parseSolidGeometryOption(o.text)))).size === 4;
}
function solveSubjectPracticeMathSolidGeometry(candidate, context = {}) {
    const exactScope = solidGeometryScopeFrom(context.questionPlan);
    const parameters = solidGeometryParametersFrom(candidate.prompt, exactScope, 'zh');
    const zh = solidGeometryParametersFrom(candidate.localizations?.zh?.prompt ?? '', exactScope, 'zh');
    const en = solidGeometryParametersFrom(candidate.localizations?.en?.prompt ?? '', exactScope, 'en');
    const expectedValue = parameters && exactScope ? solidGeometryValue(parameters, exactScope) : null;
    const parsed = Boolean(expectedValue && Number.isSafeInteger(expectedValue.coefficient));
    const optionVerdicts = (candidate.options ?? []).map(o => {
        const value = parseSolidGeometryOption(o.text);
        return { optionId: o.id, verdict: !value ? 'unknown' : JSON.stringify(value) === JSON.stringify(expectedValue) ? 'true' : 'false', semanticValue: value };
    });
    const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!parsed)
        reasonCodes.push('math_solid_geometry_prompt_or_plan_outside_bounded_scope');
    if (!zh || !en || JSON.stringify(parameters) !== JSON.stringify(zh) || JSON.stringify(parameters) !== JSON.stringify(en))
        reasonCodes.push('math_solid_geometry_bilingual_prompt_mismatch');
    if (candidate.subject !== 'math' || candidate.questionType !== 'single_choice' || candidate.designedDifficulty !== 'basic')
        reasonCodes.push('math_solid_geometry_candidate_identity_mismatch');
    if (!optionsWellFormed(candidate.options ?? []) || optionVerdicts.some(x => x.verdict === 'unknown'))
        reasonCodes.push('math_solid_geometry_invalid_or_duplicate_options');
    if (optionVerdicts.some(x => x.semanticValue && expectedValue && (x.semanticValue.power !== expectedValue.power || x.semanticValue.pi !== expectedValue.pi)))
        reasonCodes.push('math_solid_geometry_option_dimension_mismatch');
    for (const lang of ['zh', 'en']) {
        if (JSON.stringify(candidate.localizations?.[lang]?.options) !== JSON.stringify(candidate.options))
            reasonCodes.push(`math_solid_geometry_${lang}_options_mismatch`);
    }
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_solid_geometry_answer_not_unique');
    if (selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_solid_geometry_generator_disagreement');
    const scopeId = parsed ? `math-basic-solid-geometry-v1:${exactScope}` : null;
    return { solverVersion: exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_SOLVER_VERSION, status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_solid_geometry_direct_calculation', scopeId, exactScope, parameters, expectedValue,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['math_solid_geometry_scope_not_matched'] },
        optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
