"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.INEQUALITY_SIGN_CHART_CONSTRAINTS = exports.MATH_INEQUALITY_SIGN_CHART_SCOPES = exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_SOLVER_VERSION = exports.INEQUALITY_SIGN_CHART_TEMPLATE = exports.INEQUALITY_SIGN_CHART_FAMILY = void 0;
exports.signChartScopeFrom = signChartScopeFrom;
exports.signChartSigned = signChartSigned;
exports.signChartExpression = signChartExpression;
exports.signChartParametersFrom = signChartParametersFrom;
exports.formatSignChartIntervals = formatSignChartIntervals;
exports.parseSignChartIntervals = parseSignChartIntervals;
exports.signChartSolution = signChartSolution;
exports.signChartDistractors = signChartDistractors;
exports.solveSubjectPracticeMathInequalitySignChart = solveSubjectPracticeMathInequalitySignChart;
exports.INEQUALITY_SIGN_CHART_FAMILY = 'math_quadratic_rational_inequality_solution';
exports.INEQUALITY_SIGN_CHART_TEMPLATE = exports.INEQUALITY_SIGN_CHART_FAMILY + '_v1';
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_SOLVER_VERSION = 'math-inequality-sign-chart-solver-v1-exact-intervals';
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_SCOPE_VERSION = 'math-medium-inequality-sign-chart-v1';
exports.MATH_INEQUALITY_SIGN_CHART_SCOPES = [
    'quadratic_strict_sign_interval', 'quadratic_inclusive_sign_interval',
    'linear_fraction_strict_sign_interval', 'linear_fraction_inclusive_sign_interval'
];
exports.INEQUALITY_SIGN_CHART_CONSTRAINTS = {
    topicCode: 'M-INEQ-001', maximumAbsoluteScale: 5, minimumCriticalPoint: -9,
    maximumCriticalPoint: 9, distinctCriticalPointsRequired: true,
    integerCriticalPointsRequired: true, maximumOptionEndpoint: 12,
    realSolutionSetRequired: true, externalContextAllowed: false, requiresImage: false,
    finalAnswerShape: 'one_unique_union_of_at_most_two_exact_intervals'
};
function record(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function signChartScopeFrom(value) {
    const p = record(value), r = record(p?.renderConstraints), s = r?.exactInequalitySignChartScope, scenario = record(p?.scenarioContract);
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 67 && p?.targetDifficulty === 'medium'
        && p?.taskFamily === exports.INEQUALITY_SIGN_CHART_FAMILY && p?.planTemplate === exports.INEQUALITY_SIGN_CHART_TEMPLATE
        && p?.representationType === 'text' && r?.questionType === 'single_choice'
        && scenario?.scenarioMode === 'abstract' && scenario?.scenarioEntity === 'inequality_sign_chart_object' && scenario?.scenarioAction === s
        && Object.entries(exports.INEQUALITY_SIGN_CHART_CONSTRAINTS).every(([k, v]) => r?.[k] === v)
        && exports.MATH_INEQUALITY_SIGN_CHART_SCOPES.includes(s) ? s : null;
}
function signChartSigned(n) { return (n < 0 ? ' - ' : ' + ') + Math.abs(n); }
function signChartExpression(p) {
    const expression = p.kind === 'quadratic'
        ? p.a + 'x^2' + signChartSigned(p.b) + 'x' + signChartSigned(p.c)
        : '(' + p.a + 'x' + signChartSigned(p.b) + ')/(x' + signChartSigned(-p.pole) + ')';
    return expression + ' ' + p.relation + ' 0';
}
function signChartParametersFrom(text, scope, lang) {
    if (!scope)
        return null;
    const stem = String(text ?? '').match(lang === 'zh'
        ? /^(?:解不等式|求下列不等式的实数解集)：(.+)。请结合临界点、区间符号与端点开闭选择解集。$/
        : /^(?:Solve the inequality over the real numbers|Find the real solution set): (.+)\. Use critical points, interval signs and endpoint inclusion to select the solution set\.$/);
    if (!stem)
        return null;
    const kind = scope.startsWith('quadratic') ? 'quadratic' : 'linear_fraction';
    const m = stem[1].match(kind === 'quadratic'
        ? /^(-?\d+)x\^2 ([+-]) (\d+)x ([+-]) (\d+) (<=|>=|<|>) 0$/
        : /^\((-?\d+)x ([+-]) (\d+)\)\/\(x ([+-]) (\d+)\) (<=|>=|<|>) 0$/);
    if (!m)
        return null;
    const a = Number(m[1]), b = Number(m[3]) * (m[2] === '-' ? -1 : 1);
    const last = Number(m[5]) * (m[4] === '-' ? -1 : 1), relation = m[6];
    if (![a, b, last].every(Number.isSafeInteger) || !a || Math.abs(a) > 5
        || Math.abs(b) > (kind === 'quadratic' ? 90 : 45) || Math.abs(last) > (kind === 'quadratic' ? 405 : 9)
        || relation.includes('=') !== scope.includes('inclusive'))
        return null;
    let zeros, pole = null;
    if (kind === 'quadratic') {
        const d = b * b - 4 * a * last, root = Math.sqrt(d);
        if (d <= 0 || !Number.isInteger(root))
            return null;
        zeros = [(-b - root) / (2 * a), (-b + root) / (2 * a)].sort((x, y) => x - y);
    }
    else {
        zeros = [-b / a];
        pole = -last;
    }
    const critical = [...zeros, ...(pole === null ? [] : [pole])].sort((x, y) => x - y);
    if (critical.length !== 2 || critical[0] === critical[1] || critical.some(x => !Number.isInteger(x) || x < -9 || x > 9))
        return null;
    const p = { scope, kind, a, b, c: kind === 'quadratic' ? last : 0, pole, zeros, lower: critical[0], upper: critical[1], relation };
    return signChartExpression(p) === stem[1] ? p : null;
}
function formatSignChartIntervals(values) {
    const bound = (x) => x === -Infinity ? '-inf' : x === Infinity ? '+inf' : String(x);
    return values.map(i => (i.leftClosed ? '[' : '(') + bound(i.lower) + ', ' + bound(i.upper) + (i.rightClosed ? ']' : ')')).join(' U ');
}
function parseSignChartIntervals(text) {
    const parts = String(text ?? '').trim().split(/\s+U\s+/);
    if (parts.length < 1 || parts.length > 2)
        return null;
    const values = [];
    for (const part of parts) {
        const m = part.match(/^([\[(])\s*(-inf|[+-]?\d+)\s*,\s*(\+inf|[+-]?\d+)\s*([\])])$/);
        if (!m)
            return null;
        const lower = m[2] === '-inf' ? -Infinity : Number(m[2]), upper = m[3] === '+inf' ? Infinity : Number(m[3]);
        if ((m[2] !== '-inf' && !Number.isSafeInteger(lower)) || (m[3] !== '+inf' && !Number.isSafeInteger(upper)))
            return null;
        const leftClosed = m[1] === '[', rightClosed = m[4] === ']';
        if (!(lower < upper) || (!Number.isFinite(lower) && leftClosed) || (!Number.isFinite(upper) && rightClosed)
            || [lower, upper].some(x => Number.isFinite(x) && (!Number.isInteger(x) || Math.abs(x) > 12)))
            return null;
        values.push({ lower, upper, leftClosed, rightClosed });
    }
    values.sort((x, y) => x.lower - y.lower || Number(y.leftClosed) - Number(x.leftClosed));
    if (values.length === 2) {
        const [a, b] = values;
        if (a.upper > b.lower || (a.upper === b.lower && (a.rightClosed || b.leftClosed))) {
            return [{ lower: a.lower, upper: Math.max(a.upper, b.upper),
                    leftClosed: a.leftClosed || (a.lower === b.lower && b.leftClosed),
                    rightClosed: a.upper > b.upper ? a.rightClosed : a.upper < b.upper ? b.rightClosed : a.rightClosed || b.rightClosed }];
        }
    }
    return values;
}
function signChartSolution(p) {
    const outside = p.relation.startsWith('>') === (p.a > 0);
    const closed = (x) => p.relation.includes('=') && x !== p.pole;
    return outside ? [
        { lower: -Infinity, upper: p.lower, leftClosed: false, rightClosed: closed(p.lower) },
        { lower: p.upper, upper: Infinity, leftClosed: closed(p.upper), rightClosed: false }
    ] : [{ lower: p.lower, upper: p.upper, leftClosed: closed(p.lower), rightClosed: closed(p.upper) }];
}
function signChartDistractors(p) {
    const flipped = p.relation.replace(/[<>]/, c => c === '<' ? '>' : '<');
    const boundary = signChartSolution(p).map(i => ({ ...i,
        leftClosed: Number.isFinite(i.lower) && (p.pole === null ? !i.leftClosed : i.lower === p.pole ? true : i.leftClosed),
        rightClosed: Number.isFinite(i.upper) && (p.pole === null ? !i.rightClosed : i.upper === p.pole ? true : i.rightClosed)
    }));
    return [
        { text: formatSignChartIntervals(signChartSolution({ ...p, relation: flipped })), intent: 'reversed_interval_sign' },
        { text: formatSignChartIntervals(boundary), intent: p.pole === null ? 'incorrect_root_inclusion' : 'included_denominator_zero' },
        { text: formatSignChartIntervals([{ lower: -Infinity, upper: p.lower, leftClosed: false, rightClosed: false }]), intent: 'ignored_second_critical_boundary' }
    ];
}
function solveSubjectPracticeMathInequalitySignChart(candidate, context = {}) {
    const exactScope = signChartScopeFrom(context.questionPlan), parameters = signChartParametersFrom(candidate.prompt, exactScope, 'zh'), reasonCodes = [];
    if (!parameters)
        reasonCodes.push('inequality_sign_chart_prompt_or_plan_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 67 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('inequality_sign_chart_identity_mismatch');
    for (const lang of ['zh', 'en']) {
        if (!parameters || JSON.stringify(signChartParametersFrom(candidate.localizations?.[lang]?.prompt ?? '', exactScope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('inequality_sign_chart_' + lang + '_prompt_mismatch');
        if (JSON.stringify(candidate.localizations?.[lang]?.options) !== JSON.stringify(candidate.options))
            reasonCodes.push('inequality_sign_chart_' + lang + '_options_mismatch');
    }
    const expectedIntervals = parameters ? signChartSolution(parameters) : null;
    const expectedAnswer = expectedIntervals ? formatSignChartIntervals(expectedIntervals) : null;
    const options = candidate.options ?? [], parsed = options.map(o => parseSignChartIntervals(o.text));
    const keys = parsed.map(p => p ? formatSignChartIntervals(p) : null);
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: !parsed[i] ? 'unknown' : keys[i] === expectedAnswer ? 'true' : 'false' }));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.some(v => v === null) || new Set(keys).size !== 4)
        reasonCodes.push('inequality_sign_chart_invalid_or_duplicate_options');
    const trueOptionIds = optionVerdicts.filter(v => v.verdict === 'true').map(v => v.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('inequality_sign_chart_answer_disagreement');
    const expectedWrong = parameters ? signChartDistractors(parameters).concat(require('../../../../src/intent-proof-v117.cjs').intervals(exactScope,expectedAnswer)) : [], metadata = candidate.optionMetadata ?? [];
    if (metadata.length !== 3 || new Set(metadata.map(m => m.optionId)).size !== 3 || new Set(metadata.map(m => m.distractorIntent)).size !== 3
        || metadata.some(m => {
            const index = options.findIndex(o => o.id === m.optionId);
            return index < 0 || m.optionId === candidate.correctAnswer || !expectedWrong.some(w => w.intent === m.distractorIntent && w.text === keys[index]);
        }))
        reasonCodes.push('inequality_sign_chart_distractor_intent_mismatch');
    const scopeId = parameters ? exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_SCOPE_VERSION + ':' + exactScope : null;
    return { solverVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_SOLVER_VERSION,
        status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: exports.INEQUALITY_SIGN_CHART_FAMILY, scopeId, exactScope, parameters, expectedIntervals, expectedAnswer,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope, reasonCodes: parameters ? [] : ['inequality_sign_chart_scope_not_matched'] },
        optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
