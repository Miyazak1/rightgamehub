"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FUNCTION_INTERVAL_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathFunctionIntervalWithIndependentOracle = verifySubjectPracticeMathFunctionIntervalWithIndependentOracle;
// Intentionally self-contained: no Solver, generator, explanation or answer-helper imports.
exports.FUNCTION_INTERVAL_ORACLE_VERSION = 'math-function-interval-oracle-v1-complete-partitions';
const scopes = ['quadratic_closed_interval_range', 'quadratic_interval_monotonicity', 'radical_fraction_domain_intersection', 'linear_fraction_closed_interval_range'];
const obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function q(n, d = 1) {
    let a = BigInt(n), b = BigInt(d);
    if (!b)
        throw new Error('oracle_denominator_zero');
    if (b < 0n) {
        a = -a;
        b = -b;
    }
    let x = a < 0n ? -a : a, y = b;
    while (y) {
        const r = x % y;
        x = y;
        y = r;
    }
    return [a / x, b / x];
}
const plus = (a, b) => q(a[0] * b[1] + b[0] * a[1], a[1] * b[1]);
const minus = (a, b) => q(a[0] * b[1] - b[0] * a[1], a[1] * b[1]);
const times = (a, b) => q(a[0] * b[0], a[1] * b[1]);
const divide = (a, b) => q(a[0] * b[1], a[1] * b[0]);
const compare = (a, b) => { const t = a[0] * b[1] - b[0] * a[1]; return t < 0n ? -1 : t > 0n ? 1 : 0; };
const show = (a) => String(a[0]) + (a[1] === 1n ? '' : '/' + a[1]);
function edgeCompare(a, b) {
    if (a === b)
        return 0;
    if (a === '-inf' || b === '+inf')
        return -1;
    if (a === '+inf' || b === '-inf')
        return 1;
    return compare(a, b);
}
function parseSet(text) {
    const parts = String(text ?? '').split(/\s+U\s+/), result = [];
    if (parts.length > 2 || !parts.length)
        return null;
    const edge = (s) => {
        s = s.trim();
        if (s === '-inf' || s === '+inf')
            return s;
        if (!/^[+-]?\d{1,6}(?:\/\d{1,6})?$/.test(s))
            return null;
        const ns = s.split('/');
        if (ns[1] && BigInt(ns[1]) === 0n)
            return null;
        const v = q(BigInt(ns[0]), BigInt(ns[1] || '1'));
        return v[0] < -4096n || v[0] > 4096n || v[1] > 256n ? null : v;
    };
    for (const part of parts) {
        const t = part.trim(), first = t[0], last = t[t.length - 1], content = t.slice(1, -1).split(',');
        if (!['[', '('].includes(first) || ![']', ')'].includes(last) || content.length !== 2)
            return null;
        const l = edge(content[0]), r = edge(content[1]), lc = first === '[', rc = last === ']';
        if (!l || !r || edgeCompare(l, r) >= 0 || (typeof l === 'string' && lc) || (typeof r === 'string' && rc))
            return null;
        result.push({ l, r, lc, rc });
    }
    result.sort((a, b) => edgeCompare(a.l, b.l) || Number(b.lc) - Number(a.lc));
    if (result.length === 2) {
        const [a, b] = result, meet = edgeCompare(a.r, b.l), end = edgeCompare(a.r, b.r);
        if (meet > 0 || (meet === 0 && (a.rc || b.lc)))
            return [{ l: a.l, r: end >= 0 ? a.r : b.r, lc: a.lc, rc: end > 0 ? a.rc : end < 0 ? b.rc : a.rc || b.rc }];
    }
    return result;
}
const setKey = (v) => v.map(i => (i.lc ? '[' : '(') + (typeof i.l === 'string' ? i.l : show(i.l)) + ',' + (typeof i.r === 'string' ? i.r : show(i.r)) + (i.rc ? ']' : ')')).join('U');
const contains = (set, x) => set.some(i => {
    const l = edgeCompare(x, i.l), r = edgeCompare(x, i.r);
    return (l > 0 || l === 0 && i.lc) && (r < 0 || r === 0 && i.rc);
});
function readModel(text, scope, lang) {
    if (typeof text !== 'string' || text.length > 1000)
        return null;
    const zh = lang === 'zh', quad = scope.startsWith('quadratic'), radical = scope.startsWith('radical');
    const head = zh ? /^(已知函数 |设函数 )f\(x\)=/ : /^(Given |Consider )f\(x\)=/;
    if (!head.test(text))
        return null;
    let rest = text.replace(head, ''), left = 0, right = 0;
    const suffix = radical ? (zh ? '。求其定义域，需同时考虑根式与分母条件。' : '. Find its domain using both the radicand and denominator conditions.')
        : scope === scopes[1] ? (zh ? ' 上的单调性是？请先求对称轴，再结合区间位置判断。' : '. What is its monotonicity? Find the axis first, then use the interval position.')
            : (zh ? ' 上的值域是？请结合区间内的函数变化及边界值判断。' : '. What is its range? Use its variation within the interval and boundary values.');
    if (!rest.endsWith(suffix))
        return null;
    rest = rest.slice(0, -suffix.length);
    if (!radical) {
        const boundary = rest.match(zh ? /，在闭区间 \[(-?\d+), (-?\d+)\]$/ : / on the closed interval \[(-?\d+), (-?\d+)\]$/);
        if (!boundary)
            return null;
        left = Number(boundary[1]);
        right = Number(boundary[2]);
        rest = rest.slice(0, -boundary[0].length);
        if (![left, right].every(x => Number.isSafeInteger(x) && Math.abs(x) <= 9) || left >= right)
            return null;
    }
    // Tokenise the whitelisted expression separately from the primary parser.
    const tokens = rest.replace(/sqrt\(/g, 'ROOT(').replace(/ /g, '');
    const match = quad ? tokens.match(/^(-?\d+)x\^2([+-]\d+)x([+-]\d+)$/)
        : tokens.match(radical ? /^ROOT\((-?\d+)x([+-]\d+)\)\/\(x([+-]\d+)\)$/ : /^\((-?\d+)x([+-]\d+)\)\/\(x([+-]\d+)\)$/);
    if (!match)
        return null;
    const a = Number(match[1]), b = Number(match[2]), last = Number(match[3]);
    if (![a, b, last].every(Number.isSafeInteger) || a === 0 || Math.abs(a) > 4)
        return null;
    let axis = 0, offset = 0, zero = 0;
    if (quad) {
        const axes = [];
        for (let h = -6; h <= 6; h++)
            if (2 * a * h + b === 0)
                axes.push(h);
        if (axes.length !== 1)
            return null;
        axis = axes[0];
        offset = a * axis * axis + b * axis + last;
        if (Math.abs(offset) > 9)
            return null;
    }
    else if (radical) {
        const zeros = [];
        for (let z = -6; z <= 6; z++)
            if (a * z + b === 0)
                zeros.push(z);
        if (zeros.length !== 1)
            return null;
        zero = zeros[0];
    }
    const pole = quad ? 0 : -last;
    if (!quad && Math.abs(pole) > 9)
        return null;
    if (!quad && !radical && (Math.abs(b) > 12 || a * pole + b === 0 || pole >= left && pole <= right))
        return null;
    return { a, b, c: quad ? last : 0, pole, left, right, axis, zero, offset };
}
function completePartition(boundaries) {
    const b = [...new Map(boundaries.map(x => [show(x), x])).values()].sort(compare);
    const samples = [...b];
    if (!b.length)
        return [q(0)];
    samples.push(minus(b[0], q(1)), plus(b[b.length - 1], q(1)));
    for (let i = 1; i < b.length; i++)
        samples.push(divide(plus(b[i - 1], b[i]), q(2)));
    return samples;
}
function verifySubjectPracticeMathFunctionIntervalWithIndependentOracle(candidate, context = {}) {
    const plan = obj(context.questionPlan), render = obj(plan?.renderConstraints), scenario = obj(plan?.scenarioContract), scope = String(render?.exactFunctionIntervalScope ?? '');
    const required = { topicCode: 'M-FUNC-001', maximumAbsoluteScale: 4, boundedIntegerParameters: true, closedNondegenerateInputInterval: true,
        exactRationalArithmetic: true, externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
    const contract = plan?.schemaVersion === 'subject-practice-question-plan-v1' && plan?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && plan?.subject === 'math' && plan?.topicId === 68 && plan?.targetDifficulty === 'medium' && plan?.representationType === 'text'
        && plan?.taskFamily === 'math_function_interval_property_reasoning' && plan?.planTemplate === 'math_function_interval_property_reasoning_v1'
        && render?.questionType === 'single_choice' && scopes.includes(scope) && Object.entries(required).every(([k, v]) => render?.[k] === v)
        && scenario?.scenarioMode === 'abstract' && scenario?.scenarioEntity === 'function_interval_object' && scenario?.scenarioAction === scope;
    const model = contract ? readModel(candidate.prompt, scope, 'zh') : null, reasonCodes = [];
    if (!model)
        reasonCodes.push('function_interval_oracle_scope_unparsed');
    if (candidate.subject !== 'math' || candidate.topicId !== 68 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('function_interval_oracle_identity_mismatch');
    const mono = scope === scopes[1], options = candidate.options ?? [];
    const labels = { '严格递增': 'increasing', 'strictly increasing': 'increasing', '严格递减': 'decreasing', 'strictly decreasing': 'decreasing',
        '不单调': 'neither', 'not monotonic': 'neither', '常数函数': 'constant', 'constant function': 'constant' };
    const key = (t) => mono ? labels[t] ?? null : (() => { const s = parseSet(t); return s ? setKey(s) : null; })();
    const keys = options.map(o => key(o.text)), sets = options.map(o => parseSet(o.text));
    if (options.length !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || new Set(options.map(o => o.id)).size !== 4 || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('function_interval_oracle_option_invalid');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!model || JSON.stringify(readModel(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(model))
            reasonCodes.push('function_interval_oracle_' + lang + '_parameters');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, key(o.text)])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('function_interval_oracle_' + lang + '_options');
    }
    let truths = options.map(() => false), boundaryEvidence = [], certificate = '';
    if (model) {
        const m = model;
        if (mono) {
            // The affine factor has fixed sign on each side of the unique axis.
            const allPositive = m.a > 0 ? m.left >= m.axis : m.right <= m.axis;
            const allNegative = m.a > 0 ? m.right <= m.axis : m.left >= m.axis;
            const result = allPositive ? 'increasing' : allNegative ? 'decreasing' : 'neither';
            truths = keys.map(k => k === result);
            certificate = 'unique_bounded_axis_and_exact_difference_identity_on_entire_interval';
        }
        else {
            let boundaries = [], predicate;
            if (scope === scopes[0]) {
                const split = [m.left, m.right];
                if (m.axis > m.left && m.axis < m.right)
                    split.push(m.axis);
                const values = split.map(x => q(m.a * x * x + m.b * x + m.c)).sort(compare), lo = values[0], hi = values[values.length - 1];
                boundaries = [lo, hi];
                predicate = y => compare(y, lo) >= 0 && compare(y, hi) <= 0;
                certificate = 'complete_axis_partition_certified_by_fv_minus_fu_difference_identity_and_continuity';
            }
            else if (scope === scopes[2]) {
                boundaries = [q(m.zero), q(m.pole)];
                predicate = x => compare(plus(times(q(m.a), x), q(m.b)), q(0)) >= 0 && compare(x, q(m.pole)) !== 0;
                certificate = 'complete_linear_predicate_partition_including_zero_pole_and_all_option_boundaries';
            }
            else {
                const at = (x) => q(m.a * x + m.b, x - m.pole);
                boundaries = [q(m.a), at(m.left), at(m.right)];
                predicate = y => {
                    if (compare(y, q(m.a)) === 0)
                        return false;
                    const x = divide(plus(q(m.b), times(y, q(m.pole))), minus(y, q(m.a)));
                    return compare(x, q(m.left)) >= 0 && compare(x, q(m.right)) <= 0 && compare(x, q(m.pole)) !== 0;
                };
                certificate = 'complete_inverse_preimage_partition_y_equals_a_excluded_by_nonzero_determinant';
            }
            for (const s of sets)
                for (const i of s ?? [])
                    for (const e of [i.l, i.r])
                        if (typeof e !== 'string')
                            boundaries.push(e);
            const probes = completePartition(boundaries);
            boundaryEvidence = [...new Set(boundaries.map(show))];
            truths = sets.map(s => Boolean(s) && probes.every(x => contains(s, x) === predicate(x)));
        }
    }
    const trueOptionIds = options.filter((_, i) => truths[i]).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('function_interval_oracle_answer_disagreement');
    return { oracleVersion: exports.FUNCTION_INTERVAL_ORACLE_VERSION, status: reasonCodes.length ? (model ? 'disagreed' : 'unparsed') : 'verified',
        scopeMatched: Boolean(model), scopeId: model ? 'math-medium-function-interval-v1:' + scope : null, exactScope: scope, selectedOptionId, trueOptionIds,
        uniqueAnswer: trueOptionIds.length === 1, completePartition: Boolean(model), boundaryEvidence, certificate,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
