"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMPOUND_INEQUALITY_EXPLANATION_VERSION = void 0;
exports.renderCompoundInequalityExplanation = renderCompoundInequalityExplanation;
exports.verifySubjectPracticeMathCompoundInequalityExplanation = verifySubjectPracticeMathCompoundInequalityExplanation;
const subject_practice_math_compound_inequality_solver_1 = require("./subject-practice-math-compound-inequality-solver.lab117.js");
exports.COMPOUND_INEQUALITY_EXPLANATION_VERSION = 'math-compound-inequality-explanation-v1-bound-bilingual';
function renderCompoundInequalityExplanation(p, answer, option) {
    const d = (0, subject_practice_math_compound_inequality_solver_1.compoundInequalityDerive)(p);
    if (!d || d.answer !== answer)
        throw new Error('compound_explanation_invalid_input');
    const witnesses = d.hardEvidence.effectiveConstraints.map((c, j) => 'constraint' + (j + 1) + ' relaxed=' + c.relaxedSet + ', changed=' + c.witnessSet).join('; ');
    const variable = p.T ? 't' : 'x';
    return { zh: '先按零点与分母零点求不等式解集，保留定义域和端点开闭，再组合全部条件。' + (p.T ? '对S中每个x成立的条件必须覆盖整个S，开端点不能当作已经取到。' : '绝对值条件按左右分支处理，交集不能换成并集。') + d.proof + '。约束不可省略：' + witnesses + '。因此' + variable + '属于' + answer + '，选' + option + '。',
        en: 'Solve the inequalities using zeros and poles, preserve the domain and endpoint inclusion, then combine every condition. ' + (p.T ? 'The condition for every x must hold throughout S; an open endpoint is not attained. ' : 'Split absolute-value conditions into left and right branches; use intersection, not union. ') + d.proof + '. Removing a constraint changes the answer: ' + witnesses + '. Thus ' + variable + ' belongs to ' + answer + '; choose ' + option + '.' };
}
function verifySubjectPracticeMathCompoundInequalityExplanation(candidate, context = {}) {
    const s = (0, subject_practice_math_compound_inequality_solver_1.solveSubjectPracticeMathCompoundInequality)(candidate, context), e = s.status === 'verified' && s.parameters && s.expectedAnswer && s.selectedOptionId ? renderCompoundInequalityExplanation(s.parameters, s.expectedAnswer, s.selectedOptionId) : null;
    const zhBound = !!e && candidate.explanation === e.zh && candidate.localizations?.zh?.explanation === e.zh, enBound = !!e && candidate.localizations?.en?.explanation === e.en, reasonCodes = zhBound && enBound ? [] : ['compound_inequality_explanation_not_bound'];
    return { verifierVersion: exports.COMPOUND_INEQUALITY_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: s.scopeId, zhBound, enBound, hardEvidence: s.hardEvidence, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
