"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_CHEMISTRY_ACID_BASE_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeChemistryAcidBaseExplanation = verifySubjectPracticeChemistryAcidBaseExplanation;
const subject_practice_chemistry_acid_base_solver_1 = require("./subject-practice-chemistry-acid-base-solver");
exports.SUBJECT_PRACTICE_CHEMISTRY_ACID_BASE_EXPLANATION_VERIFIER_VERSION = 'chemistry-acid-base-explanation-verifier-v2-natural-symbolic-chain';
function normalized(value) {
    return String(value ?? '')
        .replace(/[−－]/g, '-')
        .replace(/[＝]/g, '=')
        .replace(/[×·]/g, '*')
        .replace(/[₂₁]/g, (token) => token === '₂' ? '2' : '1')
        .replace(/\s+/g, '')
        .toLowerCase()
        .trim();
}
function sameNumber(left, right) {
    return Math.abs(left - right) <= 0.011;
}
function promptInputNumbers(prompt) {
    const values = [];
    const pattern = /([0-9]+(?:\.[0-9]+)?)\s*(?:mol\s*\/\s*l|ml|l)(?![a-z])/gi;
    for (const match of prompt.matchAll(pattern))
        values.push(String(Number(match[1])));
    return Array.from(new Set(values));
}
function containsNumber(text, value) {
    const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(^|[^0-9.])${escaped}(?![0-9.])`).test(text);
}
function lastDerivedNumber(text) {
    const matches = Array.from(text.matchAll(/=([+-]?\d+(?:\.\d+)?)/g));
    const value = matches.at(-1)?.[1];
    return value === undefined ? null : Number(value);
}
function expectedCharacterToken(language, character) {
    if (language === 'zh')
        return character === 'acidic' ? '酸性' : character === 'basic' ? '碱性' : '中性';
    return character === 'acidic' ? 'solutionisacidic' : character === 'basic' ? 'solutionisbasic' : 'solutionisneutral';
}
function relationDerivationMatched(text, evidence) {
    const logarithm = text.includes('lg[') || text.includes('log[');
    const completeDissociation = text.includes('完全电离') || (text.includes('complete') && text.includes('dissociat'));
    if (evidence.relationKind === 'strong_acid_dilution') {
        return (text.includes('c2=c1v1/v2') || text.includes('c₂=c₁v₁/v₂'))
            && completeDissociation
            && (text.includes('[h+]=c2') || text.includes('[h+]=') || text.includes('[h⁺]='))
            && text.includes('ph=-')
            && logarithm;
    }
    if (evidence.relationKind === 'strong_base_dilution') {
        return text.includes('c2=c1v1/v2')
            && completeDissociation
            && text.includes('[oh-]=c2')
            && text.includes('poh=-')
            && logarithm
            && text.includes('ph=14-poh');
    }
    if (evidence.relationKind === 'strong_acid_base_neutralization') {
        const common = text.includes('n(h+)=')
            && text.includes('n(oh-)=')
            && (text.includes('过量') || text.includes('excess'))
            && text.includes('c=');
        if (evidence.expectedCharacter === 'acidic')
            return common && text.includes('ph=-') && logarithm;
        if (evidence.expectedCharacter === 'basic')
            return common && text.includes('poh=-') && logarithm && text.includes('ph=14-poh');
        return false;
    }
    return false;
}
function checkExplanation(input) {
    const text = normalized(input.text);
    const conclusionPh = lastDerivedNumber(text);
    const temperatureConventionPresent = text.includes('25°c');
    const derivationMatched = relationDerivationMatched(text, input.evidence);
    const inputsCovered = promptInputNumbers(input.prompt).every((value) => containsNumber(text, value));
    const conclusionMatched = input.evidence.expectedPh !== null
        && conclusionPh !== null
        && sameNumber(conclusionPh, input.evidence.expectedPh);
    const answerTargetConclusionMatched = input.evidence.answerTarget !== 'acid_base_character'
        || text.includes(expectedCharacterToken(input.language, input.evidence.expectedCharacter));
    const reasonCodes = [];
    if (!temperatureConventionPresent)
        reasonCodes.push(`chemistry_explanation_${input.language}_temperature_convention_missing`);
    if (!derivationMatched)
        reasonCodes.push(`chemistry_explanation_${input.language}_relation_derivation_missing_or_wrong`);
    if (!inputsCovered)
        reasonCodes.push(`chemistry_explanation_${input.language}_prompt_input_missing`);
    if (!conclusionMatched)
        reasonCodes.push(`chemistry_explanation_${input.language}_ph_conclusion_mismatch`);
    if (!answerTargetConclusionMatched)
        reasonCodes.push(`chemistry_explanation_${input.language}_answer_target_conclusion_missing_or_wrong`);
    return {
        language: input.language,
        temperatureConventionPresent,
        relationDerivationMatched: derivationMatched,
        promptInputsCovered: inputsCovered,
        conclusionMatched,
        answerTargetConclusionMatched,
        conclusionPh,
        reasonCodes
    };
}
function verifySubjectPracticeChemistryAcidBaseExplanation(candidate, context = {}) {
    const solverEvidence = (0, subject_practice_chemistry_acid_base_solver_1.solveSubjectPracticeChemistryAcidBase)(candidate, context);
    const english = candidate.localizations?.en;
    const checks = [
        checkExplanation({ language: 'zh', text: candidate.explanation, prompt: candidate.prompt, evidence: solverEvidence }),
        checkExplanation({
            language: 'en', text: english?.explanation ?? '', prompt: english?.prompt ?? candidate.prompt, evidence: solverEvidence
        })
    ];
    const reasonCodes = checks.flatMap((check) => check.reasonCodes);
    if (solverEvidence.status !== 'verified' || !solverEvidence.verificationScope.matched) {
        reasonCodes.unshift('chemistry_explanation_answer_recomputation_not_verified');
    }
    return {
        verifierVersion: exports.SUBJECT_PRACTICE_CHEMISTRY_ACID_BASE_EXPLANATION_VERIFIER_VERSION,
        status: solverEvidence.status === 'unparsed' ? 'unparsed' : reasonCodes.length === 0 ? 'verified' : 'failed',
        solverEvidence,
        recomputedWithoutGeneratorExplanation: true,
        formulaInputsUnitsAndConclusionChecked: true,
        chemistryAssumptionsChecked: true,
        checks,
        mismatchCount: reasonCodes.length,
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes: Array.from(new Set(reasonCodes))
    };
}
