"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_PROBABILITY_SOLVER_VERSION = void 0;
exports.rational = rational;
exports.probabilityParametersFrom = probabilityParametersFrom;
exports.solveSubjectPracticeMathProbability = solveSubjectPracticeMathProbability;
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_SOLVER_VERSION = 'math-probability-solver-v1-exact-rational';
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_SCOPE_VERSION = 'math-probability-scope-v1';
const SCOPES = new Set(['colored_objects_single_draw', 'uniform_integer_event', 'single_die_event', 'two_coin_outcome_event']);
function record(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/[，]/g, ',').replace(/\s+/g, ' ').trim(); }
function gcd(a, b) { let x = Math.abs(a), y = Math.abs(b); while (y) {
    const t = x % y;
    x = y;
    y = t;
} return x || 1; }
function rational(numerator, denominator) { const sign = denominator < 0 ? -1 : 1, g = gcd(numerator, denominator); return { numerator: sign * numerator / g, denominator: Math.abs(denominator) / g }; }
function scopeFrom(context) { const p = record(context.questionPlan), r = record(p?.renderConstraints), s = clean(r?.exactProbabilityScope); return clean(p?.taskFamily) === 'math_classical_probability_basic_calculation' && clean(p?.planTemplate) === 'math_classical_probability_basic_calculation_v1' && SCOPES.has(s) ? s : null; }
function integerAfter(text, label) { const m = clean(text).match(new RegExp(`(?:^|[^A-Z])${label}\\s*=\\s*(\\d+)`, 'i')); return m ? Number(m[1]) : null; }
function probabilityParametersFrom(prompt, scope) { if (!scope)
    return null; const t = clean(prompt); if (scope === 'colored_objects_single_draw') {
    const red = integerAfter(t, 'R'), blue = integerAfter(t, 'B');
    return red && blue ? { red, blue, favorable: red, total: red + blue } : null;
} if (scope === 'uniform_integer_event') {
    const n = integerAfter(t, 'N'), k = integerAfter(t, 'K');
    return n && k && k > 1 ? { n, k, favorable: Math.floor(n / k), total: n } : null;
} if (scope === 'single_die_event') {
    const threshold = integerAfter(t, 'T');
    return threshold && threshold >= 1 && threshold < 6 ? { threshold, favorable: 6 - threshold, total: 6 } : null;
} const heads = integerAfter(t, 'H'); return heads !== null && heads >= 0 && heads <= 2 ? { heads, favorable: heads === 1 ? 2 : 1, total: 4 } : null; }
function parseRational(text) { const t = clean(text).replace(/\s/g, ''); const m = t.match(/^(-?\d+)(?:\/(\d+))?$/); return m ? rational(Number(m[1]), m[2] ? Number(m[2]) : 1) : null; }
function same(a, b) { return Boolean(a && b && a.numerator === b.numerator && a.denominator === b.denominator); }
function solveSubjectPracticeMathProbability(candidate, context = {}) { const exactScope = scopeFrom(context), parameters = probabilityParametersFrom(candidate.prompt, exactScope), parsed = Boolean(exactScope && parameters), expectedValue = parameters ? rational(parameters.favorable, parameters.total) : null; const optionVerdicts = (candidate.options ?? []).map(o => { const value = parseRational(o.text); return { optionId: o.id, verdict: !value ? 'unknown' : same(value, expectedValue) ? 'true' : 'false', semanticValue: value }; }); const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null, reasonCodes = []; if (!exactScope)
    reasonCodes.push('math_probability_scope_plan_contract_missing'); if (!parameters)
    reasonCodes.push('math_probability_prompt_unparsed'); if (optionVerdicts.some(x => x.verdict === 'unknown'))
    reasonCodes.push('math_probability_option_unparsed'); if (trueOptionIds.length !== 1)
    reasonCodes.push(trueOptionIds.length ? 'math_probability_multiple_true_options' : 'math_probability_no_true_option'); if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('math_probability_generator_disagreement'); const scopeId = parsed ? `math-basic-probability-v1:${exactScope}` : null; return { solverVersion: exports.SUBJECT_PRACTICE_MATH_PROBABILITY_SOLVER_VERSION, status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified', taskFamily: 'math_classical_probability_basic_calculation', scopeId, exactScope, parameters, expectedValue, verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_PROBABILITY_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['math_probability_verification_scope_not_matched'] }, optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
