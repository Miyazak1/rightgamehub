"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FUNCTION_INTERVAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathFunctionIntervalLocalGenerator = createSubjectPracticeMathFunctionIntervalLocalGenerator;
const subject_practice_math_function_interval_solver_1 = require("./subject-practice-math-function-interval-solver");
const subject_practice_math_function_interval_independent_oracle_1 = require("./subject-practice-math-function-interval-independent-oracle");
const subject_practice_math_function_interval_explanation_verifier_1 = require("./subject-practice-math-function-interval-explanation-verifier");
exports.FUNCTION_INTERVAL_GENERATOR_VERSION = 'math-function-interval-generator-v1-bounded';
function parameters(scope, seed) {
    const sign = seed % 2 ? -1 : 1;
    if (scope.startsWith('quadratic')) {
        const a = sign * (1 + Math.floor(seed / 10) % 4), h = Math.floor(seed / 10) % 7 - 3, k = Math.floor(seed / 70) % 19 - 9;
        const intervals = [[h - 4, h - 1], [h + 1, h + 4], [h - 2, h + 3], [h, h + 3], [h - 3, h]];
        const [l, r] = intervals[Math.floor(seed / 2) % 5];
        return { scope, a, b: -2 * a * h, c: a * h * h + k, h, k, z: 0, p: 0, l, r };
    }
    if (scope.startsWith('radical')) {
        const a = sign * (1 + Math.floor(seed / 6) % 4), z = Math.floor(seed / 24) % 7 - 3, mode = Math.floor(seed / 2) % 3;
        const p = z + (mode === 0 ? 0 : mode === 1 ? sign * 2 : -sign * 2);
        return { scope, a, b: -a * z, c: 0, h: 0, k: 0, z, p, l: 0, r: 0 };
    }
    const a = sign * (1 + Math.floor(seed / 4) % 4), l = -4 + Math.floor(seed / 64) % 5, r = l + 1 + Math.floor(seed / 2) % 3;
    const p = Math.floor(seed / 2) % 2 ? l - 2 : r + 2;
    let b = -12 + Math.floor(seed / 16) % 25;
    if (a * p + b === 0)
        b = b === 12 ? b - 1 : b + 1;
    return { scope, a, b, c: 0, h: 0, k: 0, z: 0, p, l, r };
}
function createSubjectPracticeMathFunctionIntervalLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0;
        const exactScope = (0, subject_practice_math_function_interval_solver_1.functionIntervalScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.FUNCTION_INTERVAL_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call',
            estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null,
            oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['function_interval_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 68
            || b.topicCode !== 'M-FUNC-001' || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        const p = parameters(exactScope, seed), answer = (0, subject_practice_math_function_interval_solver_1.functionIntervalAnswer)(p), choices = (0, subject_practice_math_function_interval_solver_1.functionIntervalDistractors)(p);
        const correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
        if (new Set(choices.map(x => x.key)).size !== 4)
            return { ...unsupported, status: 'bounded_generation_exhausted' };
        const optionText = (key, en) => exactScope === 'quadratic_interval_monotonicity'
            ? subject_practice_math_function_interval_solver_1.FUNCTION_MONOTONICITY_LABELS[key][en ? 1 : 0] : key;
        const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: optionText(x.key, false) }));
        const enOptions = choices.map((x, i) => ({ id: 'ABCD'[i], text: optionText(x.key, true) }));
        const alternate = Math.floor(seed / 16) % 2 === 1, prompt = (0, subject_practice_math_function_interval_solver_1.functionIntervalPrompt)(p, 'zh', alternate), enPrompt = (0, subject_practice_math_function_interval_solver_1.functionIntervalPrompt)(p, 'en', alternate);
        const explanation = (0, subject_practice_math_function_interval_explanation_verifier_1.renderFunctionIntervalExplanation)(p, answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 68, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium',
            questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['函数的概念与性质', exactScope],
            optionMetadata: choices.flatMap((x, i) => x.intent ? [{ optionId: 'ABCD'[i], distractorIntent: x.intent, misconceptionTags: [x.intent] }] : []),
            localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['函数性质', exactScope] },
                en: { prompt: enPrompt, options: enOptions, explanation: explanation.en, knowledgeTags: ['Function properties', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_function_interval_solver_1.solveSubjectPracticeMathFunctionInterval)(candidate, context);
        const oracleEvidence = (0, subject_practice_math_function_interval_independent_oracle_1.verifySubjectPracticeMathFunctionIntervalWithIndependentOracle)(candidate, context);
        const explanationEvidence = (0, subject_practice_math_function_interval_explanation_verifier_1.verifySubjectPracticeMathFunctionIntervalExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres
            && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null,
            solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
            reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
