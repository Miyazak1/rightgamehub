"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROBABILITY_TWO_STAGE_CONSTRAINTS = exports.PROBABILITY_TWO_STAGE_SCOPES = exports.PROBABILITY_TWO_STAGE_SCOPE_VERSION = exports.PROBABILITY_TWO_STAGE_SOLVER_VERSION = exports.PROBABILITY_TWO_STAGE_TEMPLATE = exports.PROBABILITY_TWO_STAGE_FAMILY = void 0;
exports.probabilityTwoStageScopeFrom = probabilityTwoStageScopeFrom;
exports.probabilityTwoStageFraction = probabilityTwoStageFraction;
exports.probabilityTwoStageOptionKey = probabilityTwoStageOptionKey;
exports.probabilityTwoStagePrompt = probabilityTwoStagePrompt;
exports.probabilityTwoStageParametersFrom = probabilityTwoStageParametersFrom;
exports.probabilityTwoStageDerive = probabilityTwoStageDerive;
exports.probabilityTwoStageDistractors = probabilityTwoStageDistractors;
exports.solveSubjectPracticeMathProbabilityTwoStage = solveSubjectPracticeMathProbabilityTwoStage;
exports.PROBABILITY_TWO_STAGE_FAMILY = 'math_classical_probability_two_stage_calculation';
exports.PROBABILITY_TWO_STAGE_TEMPLATE = exports.PROBABILITY_TWO_STAGE_FAMILY + '_v1';
exports.PROBABILITY_TWO_STAGE_SOLVER_VERSION = 'math-probability-two-stage-solver-v1-exact-rational';
exports.PROBABILITY_TWO_STAGE_SCOPE_VERSION = 'math-medium-probability-two-stage-v1';
exports.PROBABILITY_TWO_STAGE_SCOPES = ['without_replacement_both_target', 'without_replacement_one_of_each',
    'independent_two_boxes_both_target', 'independent_two_boxes_at_least_one_target'];
exports.PROBABILITY_TWO_STAGE_CONSTRAINTS = {
    topicCode: 'M-PROB-001', boundedIntegerParameters: true, minimumColourCount: 2, maximumColourCount: 12,
    exactRationalArithmetic: true, completeLabelledSampleSpaceCertificate: true, drawCountExactly: 2,
    externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2
};
const record = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
function probabilityTwoStageScopeFrom(value) {
    const p = record(value), r = record(p?.renderConstraints), s = record(p?.scenarioContract);
    const scope = r?.exactProbabilityTwoStageScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 75 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === exports.PROBABILITY_TWO_STAGE_FAMILY && p?.planTemplate === exports.PROBABILITY_TWO_STAGE_TEMPLATE
        && r?.questionType === 'single_choice' && Object.entries(exports.PROBABILITY_TWO_STAGE_CONSTRAINTS).every(([k, v]) => r?.[k] === v)
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'finite_two_stage_probability_experiment' && s?.scenarioAction === scope
        && exports.PROBABILITY_TWO_STAGE_SCOPES.includes(scope) ? scope : null;
}
function probabilityTwoStageFraction(n, d) {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || d <= 0 || n < 0 || n > d)
        return null;
    let a = n, b = d;
    while (b) {
        const t = a % b;
        a = b;
        b = t;
    }
    return d / a === 1 ? String(n / a) : `${n / a}/${d / a}`;
}
function probabilityTwoStageOptionKey(text, _scope) {
    if (typeof text !== 'string')
        return null;
    const m = text.trim().match(/^(0|[1-9]\d{0,5})(?:\/([1-9]\d{0,5}))?$/);
    return m ? probabilityTwoStageFraction(Number(m[1]), Number(m[2] ?? 1)) : null;
}
const prefixes = {
    zh: ['进行如下等可能抽取实验。', '考察下面的随机抽取过程。', '一次抽取实验按下列规则进行。', '按以下规则进行两次抽取。'],
    en: ['Consider this uniform sampling experiment. ', 'Examine the following random selection process. ', 'An experiment follows the rules below. ', 'Carry out two draws according to these rules. ']
};
function probabilityTwoStagePrompt(p, lang) {
    const [r, b, u, v] = p.values, index = exports.PROBABILITY_TWO_STAGE_SCOPES.indexOf(p.scope), prefix = prefixes[lang][p.variant] ?? '';
    if (index < 2)
        return prefix + (lang === 'zh'
            ? `一个盒中有 R=${r} 个红球和 B=${b} 个蓝球；每个球都有不同编号。依次抽取两个球，每次从剩余球中等可能抽取一个，不放回。求${index === 0 ? '两个球都是红球' : '恰好一个红球、一个蓝球（不计先后）'}的概率。`
            : `One box contains R=${r} red balls and B=${b} blue balls; every ball has a distinct label. Draw two balls successively, each time uniformly from the remaining balls, without replacement. Find the probability of ${index === 0 ? 'both balls being red' : 'exactly one red and one blue ball, in either order'}.`);
    return prefix + (lang === 'zh'
        ? `甲盒有 R1=${r} 个红球和 B1=${b} 个蓝球，乙盒有 R2=${u} 个红球和 B2=${v} 个蓝球；每个球都有不同编号。从每盒各等可能抽取一个球，两盒的抽取相互独立。求${index === 2 ? '两个球都是红球' : '至少一个球是红球（包括两个都是红球）'}的概率。`
        : `Box I contains R1=${r} red balls and B1=${b} blue balls; box II contains R2=${u} red balls and B2=${v} blue balls. Every ball has a distinct label. Draw one ball uniformly from each box; the two selections are independent. Find the probability of ${index === 2 ? 'both balls being red' : 'at least one red ball, including the case of two red balls'}.`);
}
function probabilityTwoStageParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1000)
        return null;
    const variant = prefixes[lang].findIndex(prefix => text.startsWith(prefix));
    const values = [...text.matchAll(/(?:R1|B1|R2|B2|R|B)=(\d+)/g)].map(m => Number(m[1]));
    const p = { scope, values, variant };
    return text === probabilityTwoStagePrompt(p, lang) && probabilityTwoStageDerive(p) ? p : null;
}
function probabilityTwoStageDerive(p) {
    const i = exports.PROBABILITY_TWO_STAGE_SCOPES.indexOf(p.scope), [r, b, u, v] = p.values, n = r + b, m = u + v;
    if (i < 0 || !Number.isInteger(p.variant) || p.variant < 0 || p.variant > 3 || p.values.length !== (i < 2 ? 2 : 4)
        || !p.values.every(x => Number.isInteger(x) && x >= 2 && x <= 12))
        return null;
    const numerator = i === 0 ? r * (r - 1) : i === 1 ? 2 * r * b : i === 2 ? r * u : n * m - b * v, denominator = i < 2 ? n * (n - 1) : n * m;
    const answer = probabilityTwoStageFraction(numerator, denominator);
    if (!answer || numerator <= 0 || numerator >= denominator)
        return null;
    const proof = i === 0 ? `N=${r}+${b}=${n}; P(first red)=${r}/${n}; P(second red after first red)=${r - 1}/${n - 1}; P=(${r}/${n})*(${r - 1}/${n - 1})=${numerator}/${denominator}=${answer}`
        : i === 1 ? `N=${r}+${b}=${n}; P(red then blue)=(${r}/${n})*(${b}/${n - 1})=${r * b}/${denominator}; P(blue then red)=(${b}/${n})*(${r}/${n - 1})=${b * r}/${denominator}; P=(${r * b}+${b * r})/${denominator}=${answer}`
            : i === 2 ? `N1=${r}+${b}=${n}; N2=${u}+${v}=${m}; P(red from I)=${r}/${n}; P(red from II)=${u}/${m}; P=(${r}/${n})*(${u}/${m})=${numerator}/${denominator}=${answer}`
                : `N1=${r}+${b}=${n}; N2=${u}+${v}=${m}; P(no red)=(${b}/${n})*(${v}/${m})=${b * v}/${denominator}; P(at least one red)=1-${b * v}/${denominator}=${numerator}/${denominator}=${answer}`;
    return { answer, proof, numerator, denominator };
}
function probabilityTwoStageDistractors(p) {
    const d = probabilityTwoStageDerive(p);
    if (!d)
        return [];
    const [r, b, u, v] = p.values, n = r + b, m = u + v, i = exports.PROBABILITY_TWO_STAGE_SCOPES.indexOf(p.scope);
    const raw = i === 0 ? [
        [r * r, n * n, 'assume_replacement'], [r * r, n * (n - 1), 'forget_red_count_decrement'], [r * (r - 1), n * n, 'forget_total_decrement'], [b * (b - 1), n * (n - 1), 'target_blue_instead']
    ]
        : i === 1 ? [[r * b, n * (n - 1), 'count_only_one_order'], [2 * r * b, n * n, 'assume_replacement'], [r * (r - 1), n * (n - 1), 'require_both_red'], [b * (b - 1), n * (n - 1), 'require_both_blue']]
            : i === 2 ? [[r, n, 'ignore_second_box'], [u, m, 'ignore_first_box'], [b * v, n * m, 'require_both_blue'], [r * v, n * m, 'require_red_then_blue'], [n * m - b * v, n * m, 'use_at_least_one']]
                : [[r * u, n * m, 'require_both_red'], [r * v + b * u, n * m, 'exclude_both_red'], [b * v, n * m, 'use_no_red'], [r, n, 'ignore_second_box'], [u, m, 'ignore_first_box']];
    const seen = new Set([d.answer]);
    return raw.flatMap(([a, z, intent]) => { const key = probabilityTwoStageFraction(a, z); if (key === null || seen.has(key))
        return []; seen.add(key); return [{ key, intent }]; }).slice(0, 3);
}
function solveSubjectPracticeMathProbabilityTwoStage(candidate, context = {}) {
    const scope = probabilityTwoStageScopeFrom(context.questionPlan), parameters = probabilityTwoStageParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? probabilityTwoStageDerive(parameters) : null, reasonCodes = [];
    if (!scope || !parameters || !d)
        reasonCodes.push('probability_two_stage_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 75 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('probability_two_stage_identity');
    const options = candidate.options ?? [], keys = options.map(o => probabilityTwoStageOptionKey(o.text)), expectedKey = d?.answer ?? null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('probability_two_stage_invalid_or_duplicate_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(probabilityTwoStageParametersFrom(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('probability_two_stage_' + lang + '_prompt');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, probabilityTwoStageOptionKey(o.text)])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('probability_two_stage_' + lang + '_options');
    }
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : expectedKey !== null && keys[i] === expectedKey ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('probability_two_stage_answer');
    const wrong = parameters ? probabilityTwoStageDistractors(parameters) : [], meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId
        || !wrong.some(w => w.intent === m.distractorIntent && w.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('probability_two_stage_error_intent');
    const scopeId = parameters ? exports.PROBABILITY_TWO_STAGE_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.PROBABILITY_TWO_STAGE_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: exports.PROBABILITY_TWO_STAGE_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expectedKey, proof: d?.proof ?? null, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.PROBABILITY_TWO_STAGE_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope: scope, reasonCodes: parameters ? [] : ['probability_two_stage_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
