"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_SOLVER_VERSION = void 0;
exports.evaluateMathSetComposite = evaluateMathSetComposite;
exports.solveSubjectPracticeMathSetComposite = solveSubjectPracticeMathSetComposite;
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_SOLVER_VERSION = 'math-set-composite-solver-v1';
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_SCOPE_VERSION = 'math-set-composite-scope-v1';
const SCOPES = new Set([
    'union_then_intersection', 'intersection_then_union',
    'difference_then_intersection', 'complement_then_union'
]);
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').replace(/[，]/g, ',').replace(/\s+/g, ' ').trim(); }
function scopeFrom(context) {
    const plan = record(context.questionPlan);
    const render = record(plan?.renderConstraints);
    const value = clean(render?.exactSetCompositeScope);
    return clean(plan?.taskFamily) === 'math_finite_set_composite_operation'
        && clean(plan?.planTemplate) === 'math_finite_set_composite_operation_v1'
        && SCOPES.has(value) ? value : null;
}
function parseSet(text) {
    const match = clean(text).match(/\{([^{}]*)\}/);
    if (!match)
        return null;
    if (!match[1].trim())
        return [];
    const values = match[1].split(',').map((part) => Number(part.trim()));
    return values.every(Number.isInteger) ? [...new Set(values)].sort((a, b) => a - b) : null;
}
function namedSet(prompt, name) {
    const match = clean(prompt).match(new RegExp(`${name}\\s*=\\s*(\\{[^{}]*\\})`, 'i'));
    return match ? parseSet(match[1]) : null;
}
function union(a, b) { return [...new Set([...a, ...b])].sort((x, y) => x - y); }
function intersection(a, b) { const B = new Set(b); return a.filter((x) => B.has(x)); }
function difference(a, b) { const B = new Set(b); return a.filter((x) => !B.has(x)); }
function evaluateMathSetComposite(scope, u, a, b, c) {
    if (scope === 'union_then_intersection')
        return intersection(union(a, b), c);
    if (scope === 'intersection_then_union')
        return union(intersection(a, b), c);
    if (scope === 'difference_then_intersection')
        return intersection(difference(a, b), c);
    return union(difference(u, a), b);
}
function same(left, right) { return Boolean(left && left.length === right.length && left.every((v, i) => v === right[i])); }
function solveSubjectPracticeMathSetComposite(candidate, context = {}) {
    const scope = scopeFrom(context);
    const prompt = clean(candidate.prompt);
    const u = namedSet(prompt, 'U');
    const a = namedSet(prompt, 'A');
    const b = namedSet(prompt, 'B');
    const c = namedSet(prompt, 'C');
    const parsed = Boolean(scope && u && a && b && (scope === 'complement_then_union' || c));
    const target = parsed ? evaluateMathSetComposite(scope, u, a, b, c ?? []) : [];
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const value = parseSet(option.text);
        const truth = parsed && same(value, target);
        return { optionId: option.id, verdict: value ? (truth ? 'true' : 'false') : 'unknown', semanticValue: value };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const agreesWithGenerator = selectedOptionId === candidate.correctAnswer;
    const reasonCodes = [];
    if (!scope)
        reasonCodes.push('math_set_composite_scope_plan_contract_missing');
    if (!parsed)
        reasonCodes.push('math_set_composite_prompt_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_set_composite_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length ? 'math_set_composite_multiple_true_options' : 'math_set_composite_no_true_option');
    if (selectedOptionId && !agreesWithGenerator)
        reasonCodes.push('math_set_composite_generator_disagreement');
    const scopeId = parsed ? `math-medium-set-composite-v1:${scope}` : null;
    return {
        solverVersion: exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_SOLVER_VERSION,
        status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_finite_set_composite_operation',
        scopeId, exactScope: scope,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_SCOPE_VERSION, scopeId, matched: parsed, exactScope: scope, reasonCodes: parsed ? [] : ['math_set_composite_verification_scope_not_matched'] },
        optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1,
        agreesWithGenerator, expectedSet: target,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
