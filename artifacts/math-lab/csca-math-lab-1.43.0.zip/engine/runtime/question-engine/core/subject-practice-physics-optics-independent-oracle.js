"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticePhysicsOpticsWithIndependentOracle = verifySubjectPracticePhysicsOpticsWithIndependentOracle;
exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_INDEPENDENT_ORACLE_VERSION = 'physics-optics-independent-oracle-v1';
function compact(value) { return String(value ?? '').replace(/[＝]/g, '=').replace(/\s+/g, '').toLowerCase(); }
function recordFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function close(a, b) { return Math.abs(a - b) <= 1e-6; }
function numberAfter(source, pattern) {
    const match = source.match(pattern);
    return match ? Number(match[1]) : null;
}
function parsePrompt(prompt) {
    const source = compact(prompt);
    if (/凸透镜|convexlens/.test(source)) {
        const f = numberAfter(source, /(?:焦距|focallength)(?:为|是|is)?(\d+(?:\.\d+)?)cm/);
        const u = numberAfter(source, /(?:物距|objectdistance)(?:为|是|is)?(\d+(?:\.\d+)?)cm/);
        if (f === null || u === null || f <= 0 || u <= f)
            return null;
        const v = 1 / (1 / f - 1 / u);
        if (/放大率|magnification/.test(source)) {
            return { scope: 'convex_lens_magnification', imageDistance: v, magnification: v / u };
        }
        if (/像距|imagedistance/.test(source) && /像的性质|imagenature|imageproperty|natureoftheimage/.test(source)) {
            const imageScale = close(u, 2 * f) ? 'same_size' : u > 2 * f ? 'diminished' : 'enlarged';
            return { scope: 'convex_lens_image_distance_and_nature', imageDistance: v, imageScale };
        }
        return null;
    }
    if (!/折射|refraction/.test(source) || !/法线|normal/.test(source))
        return null;
    const ratio = /n[₂2]\/n[₁1]=√2|n2\/n1=sqrt\(?2\)?/.test(source)
        ? Math.SQRT2
        : /n[₂2]\/n[₁1]=1\/√2|n2\/n1=1\/sqrt\(?2\)?/.test(source)
            ? 1 / Math.SQRT2
            : numberAfter(source, /n[₂2]\/n[₁1]=(\d+(?:\.\d+)?)/);
    const incidence = numberAfter(source, /(?:入射角|incidenceangle)(?:为|是|is)?(\d+(?:\.\d+)?)(?:°|degrees?)/);
    if (ratio === null || incidence === null)
        return null;
    const sine = Math.sin(incidence * Math.PI / 180) / ratio;
    if (sine <= 0 || sine >= 1)
        return null;
    const angle = Number((Math.asin(sine) * 180 / Math.PI).toFixed(6));
    return { scope: 'refraction_angle_and_direction', refractionAngle: angle, direction: ratio > 1 ? 'toward_normal' : 'away_from_normal' };
}
function optionTruth(raw, model) {
    const source = compact(raw);
    if (model.scope === 'convex_lens_magnification') {
        const value = numberAfter(source, /(?:放大率(?:大小)?|magnification(?:magnitude)?)(?:为|是|is|:)?(\d+(?:\.\d+)?)/);
        return value === null || model.magnification === undefined ? null : close(value, model.magnification);
    }
    if (model.scope === 'convex_lens_image_distance_and_nature') {
        const value = numberAfter(source, /(?:像距|imagedistance)(?:为|是|is|:)?(\d+(?:\.\d+)?)cm/);
        const orientation = /倒立|inverted/.test(source) ? 'inverted' : /正立|upright/.test(source) ? 'upright' : null;
        const reality = /实像|realimage/.test(source) ? 'real' : /虚像|virtualimage/.test(source) ? 'virtual' : null;
        const scales = [
            ['diminished', /缩小|diminished|smaller/], ['same_size', /等大|samesize/], ['enlarged', /放大|enlarged|larger/]
        ].filter(([, pattern]) => pattern.test(source));
        if (value === null || !orientation || !reality || scales.length !== 1 || model.imageDistance === undefined)
            return null;
        return close(value, model.imageDistance) && orientation === 'inverted' && reality === 'real' && scales[0][0] === model.imageScale;
    }
    const angle = numberAfter(source, /(?:折射角|refractionangle)(?:为|是|is|:)?(\d+(?:\.\d+)?)(?:°|degrees?)/);
    const direction = /向法线偏折|靠近法线|towardthenormal/.test(source) ? 'toward_normal'
        : /离开法线偏折|远离法线|awayfromthenormal/.test(source) ? 'away_from_normal' : null;
    return angle === null || !direction || model.refractionAngle === undefined ? null
        : close(angle, model.refractionAngle) && direction === model.direction;
}
function verifySubjectPracticePhysicsOpticsWithIndependentOracle(candidate, context = {}) {
    const model = parsePrompt(candidate.prompt);
    const plan = recordFrom(context.questionPlan);
    const constraints = recordFrom(plan?.renderConstraints);
    const scopeMatched = Boolean(model
        && compact(plan?.schemaVersion) === 'subject-practice-question-plan-v1'
        && compact(plan?.planTemplate) === 'physics_medium_optics_two_relation_v1'
        && compact(plan?.taskFamily) === 'waves_optics_interference_refraction'
        && compact(constraints?.exactPhysicsOpticsScope) === model.scope);
    const optionVerdicts = candidate.options.map((option) => {
        const truth = model ? optionTruth(option.text, model) : null;
        return { optionId: option.id, verdict: truth === null ? 'unknown' : truth ? 'true' : 'false' };
    });
    const unknown = optionVerdicts.some((item) => item.verdict === 'unknown');
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const uniqueAnswer = !unknown && trueOptionIds.length === 1;
    const selectedOptionId = uniqueAnswer ? trueOptionIds[0] : null;
    const agreesWithGenerator = uniqueAnswer && selectedOptionId === candidate.correctAnswer;
    const reasonCodes = [];
    if (!model)
        reasonCodes.push('physics_optics_oracle_prompt_unparsed');
    if (unknown)
        reasonCodes.push('physics_optics_oracle_option_unparsed');
    if (!unknown && trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length ? 'physics_optics_oracle_multiple_true_options' : 'physics_optics_oracle_no_true_option');
    if (uniqueAnswer && !agreesWithGenerator)
        reasonCodes.push('physics_optics_oracle_generator_answer_disagrees');
    if (!scopeMatched)
        reasonCodes.push('physics_optics_oracle_scope_mismatch');
    const status = !model || unknown ? 'unparsed'
        : uniqueAnswer && agreesWithGenerator && scopeMatched ? 'verified' : 'conflict';
    return {
        oracleVersion: exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_INDEPENDENT_ORACLE_VERSION,
        status, opticsScope: model?.scope ?? null, optionVerdicts, trueOptionIds, selectedOptionId,
        uniqueAnswer, agreesWithGenerator,
        scopeId: model ? `physics-optics-two-relation-v1:${model.scope}` : null,
        scopeMatched, evidenceBoundary: 'prompt_and_visible_options_only', providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
