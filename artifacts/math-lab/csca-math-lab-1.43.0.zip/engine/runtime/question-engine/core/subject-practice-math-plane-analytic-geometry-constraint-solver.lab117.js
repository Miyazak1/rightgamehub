"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.gnorm = exports.gtxt = exports.gcmp = exports.gsq = exports.gdiv = exports.gmul = exports.gsub = exports.gneg = exports.gadd = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_CONSTRAINTS = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPES = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPE_VERSION = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SOLVER_VERSION = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_TEMPLATE = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_FAMILY = void 0;
exports.gq = gq;
exports.gread = gread;
exports.planeAnalyticGeometryConstraintScopeFrom = planeAnalyticGeometryConstraintScopeFrom;
exports.planeAnalyticGeometryConstraintPrompt = planeAnalyticGeometryConstraintPrompt;
exports.planeAnalyticGeometryConstraintParametersFrom = planeAnalyticGeometryConstraintParametersFrom;
exports.planeAnalyticGeometryConstraintOptionKey = planeAnalyticGeometryConstraintOptionKey;
exports.planeAnalyticGeometryConstraintDerive = planeAnalyticGeometryConstraintDerive;
exports.solveSubjectPracticeMathPlaneAnalyticGeometryConstraint = solveSubjectPracticeMathPlaneAnalyticGeometryConstraint;
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_FAMILY = 'math_plane_analytic_geometry_constraint_reasoning';
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_TEMPLATE = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_FAMILY + '_v1';
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SOLVER_VERSION = 'math-plane-analytic-geometry-constraint-solver-v1-exact-rational';
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPE_VERSION = 'math-hard-plane-analytic-geometry-constraint-v1';
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPES = ["circle_center_line_two_points_tangent_length_squared", "diameter_circle_secant_intersection_triangle_area_squared", "circle_line_pencil_chord_parameter_square_sum", "external_point_tangency_points_distance_squared_sum"];
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-GEO-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function gq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || (a < 0n ? -a : a).toString(2).length > 512 || (b < 0n ? -b : b).toString(2).length > 512)
    throw Error('geometry_arithmetic_bound'); if (b < 0n) {
    a = -a;
    b = -b;
} let x = a < 0n ? -a : a, y = b; while (y) {
    [x, y] = [y, x % y];
} return { n: a / x, d: b / x }; }
const gadd = (a, b) => gq(a.n * b.d + b.n * a.d, a.d * b.d), gneg = (a) => gq(-a.n, a.d), gsub = (a, b) => (0, exports.gadd)(a, (0, exports.gneg)(b)), gmul = (a, b) => gq(a.n * b.n, a.d * b.d), gdiv = (a, b) => gq(a.n * b.d, a.d * b.n), gsq = (a) => (0, exports.gmul)(a, a);
exports.gadd = gadd, exports.gneg = gneg, exports.gsub = gsub, exports.gmul = gmul, exports.gdiv = gdiv, exports.gsq = gsq;
const gcmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0, gtxt = (a) => String(a.n) + (a.d === 1n ? '' : '/' + a.d);
exports.gcmp = gcmp, exports.gtxt = gtxt;
function gread(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('geometry_rational_syntax'); const [n, d = '1'] = s.split('/'); return gq(BigInt(n), BigInt(d)); }
const bounded = (q) => q.n >= -1000000000000n && q.n <= 1000000000000n && q.d <= 1000000000n;
const Z = gq(0), T = gq(2), F = gq(4), obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
const gnorm = (a, b) => (0, exports.gadd)((0, exports.gsq)(a), (0, exports.gsq)(b));
exports.gnorm = gnorm;
const dot = (a, b, x, y) => (0, exports.gadd)((0, exports.gmul)(a, x), (0, exports.gmul)(b, y));
const lineValue = (l, x, y) => (0, exports.gadd)(dot(l[0], l[1], x, y), l[2]);
function intersect(l, m) { const determinant = (0, exports.gsub)((0, exports.gmul)(l[0], m[1]), (0, exports.gmul)(l[1], m[0])); if (!determinant.n)
    throw Error('nonunique_intersection'); return { x: (0, exports.gdiv)((0, exports.gsub)((0, exports.gmul)(l[1], m[2]), (0, exports.gmul)(l[2], m[1])), determinant), y: (0, exports.gdiv)((0, exports.gsub)((0, exports.gmul)(l[2], m[0]), (0, exports.gmul)(l[0], m[2])), determinant), determinant }; }
function planeAnalyticGeometryConstraintScopeFrom(value) { const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactPlaneAnalyticGeometryConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 72 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_FAMILY && p?.planTemplate === exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'plane_analytic_geometry_constraint_system' && s?.scenarioAction === scope && exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
const names = [['Ax', 'Ay', 'Bx', 'By', 'a', 'b', 'c', 'Px', 'Py'], ['Ux', 'Uy', 'Vx', 'Vy', 'a', 'b', 'c', 'm1', 'm2', 'm3', 'n1', 'n2', 'n3'], ['D', 'E', 'F', 'Px', 'Py', 'L'], ['D', 'E', 'F', 'Px', 'Py', 'Qx', 'Qy']];
function planeAnalyticGeometryConstraintPrompt(p, lang) {
    const i = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPES.indexOf(p.scope), zh = lang === 'zh', given = names[i].map((n, j) => n + '=(' + p.data[j] + ')').join(', ') + '. ';
    const starts = zh ? ['圆经过A=(Ax,Ay)和B=(Bx,By)，圆心在直线a*x+b*y+c=0上。给定外点P=(Px,Py)。已知 ', '圆的直径端点为U=(Ux,Uy)、V=(Vx,Vy)。直线a*x+b*y+c=0截圆于A、B；Q是m1*x+m2*y+m3=0与n1*x+n2*y+n3=0的交点。已知 ', '圆为x^2+y^2+D*x+E*y+F=0，外点为P=(Px,Py)。动直线t*x-y+Py-t*Px=0截圆的弦长为L。已知 ', '圆为x^2+y^2+D*x+E*y+F=0，P=(Px,Py)在圆外，Q=(Qx,Qy)。从P作两条切线，切点为T1、T2。已知 '] : ['A circle passes through A=(Ax,Ay) and B=(Bx,By); its center lies on a*x+b*y+c=0. P=(Px,Py) is external. Given ', 'The endpoints of a circle diameter are U=(Ux,Uy) and V=(Vx,Vy). The line a*x+b*y+c=0 cuts the circle at A,B; Q is the intersection of m1*x+m2*y+m3=0 and n1*x+n2*y+n3=0. Given ', 'The circle is x^2+y^2+D*x+E*y+F=0 and P=(Px,Py) is external. The line t*x-y+Py-t*Px=0 cuts a chord of length L. Given ', 'The circle is x^2+y^2+D*x+E*y+F=0. P=(Px,Py) is external and Q=(Qx,Qy). The two tangents from P touch the circle at T1,T2. Given '];
    const ends = zh ? ['求P到圆的切线长的平方。', '求三角形QAB面积的平方。', '求所有实数参数t的解的平方和。', '求|T1-Q|^2+|T2-Q|^2。'] : ['Find the square of the tangent length from P.', 'Find the square of the area of triangle QAB.', 'Find the sum of the squares of all real solutions for t.', 'Find |T1-Q|^2+|T2-Q|^2.'];
    return starts[i] + given + ends[i];
}
function planeAnalyticGeometryConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 3000)
    return null; const i = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPES.indexOf(scope), data = [...text.matchAll(/=\(([-+]?\d+(?:\/[1-9]\d*)?)\)/g)].map(m => m[1]), p = { scope, data }; return data.length === names[i].length && planeAnalyticGeometryConstraintPrompt(p, lang) === text ? p : null; }
function planeAnalyticGeometryConstraintOptionKey(text, _scope) { try {
    const q = gread(text.trim());
    return bounded(q) ? (0, exports.gtxt)(q) : null;
}
catch {
    return null;
} }
function planeAnalyticGeometryConstraintDerive(p) {
    try {
        const i = exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPES.indexOf(p.scope);
        if (i < 0 || p.data.length !== names[i].length)
            return null;
        const v = p.data.map(gread);
        if (!v.every(bounded))
            return null;
        let answer = Z, steps = [], groups = [], certificate = {}, witnesses = [];
        const errors = [], err = (intent, x) => { if (bounded(x))
            errors.push({ intent, text: (0, exports.gtxt)(x) }); };
        if (i === 0) {
            const [ax, ay, bx, by, a, b, c, px, py] = v, dx = (0, exports.gsub)(bx, ax), dy = (0, exports.gsub)(by, ay);
            if (!(0, exports.gnorm)(dx, dy).n || !(0, exports.gnorm)(a, b).n)
                return null;
            const bisector = [(0, exports.gmul)(T, dx), (0, exports.gmul)(T, dy), (0, exports.gsub)((0, exports.gnorm)(ax, ay), (0, exports.gnorm)(bx, by))], center = intersect(bisector, [a, b, c]), h = center.x, k = center.y, r2 = (0, exports.gnorm)((0, exports.gsub)(ax, h), (0, exports.gsub)(ay, k)), distance2 = (0, exports.gnorm)((0, exports.gsub)(px, h), (0, exports.gsub)(py, k));
            answer = (0, exports.gsub)(distance2, r2);
            if (r2.n <= 0n || answer.n <= 0n)
                return null;
            for (const omit of ['point_A', 'point_B', 'center_line']) {
                let witness = null;
                for (const scale of [gq(1, 2), gq(-1, 2), gq(1), gq(-1), gq(2), gq(-2)]) {
                    const nx = (0, exports.gadd)(h, (0, exports.gmul)(scale, omit === 'center_line' ? (0, exports.gneg)(dy) : b)), ny = (0, exports.gadd)(k, (0, exports.gmul)(scale, omit === 'center_line' ? dx : (0, exports.gneg)(a))), keep = omit === 'point_A' ? [bx, by] : [ax, ay], nr = (0, exports.gnorm)((0, exports.gsub)(keep[0], nx), (0, exports.gsub)(keep[1], ny)), alt = (0, exports.gsub)((0, exports.gnorm)((0, exports.gsub)(px, nx), (0, exports.gsub)(py, ny)), nr);
                    if (nr.n > 0n && alt.n > 0n && (0, exports.gcmp)(alt, answer)) {
                        witness = { omitted: omit, center: [(0, exports.gtxt)(nx), (0, exports.gtxt)(ny)], radiusSquared: (0, exports.gtxt)(nr), differentAnswer: (0, exports.gtxt)(alt) };
                        break;
                    }
                }
                if (!witness)
                    return null;
                witnesses.push(witness);
            }
            certificate = { kind: 'unique_center_and_external_tangent', center: [(0, exports.gtxt)(h), (0, exports.gtxt)(k)], determinant: (0, exports.gtxt)(center.determinant), radiusSquared: (0, exports.gtxt)(r2), externalDistanceSquared: (0, exports.gtxt)(distance2), pointBRadiusSquared: (0, exports.gtxt)((0, exports.gnorm)((0, exports.gsub)(bx, h), (0, exports.gsub)(by, k))), centerLineResidual: (0, exports.gtxt)(lineValue([a, b, c], h, k)) };
            if (certificate.pointBRadiusSquared !== (0, exports.gtxt)(r2) || certificate.centerLineResidual !== '0')
                return null;
            groups = ['two circle incidences', 'independent center line', 'external point'];
            steps = ['2*(Bx-Ax)*h+2*(By-Ay)*k=Bx^2+By^2-Ax^2-Ay^2; a*h+b*k+c=0', 'det=' + (0, exports.gtxt)(center.determinant) + '; C=(' + (0, exports.gtxt)(h) + ',' + (0, exports.gtxt)(k) + ')', 'r^2=((' + (0, exports.gtxt)(ax) + ')-(' + (0, exports.gtxt)(h) + '))^2+((' + (0, exports.gtxt)(ay) + ')-(' + (0, exports.gtxt)(k) + '))^2=' + (0, exports.gtxt)(r2), '|P-C|^2=' + (0, exports.gtxt)(distance2) + '>' + (0, exports.gtxt)(r2), 'tangent^2=' + (0, exports.gtxt)(distance2) + '-(' + (0, exports.gtxt)(r2) + ')=' + (0, exports.gtxt)(answer)];
            err('omit_radius_squared', distance2);
            err('add_radius_squared', (0, exports.gadd)(distance2, r2));
            err('report_radius_squared', r2);
            err('subtract_diameter_squared', (0, exports.gsub)(distance2, (0, exports.gmul)(F, r2)));
        }
        else if (i === 1) {
            const [ux, uy, vx, vy] = v, l = v.slice(4, 7), m = v.slice(7, 10), n = v.slice(10, 13), h = (0, exports.gdiv)((0, exports.gadd)(ux, vx), T), k = (0, exports.gdiv)((0, exports.gadd)(uy, vy), T), r2 = (0, exports.gdiv)((0, exports.gnorm)((0, exports.gsub)(ux, vx), (0, exports.gsub)(uy, vy)), F), K = (0, exports.gnorm)(l[0], l[1]);
            if (r2.n <= 0n || !K.n)
                return null;
            const Q = intersect(m, n), u = lineValue(l, h, k), w = lineValue(l, Q.x, Q.y), dc2 = (0, exports.gdiv)((0, exports.gsq)(u), K), dq2 = (0, exports.gdiv)((0, exports.gsq)(w), K), half2 = (0, exports.gsub)(r2, dc2);
            answer = (0, exports.gmul)(half2, dq2);
            if (half2.n <= 0n || dq2.n <= 0n)
                return null;
            certificate = { kind: 'secant_chord_and_independent_vertex', center: [(0, exports.gtxt)(h), (0, exports.gtxt)(k)], radiusSquared: (0, exports.gtxt)(r2), vertex: [(0, exports.gtxt)(Q.x), (0, exports.gtxt)(Q.y)], intersectionDeterminant: (0, exports.gtxt)(Q.determinant), normalSquared: (0, exports.gtxt)(K), centerDistanceSquared: (0, exports.gtxt)(dc2), heightSquared: (0, exports.gtxt)(dq2), halfChordSquared: (0, exports.gtxt)(half2) };
            witnesses = [{ omitted: 'diameter_length', alternativeRadiusSquared: (0, exports.gtxt)((0, exports.gadd)(r2, gq(1))), differentAnswer: (0, exports.gtxt)((0, exports.gmul)((0, exports.gadd)(half2, gq(1)), dq2)) }, { omitted: 'vertex_intersection', alternativeVertex: [(0, exports.gtxt)((0, exports.gadd)(Q.x, l[0])), (0, exports.gtxt)((0, exports.gadd)(Q.y, l[1]))], differentAnswer: (0, exports.gtxt)((0, exports.gmul)(half2, (0, exports.gdiv)((0, exports.gsq)((0, exports.gadd)(w, K)), K))) }];
            if (witnesses.some(witness => witness.differentAnswer === (0, exports.gtxt)(answer)))
                return null;
            groups = ['diameter endpoints', 'secant line', 'two-line vertex'];
            steps = ['C=(U+V)/2=(' + (0, exports.gtxt)(h) + ',' + (0, exports.gtxt)(k) + '); r^2=|U-V|^2/4=' + (0, exports.gtxt)(r2), 'solve m1*x+m2*y+m3=n1*x+n2*y+n3=0; Q=(' + (0, exports.gtxt)(Q.x) + ',' + (0, exports.gtxt)(Q.y) + ')', 'd_C^2=' + (0, exports.gtxt)(dc2) + '; (AB/2)^2=' + (0, exports.gtxt)(r2) + '-' + (0, exports.gtxt)(dc2) + '=' + (0, exports.gtxt)(half2), 'height^2=' + (0, exports.gtxt)(w) + '^2/' + (0, exports.gtxt)(K) + '=' + (0, exports.gtxt)(dq2), 'area^2=(1/4)*4*(' + (0, exports.gtxt)(half2) + ')*(' + (0, exports.gtxt)(dq2) + ')=' + (0, exports.gtxt)(answer)];
            err('omit_triangle_half_factor', (0, exports.gmul)(F, answer));
            err('use_half_chord_as_full_base', (0, exports.gdiv)(answer, F));
            err('substitute_diameter_for_chord', (0, exports.gmul)(r2, dq2));
            err('report_base_squared', (0, exports.gmul)(F, half2));
        }
        else if (i === 2) {
            const [D, E, f, px, py, L] = v, h = (0, exports.gdiv)((0, exports.gneg)(D), T), k = (0, exports.gdiv)((0, exports.gneg)(E), T), r2 = (0, exports.gsub)((0, exports.gnorm)(h, k), f), u = (0, exports.gsub)(h, px), w = (0, exports.gsub)(py, k), rho = (0, exports.gsub)(r2, (0, exports.gdiv)((0, exports.gsq)(L), F));
            if (r2.n <= 0n || L.n <= 0n || rho.n <= 0n || (0, exports.gcmp)((0, exports.gnorm)(u, w), r2) <= 0)
                return null;
            const A = (0, exports.gsub)((0, exports.gsq)(u), rho), B = (0, exports.gmul)(T, (0, exports.gmul)(u, w)), C = (0, exports.gsub)((0, exports.gsq)(w), rho), discriminant = (0, exports.gsub)((0, exports.gsq)(B), (0, exports.gmul)(F, (0, exports.gmul)(A, C)));
            if (!A.n || discriminant.n <= 0n)
                return null;
            const sum = (0, exports.gdiv)((0, exports.gneg)(B), A), product = (0, exports.gdiv)(C, A);
            answer = (0, exports.gsub)((0, exports.gsq)(sum), (0, exports.gmul)(T, product));
            if (answer.n <= 0n)
                return null;
            certificate = { kind: 'complete_real_parameter_quadratic', center: [(0, exports.gtxt)(h), (0, exports.gtxt)(k)], radiusSquared: (0, exports.gtxt)(r2), rho: (0, exports.gtxt)(rho), coefficients: [A, B, C].map(exports.gtxt), discriminant: (0, exports.gtxt)(discriminant), allRealRoots: '(-B+-sqrt(discriminant))/(2*A)', realRootCount: 2, lineNormPositive: '1+t^2>0 for every real t', noExtraneousRoots: true };
            for (const omitted of ['chord_length', 'external_point']) {
                let witness = null;
                for (const delta of [gq(1, 2), gq(-1, 2), gq(1), gq(-1), gq(2)]) {
                    const ll = omitted === 'chord_length' ? (0, exports.gadd)(L, delta) : L, uu = omitted === 'external_point' ? (0, exports.gadd)(u, delta) : u, rr = (0, exports.gsub)(r2, (0, exports.gdiv)((0, exports.gsq)(ll), F)), aa = (0, exports.gsub)((0, exports.gsq)(uu), rr), bb = (0, exports.gmul)(T, (0, exports.gmul)(uu, w)), cc = (0, exports.gsub)((0, exports.gsq)(w), rr), dd = (0, exports.gsub)((0, exports.gsq)(bb), (0, exports.gmul)(F, (0, exports.gmul)(aa, cc)));
                    if (ll.n <= 0n || rr.n <= 0n || !aa.n || dd.n <= 0n || (0, exports.gcmp)((0, exports.gnorm)(uu, w), r2) <= 0)
                        continue;
                    const other = (0, exports.gsub)((0, exports.gsq)((0, exports.gdiv)(bb, aa)), (0, exports.gmul)(T, (0, exports.gdiv)(cc, aa)));
                    if (other.n > 0n && (0, exports.gcmp)(other, answer)) {
                        witness = { omitted, alternativeChordLength: (0, exports.gtxt)(ll), alternativeP: [(0, exports.gtxt)((0, exports.gsub)(h, uu)), (0, exports.gtxt)(py)], differentAnswer: (0, exports.gtxt)(other) };
                        break;
                    }
                }
                if (!witness)
                    return null;
                witnesses.push(witness);
            }
            groups = ['circle coefficients', 'line pencil through external point', 'chord length'];
            steps = ['C=(' + (0, exports.gtxt)(h) + ',' + (0, exports.gtxt)(k) + '); r^2=' + (0, exports.gtxt)(r2), 'distance^2=r^2-L^2/4=' + (0, exports.gtxt)(rho) + '; u=' + (0, exports.gtxt)(u) + ', v=' + (0, exports.gtxt)(w), '(' + (0, exports.gtxt)(A) + ')*t^2+(' + (0, exports.gtxt)(B) + ')*t+(' + (0, exports.gtxt)(C) + ')=0', 'discriminant=' + (0, exports.gtxt)(discriminant) + '>0; two real roots; denominator 1+t^2>0', 't1+t2=' + (0, exports.gtxt)(sum) + '; t1*t2=' + (0, exports.gtxt)(product), 't1^2+t2^2=(' + (0, exports.gtxt)(sum) + ')^2-2*(' + (0, exports.gtxt)(product) + ')=' + (0, exports.gtxt)(answer)];
            err('report_parameter_sum', sum);
            err('report_parameter_product', product);
            err('omit_twice_parameter_product', (0, exports.gsq)(sum));
            err('omit_square_of_parameter_sum', (0, exports.gneg)((0, exports.gmul)(T, product)));
            err('reverse_final_sign', (0, exports.gneg)(answer));
        }
        else {
            const [D, E, f, px, py, qx, qy] = v, h = (0, exports.gdiv)((0, exports.gneg)(D), T), k = (0, exports.gdiv)((0, exports.gneg)(E), T), r2 = (0, exports.gsub)((0, exports.gnorm)(h, k), f), u = (0, exports.gsub)(px, h), w = (0, exports.gsub)(py, k), d2 = (0, exports.gnorm)(u, w), qx0 = (0, exports.gsub)(qx, h), qy0 = (0, exports.gsub)(qy, k);
            if (r2.n <= 0n || (0, exports.gcmp)(d2, r2) <= 0 || !(0, exports.gsub)((0, exports.gmul)(u, qy0), (0, exports.gmul)(w, qx0)).n || !dot(u, w, qx0, qy0).n)
                return null;
            const scale = (0, exports.gdiv)(r2, d2), mx = (0, exports.gadd)(h, (0, exports.gmul)(scale, u)), my = (0, exports.gadd)(k, (0, exports.gmul)(scale, w)), half2 = (0, exports.gsub)(r2, (0, exports.gdiv)((0, exports.gsq)(r2), d2)), mq2 = (0, exports.gnorm)((0, exports.gsub)(qx, mx), (0, exports.gsub)(qy, my));
            answer = (0, exports.gmul)(T, (0, exports.gadd)(mq2, half2));
            if (half2.n <= 0n)
                return null;
            certificate = { kind: 'two_real_tangency_points', center: [(0, exports.gtxt)(h), (0, exports.gtxt)(k)], radiusSquared: (0, exports.gtxt)(r2), externalDistanceSquared: (0, exports.gtxt)(d2), contactLine: [u, w, (0, exports.gneg)((0, exports.gadd)(dot(u, w, h, k), r2))].map(exports.gtxt), midpoint: [(0, exports.gtxt)(mx), (0, exports.gtxt)(my)], halfChordSquared: (0, exports.gtxt)(half2), midpointDistanceSquared: (0, exports.gtxt)(mq2), realContactPointCount: 2 };
            witnesses = [{ omitted: 'point_Q', alternativeQ: [(0, exports.gtxt)((0, exports.gadd)(mx, (0, exports.gmul)(T, (0, exports.gsub)(qx, mx)))), (0, exports.gtxt)((0, exports.gadd)(my, (0, exports.gmul)(T, (0, exports.gsub)(qy, my))))], differentAnswer: (0, exports.gtxt)((0, exports.gmul)(T, (0, exports.gadd)((0, exports.gmul)(F, mq2), half2))) }, { omitted: 'point_P', alternativeP: [(0, exports.gtxt)((0, exports.gadd)(h, (0, exports.gmul)(T, u))), (0, exports.gtxt)((0, exports.gadd)(k, (0, exports.gmul)(T, w)))], contactMidpointChanges: true, differentAnswer: (0, exports.gtxt)((0, exports.gmul)(T, (0, exports.gadd)((0, exports.gnorm)((0, exports.gsub)(qx, (0, exports.gadd)(h, (0, exports.gdiv)((0, exports.gmul)(scale, u), T))), (0, exports.gsub)(qy, (0, exports.gadd)(k, (0, exports.gdiv)((0, exports.gmul)(scale, w), T)))), (0, exports.gsub)(r2, (0, exports.gdiv)((0, exports.gsq)(r2), (0, exports.gmul)(F, d2)))))) }];
            groups = ['circle equation', 'external tangent point', 'distance reference point'];
            steps = ['C=(' + (0, exports.gtxt)(h) + ',' + (0, exports.gtxt)(k) + '); r^2=' + (0, exports.gtxt)(r2), '(P-T) dot (T-C)=0 and |T-C|^2=r^2 => (P-C) dot (T-C)=r^2', 'contact midpoint M=C+(r^2/|P-C|^2)*(P-C)=(' + (0, exports.gtxt)(mx) + ',' + (0, exports.gtxt)(my) + ')', '|T1-M|^2=|T2-M|^2=' + (0, exports.gtxt)(half2) + '; |Q-M|^2=' + (0, exports.gtxt)(mq2), 'sum=2*(' + (0, exports.gtxt)(mq2) + '+' + (0, exports.gtxt)(half2) + ')=' + (0, exports.gtxt)(answer)];
            err('omit_tangency_chord_spread', (0, exports.gmul)(T, mq2));
            err('report_one_of_equal_pair_terms', (0, exports.gdiv)(answer, T));
            err('ignore_external_point_use_center', (0, exports.gmul)(T, (0, exports.gadd)((0, exports.gnorm)(qx0, qy0), r2)));
            err('use_full_chord_for_each_offset', (0, exports.gmul)(T, (0, exports.gadd)(mq2, (0, exports.gmul)(F, half2))));
        }
        if (!bounded(answer))
            return null;
        const key = (0, exports.gtxt)(answer), distinct = errors.filter((e, j, all) => e.text !== key && all.findIndex(x => x.text === e.text) === j).slice(0, 3);
        if (distinct.length !== 3)
            return null;
        const proof = 'givens=' + p.data.join(',') + '; ' + steps.join('; '), hardEvidence = { version: 'plane-analytic-geometry-constraint-hard-evidence-v1', evidenceSlots: p.data.length, independentEvidenceGroups: groups.length, reasoningSteps: steps.length, quantitativeRelations: 2, groups, effectiveConstraints: witnesses, completeAnalyticGeometryCertificate: certificate, criticalPoints: [], answer: key, visibleProof: proof, studentCalibrated: false };
        return { answer: key, text: key, errors: distinct.map(e => ({ ...e, key: e.text })), proof, steps, hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathPlaneAnalyticGeometryConstraint(candidate, context = {}) {
    const scope = planeAnalyticGeometryConstraintScopeFrom(context.questionPlan), parameters = planeAnalyticGeometryConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? planeAnalyticGeometryConstraintDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('plane_geometry_constraint_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 72 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('plane_geometry_constraint_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? planeAnalyticGeometryConstraintOptionKey(o.text, scope) : null);
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('plane_geometry_constraint_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(planeAnalyticGeometryConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('plane_geometry_constraint_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, scope ? planeAnalyticGeometryConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('plane_geometry_constraint_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('plane_geometry_constraint_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.concat(require('../../../../src/intent-proof-v117.cjs').chord(parameters,d.hardEvidence?.completeAnalyticGeometryCertificate)).some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('plane_geometry_constraint_error_intent');
    const scopeId = parameters ? exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['plane_geometry_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
