"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sgsum = exports.sasum = exports.sterm = exports.stxt = exports.scmp = exports.sdiv = exports.smul = exports.ssub = exports.sneg = exports.sadd = exports.SEQUENCE_CONSTRAINT_CONSTRAINTS = exports.SEQUENCE_CONSTRAINT_SCOPES = exports.SEQUENCE_CONSTRAINT_SCOPE_VERSION = exports.SEQUENCE_CONSTRAINT_SOLVER_VERSION = exports.SEQUENCE_CONSTRAINT_TEMPLATE = exports.SEQUENCE_CONSTRAINT_FAMILY = void 0;
exports.sq = sq;
exports.spow = spow;
exports.sread = sread;
exports.sfloor = sfloor;
exports.sequenceConstraintScopeFrom = sequenceConstraintScopeFrom;
exports.sequenceConstraintPrompt = sequenceConstraintPrompt;
exports.sequenceConstraintParametersFrom = sequenceConstraintParametersFrom;
exports.sequenceConstraintOptionKey = sequenceConstraintOptionKey;
exports.sequenceConstraintDerive = sequenceConstraintDerive;
exports.solveSubjectPracticeMathSequenceConstraint = solveSubjectPracticeMathSequenceConstraint;
exports.SEQUENCE_CONSTRAINT_FAMILY = 'math_sequence_constraint_reasoning';
exports.SEQUENCE_CONSTRAINT_TEMPLATE = exports.SEQUENCE_CONSTRAINT_FAMILY + '_v1';
exports.SEQUENCE_CONSTRAINT_SOLVER_VERSION = 'math-sequence-constraint-solver-v1-exact-rational';
exports.SEQUENCE_CONSTRAINT_SCOPE_VERSION = 'math-hard-sequence-constraint-v1';
exports.SEQUENCE_CONSTRAINT_SCOPES = ['arithmetic_term_sum_positive_window_sum', 'arithmetic_two_terms_partial_sum_threshold_index', 'geometric_two_terms_partial_sum_threshold_index', 'affine_recurrence_two_terms_partial_sum'];
exports.SEQUENCE_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-SEQ-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
const bits = (n) => (n < 0n ? -n : n).toString(2).length;
function sq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || bits(a) > 512 || bits(b) > 512)
    throw Error('sequence_arithmetic_bound'); if (b < 0n) {
    a = -a;
    b = -b;
} let x = a < 0n ? -a : a, y = b; while (y) {
    const t = x % y;
    x = y;
    y = t;
} return { n: a / x, d: b / x }; }
const sadd = (a, b) => sq(a.n * b.d + b.n * a.d, a.d * b.d), sneg = (a) => sq(-a.n, a.d), ssub = (a, b) => (0, exports.sadd)(a, (0, exports.sneg)(b)), smul = (a, b) => sq(a.n * b.n, a.d * b.d), sdiv = (a, b) => sq(a.n * b.d, a.d * b.n);
exports.sadd = sadd, exports.sneg = sneg, exports.ssub = ssub, exports.smul = smul, exports.sdiv = sdiv;
const scmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0, stxt = (a) => String(a.n) + (a.d === 1n ? '' : '/' + a.d);
exports.scmp = scmp, exports.stxt = stxt;
function spow(a, n) { if (!Number.isSafeInteger(n) || n < 0 || n > 256)
    throw Error('sequence_exponent'); let v = sq(1); for (let i = 0; i < n; i++)
    v = (0, exports.smul)(v, a); return v; }
function sread(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('sequence_rational_syntax'); const [n, d = '1'] = s.split('/'); return sq(BigInt(n), BigInt(d)); }
const bounded = (q) => q.n >= -1000000000000n && q.n <= 1000000000000n && q.d <= 1000000000n;
const Z = sq(0), O = sq(1), rec = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function sfloor(q) { const n = q.n >= 0n ? q.n / q.d : -((-q.n + q.d - 1n) / q.d); if (n > 1000000000000n || n < -1000000000000n)
    throw Error('sequence_integer_bound'); return Number(n); }
const index = (q, max) => q.d === 1n && q.n >= 1n && q.n <= BigInt(max) ? Number(q.n) : null;
const sterm = (a, d, n) => (0, exports.sadd)(a, (0, exports.smul)(sq(n - 1), d));
exports.sterm = sterm;
const sasum = (a, d, n) => (0, exports.smul)(sq(n, 2), (0, exports.sadd)((0, exports.smul)(sq(2), a), (0, exports.smul)(sq(n - 1), d)));
exports.sasum = sasum;
const sgsum = (a, q, n) => (0, exports.sdiv)((0, exports.smul)(a, (0, exports.ssub)(spow(q, n), O)), (0, exports.ssub)(q, O));
exports.sgsum = sgsum;
function root(q) { if (q.n < 0n)
    return null; const r = (n) => { let l = 0n, h = n + 1n; while (h - l > 1n) {
    const m = (h + l) / 2n;
    if (m * m <= n)
        l = m;
    else
        h = m;
} return l * l === n ? l : null; }; const n = r(q.n), d = r(q.d); return n === null || d === null ? null : sq(n, d); }
function window(a, d, l, u) { if (!d.n)
    return null; const zero = (0, exports.sdiv)((0, exports.sneg)(a), d), first = d.n > 0n ? Math.max(l, sfloor(zero) + 2) : l, last = d.n < 0n ? Math.min(u, -sfloor((0, exports.sneg)(zero))) : u; if (first > last)
    return { first, last, count: 0, total: Z }; return { first, last, count: last - first + 1, total: (0, exports.smul)(sq(last - first + 1, 2), (0, exports.sadd)((0, exports.sterm)(a, d, first), (0, exports.sterm)(a, d, last))) }; }
function threshold(a, d, t, rel, geo, max) { if ((0, exports.scmp)(a, Z) <= 0 || (0, exports.scmp)(d, geo ? O : Z) <= 0 || (0, exports.scmp)(t, Z) <= 0 || !['ge', 'gt'].includes(rel))
    return null; const sum = (n) => geo ? (0, exports.sgsum)(a, d, n) : (0, exports.sasum)(a, d, n), ok = (n) => (0, exports.scmp)(sum(n), t) >= (rel === 'ge' ? 0 : 1); let hi = 1; while (hi < max && !ok(hi))
    hi = Math.min(max, hi * 2); if (!ok(hi))
    return null; let lo = 0; while (hi - lo > 1) {
    const m = Math.floor((lo + hi) / 2);
    if (ok(m))
        hi = m;
    else
        lo = m;
} return { n: hi, previous: sum(hi - 1), current: sum(hi) }; }
function recurrence(a, q, c, n) { const shifted = (0, exports.sadd)(a, (0, exports.sdiv)(c, (0, exports.ssub)(q, O))); return { shifted, total: (0, exports.ssub)((0, exports.sgsum)(shifted, q, n), (0, exports.smul)(sq(n), (0, exports.sdiv)(c, (0, exports.ssub)(q, O)))), last: (0, exports.ssub)((0, exports.smul)(shifted, spow(q, n - 1)), (0, exports.sdiv)(c, (0, exports.ssub)(q, O))) }; }
function sequenceConstraintScopeFrom(value) { const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactSequenceConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 70 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.SEQUENCE_CONSTRAINT_FAMILY && p?.planTemplate === exports.SEQUENCE_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.SEQUENCE_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'sequence_constraint_system' && s?.scenarioAction === scope && exports.SEQUENCE_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
function sequenceConstraintPrompt(p, lang) {
    const d = p.data, i = exports.SEQUENCE_CONSTRAINT_SCOPES.indexOf(p.scope), zh = lang === 'zh', put = (names) => names.map((name, j) => name + '=(' + d[j] + ')').join(', ') + '. ';
    const ap = zh ? '设等差数列，S_n为前n项和。已知 ' : 'For an arithmetic sequence, S_n is the sum of its first n terms. Given ';
    const tail = (rel) => (zh ? '求使' : 'Find the smallest positive integer n satisfying ') + ' S_n' + (rel === 'ge' ? '>=' : '>') + 'T' + (zh ? '成立的最小正整数n。' : '.');
    if (i === 0)
        return ap + put(['r', 'a_r', 'm', 'S_m', 'L', 'U']) + (zh ? '求整数索引L<=i<=U中所有a_i>0的项之和。' : 'Find the sum of all positive terms a_i>0 with integer indices L<=i<=U.');
    if (i === 1)
        return ap + put(['r', 'a_r', 's', 'a_s', 'T']) + tail(d[5]);
    if (i === 2)
        return (zh ? '设公比q>1的等比数列，S_n为前n项和。已知 ' : 'For a geometric sequence with q>1, S_n is the sum of its first n terms. Given ') + put(['r', 'a_r', 'a_(r+2)', 'T']) + tail(d[4]);
    return (zh ? '设递推数列a_(n+1)=q*a_n+c，c未知。已知 ' : 'Let a_(n+1)=q*a_n+c, where c is unknown. Given ') + put(['q', 'a_1', 'k', 'a_k', 'N']) + (zh ? '求前N项之和S_N。' : 'Find S_N, the sum of the first N terms.');
}
function sequenceConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 2200)
    return null; const i = exports.SEQUENCE_CONSTRAINT_SCOPES.indexOf(scope), data = [...text.matchAll(/=\(([-+]?\d+(?:\/[1-9]\d*)?)\)/g)].map(m => m[1]); if (i === 1 || i === 2)
    data.push(text.includes('S_n>=T') ? 'ge' : 'gt'); const p = { scope, data }; return data.length === [6, 6, 5, 5][i] && sequenceConstraintPrompt(p, lang) === text ? p : null; }
function sequenceConstraintOptionKey(text, scope) { try {
    const q = sread(text.trim()), i = exports.SEQUENCE_CONSTRAINT_SCOPES.indexOf(scope);
    return bounded(q) && (!(i === 1 || i === 2) || q.d === 1n && q.n > 0n) ? (0, exports.stxt)(q) : null;
}
catch {
    return null;
} }
function sequenceConstraintDerive(p) {
    try {
        const i = exports.SEQUENCE_CONSTRAINT_SCOPES.indexOf(p.scope);
        if (i < 0 || p.data.length !== [6, 6, 5, 5][i])
            return null;
        const v = p.data.slice(0, i === 1 ? 5 : i === 2 ? 4 : undefined).map(sread);
        if (!v.every(bounded))
            return null;
        let answer = Z, steps = [], groups = [], certificate = {}, witnesses = [];
        const errors = [];
        const err = (intent, value) => { if (bounded(value))
            errors.push({ intent, text: (0, exports.stxt)(value) }); };
        if (i === 0) {
            const r = index(v[0], 12), m = index(v[2], 12), l = index(v[4], 32), u = index(v[5], 32);
            if (!r || !m || !l || !u || l >= u || m + 1 === 2 * r)
                return null;
            const d = (0, exports.sdiv)((0, exports.smul)(sq(2), (0, exports.ssub)(v[3], (0, exports.smul)(sq(m), v[1]))), sq(m * (m + 1 - 2 * r))), a = (0, exports.ssub)(v[1], (0, exports.smul)(sq(r - 1), d)), w = window(a, d, l, u);
            if (!w || w.count < 2 || !d.n || !bounded(a) || !bounded(d))
                return null;
            const negative = Array.from({ length: u - l + 1 }, (_, j) => (0, exports.sterm)(a, d, l + j)).filter(t => t.n < 0n).length;
            if (negative < 2)
                return null;
            answer = w.total;
            const extended = window(a, d, Math.max(1, l - 1), u + 1);
            if (!extended || !(0, exports.scmp)(extended.total, answer))
                return null;
            for (const omitted of ['given_term', 'given_partial_sum']) {
                let witness = null;
                for (const delta of [sq(1, 2), sq(-1, 2), sq(1), sq(-1), sq(2), sq(-2)]) {
                    const dd = (0, exports.sadd)(d, delta), aa = omitted === 'given_term' ? (0, exports.ssub)((0, exports.sdiv)(v[3], sq(m)), (0, exports.smul)(sq(m - 1, 2), dd)) : (0, exports.ssub)(v[1], (0, exports.smul)(sq(r - 1), dd)), ww = window(aa, dd, l, u);
                    if (ww && (0, exports.scmp)(ww.total, answer)) {
                        witness = { omitted, a1: (0, exports.stxt)(aa), d: (0, exports.stxt)(dd), differentAnswer: (0, exports.stxt)(ww.total) };
                        break;
                    }
                }
                if (!witness)
                    return null;
                witnesses.push(witness);
            }
            const total = (0, exports.ssub)((0, exports.sasum)(a, d, u), (0, exports.sasum)(a, d, l - 1));
            err('sum_all_window_terms_without_sign_filter', total);
            err('sum_absolute_values_instead_of_positive_terms', (0, exports.ssub)((0, exports.smul)(sq(2), answer), total));
            err('report_number_of_positive_terms', sq(w.count));
            err('extend_window_beyond_given_indices', extended.total);
            certificate = { parameterDeterminant: m * (m + 1 - 2 * r), a1: (0, exports.stxt)(a), d: (0, exports.stxt)(d), firstPositive: w.first, lastPositive: w.last, positiveCount: w.count, negativeCount: negative, zeroTerms: Array.from({ length: u - l + 1 }, (_, j) => l + j).filter(n => !(0, exports.sterm)(a, d, n).n), completeWindow: [l, u], adjacentValues: [w.first - 1, w.first, w.last, w.last + 1].map(n => [n, (0, exports.stxt)((0, exports.sterm)(a, d, n))]) };
            groups = ['independent term and partial-sum constraints', 'integer sign filter', 'finite index window'];
            steps = ['a_r=a1+(r-1)d; S_m=m*(2*a1+(m-1)d)/2; r=' + r + ', m=' + m, 'a1=' + (0, exports.stxt)(a) + ', d=' + (0, exports.stxt)(d) + '; determinant=' + m * (m + 1 - 2 * r), 'a_i>0; integer bounds intersect [' + l + ',' + u + ']: [' + w.first + ',' + w.last + ']', 'boundary values=' + JSON.stringify(certificate.adjacentValues), 'sum=(' + w.count + ')*(' + (0, exports.stxt)((0, exports.sterm)(a, d, w.first)) + '+' + (0, exports.stxt)((0, exports.sterm)(a, d, w.last)) + ')/2=' + (0, exports.stxt)(answer)];
        }
        else if (i === 1 || i === 2) {
            const geo = i === 2, r = index(v[0], geo ? 4 : 12), s = geo ? (r ? r + 2 : 0) : index(v[2], 12), u = v[1], other = geo ? v[2] : v[3], t = geo ? v[3] : v[4], rel = p.data[geo ? 4 : 5];
            if (!r || !s || r === s)
                return null;
            let d, a;
            if (geo) {
                if (u.n <= 0n)
                    return null;
                const q = root((0, exports.sdiv)(other, u));
                if (!q || (0, exports.scmp)(q, O) <= 0)
                    return null;
                d = q;
                a = (0, exports.sdiv)(u, spow(q, r - 1));
            }
            else {
                d = (0, exports.sdiv)((0, exports.ssub)(other, u), sq(s - r));
                a = (0, exports.ssub)(u, (0, exports.smul)(sq(r - 1), d));
            }
            const max = geo ? 24 : 32, result = threshold(a, d, t, rel, geo, max);
            if (!result || result.n <= Math.max(r, s) || result.n < (geo ? 5 : 4) || !bounded(a) || !bounded(d))
                return null;
            answer = sq(result.n);
            for (const omitted of ['first_given_term', 'second_given_term']) {
                let witness = null;
                const variants = geo ? [sq(3, 2), sq(2), sq(3), sq(4)] : [(0, exports.smul)(d, sq(1, 2)), (0, exports.smul)(d, sq(2)), (0, exports.smul)(d, sq(3)), (0, exports.sadd)(d, sq(1))];
                for (const dd of variants) {
                    const keep = omitted === 'first_given_term' ? s : r, value = omitted === 'first_given_term' ? other : u, aa = geo ? (0, exports.sdiv)(value, spow(dd, keep - 1)) : (0, exports.ssub)(value, (0, exports.smul)(sq(keep - 1), dd)), rr = threshold(aa, dd, t, rel, geo, max);
                    if (rr && rr.n !== result.n) {
                        witness = { omitted, a1: (0, exports.stxt)(aa), step: (0, exports.stxt)(dd), differentAnswer: String(rr.n) };
                        break;
                    }
                }
                if (!witness)
                    return null;
                witnesses.push(witness);
            }
            let individual = 1;
            while (individual <= 256 && (0, exports.scmp)(geo ? (0, exports.smul)(a, spow(d, individual - 1)) : (0, exports.sterm)(a, d, individual), t) < (rel === 'ge' ? 0 : 1))
                individual++;
            err('report_additional_terms_after_given_index', sq(result.n - r));
            const ratio = (0, exports.sdiv)(t, a), constant = rel === 'ge' ? -sfloor((0, exports.sneg)(ratio)) : sfloor(ratio) + 1;
            err('ignore_growth_use_constant_first_term', sq(constant));
            if (individual <= 256)
                err('apply_threshold_to_single_term_not_partial_sum', sq(individual));
            err('sum_indices_instead_of_counting_terms', sq(result.n * (result.n + 1) / 2));
            certificate = { a1: (0, exports.stxt)(a), step: (0, exports.stxt)(d), parameterEquation: geo ? 'q^2=a_(r+2)/a_r; q>1' : 'd=(a_s-a_r)/(s-r)', parameterWitness: geo ? (0, exports.stxt)((0, exports.smul)(d, d)) : String(s - r), allTermsPositive: true, allPartialSumsStrictlyIncreasing: true, relation: rel, threshold: (0, exports.stxt)(t), minimalIndex: result.n, previous: (0, exports.stxt)(result.previous), current: (0, exports.stxt)(result.current), completeSearchUpperBound: max };
            groups = ['two independent observed terms', 'unique admissible parameter branch', 'integer partial-sum threshold'];
            steps = [geo ? 'q^2=(' + (0, exports.stxt)(other) + ')/(' + (0, exports.stxt)(u) + '); q>1 => q=' + (0, exports.stxt)(d) : 'd=(' + (0, exports.stxt)(other) + '-' + (0, exports.stxt)(u) + ')/(' + s + '-' + r + ')=' + (0, exports.stxt)(d), 'a1=' + (0, exports.stxt)(a) + '; a_r=' + (0, exports.stxt)(u) + '; a_' + s + '=' + (0, exports.stxt)(other), geo ? 'S_n=a1*(q^n-1)/(q-1)' : 'S_n=n*(2*a1+(n-1)*d)/2', 'all a_n>0, so S_n is strictly increasing for every positive integer n', 'S_' + (result.n - 1) + '=' + (0, exports.stxt)(result.previous) + '; T=' + (0, exports.stxt)(t) + '; S_' + result.n + '=' + (0, exports.stxt)(result.current) + '; relation=' + rel, 'first valid positive integer n=' + result.n];
        }
        else {
            const q = v[0], a = v[1], k = index(v[2], 6), n = index(v[4], 16);
            if (!k || k < 3 || !n || n < k + 2 || !q.n || !(0, exports.scmp)(q, O))
                return null;
            const beta = (0, exports.sdiv)((0, exports.ssub)(spow(q, k - 1), O), (0, exports.ssub)(q, O));
            if (!beta.n)
                return null;
            const c = (0, exports.sdiv)((0, exports.ssub)(v[3], (0, exports.smul)(spow(q, k - 1), a)), beta), result = recurrence(a, q, c, n);
            if (!c.n || !result.shifted.n || !bounded(c))
                return null;
            answer = result.total;
            const c2 = (0, exports.sadd)(c, O), a2 = (0, exports.sadd)(a, O), c3 = (0, exports.sdiv)((0, exports.ssub)(v[3], (0, exports.smul)(spow(q, k - 1), a2)), beta), changedInitial = recurrence(a2, q, c3, n), changedTerminal = recurrence(a, q, c2, n);
            if (!(0, exports.scmp)(changedInitial.total, answer) || !(0, exports.scmp)(changedTerminal.total, answer))
                return null;
            witnesses = [{ omitted: 'given_initial_term', a1: (0, exports.stxt)(a2), c: (0, exports.stxt)(c3), differentAnswer: (0, exports.stxt)(changedInitial.total) }, { omitted: 'given_kth_term', a1: (0, exports.stxt)(a), c: (0, exports.stxt)(c2), differentAnswer: (0, exports.stxt)(changedTerminal.total) }];
            err('omit_additive_recurrence_constant', (0, exports.sgsum)(a, q, n));
            err('sum_shifted_sequence_without_shift_correction', (0, exports.sgsum)(result.shifted, q, n));
            err('report_last_term_instead_of_partial_sum', result.last);
            err('use_one_step_coefficient_to_recover_constant', recurrence(a, q, (0, exports.ssub)(v[3], (0, exports.smul)(spow(q, k - 1), a)), n).total);
            certificate = { a1: (0, exports.stxt)(a), q: (0, exports.stxt)(q), k, n, betaK: (0, exports.stxt)(beta), c: (0, exports.stxt)(c), shiftedFirst: (0, exports.stxt)(result.shifted), kthBackSubstitution: (0, exports.stxt)(recurrence(a, q, c, k).last), completeRecurrenceLength: n };
            if ((0, exports.scmp)(recurrence(a, q, c, k).last, v[3]))
                return null;
            groups = ['affine recurrence relation', 'initial term', 'later observed term and requested sum'];
            steps = ['a_k=q^(k-1)*a1+c*(q^(k-1)-1)/(q-1); k=' + k + '; q=' + (0, exports.stxt)(q), 'beta_k=' + (0, exports.stxt)(beta) + '!=0; c=(' + (0, exports.stxt)(v[3]) + '-q^(' + (k - 1) + ')*(' + (0, exports.stxt)(a) + '))/beta_k=' + (0, exports.stxt)(c), 'b_n=a_n+c/(q-1); b1=' + (0, exports.stxt)(result.shifted) + '; b_(n+1)=q*b_n', 'a_' + k + '=' + (0, exports.stxt)(v[3]) + '; a_' + n + '=' + (0, exports.stxt)(result.last), 'S_' + n + '=b1*(q^' + n + '-1)/(q-1)-' + n + '*c/(q-1)=' + (0, exports.stxt)(answer)];
        }
        if (!bounded(answer))
            return null;
        const key = (0, exports.stxt)(answer), distinct = errors.filter((e, j, all) => sequenceConstraintOptionKey(e.text, p.scope) !== null && e.text !== key && all.findIndex(x => x.text === e.text) === j).slice(0, 3);
        if (distinct.length !== 3 || new Set(distinct.map(e => e.intent)).size !== 3)
            return null;
        const proof = 'parameters=' + p.data.join(',') + '; ' + steps.join('; '), hardEvidence = { version: 'sequence-constraint-hard-evidence-v1', evidenceSlots: p.data.length, independentEvidenceGroups: groups.length, reasoningSteps: steps.length, quantitativeRelations: 2, groups, effectiveConstraints: witnesses, completeDiscreteCertificate: certificate, criticalPoints: [], answer: key, visibleProof: proof, studentCalibrated: false };
        return { answer: key, text: key, errors: distinct.map(e => ({ ...e, key: e.text })), proof, steps, hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathSequenceConstraint(candidate, context = {}) {
    const scope = sequenceConstraintScopeFrom(context.questionPlan), parameters = sequenceConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? sequenceConstraintDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('sequence_constraint_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 70 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('sequence_constraint_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? sequenceConstraintOptionKey(o.text, scope) : null);
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('sequence_constraint_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(sequenceConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('sequence_constraint_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, scope ? sequenceConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('sequence_constraint_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('sequence_constraint_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('sequence_constraint_error_intent');
    const scopeId = parameters ? exports.SEQUENCE_CONSTRAINT_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.SEQUENCE_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.SEQUENCE_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.SEQUENCE_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['sequence_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
