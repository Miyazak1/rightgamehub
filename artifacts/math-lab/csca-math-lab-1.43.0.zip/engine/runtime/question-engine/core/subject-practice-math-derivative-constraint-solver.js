"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dderivative = exports.dvalue = exports.dpow = exports.dtxt = exports.dcmp = exports.ddiv = exports.dmul = exports.dsub = exports.dneg = exports.dadd = exports.DERIVATIVE_CONSTRAINT_CONSTRAINTS = exports.DERIVATIVE_CONSTRAINT_SCOPES = exports.DERIVATIVE_CONSTRAINT_SCOPE_VERSION = exports.DERIVATIVE_CONSTRAINT_SOLVER_VERSION = exports.DERIVATIVE_CONSTRAINT_TEMPLATE = exports.DERIVATIVE_CONSTRAINT_FAMILY = void 0;
exports.dq = dq;
exports.dread = dread;
exports.droot = droot;
exports.dstationary = dstationary;
exports.derivativeConstraintScopeFrom = derivativeConstraintScopeFrom;
exports.derivativeConstraintPrompt = derivativeConstraintPrompt;
exports.derivativeConstraintParametersFrom = derivativeConstraintParametersFrom;
exports.derivativeConstraintOptionKey = derivativeConstraintOptionKey;
exports.derivativeConstraintDerive = derivativeConstraintDerive;
exports.solveSubjectPracticeMathDerivativeConstraint = solveSubjectPracticeMathDerivativeConstraint;
exports.DERIVATIVE_CONSTRAINT_FAMILY = 'math_derivative_constraint_reasoning';
exports.DERIVATIVE_CONSTRAINT_TEMPLATE = exports.DERIVATIVE_CONSTRAINT_FAMILY + '_v1';
exports.DERIVATIVE_CONSTRAINT_SOLVER_VERSION = 'math-derivative-constraint-solver-v1-exact-rational';
exports.DERIVATIVE_CONSTRAINT_SCOPE_VERSION = 'math-hard-derivative-constraint-v1';
exports.DERIVATIVE_CONSTRAINT_SCOPES = ['cubic_tangent_constraint_closed_interval_extremum', 'cubic_two_interval_monotonic_parameter_range', 'cubic_level_equation_closed_interval_root_count', 'cubic_extrema_gap_point_constraint_tangent_line'];
exports.DERIVATIVE_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-CALC-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000, rationalDenominatorMax: 10000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function dq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
    throw Error('zero_denominator'); if (b < 0n) {
    a = -a;
    b = -b;
} let x = a < 0n ? -a : a, y = b; while (y) {
    const r = x % y;
    x = y;
    y = r;
} a /= x; b /= x; if (a > 10n ** 30n || a < -(10n ** 30n) || b > 10n ** 24n)
    throw Error('arithmetic_bound'); return { n: a, d: b }; }
const dadd = (a, b) => dq(a.n * b.d + b.n * a.d, a.d * b.d), dneg = (a) => dq(-a.n, a.d), dsub = (a, b) => (0, exports.dadd)(a, (0, exports.dneg)(b)), dmul = (a, b) => dq(a.n * b.n, a.d * b.d), ddiv = (a, b) => dq(a.n * b.d, a.d * b.n);
exports.dadd = dadd, exports.dneg = dneg, exports.dsub = dsub, exports.dmul = dmul, exports.ddiv = ddiv;
const dcmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0, dtxt = (a) => String(a.n) + (a.d === 1n ? '' : '/' + a.d), dpow = (a, n) => dq(a.n ** BigInt(n), a.d ** BigInt(n));
exports.dcmp = dcmp, exports.dtxt = dtxt, exports.dpow = dpow;
function dread(s) { if (typeof s !== 'string' || s.length > 32 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('rational_syntax'); const [n, d = '1'] = s.split('/'); return dq(BigInt(n), BigInt(d)); }
const Z = dq(0), ONE = dq(1), rec = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function droot(a, k) { if (a.n < 0n)
    return null; const r = (n) => { let l = 0n, h = n + 1n; while (h - l > 1n) {
    const m = (l + h) / 2n;
    if (m ** BigInt(k) <= n)
        l = m;
    else
        h = m;
} return l ** BigInt(k) === n ? l : null; }; const n = r(a.n), d = r(a.d); return n === null || d === null ? null : dq(n, d); }
const dvalue = (c, x) => c.slice().reverse().reduce((v, a) => (0, exports.dadd)((0, exports.dmul)(v, x), a), Z);
exports.dvalue = dvalue;
const dderivative = (c) => c.slice(1).map((v, i) => (0, exports.dmul)(dq(i + 1), v));
exports.dderivative = dderivative;
function dstationary(c) { const [C, B, A] = (0, exports.dderivative)(c), disc = (0, exports.dsub)((0, exports.dpow)(B, 2), (0, exports.dmul)(dq(4), (0, exports.dmul)(A, C))), r = droot(disc, 2); if (!r || !r.n)
    return null; const roots = [(0, exports.ddiv)((0, exports.dsub)((0, exports.dneg)(B), r), (0, exports.dmul)(dq(2), A)), (0, exports.ddiv)((0, exports.dadd)((0, exports.dneg)(B), r), (0, exports.dmul)(dq(2), A))].sort(exports.dcmp); return roots.every(x => (0, exports.dcmp)(x, dq(-8)) >= 0 && (0, exports.dcmp)(x, dq(8)) <= 0) && roots.every(x => !(0, exports.dvalue)((0, exports.dderivative)(c), x).n) ? roots : null; }
const bounded = (v) => v.n >= -1000000n && v.n <= 1000000n && v.d <= 10000n;
const coordinate = (v) => bounded(v) && (0, exports.dcmp)(v, dq(-8)) >= 0 && (0, exports.dcmp)(v, dq(8)) <= 0;
const unique = (xs) => xs.sort(exports.dcmp).filter((x, i, a) => !i || (0, exports.dcmp)(x, a[i - 1]));
function extrema(c, l, u, mode) { const roots = dstationary(c); if (!roots || (0, exports.dcmp)(l, u) >= 0 || !roots.some(x => (0, exports.dcmp)(x, l) > 0 && (0, exports.dcmp)(x, u) < 0))
    return null; const points = unique([l, u, ...roots.filter(x => (0, exports.dcmp)(x, l) >= 0 && (0, exports.dcmp)(x, u) <= 0)]), values = points.map(x => (0, exports.dvalue)(c, x)), sorted = values.slice().sort(exports.dcmp); return { roots, points, values, answer: mode === 'maximum' ? sorted[sorted.length - 1] : sorted[0] }; }
function derivativeConstraintScopeFrom(value) { const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactDerivativeConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 71 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.DERIVATIVE_CONSTRAINT_FAMILY && p?.planTemplate === exports.DERIVATIVE_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.DERIVATIVE_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'derivative_constraint_system' && s?.scenarioAction === scope && exports.DERIVATIVE_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
function derivativeConstraintPrompt(p, lang) {
    const d = p.data, i = exports.DERIVATIVE_CONSTRAINT_SCOPES.indexOf(p.scope), zh = lang === 'zh';
    if (i === 0)
        return (zh ? '设三次函数 f(x)=A*x^3+B*x^2+C*x+D，其中 ' : 'Let f(x)=A*x^3+B*x^2+C*x+D, with ') + `A=(${d[0]}), B=(${d[1]}). ` + (zh ? '未知系数为 C,D；在 ' : 'C,D are unknown; at ') + `x=(${d[2]}), y=(${d[3]})*x+(${d[4]})` + (zh ? ' 是切线。求 ' : ' is the tangent. Find ') + `f(x), x in [${d[5]},${d[6]}]` + (zh ? ' 的' + (d[7] === 'maximum' ? '最大值' : '最小值') + '。' : ': the ' + d[7] + ' value.');
    if (i === 1)
        return (zh ? '实参数 p 的三次函数 ' : 'For real p, consider ') + `f_p(x)=A*((x-h)^3-3*p*(x-h))+d; A=(${d[0]}), h=(${d[1]}), d=(${d[2]}). I=[${d[3]},${d[4]}], J=[${d[5]},${d[6]}]. ` + (zh ? '当 A>0 时要求 I 上单调不减、J 上单调不增；A<0 时这两个方向互换。求 p 的全部取值范围。' : 'For A>0 require nondecreasing on I and nonincreasing on J; reverse both directions for A<0. Find all real p.');
    if (i === 2)
        return (zh ? '设三次函数 ' : 'Let ') + `f(x)=A*x^3+B*x^2+C*x+D; A=(${d[0]}), B=(${d[1]}), C=(${d[2]}), D=(${d[3]}). ` + (zh ? '求方程 ' : 'Count the distinct real roots of ') + `f(x)=(${d[4]}), x in [${d[5]},${d[6]}]` + (zh ? ' 在闭区间内的不同实根个数；重根只计一次。' : '; include endpoints and count each multiple root once.');
    return (zh ? '设 ' : 'Let ') + `f(x)=A*((x-h)^3-3*p*(x-h))+c; A=(${d[0]}), h=(${d[1]}), p>0. ` + (zh ? '未知量为 p,c。局部极大值减局部极小值为 ' : 'The unknowns are p,c. The local maximum minus local minimum is ') + `Delta=(${d[2]}); f((${d[3]}))=(${d[4]}). ` + (zh ? '求 ' : 'Find the tangent line at ') + `x=(${d[5]})` + (zh ? ' 处的切线方程。' : '.');
}
function derivativeConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 2400)
    return null; const i = exports.DERIVATIVE_CONSTRAINT_SCOPES.indexOf(scope), nums = [...text.matchAll(/\(([-+]?\d+(?:\/[1-9]\d*)?)\)/g)].map(m => m[1]), intervals = [...text.matchAll(/\[([-+]?\d+(?:\/[1-9]\d*)?),([-+]?\d+(?:\/[1-9]\d*)?)\]/g)].flatMap(m => m.slice(1)), mode = i === 0 ? (text.includes('最大值') || text.includes('maximum') ? 'maximum' : 'minimum') : null, data = i === 0 ? [...nums, ...intervals, mode] : i === 1 || i === 2 ? [...nums, ...intervals] : nums, p = { scope, data }; return data.length === [8, 7, 7, 6][i] && derivativeConstraintPrompt(p, lang) === text ? p : null; }
function derivativeConstraintOptionKey(text, scope) { try {
    if (typeof text !== 'string' || text.length > 300)
        return null;
    const i = exports.DERIVATIVE_CONSTRAINT_SCOPES.indexOf(scope);
    if (i === 1) {
        const m = /^([[(])\s*([-+]?\d+(?:\/[1-9]\d*)?)\s*,\s*([-+]?\d+(?:\/[1-9]\d*)?)\s*([\])])$/.exec(text);
        if (!m)
            return null;
        const l = dread(m[2]), u = dread(m[3]);
        if ((0, exports.dcmp)(l, u) > 0 || !(0, exports.dcmp)(l, u) && (m[1] !== '[' || m[4] !== ']'))
            return null;
        return m[1] + (0, exports.dtxt)(l) + ',' + (0, exports.dtxt)(u) + m[4];
    }
    if (i === 3) {
        const m = /^y=([-+]?\d+(?:\/[1-9]\d*)?)\*x\+\(([-+]?\d+(?:\/[1-9]\d*)?)\)$/.exec(text);
        return m ? 'y=' + (0, exports.dtxt)(dread(m[1])) + '*x+(' + (0, exports.dtxt)(dread(m[2])) + ')' : null;
    }
    const v = dread(text);
    return i === 2 && (v.d !== 1n || v.n < 0n || v.n > 6n) ? null : (0, exports.dtxt)(v);
}
catch {
    return null;
} }
function derivativeConstraintDerive(p) {
    try {
        const i = exports.DERIVATIVE_CONSTRAINT_SCOPES.indexOf(p.scope);
        if (i < 0 || p.data.length !== [8, 7, 7, 6][i])
            return null;
        const v = p.data.slice(0, i === 0 ? 7 : undefined).map(dread), A = v[0];
        if (!v.every(bounded) || A.d !== 1n || !A.n || A.n < -4n || A.n > 4n)
            return null;
        let answer = '', steps = [], groups = [], critical = [], errors = [], witnesses = [];
        const err = (intent, x) => errors.push({ intent, text: typeof x === 'string' ? x : (0, exports.dtxt)(x) });
        if (i === 0) {
            const [, B, t, m, n, l, u] = v, mode = p.data[7];
            if (![t, l, u].every(coordinate) || !['maximum', 'minimum'].includes(mode))
                return null;
            const C = (0, exports.dsub)((0, exports.dsub)(m, (0, exports.dmul)(dq(3), (0, exports.dmul)(A, (0, exports.dpow)(t, 2)))), (0, exports.dmul)(dq(2), (0, exports.dmul)(B, t))), D = (0, exports.dadd)(n, (0, exports.dadd)((0, exports.dmul)(dq(2), (0, exports.dmul)(A, (0, exports.dpow)(t, 3))), (0, exports.dmul)(B, (0, exports.dpow)(t, 2)))), c = [D, C, B, A], e = extrema(c, l, u, mode);
            if (!e || !c.every(bounded))
                return null;
            critical = e.roots;
            answer = (0, exports.dtxt)(e.answer);
            const ep = [(0, exports.dvalue)(c, l), (0, exports.dvalue)(c, u)].sort(exports.dcmp), rp = e.roots.filter(x => (0, exports.dcmp)(x, l) >= 0 && (0, exports.dcmp)(x, u) <= 0).map(x => (0, exports.dvalue)(c, x)).sort(exports.dcmp);
            err('compare_only_endpoints', mode === 'maximum' ? ep[ep.length - 1] : ep[0]);
            err('compare_only_stationary_values', mode === 'maximum' ? rp[rp.length - 1] : rp[0]);
            err('confuse_extremum_with_stationary_coordinate', e.roots[0]);
            err('omit_constant_after_coefficient_recovery', (0, exports.dsub)(e.answer, D));
            err('reverse_maximum_and_minimum', e.values.slice().sort(exports.dcmp)[mode === 'maximum' ? 0 : e.values.length - 1]);
            err('report_tangent_slope_as_extremum', m);
            const tangentValues = [(0, exports.dadd)((0, exports.dmul)(m, l), n), (0, exports.dadd)((0, exports.dmul)(m, u), n)].sort(exports.dcmp), tangentExtremum = mode === 'maximum' ? tangentValues[tangentValues.length - 1] : tangentValues[0];
            if (bounded(tangentExtremum))
                err('optimize_tangent_line_instead_of_cubic', tangentExtremum);
            let slopeWitness = null;
            for (const shift of [dq(1, 2), dq(1), dq(-1, 2), (0, exports.dneg)((0, exports.ddiv)((0, exports.dsub)(e.roots[1], e.roots[0]), dq(4))), (0, exports.ddiv)((0, exports.dsub)(e.roots[1], e.roots[0]), dq(8))]) {
                const r = (0, exports.dsub)(e.roots[0], shift), s = (0, exports.dadd)(e.roots[1], shift), C2 = (0, exports.dmul)(dq(3), (0, exports.dmul)(A, (0, exports.dmul)(r, s))), D2 = (0, exports.dadd)(D, (0, exports.dmul)((0, exports.dsub)(C, C2), t)), c2 = [D2, C2, B, A], e2 = c2.every(bounded) ? extrema(c2, l, u, mode) : null;
                if (e2 && (0, exports.dcmp)(e2.answer, e.answer) && !(0, exports.dcmp)((0, exports.dvalue)(c2, t), (0, exports.dvalue)(c, t)) && (0, exports.dcmp)((0, exports.dvalue)((0, exports.dderivative)(c2), t), m)) {
                    slopeWitness = { omitted: 'tangent_slope', coefficients: c2.map(exports.dtxt), samePoint: (0, exports.dtxt)((0, exports.dvalue)(c2, t)), differentAnswer: (0, exports.dtxt)(e2.answer) };
                    break;
                }
            }
            if (!slopeWitness)
                return null;
            witnesses = [slopeWitness, { omitted: 'tangent_incidence', coefficients: [(0, exports.dadd)(D, ONE), C, B, A].map(exports.dtxt), sameSlope: (0, exports.dtxt)(m), differentAnswer: (0, exports.dtxt)((0, exports.dadd)(e.answer, ONE)) }];
            groups = ['tangent slope', 'tangent incidence', 'closed domain'];
            steps = ['f\'(t)=m=' + (0, exports.dtxt)(m) + '; f(t)=m*t+n=' + (0, exports.dtxt)((0, exports.dvalue)(c, t)), 'C=' + (0, exports.dtxt)(C) + '; D=' + (0, exports.dtxt)(D), 'f\'(x) coefficients=' + (0, exports.dderivative)(c).map(exports.dtxt).join(','), 'all stationary points=' + critical.map(exports.dtxt).join(','), 'endpoint/stationary pairs=' + e.points.map((x, j) => (0, exports.dtxt)(x) + ':' + (0, exports.dtxt)(e.values[j])).join(','), mode + '=' + answer];
        }
        else if (i === 1) {
            const [, h, d, l, u, r, s] = v;
            if (![h, l, u, r, s].every(coordinate) || (0, exports.dcmp)(l, u) >= 0 || (0, exports.dcmp)(r, s) >= 0)
                return null;
            const square = (x) => (0, exports.dpow)((0, exports.dsub)(x, h), 2), minI = (0, exports.dcmp)(l, h) <= 0 && (0, exports.dcmp)(h, u) <= 0 ? Z : [square(l), square(u)].sort(exports.dcmp)[0], maxJ = [square(r), square(s)].sort(exports.dcmp)[1];
            if ((0, exports.dcmp)(maxJ, Z) <= 0 || (0, exports.dcmp)(maxJ, minI) >= 0)
                return null;
            answer = '[' + (0, exports.dtxt)(maxJ) + ',' + (0, exports.dtxt)(minI) + ']';
            err('exclude_valid_lower_equality', '(' + (0, exports.dtxt)(maxJ) + ',' + (0, exports.dtxt)(minI) + ']');
            err('exclude_valid_upper_equality', '[' + (0, exports.dtxt)(maxJ) + ',' + (0, exports.dtxt)(minI) + ')');
            err('reverse_parameter_sign', '[' + (0, exports.dtxt)((0, exports.dneg)(minI)) + ',' + (0, exports.dtxt)((0, exports.dneg)(maxJ)) + ']');
            critical = [h];
            witnesses = [{ omitted: 'J monotonicity', parameter: (0, exports.dtxt)((0, exports.dsub)(maxJ, ONE)), violated: 'p>=max_J' }, { omitted: 'I monotonicity', parameter: (0, exports.dtxt)((0, exports.dadd)(minI, ONE)), violated: 'p<=min_I' }];
            groups = ['cubic derivative', 'I monotonicity', 'J monotonicity'];
            steps = ['f\'_p=3*(' + (0, exports.dtxt)(A) + ')*((x-(' + (0, exports.dtxt)(h) + '))^2-p)', 'A sign=' + (0, exports.dcmp)(A, Z) + '; specified directions follow sign', 'min_I (x-h)^2=' + (0, exports.dtxt)(minI), 'max_J (x-h)^2=' + (0, exports.dtxt)(maxJ), 'p>=' + (0, exports.dtxt)(maxJ) + ' and p<=' + (0, exports.dtxt)(minI), 'isolated zero derivatives allowed; p in ' + answer + '; d=' + (0, exports.dtxt)(d)];
        }
        else if (i === 2) {
            const [, B, C, D, k, l, u] = v, c = [D, C, B, A], roots = dstationary(c);
            if (!roots || ![l, u].every(coordinate) || (0, exports.dcmp)(l, roots[0]) >= 0 || (0, exports.dcmp)(roots[1], u) >= 0)
                return null;
            critical = roots;
            const xs = [l, ...roots, u], signs = xs.map(x => (0, exports.dcmp)((0, exports.dvalue)(c, x), k)), crossings = signs.slice(0, -1).reduce((n, s, j) => n + (s * signs[j + 1] < 0 ? 1 : 0), 0), equal = signs.filter(x => x === 0).length, count = crossings + equal;
            answer = String(count);
            const aSign = (0, exports.dcmp)(A, Z), globalSigns = [-aSign, ...roots.map(x => (0, exports.dcmp)((0, exports.dvalue)(c, x), k)), aSign], globalCount = globalSigns.filter(x => !x).length + globalSigns.slice(0, -1).reduce((n, s, j) => n + (s * globalSigns[j + 1] < 0 ? 1 : 0), 0);
            err('ignore_interval_use_all_real_roots', String(globalCount));
            err('report_derivative_root_count', '2');
            err('assume_degree_equals_distinct_root_count', '3');
            err('omit_tangent_and_endpoint_equality_roots', String(crossings));
            err('count_only_endpoint_equalities', String(Number(!signs[0]) + Number(!signs[3])));
            err('count_multiplicity_as_distinct', String(count + Number(!signs[1]) + Number(!signs[2])));
            err('inspect_only_middle_monotone_piece', String(signs[1] * signs[2] < 0 ? 1 : 0));
            groups = ['cubic critical structure', 'level constraint', 'closed interval'];
            witnesses = xs.map((x, j) => ({ singleton: (0, exports.dtxt)(x), levelSign: signs[j], included: signs[j] === 0 }));
            steps = ['f\'(x) coefficients=' + (0, exports.dderivative)(c).map(exports.dtxt).join(','), 'complete stationary roots=' + roots.map(exports.dtxt).join(','), 'ordered closed-domain partition=' + xs.map(exports.dtxt).join(','), 'signs of f(x)-(' + (0, exports.dtxt)(k) + ') at partition=' + signs.join(','), 'open-piece crossings=' + crossings + '; equal boundary singletons=' + equal, 'distinct roots=' + count + '; each equality counted once'];
        }
        else {
            const [, h, delta, s, y, t] = v;
            if (![h, s, t].every(coordinate) || (0, exports.dcmp)(delta, Z) <= 0 || !(0, exports.dcmp)(s, t))
                return null;
            const absA = dq(A.n < 0n ? -A.n : A.n), q = droot((0, exports.ddiv)(delta, (0, exports.dmul)(dq(4), absA)), 3);
            if (!q || (0, exports.dcmp)(q, Z) <= 0 || (0, exports.dcmp)(q, dq(4)) > 0)
                return null;
            const parameter = (0, exports.dpow)(q, 2), center = (x) => (0, exports.dsub)(x, h), base = (x) => (0, exports.dmul)(A, (0, exports.dsub)((0, exports.dpow)(center(x), 3), (0, exports.dmul)(dq(3), (0, exports.dmul)(parameter, center(x))))), constant = (0, exports.dsub)(y, base(s)), at = (0, exports.dadd)(base(t), constant), slope = (0, exports.dmul)(dq(3), (0, exports.dmul)(A, (0, exports.dsub)((0, exports.dpow)(center(t), 2), parameter))), intercept = (0, exports.dsub)(at, (0, exports.dmul)(slope, t)), line = (m, b) => 'y=' + (0, exports.dtxt)(m) + '*x+(' + (0, exports.dtxt)(b) + ')';
            if (!slope.n || ![constant, slope, intercept].every(bounded))
                return null;
            answer = line(slope, intercept);
            err('omit_tangent_intercept', line(slope, Z));
            err('use_function_value_as_tangent_slope', line(at, (0, exports.dsub)(at, (0, exports.dmul)(at, t))));
            err('force_tangent_through_given_point', line(slope, (0, exports.dsub)(y, (0, exports.dmul)(slope, s))));
            err('omit_vertical_shift_in_tangent', line(slope, (0, exports.dsub)(intercept, constant)));
            const q2 = (0, exports.dadd)(q, dq(1, 2));
            if ((0, exports.dcmp)(q2, dq(4)) > 0)
                return null;
            const p2 = (0, exports.dpow)(q2, 2), base2 = (x) => (0, exports.dmul)(A, (0, exports.dsub)((0, exports.dpow)(center(x), 3), (0, exports.dmul)(dq(3), (0, exports.dmul)(p2, center(x))))), c2 = (0, exports.dsub)(y, base2(s)), m2 = (0, exports.dmul)(dq(3), (0, exports.dmul)(A, (0, exports.dsub)((0, exports.dpow)(center(t), 2), p2))), b2 = (0, exports.dsub)((0, exports.dadd)(base2(t), c2), (0, exports.dmul)(m2, t));
            if (line(m2, b2) === answer)
                return null;
            witnesses = [{ omitted: 'extrema_gap', p: (0, exports.dtxt)(p2), c: (0, exports.dtxt)(c2), samePoint: (0, exports.dtxt)(y), differentAnswer: line(m2, b2) }, { omitted: 'point_value', p: (0, exports.dtxt)(parameter), c: (0, exports.dtxt)((0, exports.dadd)(constant, ONE)), sameGap: (0, exports.dtxt)(delta), differentAnswer: line(slope, (0, exports.dadd)(intercept, ONE)) }];
            critical = [(0, exports.dsub)(h, q), (0, exports.dadd)(h, q)];
            groups = ['positive parameter and extrema gap', 'specified function value', 'specified tangent point'];
            steps = ['stationary points h+-sqrt(p); A sign=' + (0, exports.dcmp)(A, Z), 'Delta=4*abs(A)*p^(3/2)=' + (0, exports.dtxt)(delta), 'unique positive sqrt(p)=' + (0, exports.dtxt)(q) + '; p=' + (0, exports.dtxt)(parameter), 'c=f(s)-A*((s-h)^3-3*p*(s-h))=' + (0, exports.dtxt)(constant), 'f(t)=' + (0, exports.dtxt)(at) + '; f\'(t)=' + (0, exports.dtxt)(slope), 'intercept=f(t)-t*f\'(t)=' + (0, exports.dtxt)(intercept), 'tangent ' + answer];
        }
        const distinct = errors.filter((e, j, a) => e.text !== answer && derivativeConstraintOptionKey(e.text, p.scope) !== null && a.findIndex(z => z.text === e.text) === j).slice(0, 3);
        if (distinct.length !== 3 || new Set(distinct.map(e => e.intent)).size !== 3)
            return null;
        const proof = 'parameters=' + p.data.join(',') + '; ' + steps.join('; '), hardEvidence = { version: 'derivative-constraint-hard-evidence-v1', evidenceSlots: p.data.length, independentEvidenceGroups: groups.length, reasoningSteps: steps.length, quantitativeRelations: 2, groups, effectiveConstraints: witnesses, criticalPoints: critical.map(exports.dtxt), answer, visibleProof: proof, studentCalibrated: false };
        return { answer, text: answer, errors: distinct.map(e => ({ ...e, key: e.text })), proof, steps, hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathDerivativeConstraint(candidate, context = {}) { const scope = derivativeConstraintScopeFrom(context.questionPlan), parameters = derivativeConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? derivativeConstraintDerive(parameters) : null, reasonCodes = []; if (!d)
    reasonCodes.push('derivative_constraint_outside_hard_scope'); if (candidate.subject !== 'math' || candidate.topicId !== 71 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
    reasonCodes.push('derivative_constraint_identity'); const options = candidate.options ?? [], keys = options.map(o => scope ? derivativeConstraintOptionKey(o.text, scope) : null); if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
    reasonCodes.push('derivative_constraint_options'); for (const lang of ['zh', 'en']) {
    const l = candidate.localizations?.[lang];
    if (!parameters || JSON.stringify(derivativeConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
        reasonCodes.push('derivative_constraint_' + lang + '_stem');
    if (JSON.stringify(l?.options?.map(o => [o.id, scope ? derivativeConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
        reasonCodes.push('derivative_constraint_' + lang + '_options');
} const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null; if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('derivative_constraint_answer'); const meta = candidate.optionMetadata ?? []; if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
    reasonCodes.push('derivative_constraint_error_intent'); const scopeId = parameters ? exports.DERIVATIVE_CONSTRAINT_SCOPE_VERSION + ':' + scope : null; return { solverVersion: exports.DERIVATIVE_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.DERIVATIVE_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.DERIVATIVE_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['derivative_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
