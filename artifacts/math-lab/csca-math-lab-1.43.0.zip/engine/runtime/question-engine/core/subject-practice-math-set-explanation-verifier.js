"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SET_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathSetExplanation = verifySubjectPracticeMathSetExplanation;
const subject_practice_math_set_solver_1 = require("./subject-practice-math-set-solver");
exports.SUBJECT_PRACTICE_MATH_SET_EXPLANATION_VERIFIER_VERSION = 'math-set-explanation-verifier-v1';
function verifySubjectPracticeMathSetExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_set_solver_1.solveSubjectPracticeMathSet)(candidate, context);
    const explanation = String(candidate.explanation ?? '').replace(/[，]/g, ',');
    const expected = `{${(solver.expectedSet ?? []).join(',')}}`;
    const normalized = explanation.replace(/\s+/g, '');
    const operationVisible = /(并集|交集|差集|补集|union|intersection|difference|complement|∪|∩|\\)/i.test(explanation);
    const conclusionVisible = normalized.includes(expected);
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_set_explanation_primary_solver_not_verified');
    if (!operationVisible)
        reasonCodes.push('math_set_explanation_operation_missing');
    if (!conclusionVisible)
        reasonCodes.push('math_set_explanation_conclusion_missing_or_wrong');
    return {
        verifierVersion: exports.SUBJECT_PRACTICE_MATH_SET_EXPLANATION_VERIFIER_VERSION,
        status: reasonCodes.length ? 'failed' : 'verified',
        scopeId: solver.scopeId,
        operationVisible,
        conclusionVisible,
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes
    };
}
