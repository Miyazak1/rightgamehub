"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FUNCTION_INTERVAL_EXPLANATION_VERSION = void 0;
exports.renderFunctionIntervalExplanation = renderFunctionIntervalExplanation;
exports.verifySubjectPracticeMathFunctionIntervalExplanation = verifySubjectPracticeMathFunctionIntervalExplanation;
const subject_practice_math_function_interval_solver_1 = require("./subject-practice-math-function-interval-solver");
exports.FUNCTION_INTERVAL_EXPLANATION_VERSION = 'math-function-interval-explanation-v1-bound-bilingual';
// A renderer is shared, but every verification reconstructs the mathematics from the visible stem.
function renderFunctionIntervalExplanation(p, answer, option) {
    let proof = 'f(x)=' + (0, subject_practice_math_function_interval_solver_1.functionExpression)(p) + '; a=' + p.a + '; b=' + p.b;
    if (p.scope.startsWith('quadratic')) {
        proof += '; c=' + p.c + '; h=-(' + p.b + ')/(2*(' + p.a + '))=' + p.h
            + '; f(h)=' + p.k + '; interval=[' + p.l + ', ' + p.r + ']'
            + '; f(' + p.l + ')=' + (0, subject_practice_math_function_interval_solver_1.formatRat)((0, subject_practice_math_function_interval_solver_1.functionEndpointValue)(p, p.l)) + '; f(' + p.r + ')=' + (0, subject_practice_math_function_interval_solver_1.formatRat)((0, subject_practice_math_function_interval_solver_1.functionEndpointValue)(p, p.r))
            + '; axis_location=' + (p.h < p.l ? 'left' : p.h > p.r ? 'right' : p.h === p.l ? 'left_endpoint' : p.h === p.r ? 'right_endpoint' : 'interior')
            + '; f(v)-f(u)=(v-u)*(' + p.a + '*(u+v)+(' + p.b + '))';
    }
    else if (p.scope.startsWith('radical')) {
        proof += '; radicand: ' + p.a + '*x+(' + p.b + ')>=0'
            + '; x' + (p.a > 0 ? '>=' : '<=') + p.z + '; denominator: x-(' + p.p + ')!=0; x!=' + p.p
            + '; root_boundary=' + p.z + ':' + (p.z === p.p ? 'excluded' : 'included') + '; pole=' + p.p + ':excluded';
    }
    else {
        proof += '; pole=' + p.p + '; interval=[' + p.l + ', ' + p.r + ']; pole_outside_interval=true'
            + '; f(x)=' + p.a + '+(' + (p.a * p.p + p.b) + ')/(x-(' + p.p + '))'
            + '; direction=' + (p.a * p.p + p.b > 0 ? 'decreasing' : 'increasing')
            + '; f(' + p.l + ')=' + (0, subject_practice_math_function_interval_solver_1.formatRat)((0, subject_practice_math_function_interval_solver_1.functionEndpointValue)(p, p.l)) + '; f(' + p.r + ')=' + (0, subject_practice_math_function_interval_solver_1.formatRat)((0, subject_practice_math_function_interval_solver_1.functionEndpointValue)(p, p.r))
            + '; endpoint_values_attained=true';
    }
    proof += '; result=' + answer;
    return {
        zh: '先从解析式确定关键位置和限制，再结合区间及边界完成判断：' + proof + '。对应选项 ' + option + '。',
        en: 'Derive the critical position and restrictions from the expression, then apply the interval and its boundaries: ' + proof + '. Option ' + option + '.'
    };
}
function verifySubjectPracticeMathFunctionIntervalExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_function_interval_solver_1.solveSubjectPracticeMathFunctionInterval)(candidate, context), p = solved.parameters;
    const expected = p && solved.expectedAnswer && solved.selectedOptionId ? renderFunctionIntervalExplanation(p, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh);
    const enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en);
    const reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('function_interval_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('function_interval_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('function_interval_explanation_en_mismatch');
    return { verifierVersion: exports.FUNCTION_INTERVAL_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified',
        scopeId: solved.scopeId, zhBound, enBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
