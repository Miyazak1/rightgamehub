"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.intervalSetText = exports.intervalText = exports.INTERVAL_SET_PARAMETER_CONSTRAINTS = exports.INTERVAL_SET_PARAMETER_SCOPES = exports.INTERVAL_SET_PARAMETER_SCOPE_VERSION = exports.INTERVAL_SET_PARAMETER_SOLVER_VERSION = exports.INTERVAL_SET_PARAMETER_TEMPLATE = exports.INTERVAL_SET_PARAMETER_FAMILY = void 0;
exports.intervalSetParameterScopeFrom = intervalSetParameterScopeFrom;
exports.normalizeIntervals = normalizeIntervals;
exports.intervalIntersect = intervalIntersect;
exports.intervalSubtract = intervalSubtract;
exports.parseIntervalSet = parseIntervalSet;
exports.intervalSetParametersValid = intervalSetParametersValid;
exports.intervalSetParameterPrompt = intervalSetParameterPrompt;
exports.intervalSetParametersFrom = intervalSetParametersFrom;
exports.intervalSetParameterDerive = intervalSetParameterDerive;
exports.solveSubjectPracticeMathIntervalSetParameter = solveSubjectPracticeMathIntervalSetParameter;
exports.INTERVAL_SET_PARAMETER_FAMILY = 'math_interval_set_parameter_reasoning';
exports.INTERVAL_SET_PARAMETER_TEMPLATE = exports.INTERVAL_SET_PARAMETER_FAMILY + '_v1';
exports.INTERVAL_SET_PARAMETER_SOLVER_VERSION = 'math-interval-set-parameter-solver-v1-interval-algebra';
exports.INTERVAL_SET_PARAMETER_SCOPE_VERSION = 'math-hard-interval-set-parameter-v1';
exports.INTERVAL_SET_PARAMETER_SCOPES = [
    'translated_interval_subset_two_component_union',
    'translated_interval_disjoint_two_component_union',
    'translated_interval_meets_relative_complement',
    'translated_interval_union_covers_target'
];
exports.INTERVAL_SET_PARAMETER_CONSTRAINTS = { topicCode: 'M-SET-001', boundedIntegerParameters: true, fixedEndpointMin: -24, fixedEndpointMax: 24, movingOffsetMin: -6, movingOffsetMax: 6, maximumConstructionAttempts: 128, parameterDomain: 'bounded_real_interval', minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
const rec = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function intervalSetParameterScopeFrom(value) {
    const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactIntervalSetParameterScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 66 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.INTERVAL_SET_PARAMETER_FAMILY && p?.planTemplate === exports.INTERVAL_SET_PARAMETER_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.INTERVAL_SET_PARAMETER_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'parameterized_interval_set_system' && s?.scenarioAction === scope && exports.INTERVAL_SET_PARAMETER_SCOPES.includes(scope) ? scope : null;
}
const valid = (x) => x.lo < x.hi || (x.lo === x.hi && x.lc && x.hc);
const intervalText = (x) => (x.lc ? '[' : '(') + x.lo + ',' + x.hi + (x.hc ? ']' : ')');
exports.intervalText = intervalText;
function normalizeIntervals(xs) {
    const sorted = xs.filter(valid).map(x => ({ ...x })).sort((a, b) => a.lo - b.lo || Number(b.lc) - Number(a.lc)), out = [];
    for (const x of sorted) {
        const a = out[out.length - 1];
        if (!a || x.lo > a.hi || (x.lo === a.hi && !x.lc && !a.hc)) {
            out.push(x);
            continue;
        }
        if (x.hi > a.hi) {
            a.hi = x.hi;
            a.hc = x.hc;
        }
        else if (x.hi === a.hi)
            a.hc = a.hc || x.hc;
    }
    return out;
}
const intervalSetText = (xs) => normalizeIntervals(xs).map(exports.intervalText).join(' U ') || 'empty';
exports.intervalSetText = intervalSetText;
function intervalIntersect(a, b) {
    return normalizeIntervals(a.flatMap(x => b.map(y => ({ lo: Math.max(x.lo, y.lo), hi: Math.min(x.hi, y.hi), lc: x.lo > y.lo ? x.lc : y.lo > x.lo ? y.lc : x.lc && y.lc, hc: x.hi < y.hi ? x.hc : y.hi < x.hi ? y.hc : x.hc && y.hc }))));
}
function intervalSubtract(a, b) {
    let out = normalizeIntervals(a);
    for (const y of normalizeIntervals(b)) {
        out = out.flatMap(x => { const z = intervalIntersect([x], [y])[0]; return !z ? [x] : [{ lo: x.lo, hi: z.lo, lc: x.lc, hc: !z.lc }, { lo: z.hi, hi: x.hi, lc: !z.hc, hc: x.hc }].filter(valid); });
    }
    return normalizeIntervals(out);
}
function parseIntervalSet(text) {
    if (text === 'empty')
        return [];
    if (typeof text !== 'string' || text.length > 300)
        return null;
    const out = [];
    for (const part of text.split(' U ')) {
        const m = /^([[(])(-?\d{1,3}),(-?\d{1,3})([\])])$/.exec(part);
        if (!m)
            return null;
        const x = { lo: +m[2], hi: +m[3], lc: m[1] === '[', hc: m[4] === ']' };
        if (!valid(x) || Math.abs(x.lo) > 100 || Math.abs(x.hi) > 100)
            return null;
        out.push(x);
    }
    return out.length <= 4 ? normalizeIntervals(out) : null;
}
const contain = (a, b) => ({ lo: b.lo - a.lo, hi: b.hi - a.hi, lc: !a.lc || b.lc, hc: !a.hc || b.hc });
const overlap = (a, b) => ({ lo: b.lo - a.hi, hi: b.hi - a.lo, lc: a.hc && b.lc, hc: a.lc && b.hc });
const cover = (a, r) => {
    const n = normalizeIntervals(r);
    if (!n.length)
        return [];
    const l = n[0], h = n[n.length - 1];
    return normalizeIntervals([{ lo: h.hi - a.hi, hi: l.lo - a.lo, lc: !h.hc || a.hc, hc: !l.lc || a.lc }]);
};
function intervalSetParametersValid(p) {
    const i = exports.INTERVAL_SET_PARAMETER_SCOPES.indexOf(p.scope), all = [p.T, ...p.B, ...(p.U ? [p.U] : []), ...(p.C ? [p.C] : [])];
    if (i < 0 || p.B.length !== 2 || all.some(x => !Number.isSafeInteger(x.lo) || !Number.isSafeInteger(x.hi) || x.lo < -24 || x.hi > 24 || x.lo >= x.hi || typeof x.lc !== 'boolean' || typeof x.hc !== 'boolean') || !p.T.lc || !p.T.hc)
        return false;
    if (!Number.isSafeInteger(p.A.lo) || !Number.isSafeInteger(p.A.hi) || p.A.lo < -6 || p.A.hi > 6 || p.A.hi - p.A.lo < 1 || p.A.hi - p.A.lo > 12 || typeof p.A.lc !== 'boolean' || typeof p.A.hc !== 'boolean')
        return false;
    if (p.B.some(x => x.hi - x.lo < 2 || x.hi - x.lo > 12) || p.B[1].lo - p.B[0].hi < 2 || p.B[1].lo - p.B[0].hi > 10)
        return false;
    if (i < 2)
        return p.U === null && p.C === null;
    if (!p.U || intervalSubtract(p.B, [p.U]).length)
        return false;
    return i === 2 ? p.C === null : !!p.C;
}
const relations = [
    'A(t) subset (B1 U B2)',
    'A(t) intersect (B1 U B2) = empty',
    'A(t) subset U and A(t) intersect (U \\ (B1 U B2)) != empty',
    '(D1 U D2) subset (C U A(t)) and A(t) subset U'
];
function intervalSetParameterPrompt(p, lang) {
    const i = exports.INTERVAL_SET_PARAMETER_SCOPES.indexOf(p.scope), a = (p.A.lc ? '[' : '(') + 't+(' + p.A.lo + '),t+(' + p.A.hi + ')' + (p.A.hc ? ']' : ')');
    const data = 'T=' + (0, exports.intervalText)(p.T) + '; A(t)=' + a + '; ' + (i === 3 ? 'D1' : 'B1') + '=' + (0, exports.intervalText)(p.B[0]) + '; ' + (i === 3 ? 'D2' : 'B2') + '=' + (0, exports.intervalText)(p.B[1]) + (p.U ? '; U=' + (0, exports.intervalText)(p.U) : '') + (p.C ? '; C=' + (0, exports.intervalText)(p.C) : '') + '.';
    return (lang === 'zh' ? '实参数t属于T。区间端点的开闭按括号确定；所有集合均为实数集。' : 'The parameter t is real and belongs to T. Brackets specify endpoint inclusion; all sets are real sets.') + data + (lang === 'zh' ? '求使下列条件同时成立的全部t：' : 'Find all t satisfying the following conditions: ') + relations[i] + '.';
}
function intervalSetParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1500)
        return null;
    const one = (name) => { const m = new RegExp('(?:^|[;。.]) ?' + name + '=([\\[(]-?\\d+,-?\\d+[\\])])').exec(text); const a = m ? parseIntervalSet(m[1]) : null; return a?.length === 1 ? a[0] : null; };
    const t = /T=([\[(]-?\d+,-?\d+[\])])/.exec(text), am = /A\(t\)=([[(])t\+\((-?\d+)\),t\+\((-?\d+)\)([\])])/.exec(text), idx = exports.INTERVAL_SET_PARAMETER_SCOPES.indexOf(scope), B = [one(idx === 3 ? 'D1' : 'B1'), one(idx === 3 ? 'D2' : 'B2')], T = t ? parseIntervalSet(t[1])?.[0] : null;
    if (!T || !am || B.some(x => !x))
        return null;
    const p = { scope, T, A: { lo: +am[2], hi: +am[3], lc: am[1] === '[', hc: am[4] === ']' }, B: B, U: one('U'), C: one('C') };
    return intervalSetParametersValid(p) && intervalSetParameterPrompt(p, lang) === text ? p : null;
}
function intervalSetParameterDerive(p) {
    if (!intervalSetParametersValid(p))
        return null;
    const i = exports.INTERVAL_SET_PARAMETER_SCOPES.indexOf(p.scope), T = [p.T], A = p.A;
    let raw = [], transformed = [], groups = [], branchSets = [];
    if (i === 0) {
        branchSets = p.B.map(b => normalizeIntervals([contain(A, b)]));
        raw = normalizeIntervals(branchSets.flat());
        transformed = p.B;
        // Independently remove the lower and upper containment constraints in both branches.
        groups = [normalizeIntervals(p.B.map(b => ({ lo: p.T.lo, hi: b.hi - A.hi, lc: true, hc: !A.hc || b.hc }))), normalizeIntervals(p.B.map(b => ({ lo: b.lo - A.lo, hi: p.T.hi, lc: !A.lc || b.lc, hc: true })))];
    }
    else if (i === 1) {
        branchSets = p.B.map(b => intervalSubtract(T, [overlap(A, b)]));
        raw = intervalIntersect(branchSets[0], branchSets[1]);
        transformed = p.B;
        groups = [branchSets[0], branchSets[1]];
    }
    else if (i === 2) {
        transformed = intervalSubtract([p.U], p.B);
        const u = normalizeIntervals([contain(A, p.U)]), hits = normalizeIntervals(transformed.map(b => overlap(A, b)));
        branchSets = [u, hits];
        raw = intervalIntersect(u, hits);
        groups = [u, hits];
    }
    else {
        transformed = intervalSubtract(p.B, [p.C]);
        const u = normalizeIntervals([contain(A, p.U)]), coverage = cover(A, transformed);
        branchSets = [u, coverage];
        raw = intervalIntersect(u, coverage);
        groups = [u, coverage];
    }
    const answer = intervalIntersect(T, raw), key = (0, exports.intervalSetText)(answer), domain = (0, exports.intervalSetText)(T);
    if (!answer.length || key === domain || answer.length > 4)
        return null;
    const effective = groups.map(g => ({ relaxedSet: (0, exports.intervalSetText)(intervalIntersect(g, T)), witnessSet: (0, exports.intervalSetText)(intervalSubtract(intervalIntersect(g, T), answer)) }));
    if (effective.length !== 2 || effective.some(g => g.witnessSet === 'empty'))
        return null;
    if ((i === 0 && answer.length !== 2) || (i === 1 && answer.length < 2) || (i === 2 && transformed.length < 2) || (i === 3 && (transformed.length !== 2 || (0, exports.intervalSetText)(transformed) === (0, exports.intervalSetText)(p.B))))
        return null;
    const proof = 'T=' + domain + '; A-offsets=' + (0, exports.intervalText)(A) + '; inputs=' + p.B.map(exports.intervalText).join(' U ') + '; U=' + (p.U ? (0, exports.intervalText)(p.U) : 'none') + '; C=' + (p.C ? (0, exports.intervalText)(p.C) : 'none') + '; transformed=' + (0, exports.intervalSetText)(transformed) + '; parameterBranches=' + branchSets.map(exports.intervalSetText).join(' | ') + '; combined=' + (0, exports.intervalSetText)(raw) + '; intersectT=' + key;
    const certificate = { version: 'interval-set-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 3, reasoningSteps: 4, quantitativeRelations: 2, effectiveConstraints: effective, transformedSet: (0, exports.intervalSetText)(transformed), branchSets: branchSets.map(exports.intervalSetText), domain, answer: key, visibleProof: proof, studentCalibrated: false };
    // Three different mathematical mistakes: wrong left contact, wrong right contact, negated predicate.
    const flip = (which) => { const z = answer.map(x => ({ ...x })); if (which === 'left')
        z[0].lc = !z[0].lc;
    else
        z[z.length - 1].hc = !z[z.length - 1].hc; return normalizeIntervals(z); };
    const errors = [{ intent: 'reverse_left_contact_inclusion', set: flip('left') }, { intent: 'reverse_right_contact_inclusion', set: flip('right') }, { intent: 'negate_required_set_predicate', set: intervalSubtract(T, answer) }].map(e => ({ intent: e.intent, text: (0, exports.intervalSetText)(e.set), key: (0, exports.intervalSetText)(e.set) }));
    if (new Set([key, ...errors.map(e => e.key)]).size !== 4)
        return null;
    return { answer: key, text: key, errors, proof, hardEvidence: certificate };
}
function solveSubjectPracticeMathIntervalSetParameter(candidate, context = {}) {
    const scope = intervalSetParameterScopeFrom(context.questionPlan), parameters = intervalSetParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? intervalSetParameterDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('interval_set_parameter_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 66 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('interval_set_parameter_identity');
    const options = candidate.options ?? [], keys = options.map(o => { const s = parseIntervalSet(o.text); return s ? (0, exports.intervalSetText)(s) : null; });
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('interval_set_parameter_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(intervalSetParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('interval_set_parameter_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, parseIntervalSet(o.text) === null ? null : (0, exports.intervalSetText)(parseIntervalSet(o.text))])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('interval_set_parameter_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('interval_set_parameter_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('interval_set_parameter_error_intent');
    const scopeId = parameters ? exports.INTERVAL_SET_PARAMETER_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.INTERVAL_SET_PARAMETER_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.INTERVAL_SET_PARAMETER_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.INTERVAL_SET_PARAMETER_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['interval_set_parameter_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
