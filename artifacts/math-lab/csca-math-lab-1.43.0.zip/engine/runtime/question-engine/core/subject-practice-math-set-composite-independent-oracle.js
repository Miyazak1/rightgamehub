"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathSetCompositeWithIndependentOracle = verifySubjectPracticeMathSetCompositeWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_INDEPENDENT_ORACLE_VERSION = 'math-set-composite-independent-oracle-v1';
function obj(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function scope(context) {
    const p = obj(context.questionPlan);
    const r = obj(p?.renderConstraints);
    const s = String(r?.exactSetCompositeScope ?? '');
    return String(p?.taskFamily ?? '') === 'math_finite_set_composite_operation'
        && String(p?.planTemplate ?? '') === 'math_finite_set_composite_operation_v1'
        && ['union_then_intersection', 'intersection_then_union', 'difference_then_intersection', 'complement_then_union'].includes(s) ? s : null;
}
function values(text, name) {
    const source = String(text).replace(/[，]/g, ',');
    const match = name ? source.match(new RegExp(`${name}\\s*=\\s*\\{([^{}]*)\\}`, 'i')) : source.match(/\{([^{}]*)\}/);
    if (!match)
        return null;
    const parsed = match[1].trim() ? match[1].split(',').map((x) => Number(x.trim())) : [];
    return parsed.every((x) => Number.isInteger(x) && x >= 0 && x <= 30) ? parsed : null;
}
function mask(items) { return items.reduce((out, n) => out | (1 << n), 0); }
function verifySubjectPracticeMathSetCompositeWithIndependentOracle(candidate, context = {}) {
    const exactScope = scope(context);
    const u = values(candidate.prompt, 'U');
    const a = values(candidate.prompt, 'A');
    const b = values(candidate.prompt, 'B');
    const c = values(candidate.prompt, 'C');
    const parsed = Boolean(exactScope && u && a && b && (exactScope === 'complement_then_union' || c));
    const um = mask(u ?? []);
    const am = mask(a ?? []);
    const bm = mask(b ?? []);
    const cm = mask(c ?? []);
    const wanted = exactScope === 'union_then_intersection' ? (am | bm) & cm
        : exactScope === 'intersection_then_union' ? (am & bm) | cm
            : exactScope === 'difference_then_intersection' ? (am & ~bm) & cm
                : (um & ~am) | bm;
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const item = values(option.text);
        const truth = parsed && item !== null && mask(item) === wanted;
        return { optionId: option.id, verdict: item === null ? 'unknown' : truth ? 'true' : 'false' };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!parsed)
        reasonCodes.push('math_set_composite_oracle_prompt_or_plan_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_set_composite_oracle_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_set_composite_oracle_answer_not_unique');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_set_composite_oracle_generator_disagreement');
    return {
        oracleVersion: exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_INDEPENDENT_ORACLE_VERSION,
        status: reasonCodes.length ? (parsed ? 'disagreed' : 'abstained') : 'verified',
        scopeId: parsed ? `math-medium-set-composite-v1:${exactScope}` : null,
        exactScope, scopeMatched: parsed, optionVerdicts, trueOptionIds, selectedOptionId,
        agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
