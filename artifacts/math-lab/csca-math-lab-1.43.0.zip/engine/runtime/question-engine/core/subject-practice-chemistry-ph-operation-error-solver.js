"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_SCOPE_VERSION = exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_SOLVER_VERSION = void 0;
exports.solveSubjectPracticeChemistryPhOperationError = solveSubjectPracticeChemistryPhOperationError;
exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_SOLVER_VERSION = 'chemistry-ph-operation-error-solver-v2-common-species-and-indeterminate';
exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_SCOPE_VERSION = 'chemistry-ph-operation-error-scope-v1';
function recordFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function normalized(value) {
    return String(value ?? '')
        .replace(/[，、；]/g, ',')
        .replace(/[。]/g, '.')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
}
function inferScope(prompt) {
    const source = normalized(prompt);
    const acid = /(酸性溶液|强酸溶液|盐酸|硝酸|\bhcl\b|\bhno3\b|acidic solution|strong acid solution)/i.test(source);
    const base = /(碱性溶液|强碱溶液|氢氧化钠|氢氧化钾|\bnaoh\b|\bkoh\b|alkaline solution|basic solution|strong base solution)/i.test(source);
    if (acid === base)
        return null;
    const wetPaper = /((?:润湿|湿润).{0,18}ph.{0,8}试纸|ph.{0,8}试纸.{0,18}(?:润湿|湿润)|wet(?:ted)?\s+(?:the\s+)?ph paper|ph paper.{0,18}(?:wet|moisten))/i.test(source);
    if (wetPaper)
        return acid ? 'ph_paper_wetting_acid' : 'ph_paper_wetting_base';
    const flask = /(容量瓶|volumetric flask)/i.test(source);
    const overfill = /(超过.{0,10}刻度线|高于.{0,10}刻度线|加水过量|above the calibration mark|past the calibration mark|overfill)/i.test(source);
    const underfill = /(未到.{0,10}刻度线|低于.{0,10}刻度线|加水不足|below the calibration mark|short of the calibration mark|underfill)/i.test(source);
    if (!flask || overfill === underfill)
        return null;
    if (overfill)
        return acid ? 'volumetric_overfill_acid' : 'volumetric_overfill_base';
    return acid ? 'volumetric_underfill_acid' : 'volumetric_underfill_base';
}
function modelFor(scope) {
    const acid = scope.endsWith('_acid');
    const dilution = scope.startsWith('ph_paper_wetting_') || scope.startsWith('volumetric_overfill_');
    const concentrationDirection = dilution ? 'decrease' : 'increase';
    const expectedBias = acid
        ? (dilution ? 'higher' : 'lower')
        : (dilution ? 'lower' : 'higher');
    return { operationScope: scope, solutionCharacter: acid ? 'acid' : 'base', concentrationDirection, expectedBias };
}
function biasFromOption(value) {
    const source = normalized(value);
    const matches = [];
    if (/(偏高|较高|升高|higher|too high|increase)/i.test(source))
        matches.push('higher');
    if (/(偏低|较低|降低|lower|too low|decrease)/i.test(source))
        matches.push('lower');
    if (/(不变|无影响|unchanged|no change|unaffected)/i.test(source))
        matches.push('unchanged');
    if (/(无法判断|无法确定|不能确定|indeterminate|cannot be determined|insufficient)/i.test(source))
        matches.push('indeterminate');
    return matches.length === 1 ? matches[0] : null;
}
function verificationScopeFor(questionPlan, operationScope) {
    const plan = recordFrom(questionPlan);
    const constraints = recordFrom(plan?.renderConstraints);
    const contractPresent = Boolean(plan
        && normalized(plan.schemaVersion) === 'subject-practice-question-plan-v1'
        && normalized(plan.policyVersion) === 'subject-practice-question-plan-policy-v1'
        && normalized(plan.planTemplate) === 'basic_ph_measurement_preparation_error_v1'
        && normalized(plan.taskFamily) === 'basic_ph_measurement_or_preparation_error_judgement'
        && normalized(plan.targetDifficulty) === 'basic'
        && constraints?.forbidDirectPhCalculation === true
        && Number(constraints?.maxChemistryReasoningMoves) === 2);
    const planned = normalized(constraints?.exactChemistryOperationErrorScope);
    const reasonCodes = [];
    if (!contractPresent)
        reasonCodes.push('chemistry_ph_operation_error_scope_plan_contract_missing');
    if (contractPresent && !operationScope)
        reasonCodes.push('chemistry_ph_operation_error_scope_prompt_unparsed');
    if (contractPresent && operationScope && planned !== operationScope)
        reasonCodes.push('chemistry_ph_operation_error_scope_plan_prompt_mismatch');
    const matched = contractPresent && Boolean(operationScope) && planned === operationScope && reasonCodes.length === 0;
    return {
        scopeVersion: exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_SCOPE_VERSION,
        scopeId: contractPresent && operationScope ? `chemistry-ph-operation-error-v1:${operationScope}` : null,
        status: !contractPresent ? 'missing_plan_contract' : matched ? 'matched' : 'mismatch',
        matched,
        operationScope,
        reasonCodes
    };
}
function solveSubjectPracticeChemistryPhOperationError(candidate, context = {}) {
    const operationScope = inferScope(candidate.prompt);
    const model = operationScope ? modelFor(operationScope) : null;
    const verificationScope = verificationScopeFor(context.questionPlan, operationScope);
    const optionVerdicts = candidate.options.map((option) => {
        const parsedBias = biasFromOption(option.text);
        return {
            optionId: option.id,
            verdict: !parsedBias || !model ? 'unknown' : parsedBias === model.expectedBias ? 'true' : 'false',
            parsedBias,
            reasonCode: !parsedBias ? 'chemistry_ph_operation_error_option_unparsed'
                : !model ? 'chemistry_ph_operation_error_prompt_unparsed'
                    : parsedBias === model.expectedBias ? 'chemistry_ph_operation_error_bias_matches' : 'chemistry_ph_operation_error_bias_mismatch'
        };
    });
    const hasUnknown = optionVerdicts.some((item) => item.verdict === 'unknown');
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const uniqueAnswer = !hasUnknown && trueOptionIds.length === 1;
    const selectedOptionId = uniqueAnswer ? trueOptionIds[0] : null;
    const agreesWithGenerator = uniqueAnswer && selectedOptionId === candidate.correctAnswer;
    const reasonCodes = [...verificationScope.reasonCodes];
    if (!operationScope)
        reasonCodes.push('chemistry_ph_operation_error_prompt_unparsed');
    if (hasUnknown)
        reasonCodes.push('chemistry_ph_operation_error_option_unparsed');
    if (!hasUnknown && trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length
            ? 'chemistry_ph_operation_error_multiple_true_options'
            : 'chemistry_ph_operation_error_no_true_option');
    if (uniqueAnswer && !agreesWithGenerator)
        reasonCodes.push('chemistry_ph_operation_error_generator_answer_disagrees');
    const status = !operationScope || hasUnknown
        ? 'unparsed'
        : uniqueAnswer && agreesWithGenerator && verificationScope.matched
            ? 'verified'
            : 'conflict';
    return {
        solverVersion: exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_SOLVER_VERSION,
        taskFamily: 'basic_ph_measurement_or_preparation_error_judgement',
        status,
        parsed: Boolean(operationScope) && !hasUnknown,
        operationScope,
        expectedBias: model?.expectedBias ?? null,
        canonicalTask: model,
        optionVerdicts,
        trueOptionIds,
        selectedOptionId,
        uniqueAnswer,
        agreesWithGenerator,
        evidenceBoundary: 'prompt_and_visible_options_only',
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes: Array.from(new Set(reasonCodes)),
        verificationScope
    };
}
