"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NORMAL_TWO_STEP_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathNormalTwoStepLocalGenerator = createSubjectPracticeMathNormalTwoStepLocalGenerator;
const subject_practice_math_normal_distribution_two_step_solver_1 = require("./subject-practice-math-normal-distribution-two-step-solver");
const subject_practice_math_normal_distribution_two_step_independent_oracle_1 = require("./subject-practice-math-normal-distribution-two-step-independent-oracle");
const subject_practice_math_normal_distribution_two_step_explanation_verifier_1 = require("./subject-practice-math-normal-distribution-two-step-explanation-verifier");
exports.NORMAL_TWO_STEP_GENERATOR_VERSION = 'math-normal-distribution-two-step-generator-v1-bounded';
function createSubjectPracticeMathNormalTwoStepLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, exactScope = (0, subject_practice_math_normal_distribution_two_step_solver_1.normalTwoStepScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.NORMAL_TWO_STEP_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['normal_two_step_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 77 || b.topicCode !== 'M-STAT-002' || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        const n = seed % 100000, sigma = 2 + n % 11, mu = -20 + (n * 7) % 101, i = subject_practice_math_normal_distribution_two_step_solver_1.NORMAL_TWO_STEP_SCOPES.indexOf(exactScope);
        const p = { scope: exactScope, mu, variance: sigma * sigma, a: 0, b: 0, direction: 'left', tail: 0 };
        if (i === 0 || i === 2) {
            const pairs = i === 0 ? [[-2, -1], [-2, 1], [-1, 2], [1, 2]] : [[-3, -1], [-2, 1], [-1, 2], [1, 3], [-3, 2], [-2, 3]], pair = pairs[n % pairs.length];
            p.a = mu + pair[0] * sigma;
            p.b = mu + pair[1] * sigma;
        }
        else {
            p.direction = n % 2 ? 'right' : 'left';
            const k = 1 + Math.floor(n / 2) % (i === 1 ? 2 : 3);
            p.tail = (i === 1 ? [1587, 228] : [1600, 250, 15])[k - 1];
            if (i === 1)
                p.a = mu + (p.direction === 'left' ? -1 : 1) * k * sigma;
        }
        const d = (0, subject_practice_math_normal_distribution_two_step_solver_1.normalTwoStepDerive)(p);
        if (!d)
            return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts: 1 };
        const choices = d.errors.map(e => ({ text: e.text, intent: e.intent })), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { text: d.text, intent: '' });
        const options = choices.map((e, j) => ({ id: 'ABCD'[j], text: e.text })), prompt = (0, subject_practice_math_normal_distribution_two_step_solver_1.normalTwoStepPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_normal_distribution_two_step_solver_1.normalTwoStepPrompt)(p, 'en'), explanation = (0, subject_practice_math_normal_distribution_two_step_explanation_verifier_1.renderNormalTwoStepExplanation)(p, d.answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 77, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['正态分布的基本概念', exactScope], optionMetadata: choices.flatMap((e, j) => e.intent ? [{ optionId: 'ABCD'[j], distractorIntent: e.intent, misconceptionTags: [e.intent] }] : []), localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['正态分布的基本概念', exactScope] }, en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Normal distribution', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_normal_distribution_two_step_solver_1.solveSubjectPracticeMathNormalTwoStep)(candidate, context), oracleEvidence = (0, subject_practice_math_normal_distribution_two_step_independent_oracle_1.verifySubjectPracticeMathNormalTwoStepWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_normal_distribution_two_step_explanation_verifier_1.verifySubjectPracticeMathNormalTwoStepExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, parameterAttempts: 1, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
