"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticePhysicsNewtonForceExplanation = verifySubjectPracticePhysicsNewtonForceExplanation;
const subject_practice_physics_newton_force_solver_1 = require("./subject-practice-physics-newton-force-solver");
exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_EXPLANATION_VERIFIER_VERSION = 'physics-newton-basic-force-explanation-verifier-v1-bilingual-parameter-bound';
function compact(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/²/g, '^2').replace(/\s+/g, ''); }
function has(t, label, value) { return new RegExp(`${label}=${String(value).replace('-', '\\-')}(?:[^0-9.]|$)`, 'i').test(t); }
function verifySubjectPracticePhysicsNewtonForceExplanation(candidate, context = {}) { const solver = (0, subject_practice_physics_newton_force_solver_1.solveSubjectPracticePhysicsNewtonForce)(candidate, context), p = solver.parameters ?? {}, zh = compact(candidate.localizations?.zh?.explanation ?? candidate.explanation), en = compact(candidate.localizations?.en?.explanation), required = []; if (p.massKg !== undefined)
    required.push(['m', p.massKg]); if (p.accelerationMps2 !== undefined)
    required.push(['a', p.accelerationMps2]); if (p.netForceN !== undefined)
    required.push(['F_?net', p.netForceN]); if (p.rightForceN !== undefined)
    required.push(['F_?right', p.rightForceN]); if (p.leftForceN !== undefined)
    required.push(['F_?left', p.leftForceN]); if (p.knownForceN !== undefined)
    required.push(['F_?known', p.knownForceN]); const zhParametersBound = required.length > 0 && required.every(([l, v]) => has(zh, l, v)), enParametersBound = required.length > 0 && required.every(([l, v]) => has(en, l, v)), expected = solver.expectedSiValue, unit = solver.expectedDimension === 'force' ? 'N' : 'm/s^2', conclusion = expected === null ? '' : `${expected}${unit}`, zhConclusionBound = Boolean(conclusion && zh.toLowerCase().includes(conclusion.toLowerCase())), enConclusionBound = Boolean(conclusion && en.toLowerCase().includes(conclusion.toLowerCase())); const formulaBound = /(F_?net=ma|a=F_?net\/m|F_?right-F_?left|ΣF=0|sumofforcesiszero|newton'?ssecondlaw)/i.test(`${zh}${en}`); const reasonCodes = []; if (solver.status !== 'verified')
    reasonCodes.push('physics_newton_force_explanation_primary_solver_not_verified'); if (!zhParametersBound)
    reasonCodes.push('physics_newton_force_explanation_zh_parameters_not_bound'); if (!enParametersBound)
    reasonCodes.push('physics_newton_force_explanation_en_parameters_not_bound'); if (!zhConclusionBound)
    reasonCodes.push('physics_newton_force_explanation_zh_conclusion_missing_or_wrong'); if (!enConclusionBound)
    reasonCodes.push('physics_newton_force_explanation_en_conclusion_missing_or_wrong'); if (!formulaBound)
    reasonCodes.push('physics_newton_force_explanation_formula_missing'); return { verifierVersion: exports.SUBJECT_PRACTICE_PHYSICS_NEWTON_FORCE_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solver.scopeId, zhParametersBound, enParametersBound, zhConclusionBound, enConclusionBound, formulaBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
