"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.INTERVAL_SET_PARAMETER_EXPLANATION_VERSION = void 0;
exports.renderIntervalSetParameterExplanation = renderIntervalSetParameterExplanation;
exports.verifySubjectPracticeMathIntervalSetParameterExplanation = verifySubjectPracticeMathIntervalSetParameterExplanation;
const subject_practice_math_interval_set_parameter_solver_1 = require("./subject-practice-math-interval-set-parameter-solver");
exports.INTERVAL_SET_PARAMETER_EXPLANATION_VERSION = 'math-interval-set-parameter-explanation-v1-bound-bilingual';
function renderIntervalSetParameterExplanation(p, answer, option) {
    const d = (0, subject_practice_math_interval_set_parameter_solver_1.intervalSetParameterDerive)(p);
    if (!d || d.answer !== answer)
        throw new Error('interval_explanation_invalid_input');
    const witnesses = d.hardEvidence.effectiveConstraints.map((c, j) => 'constraint' + (j + 1) + ' relaxed=' + c.relaxedSet + ', extra=' + c.witnessSet).join('; ');
    return { zh: '先保留各端点开闭，将原集合关系转为区间条件，再合并分支并与参数域取交。' + d.proof + '。两项约束均不可省略：' + witnesses + '。因此t属于' + answer + '，选' + option + '。',
        en: 'Preserve endpoint inclusion, transform the set relation into interval conditions, combine the branches and intersect the parameter domain. ' + d.proof + '. Neither constraint is redundant: ' + witnesses + '. Thus t belongs to ' + answer + '; choose ' + option + '.' };
}
function verifySubjectPracticeMathIntervalSetParameterExplanation(candidate, context = {}) {
    const s = (0, subject_practice_math_interval_set_parameter_solver_1.solveSubjectPracticeMathIntervalSetParameter)(candidate, context), e = s.status === 'verified' && s.parameters && s.expectedAnswer && s.selectedOptionId ? renderIntervalSetParameterExplanation(s.parameters, s.expectedAnswer, s.selectedOptionId) : null;
    const zhBound = !!e && candidate.explanation === e.zh && candidate.localizations?.zh?.explanation === e.zh, enBound = !!e && candidate.localizations?.en?.explanation === e.en, reasonCodes = zhBound && enBound ? [] : ['interval_set_parameter_explanation_not_bound'];
    return { verifierVersion: exports.INTERVAL_SET_PARAMETER_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: s.scopeId, zhBound, enBound, hardEvidence: s.hardEvidence, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
