"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SOLID_GEOMETRY_CONSTRAINT_ORACLE_VERSION = void 0;
exports.solidGeometryConstraintIndependentCalculation = solidGeometryConstraintIndependentCalculation;
exports.verifySubjectPracticeMathSolidGeometryConstraintWithIndependentOracle = verifySubjectPracticeMathSolidGeometryConstraintWithIndependentOracle;
// Independent visible-text parser and arithmetic; no runtime dependency on the Solver or generator.
exports.SOLID_GEOMETRY_CONSTRAINT_ORACLE_VERSION = 'math-solid-geometry-constraint-oracle-v1-independent-spatial-certificates';
const scopes = ["cuboid_face_diagonals_division_point_plane_distance_squared", "cuboid_volume_face_areas_skew_lines_cosine_squared", "rectangular_pyramid_lateral_edge_section_plane_cosine_squared", "cone_two_sections_frustum_total_surface_area"];
const abs = (n) => n < 0n ? -n : n;
class R {
    n;
    d;
    constructor(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || abs(a).toString(2).length > 512 || abs(b).toString(2).length > 512)
        throw Error('oracle_arithmetic_bound'); if (b < 0n) {
        a = -a;
        b = -b;
    } let x = abs(a), y = b; while (y) {
        const t = x % y;
        x = y;
        y = t;
    } this.n = a / x; this.d = b / x; }
    add(q) { return new R(this.n * q.d + q.n * this.d, this.d * q.d); }
    neg() { return new R(-this.n, this.d); }
    sub(q) { return this.add(q.neg()); }
    mul(q) { return new R(this.n * q.n, this.d * q.d); }
    div(q) { return new R(this.n * q.d, this.d * q.n); }
    sq() { return this.mul(this); }
    eq(q) { return this.n === q.n && this.d === q.d; }
    cmp(q) { const n = this.n * q.d - q.n * this.d; return n < 0n ? -1 : n > 0n ? 1 : 0; }
    toString() { return String(this.n) + (this.d === 1n ? '' : '/' + this.d); }
}
const z = new R(0), one = new R(1), two = new R(2), four = new R(4);
function read(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('oracle_rational_syntax'); const [a, b = '1'] = s.split('/'), q = new R(BigInt(a), BigInt(b)); if (abs(q.n) > 1000000000000n || q.d > 1000000000n)
    throw Error('oracle_input_bound'); return q; }
const object = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
const names = [["P", "Q", "R", "t"], ["U", "W", "V", "t"], ["a", "b", "E", "t"], ["P", "A", "B", "C"]];
const startsZh = ["长方体中 O=(0,0,0)、U=(a,0,0)、V=(0,b,0)、W=(0,0,c)，对顶点 K=(a,b,c)，a、b、c>0（长度单位 cm）。三个过 O 的面对角线长度的平方为 P=a^2+b^2、Q=a^2+c^2、R=b^2+c^2（单位 cm^2）。T 在线段 OK 上，OT/OK=t。已知 ", "长方体 ABCD-A1B1C1D1 中 A=(0,0,0)、B=(a,0,0)、C=(a,b,0)、A1=(0,0,c)，a、b、c>0（长度单位 cm）。相邻面面积 U=ab、W=ac（单位 cm^2），体积 V=abc（单位 cm^3）。E 在线段 CC1 上，CE/CC1=t。已知 ", "矩形底四棱锥 S-ABCD 中，AB=a cm、BC=b cm，S 在底面中心的正上方，SA^2=E cm^2。T 在线段 AB 内，AT/AB=t。已知 ", "直圆锥的轴截面周长为 P cm，包含底面的总表面积为 Aπ cm^2。两个内部截面均平行于底面，面积依次为 Bπ、Cπ cm^2，且 0<B<C。已知 "], startsEn = ["In a cuboid, O=(0,0,0), U=(a,0,0), V=(0,b,0), W=(0,0,c), and opposite vertex K=(a,b,c), with a,b,c>0 in cm. The three face-diagonal squares at O are P=a^2+b^2, Q=a^2+c^2, R=b^2+c^2 in cm^2. T lies on OK with OT/OK=t. Given ", "In cuboid ABCD-A1B1C1D1, A=(0,0,0), B=(a,0,0), C=(a,b,0), A1=(0,0,c), with a,b,c>0 in cm. Adjacent face areas are U=ab and W=ac in cm^2, and volume V=abc in cm^3. E lies on CC1 with CE/CC1=t. Given ", "In rectangular pyramid S-ABCD, AB=a cm, BC=b cm, S lies vertically above the base center, and SA^2=E cm^2. T is inside segment AB with AT/AB=t. Given ", "A right circular cone has axial-section perimeter P cm and total surface area Aπ cm^2 including the base. Two internal sections parallel to the base have areas Bπ and Cπ cm^2, with 0<B<C. Given "], endsZh = ["求点 T 到平面 UVW 的距离平方（单位 cm^2）。", "求异面直线 AB1 与 BE 所成锐角的余弦平方。", "求平面 SAB 与 SCT 所成锐角的余弦平方。", "求两截面之间圆台的总表面积，包含两端圆面（单位 cm^2，保留 π）。"], endsEn = ["Find the squared distance from T to plane UVW in cm^2.", "Find the squared cosine of the acute angle between skew lines AB1 and BE.", "Find the squared cosine of the acute angle between planes SAB and SCT.", "Find the total surface area of the frustum between these sections, including both circular ends, in cm^2; keep π exact."];
const starts = { zh: startsZh, en: startsEn }, ends = { zh: endsZh, en: endsEn };
function parse(text, i, lang) { if (i < 0 || typeof text !== 'string' || text.length > 3000 || !text.startsWith(starts[lang][i]) || !text.endsWith('. ' + ends[lang][i]))
    throw Error('oracle_stem'); const middle = text.slice(starts[lang][i].length, -('. ' + ends[lang][i]).length), parts = middle.split(', '); if (parts.length !== names[i].length)
    throw Error('oracle_givens'); return parts.map((part, j) => { const m = part.match(/^([A-Za-z0-9]+)=\(([-+]?\d+(?:\/[1-9]\d*)?)\)$/); if (!m || m[1] !== names[i][j])
    throw Error('oracle_parameter_label'); read(m[2]); return m[2]; }); }
function eliminate(rows) { const a = rows.map(r => r.slice()), n = a.length; if (a.some(r => r.length !== n + 1))
    throw Error('oracle_linear_dimension'); const pivots = []; for (let c = 0; c < n; c++) {
    const pivot = a.findIndex((r, j) => j >= c && r[c].n !== 0n);
    if (pivot < 0)
        throw Error('oracle_singular_equations');
    [a[c], a[pivot]] = [a[pivot], a[c]];
    const d = a[c][c];
    pivots.push(String(d));
    a[c] = a[c].map(v => v.div(d));
    for (let j = 0; j < n; j++)
        if (j !== c) {
            const factor = a[j][c];
            a[j] = a[j].map((v, k) => v.sub(factor.mul(a[c][k])));
        }
} const solution = a.map(r => r[n]); for (const r of rows)
    if (!r.slice(0, n).reduce((s, v, j) => s.add(v.mul(solution[j])), z).eq(r[n]))
        throw Error('oracle_linear_round_trip'); return { solution, pivots }; }
function calculate(data, i) {
    if (i < 0 || i > 3 || data.length !== 4)
        throw Error('oracle_parameters');
    const v = data.map(read);
    let answer, certificate;
    if (i === 0) {
        const [P, Q, S, t] = v, e = eliminate([[one, one, z, P], [one, z, one, Q], [z, one, one, S]]), [X, Y, Z] = e.solution;
        if ([P, Q, S, X, Y, Z].some(x => x.n <= 0n) || t.n <= 0n || t.cmp(one) >= 0 || t.eq(new R(1, 3)))
            throw Error('oracle_impossible_cuboid');
        const sixteenArea = two.mul(P.mul(Q).add(P.mul(S)).add(Q.mul(S))).sub(P.sq().add(Q.sq()).add(S.sq()));
        if (sixteenArea.n <= 0n)
            throw Error('oracle_degenerate_section');
        const sixVolumeSquared = one.sub(new R(3).mul(t)).sq().mul(X).mul(Y).mul(Z);
        answer = four.mul(sixVolumeSquared).div(sixteenArea);
        certificate = { method: 'independent_elimination_Heron_and_tetrahedron_volume', squaredEdges: e.solution.map(String), sixteenAreaSquared: String(sixteenArea), sixVolumeSquared: String(sixVolumeSquared), complete: true };
    }
    else if (i === 1) {
        const [U, W, V, t] = v;
        if ([U, W, V, t].some(x => x.n <= 0n) || t.cmp(one) >= 0)
            throw Error('oracle_invalid_dimensions');
        const b = V.div(W), c = V.div(U), a = U.div(b);
        if (!a.mul(c).eq(W) || !a.mul(b).mul(c).eq(V))
            throw Error('oracle_dimension_round_trip');
        const first = a.sq().add(c.sq()), second = b.sq().add(t.mul(c).sq()), difference = a.sq().add(b.sq()).add(c.mul(one.sub(t)).sq()), twiceDot = first.add(second).sub(difference);
        answer = twiceDot.sq().div(four.mul(first).mul(second));
        certificate = { method: 'independent_area_ratio_reconstruction_translated_triangle_cosine_law', edges: [a, b, c].map(String), triangleSquaredLengths: [first, second, difference].map(String), nonzeroSkewTripleProduct: String(a.mul(b).mul(c)), complete: true };
    }
    else if (i === 2) {
        const [a, b, E, t] = v, H = E.sub(a.sq().add(b.sq()).div(four));
        if ([a, b, E, H, t].some(x => x.n <= 0n) || t.cmp(one) >= 0)
            throw Error('oracle_invalid_pyramid');
        const metric = (u, w) => u[0].mul(w[0]).add(u[1].mul(w[1])).add(H.mul(u[2]).mul(w[2]));
        const axis = [a.mul(t.sub(new R(1, 2))), b.div(two).neg(), one.neg()], u = [a.div(two).neg(), b.div(two).neg(), one.neg()], w = [a.div(two), b.div(two), one.neg()];
        const L = metric(axis, axis), U = metric(u, u), W = metric(w, w), du = metric(u, axis), dw = metric(w, axis), D = metric(u, w), Uperp = U.sub(du.sq().div(L)), Wperp = W.sub(dw.sq().div(L)), projection = D.sub(du.mul(dw).div(L));
        if ([L, Uperp, Wperp].some(x => x.n <= 0n))
            throw Error('oracle_degenerate_planes');
        answer = projection.sq().div(Uperp.mul(Wperp));
        certificate = { method: 'independent_common_edge_orthogonal_projection_Gram', heightSquared: String(H), commonEdgeSquared: String(L), projectedNorms: [Uperp, Wperp].map(String), projectedDot: String(projection), complete: true };
    }
    else {
        const [P, A, B, C] = v;
        if (v.some(x => x.n <= 0n) || B.cmp(C) >= 0)
            throw Error('oracle_cut_order');
        const aspect = P.sq().div(four.mul(A)).sub(one), R = P.div(two).div(one.add(aspect)).sq(), H = R.mul(aspect.sq().sub(one));
        if (aspect.cmp(one) <= 0 || H.n <= 0n || C.cmp(R) >= 0)
            throw Error('oracle_impossible_cone');
        const upperSector = B.mul(aspect), lowerSector = C.mul(aspect);
        answer = lowerSector.sub(upperSector).add(B).add(C);
        certificate = { method: 'independent_dimensionless_aspect_and_unrolled_sectors', slantToRadius: String(aspect), radiusSquared: String(R), heightSquared: String(H), sectionScaleSquares: [B.div(R), C.div(R)].map(String), lateralCoefficients: [upperSector, lowerSector].map(String), complete: true };
    }
    read(String(answer));
    if (answer.n <= 0n || ((i === 1 || i === 2) && answer.cmp(one) >= 0))
        throw Error('oracle_invalid_answer');
    return { answer, certificate };
}
function answerText(q, i) { return String(q) + (i === 0 ? ' cm^2' : i === 3 ? 'π cm^2' : ''); }
function solidGeometryConstraintIndependentCalculation(data, i) {
    const d = calculate(data, i), witnesses = [];
    for (let j = 0; j < 4; j++) {
        let found = false;
        for (const delta of (i === 1 ? [new R(-1), new R(1), new R(-1, 2), new R(1, 2), new R(-1, 4), new R(1, 4), new R(-1, 8), new R(1, 8), new R(-1, 16), new R(1, 16), new R(-1, 32), new R(1, 32), new R(-1, 64), new R(1, 64)] : [new R(1, 64), new R(-1, 64), new R(1, 32), new R(-1, 32), new R(1, 16), new R(-1, 16)])) {
            const alt = data.slice();
            alt[j] = String(read(alt[j]).add(delta));
            try {
                const e = calculate(alt, i);
                if (!e.answer.eq(d.answer)) {
                    witnesses.push({ omitted: names[i][j], alternativeData: alt, differentAnswer: answerText(e.answer, i) });
                    found = true;
                    break;
                }
            }
            catch { }
        }
        if (!found)
            throw Error('oracle_ineffective_constraint');
    }
    return { answer: answerText(d.answer, i), certificate: { ...d.certificate, effectiveConstraints: witnesses } };
}
function option(text, i) { try {
    const s = text.trim().replace(/\u00b2/g, '^2').replace(/\*\u03c0/g, 'π').replace(/\s+/g, ' '), suffix = i === 0 ? ' cm^2' : i === 3 ? 'π cm^2' : '';
    if (suffix && !s.endsWith(suffix))
        return null;
    return answerText(read(suffix ? s.slice(0, -suffix.length) : s), i);
}
catch {
    return null;
} }
function verifySubjectPracticeMathSolidGeometryConstraintWithIndependentOracle(candidate, context = {}) {
    const p = object(context.questionPlan), r = object(p?.renderConstraints), s = object(p?.scenarioContract), scope = String(r?.exactSolidGeometryConstraintScope ?? ''), i = scopes.indexOf(scope), required = { topicCode: 'M-GEO-002', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
    const bound = i >= 0 && p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 74 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === 'math_solid_geometry_constraint_reasoning' && p?.planTemplate === 'math_solid_geometry_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'solid_geometry_constraint_system' && s?.scenarioAction === scope;
    const reasonCodes = [];
    let expectedAnswer = null, certificate = null, data = null;
    try {
        if (!bound)
            throw Error('oracle_exact_plan');
        data = parse(candidate.prompt, i, 'zh');
        const d = solidGeometryConstraintIndependentCalculation(data, i);
        expectedAnswer = d.answer;
        certificate = d.certificate;
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parse(candidate.localizations?.[lang]?.prompt ?? '', i, lang)) !== JSON.stringify(data))
                throw Error('oracle_translation_parameters');
    }
    catch (e) {
        reasonCodes.push(e instanceof Error ? e.message : 'oracle_unparsed');
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 74 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => option(o.text, i));
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(o => [o.id, option(o.text, i)])) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('oracle_' + lang + '_options');
    const trueOptionIds = opts.filter((_, j) => keys[j] !== null && keys[j] === expectedAnswer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('oracle_answer_disagreement');
    return { oracleVersion: exports.SOLID_GEOMETRY_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? (data ? 'disagreed' : 'unparsed') : 'verified', scopeMatched: bound && !!data, scopeId: bound && data ? 'math-hard-solid-geometry-constraint-v1:' + scope : null, exactScope: scope, expectedAnswer, selectedOptionId, trueOptionIds, certificate, complete: !!certificate, completeCertificate: !!certificate, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
