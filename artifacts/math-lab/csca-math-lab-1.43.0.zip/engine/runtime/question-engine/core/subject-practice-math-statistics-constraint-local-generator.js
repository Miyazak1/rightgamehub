"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_CONSTRAINT_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathStatisticsConstraintLocalGenerator = createSubjectPracticeMathStatisticsConstraintLocalGenerator;
const subject_practice_math_statistics_constraint_solver_1 = require("./subject-practice-math-statistics-constraint-solver");
const subject_practice_math_statistics_constraint_independent_oracle_1 = require("./subject-practice-math-statistics-constraint-independent-oracle");
const subject_practice_math_statistics_constraint_explanation_verifier_1 = require("./subject-practice-math-statistics-constraint-explanation-verifier");
exports.STATISTICS_CONSTRAINT_GENERATOR_VERSION = 'math-statistics-constraint-generator-v1-bounded';
function createSubjectPracticeMathStatisticsConstraintLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, scope = (0, subject_practice_math_statistics_constraint_solver_1.statisticsConstraintScopeFrom)(input.questionPlan), b = input.blueprint, common = { generatorVersion: exports.STATISTICS_CONSTRAINT_GENERATOR_VERSION, seed, exactScope: scope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false }, unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['statistics_constraint_local_plan_not_supported'] };
        if (!validSeed || !scope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 76 || b.topicCode !== 'M-STAT-001' || b.difficulty !== 'hard' || b.questionType !== 'single_choice')
            return unsupported;
        for (let attempt = 0; attempt < 256; attempt++) {
            const i = subject_practice_math_statistics_constraint_solver_1.STATISTICS_CONSTRAINT_SCOPES.indexOf(scope);
            let state = ((seed + 1) * 2654435761 + attempt * 2246822519) >>> 0;
            const next = (max) => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return (state >>> 0) % max; };
            let data;
            if (i === 0) {
                const known = Array.from({ length: 4 }, () => next(13) - 6), x = next(17) - 8, y = next(17) - 8;
                if (x === y)
                    continue;
                const m = (0, subject_practice_math_statistics_constraint_solver_1.statisticsMoments)([...known, x, y].map(v => (0, subject_practice_math_statistics_constraint_solver_1.sq)(v)));
                data = [known.join(','), (0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.mean), (0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.variance), x < y ? '<' : '>', String([-2, -1, 2, 3][next(4)]), String(next(11) - 5)];
            }
            else if (i === 1) {
                const shift = next(9) - 4, step = next(3) + 1, levels = [-1, 0, 1, 2].map(x => shift + step * x), ki = seed % 4, frequencies = attempt % 3 ? ((ki === 0 || ki === 2) ? [1, 6, 3, 8] : [8, 3, 6, 1]) : Array.from({ length: 4 }, () => 1 + next(12)), removed = next(4), m = (0, subject_practice_math_statistics_constraint_solver_1.statisticsMoments)(levels.flatMap((x, j) => Array.from({ length: frequencies[j] }, () => (0, subject_practice_math_statistics_constraint_solver_1.sq)(x))));
                data = [levels.join(','), String(ki + 1), String(frequencies[ki]), String(m.count), (0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.mean), (0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.variance), String(removed + 1)];
            }
            else if (i === 2) {
                const nA = 4 + 2 * next(3), nB = 4 + 2 * next(3), vA = [1, 4, 9][next(3)], vB = [1, 4, 9][next(3)], muA = next(17) - 8, muB = next(17) - 8, pW = 1 + next(3), qW = 1 + next(3);
                if (muA === muB || pW === qW)
                    continue;
                const arr = [...Array.from({ length: nA }, (_, j) => (0, subject_practice_math_statistics_constraint_solver_1.sq)(muA + (j < nA / 2 ? -Math.sqrt(vA) : Math.sqrt(vA)))), ...Array.from({ length: nB }, (_, j) => (0, subject_practice_math_statistics_constraint_solver_1.sq)(muB + (j < nB / 2 ? -Math.sqrt(vB) : Math.sqrt(vB))))], m = (0, subject_practice_math_statistics_constraint_solver_1.statisticsMoments)(arr);
                data = [nA, nB, vA, vB].map(String).concat([(0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.mean), (0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.variance), muA < muB ? '<' : '>', String(pW), String(qW)]);
            }
            else {
                const known = Array.from({ length: 5 + next(4) }, () => next(13) - 6), a = (0, subject_practice_math_statistics_constraint_solver_1.sq)([-6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6][next(12)], 2), b = (0, subject_practice_math_statistics_constraint_solver_1.sq)(next(21) - 10, 2), arr = known.map(x => (0, subject_practice_math_statistics_constraint_solver_1.sadd)((0, subject_practice_math_statistics_constraint_solver_1.smul)(a, (0, subject_practice_math_statistics_constraint_solver_1.sq)(x)), b)), m = (0, subject_practice_math_statistics_constraint_solver_1.statisticsMoments)(arr), cut = arr[next(arr.length)];
                data = [known.join(','), (0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.mean), (0, subject_practice_math_statistics_constraint_solver_1.stxt)(m.variance), a.n > 0n ? '+' : '-', (0, subject_practice_math_statistics_constraint_solver_1.stxt)(cut), next(2) ? '>' : '>='];
            }
            const p = { scope, data }, d = (0, subject_practice_math_statistics_constraint_solver_1.statisticsConstraintDerive)(p);
            if (!d)
                continue;
            const choices = d.errors.map(e => ({ text: e.text, intent: e.intent })), correctAnswer = 'ABCD'[Math.floor(seed / 4) % 4];
            choices.splice('ABCD'.indexOf(correctAnswer), 0, { text: d.answer, intent: '' });
            const options = choices.map((e, j) => ({ id: 'ABCD'[j], text: e.text })), prompt = (0, subject_practice_math_statistics_constraint_solver_1.statisticsConstraintPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_statistics_constraint_solver_1.statisticsConstraintPrompt)(p, 'en'), explanation = (0, subject_practice_math_statistics_constraint_explanation_verifier_1.renderStatisticsConstraintExplanation)(p, d.answer, correctAnswer), tags = ['数据的数字特征', '多条件参数反推与统计量', scope];
            const candidate = { subject: 'math', topicId: 76, blueprintId: input.blueprint.id, sourceType: 'ai', designedDifficulty: 'hard', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: tags, optionMetadata: choices.flatMap((e, j) => e.intent ? [{ optionId: 'ABCD'[j], distractorIntent: e.intent, misconceptionTags: [e.intent] }] : []), localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: tags }, en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Descriptive statistics', 'Constrained moment inference', scope] } }, syllabusVersion: input.blueprint.syllabusVersion };
            const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_statistics_constraint_solver_1.solveSubjectPracticeMathStatisticsConstraint)(candidate, context), oracleEvidence = (0, subject_practice_math_statistics_constraint_independent_oracle_1.verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_statistics_constraint_explanation_verifier_1.verifySubjectPracticeMathStatisticsConstraintExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate), verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.expectedAnswer === oracleEvidence.expectedAnswer && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
            return { ...common, parameterAttempts: attempt + 1, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
        }
        return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts: 256 };
    };
}
