"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_ORACLE_VERSION = void 0;
exports.planeAnalyticGeometryConstraintIndependentCalculation = planeAnalyticGeometryConstraintIndependentCalculation;
exports.verifySubjectPracticeMathPlaneAnalyticGeometryConstraintWithIndependentOracle = verifySubjectPracticeMathPlaneAnalyticGeometryConstraintWithIndependentOracle;
// Independent visible-text parser and arithmetic; no runtime dependency on the Solver or generator.
exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_ORACLE_VERSION = 'math-plane-analytic-geometry-constraint-oracle-v1-independent-elimination-certificates';
const scopes = ["circle_center_line_two_points_tangent_length_squared", "diameter_circle_secant_intersection_triangle_area_squared", "circle_line_pencil_chord_parameter_square_sum", "external_point_tangency_points_distance_squared_sum"];
const abs = (n) => n < 0n ? -n : n;
class R {
    n;
    d;
    constructor(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || abs(a).toString(2).length > 512 || abs(b).toString(2).length > 512)
        throw Error('oracle_arithmetic_bound'); if (b < 0n) {
        a = -a;
        b = -b;
    } let x = abs(a), y = b; while (y) {
        const t = x % y;
        x = y;
        y = t;
    } this.n = a / x; this.d = b / x; }
    add(q) { return new R(this.n * q.d + q.n * this.d, this.d * q.d); }
    neg() { return new R(-this.n, this.d); }
    sub(q) { return this.add(q.neg()); }
    mul(q) { return new R(this.n * q.n, this.d * q.d); }
    div(q) { return new R(this.n * q.d, this.d * q.n); }
    sq() { return this.mul(this); }
    eq(q) { return this.n === q.n && this.d === q.d; }
    cmp(q) { const n = this.n * q.d - q.n * this.d; return n < 0n ? -1 : n > 0n ? 1 : 0; }
    toString() { return String(this.n) + (this.d === 1n ? '' : '/' + this.d); }
}
const z = new R(0), one = new R(1), two = new R(2), four = new R(4);
function read(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('oracle_rational_syntax'); const [a, b = '1'] = s.split('/'), q = new R(BigInt(a), BigInt(b)); if (abs(q.n) > 1000000000000n || q.d > 1000000000n)
    throw Error('oracle_input_bound'); return q; }
const object = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
const names = [['Ax', 'Ay', 'Bx', 'By', 'a', 'b', 'c', 'Px', 'Py'], ['Ux', 'Uy', 'Vx', 'Vy', 'a', 'b', 'c', 'm1', 'm2', 'm3', 'n1', 'n2', 'n3'], ['D', 'E', 'F', 'Px', 'Py', 'L'], ['D', 'E', 'F', 'Px', 'Py', 'Qx', 'Qy']];
const starts = { zh: ['圆经过A=(Ax,Ay)和B=(Bx,By)，圆心在直线a*x+b*y+c=0上。给定外点P=(Px,Py)。已知 ', '圆的直径端点为U=(Ux,Uy)、V=(Vx,Vy)。直线a*x+b*y+c=0截圆于A、B；Q是m1*x+m2*y+m3=0与n1*x+n2*y+n3=0的交点。已知 ', '圆为x^2+y^2+D*x+E*y+F=0，外点为P=(Px,Py)。动直线t*x-y+Py-t*Px=0截圆的弦长为L。已知 ', '圆为x^2+y^2+D*x+E*y+F=0，P=(Px,Py)在圆外，Q=(Qx,Qy)。从P作两条切线，切点为T1、T2。已知 '], en: ['A circle passes through A=(Ax,Ay) and B=(Bx,By); its center lies on a*x+b*y+c=0. P=(Px,Py) is external. Given ', 'The endpoints of a circle diameter are U=(Ux,Uy) and V=(Vx,Vy). The line a*x+b*y+c=0 cuts the circle at A,B; Q is the intersection of m1*x+m2*y+m3=0 and n1*x+n2*y+n3=0. Given ', 'The circle is x^2+y^2+D*x+E*y+F=0 and P=(Px,Py) is external. The line t*x-y+Py-t*Px=0 cuts a chord of length L. Given ', 'The circle is x^2+y^2+D*x+E*y+F=0. P=(Px,Py) is external and Q=(Qx,Qy). The two tangents from P touch the circle at T1,T2. Given '] };
const ends = { zh: ['求P到圆的切线长的平方。', '求三角形QAB面积的平方。', '求所有实数参数t的解的平方和。', '求|T1-Q|^2+|T2-Q|^2。'], en: ['Find the square of the tangent length from P.', 'Find the square of the area of triangle QAB.', 'Find the sum of the squares of all real solutions for t.', 'Find |T1-Q|^2+|T2-Q|^2.'] };
function parse(text, i, lang) { if (i < 0 || typeof text !== 'string' || text.length > 3000 || !text.startsWith(starts[lang][i]) || !text.endsWith('. ' + ends[lang][i]))
    throw Error('oracle_stem'); const middle = text.slice(starts[lang][i].length, -('. ' + ends[lang][i]).length), parts = middle.split(', '); if (parts.length !== names[i].length)
    throw Error('oracle_givens'); return parts.map((part, j) => { const m = part.match(/^([A-Za-z0-9]+)=\(([-+]?\d+(?:\/[1-9]\d*)?)\)$/); if (!m || m[1] !== names[i][j])
    throw Error('oracle_parameter_label'); read(m[2]); return m[2]; }); }
function eliminate(rows) { const a = rows.map(r => r.slice()), n = a.length; if (a.some(r => r.length !== n + 1))
    throw Error('oracle_linear_dimension'); const pivots = []; for (let c = 0; c < n; c++) {
    const pivot = a.findIndex((r, j) => j >= c && r[c].n !== 0n);
    if (pivot < 0)
        throw Error('oracle_singular_equations');
    [a[c], a[pivot]] = [a[pivot], a[c]];
    const d = a[c][c];
    pivots.push(String(d));
    a[c] = a[c].map(v => v.div(d));
    for (let j = 0; j < n; j++)
        if (j !== c) {
            const factor = a[j][c];
            a[j] = a[j].map((v, k) => v.sub(factor.mul(a[c][k])));
        }
} const solution = a.map(r => r[n]); for (const r of rows)
    if (!r.slice(0, n).reduce((s, v, j) => s.add(v.mul(solution[j])), z).eq(r[n]))
        throw Error('oracle_linear_round_trip'); return { solution, pivots }; }
const ap = (a, b = z) => ({ a, b }), add = (x, y) => ap(x.a.add(y.a), x.b.add(y.b)), neg = (x) => ap(x.a.neg(), x.b.neg()), sub = (x, y) => add(x, neg(y));
const times = (x, y, D) => ap(x.a.mul(y.a).add(x.b.mul(y.b).mul(D)), x.a.mul(y.b).add(x.b.mul(y.a)));
const scale = (x, q) => ap(x.a.mul(q), x.b.mul(q)), zero = (x) => x.a.n === 0n && x.b.n === 0n;
const show = (x) => ({ rational: String(x.a), radicalCoefficient: String(x.b) });
function roots(A, B, C) { const D = B.sq().sub(four.mul(A).mul(C)); if (!A.n || D.n <= 0n)
    throw Error('oracle_two_real_roots'); const denominator = two.mul(A), pair = [ap(B.neg().div(denominator), one.neg().div(denominator)), ap(B.neg().div(denominator), one.div(denominator))]; for (const t of pair)
    if (!zero(add(add(scale(times(t, t, D), A), scale(t, B)), ap(C))))
        throw Error('oracle_root_round_trip'); return { D, pair }; }
function section(D, E, F, line) { const [a, b, c] = line; if (!a.n && !b.n)
    throw Error('oracle_zero_line'); const x0 = a.n ? c.neg().div(a) : z, y0 = a.n ? z : c.neg().div(b), vx = b, vy = a.neg(), A = vx.sq().add(vy.sq()), B = two.mul(x0.mul(vx).add(y0.mul(vy))).add(D.mul(vx)).add(E.mul(vy)), C = x0.sq().add(y0.sq()).add(D.mul(x0)).add(E.mul(y0)).add(F), r = roots(A, B, C); const points = r.pair.map(t => [add(ap(x0), scale(t, vx)), add(ap(y0), scale(t, vy))]); for (const [x, y] of points) {
    if (!zero(add(add(add(times(x, x, r.D), times(y, y, r.D)), add(scale(x, D), scale(y, E))), ap(F))))
        throw Error('oracle_circle_round_trip');
    if (!zero(add(add(scale(x, a), scale(y, b)), ap(c))))
        throw Error('oracle_line_round_trip');
} return { ...r, A, B, C, x0, y0, vx, vy, points }; }
function polyAdd(a, b) { return Array.from({ length: Math.max(a.length, b.length) }, (_, i) => (a[i] ?? z).add(b[i] ?? z)); }
function polyMul(a, b) { const out = Array.from({ length: a.length + b.length - 1 }, () => z); a.forEach((v, i) => b.forEach((w, j) => { out[i + j] = out[i + j].add(v.mul(w)); })); return out; }
function planeAnalyticGeometryConstraintIndependentCalculation(data, i) {
    if (i < 0 || data.length !== names[i].length)
        throw Error('oracle_parameters');
    const v = data.map(read);
    let answer, certificate;
    if (i === 0) {
        const [ax, ay, bx, by, a, b, c, px, py] = v;
        if (ax.eq(bx) && ay.eq(by) || !a.n && !b.n)
            throw Error('oracle_degenerate_incidence');
        const e = eliminate([[ax, ay, one, ax.sq().add(ay.sq()).neg()], [bx, by, one, bx.sq().add(by.sq()).neg()], [a, b, z, two.mul(c)]]), [D, E, F] = e.solution, r2 = D.sq().add(E.sq()).div(four).sub(F);
        answer = px.sq().add(py.sq()).add(D.mul(px)).add(E.mul(py)).add(F);
        if (r2.n <= 0n || answer.n <= 0n)
            throw Error('oracle_external_circle');
        certificate = { kind: 'independent_general_circle_gaussian_elimination', generalCircle: e.solution.map(String), pivots: e.pivots, radiusSquared: String(r2), powerAtExternalPoint: String(answer), complete: true };
    }
    else if (i === 1) {
        const [ux, uy, vx, vy] = v, D = ux.add(vx).neg(), E = uy.add(vy).neg(), F = ux.mul(vx).add(uy.mul(vy));
        if (ux.eq(vx) && uy.eq(vy))
            throw Error('oracle_zero_diameter');
        const e = eliminate([[v[7], v[8], v[9].neg()], [v[10], v[11], v[12].neg()]]), [qx, qy] = e.solution, s = section(D, E, F, v.slice(4, 7)), cross = s.vx.mul(qy.sub(s.y0)).sub(s.vy.mul(qx.sub(s.x0)));
        answer = s.D.mul(cross.sq()).div(four.mul(s.A.sq()));
        if (answer.n <= 0n)
            throw Error('oracle_degenerate_triangle');
        certificate = { kind: 'independent_secant_discriminant_area', generalCircle: [D, E, F].map(String), vertex: e.solution.map(String), lineQuadratic: [s.A, s.B, s.C].map(String), discriminant: String(s.D), twoIntersections: s.points.map(p => p.map(show)), areaSquared: String(answer), complete: true };
    }
    else if (i === 2) {
        const [D, E, F, px, py, L] = v, r2 = D.sq().add(E.sq()).div(four).sub(F), power = px.sq().add(py.sq()).add(D.mul(px)).add(E.mul(py)).add(F);
        if (r2.n <= 0n || power.n <= 0n || L.n <= 0n || L.sq().cmp(four.mul(r2)) >= 0)
            throw Error('oracle_chord_domain');
        const lineConstant = [py, px.neg()], linear = polyAdd([D], polyMul([z, one], polyAdd(lineConstant.map(x => two.mul(x)), [E]))), constant = polyAdd(polyAdd(polyMul(lineConstant, lineConstant), lineConstant.map(x => E.mul(x))), [F]), disc = polyAdd(polyMul(linear, linear), polyMul([one, z, one], constant).map(x => four.mul(x).neg())), equation = polyAdd(disc, [L.sq().neg(), z, L.sq().neg()]);
        if (equation.slice(3).some(x => x.n))
            throw Error('oracle_polynomial_cancellation');
        const C = equation[0], B = equation[1], A = equation[2], r = roots(A, B, C), squares = r.pair.map(t => times(t, t, r.D)), total = add(squares[0], squares[1]);
        if (total.b.n || total.a.n <= 0n)
            throw Error('oracle_radical_sum');
        answer = total.a;
        certificate = { kind: 'independent_circle_line_elimination_all_real_parameters', parameterPolynomial: [A, B, C].map(String), discriminant: String(r.D), realRoots: r.pair.map(show), rootSquares: squares.map(show), radicalSum: String(total.b), realRootCount: 2, identity: 'chord_squared=intersection_discriminant/(1+t^2); 1+t^2>0 for all real t', complete: true };
    }
    else {
        const [D, E, F, px, py, qx, qy] = v, r2 = D.sq().add(E.sq()).div(four).sub(F), power = px.sq().add(py.sq()).add(D.mul(px)).add(E.mul(py)).add(F), u = px.add(D.div(two)), w = py.add(E.div(two)), qx0 = qx.add(D.div(two)), qy0 = qy.add(E.div(two));
        if (r2.n <= 0n || power.n <= 0n || !u.mul(qy0).sub(w.mul(qx0)).n || !u.mul(qx0).add(w.mul(qy0)).n)
            throw Error('oracle_tangent_domain');
        const line = [u, w, F.add(px.mul(D).add(py.mul(E)).div(two))], s = section(D, E, F, line);
        let total = ap(z);
        const distances = [];
        for (const [x, y] of s.points) {
            const orth = add(times(sub(ap(px), x), add(x, ap(D.div(two))), s.D), times(sub(ap(py), y), add(y, ap(E.div(two))), s.D));
            if (!zero(orth))
                throw Error('oracle_tangent_orthogonality');
            const dx = sub(x, ap(qx)), dy = sub(y, ap(qy)), distance = add(times(dx, dx, s.D), times(dy, dy, s.D));
            distances.push(distance);
            total = add(total, distance);
        }
        if (total.b.n || total.a.n <= 0n)
            throw Error('oracle_contact_sum');
        answer = total.a;
        certificate = { kind: 'independent_two_contact_points_and_distances', contactLine: line.map(String), discriminant: String(s.D), contactPoints: s.points.map(p => p.map(show)), distances: distances.map(show), radicalSum: String(total.b), orthogonalityVerified: true, complete: true };
    }
    if (abs(answer.n) > 1000000000000n || answer.d > 1000000000n)
        throw Error('oracle_answer_bound');
    return { answer: String(answer), certificate };
}
function option(text) { try {
    return String(read(text.trim()));
}
catch {
    return null;
} }
function verifySubjectPracticeMathPlaneAnalyticGeometryConstraintWithIndependentOracle(candidate, context = {}) {
    const p = object(context.questionPlan), r = object(p?.renderConstraints), s = object(p?.scenarioContract), scope = String(r?.exactPlaneAnalyticGeometryConstraintScope ?? ''), i = scopes.indexOf(scope), required = { topicCode: 'M-GEO-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
    const bound = i >= 0 && p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 72 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === 'math_plane_analytic_geometry_constraint_reasoning' && p?.planTemplate === 'math_plane_analytic_geometry_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'plane_analytic_geometry_constraint_system' && s?.scenarioAction === scope;
    const reasonCodes = [];
    let expectedAnswer = null, certificate = null, data = null;
    try {
        if (!bound)
            throw Error('oracle_exact_plan');
        data = parse(candidate.prompt, i, 'zh');
        const d = planeAnalyticGeometryConstraintIndependentCalculation(data, i);
        expectedAnswer = d.answer;
        certificate = d.certificate;
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parse(candidate.localizations?.[lang]?.prompt ?? '', i, lang)) !== JSON.stringify(data))
                throw Error('oracle_translation_parameters');
    }
    catch (e) {
        reasonCodes.push(e instanceof Error ? e.message : 'oracle_unparsed');
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 72 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => option(o.text));
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(o => [o.id, option(o.text)])) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('oracle_' + lang + '_options');
    const trueOptionIds = opts.filter((_, j) => keys[j] !== null && keys[j] === expectedAnswer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('oracle_answer_disagreement');
    return { oracleVersion: exports.PLANE_ANALYTIC_GEOMETRY_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? (data ? 'disagreed' : 'unparsed') : 'verified', scopeMatched: bound && !!data, scopeId: bound && data ? 'math-hard-plane-analytic-geometry-constraint-v1:' + scope : null, exactScope: scope, expectedAnswer, selectedOptionId, trueOptionIds, certificate, complete: !!certificate, completeCertificate: !!certificate, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
