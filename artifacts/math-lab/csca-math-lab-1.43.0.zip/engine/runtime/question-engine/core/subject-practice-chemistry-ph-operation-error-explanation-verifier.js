"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeChemistryPhOperationErrorExplanation = verifySubjectPracticeChemistryPhOperationErrorExplanation;
const subject_practice_chemistry_ph_operation_error_solver_1 = require("./subject-practice-chemistry-ph-operation-error-solver");
exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_EXPLANATION_VERIFIER_VERSION = 'chemistry-ph-operation-error-explanation-verifier-v1';
function compact(value) {
    return String(value ?? '').replace(/\s+/g, '').toLowerCase();
}
function checkExplanation(input) {
    const text = compact(input.text);
    const task = input.evidence.canonicalTask;
    const dilution = task?.concentrationDirection === 'decrease';
    const acid = task?.solutionCharacter === 'acid';
    const operationEffectMatched = dilution
        ? /(稀释|体积增大|浓度降低|dilut|largervolume|concentrationdecreases?)/.test(text)
        : /(体积偏小|浓度升高|浓度增大|smallervolume|concentrationincreases?|moreconcentrated)/.test(text);
    const ionOrConcentrationDirectionMatched = acid
        ? dilution
            ? /(\[?h\+?\]?|氢离子).{0,20}(降低|减小|decreas|lower)/.test(text)
            : /(\[?h\+?\]?|氢离子).{0,20}(升高|增大|increas|higher)/.test(text)
        : dilution
            ? /(\[?oh-?\]?|氢氧根).{0,20}(降低|减小|decreas|lower)/.test(text)
            : /(\[?oh-?\]?|氢氧根).{0,20}(升高|增大|increas|higher)/.test(text);
    const biasPattern = input.evidence.expectedBias === 'higher'
        ? /(ph.{0,12}(偏高|升高|增大|higher|increas)|偏高.{0,12}ph)/
        : /(ph.{0,12}(偏低|降低|减小|lower|decreas)|偏低.{0,12}ph)/;
    const phConclusionMatched = biasPattern.test(text);
    const reasonCodes = [];
    if (!operationEffectMatched)
        reasonCodes.push(`chemistry_ph_operation_error_explanation_${input.language}_operation_effect_missing`);
    if (!ionOrConcentrationDirectionMatched)
        reasonCodes.push(`chemistry_ph_operation_error_explanation_${input.language}_ion_direction_missing`);
    if (!phConclusionMatched)
        reasonCodes.push(`chemistry_ph_operation_error_explanation_${input.language}_ph_conclusion_missing_or_wrong`);
    return { language: input.language, operationEffectMatched, ionOrConcentrationDirectionMatched, phConclusionMatched, reasonCodes };
}
function verifySubjectPracticeChemistryPhOperationErrorExplanation(candidate, context = {}) {
    const solverEvidence = (0, subject_practice_chemistry_ph_operation_error_solver_1.solveSubjectPracticeChemistryPhOperationError)(candidate, context);
    const checks = [
        checkExplanation({ language: 'zh', text: candidate.explanation, evidence: solverEvidence }),
        checkExplanation({ language: 'en', text: candidate.localizations?.en?.explanation ?? '', evidence: solverEvidence })
    ];
    const reasonCodes = checks.flatMap((check) => check.reasonCodes);
    if (solverEvidence.status !== 'verified' || !solverEvidence.verificationScope.matched) {
        reasonCodes.unshift('chemistry_ph_operation_error_explanation_answer_recomputation_not_verified');
    }
    const status = solverEvidence.status === 'unparsed'
        ? 'unparsed'
        : reasonCodes.length === 0 ? 'verified' : 'failed';
    return {
        verifierVersion: exports.SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_EXPLANATION_VERIFIER_VERSION,
        status,
        solverEvidence,
        causalChainChecked: true,
        checks,
        mismatchCount: reasonCodes.length,
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes: Array.from(new Set(reasonCodes))
    };
}
