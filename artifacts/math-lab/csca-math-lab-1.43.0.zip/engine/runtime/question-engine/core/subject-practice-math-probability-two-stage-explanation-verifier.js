"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROBABILITY_TWO_STAGE_EXPLANATION_VERSION = void 0;
exports.renderProbabilityTwoStageExplanation = renderProbabilityTwoStageExplanation;
exports.verifySubjectPracticeMathProbabilityTwoStageExplanation = verifySubjectPracticeMathProbabilityTwoStageExplanation;
const subject_practice_math_probability_two_stage_solver_1 = require("./subject-practice-math-probability-two-stage-solver");
exports.PROBABILITY_TWO_STAGE_EXPLANATION_VERSION = 'math-probability-two-stage-explanation-v1-bound-bilingual';
function renderProbabilityTwoStageExplanation(p, answer, option) {
    const d = (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStageDerive)(p);
    if (!d)
        throw Error('probability_two_stage_invalid_explanation_parameters');
    const notes = {
        without_replacement_both_target: ['不放回时，第一次取红球后红球数和总球数均减一，按两个阶段相乘。', 'Without replacement, a first red draw reduces both the red count and the total by one; multiply the two stage probabilities.'],
        without_replacement_one_of_each: ['分别计算红蓝和蓝红两种互斥顺序，每种第二步的总球数减一，再相加。', 'Count the disjoint red-blue and blue-red orders, reducing the second-stage total by one, then add.'],
        independent_two_boxes_both_target: ['分别使用两盒各自的总球数；由于两次选择独立，两个红球概率相乘。', 'Use the separate box totals; independence allows multiplying the two red probabilities.'],
        independent_two_boxes_at_least_one_target: ['先按独立性计算两球均蓝的概率，再取补集；补集包含恰好一个红球及两个红球。', 'Multiply the independent blue probabilities, then take the complement, which includes both exactly one red and two reds.']
    };
    return { zh: (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStagePrompt)(p, 'zh') + ' ' + notes[p.scope][0] + ' ' + d.proof + '; result=' + answer + '。对应选项 ' + option + '。',
        en: (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStagePrompt)(p, 'en') + ' ' + notes[p.scope][1] + ' ' + d.proof + '; result=' + answer + '. Option ' + option + '.' };
}
function verifySubjectPracticeMathProbabilityTwoStageExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_probability_two_stage_solver_1.solveSubjectPracticeMathProbabilityTwoStage)(candidate, context), expected = solved.parameters && solved.expectedAnswer && solved.selectedOptionId ? renderProbabilityTwoStageExplanation(solved.parameters, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh), enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('probability_two_stage_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('probability_two_stage_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('probability_two_stage_explanation_en_mismatch');
    return { verifierVersion: exports.PROBABILITY_TWO_STAGE_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solved.scopeId, zhBound, enBound, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
