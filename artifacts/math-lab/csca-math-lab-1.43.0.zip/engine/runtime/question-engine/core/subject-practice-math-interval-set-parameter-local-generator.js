"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.INTERVAL_SET_PARAMETER_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathIntervalSetParameterLocalGenerator = createSubjectPracticeMathIntervalSetParameterLocalGenerator;
const subject_practice_math_interval_set_parameter_solver_1 = require("./subject-practice-math-interval-set-parameter-solver");
const subject_practice_math_interval_set_parameter_independent_oracle_1 = require("./subject-practice-math-interval-set-parameter-independent-oracle");
const subject_practice_math_interval_set_parameter_explanation_verifier_1 = require("./subject-practice-math-interval-set-parameter-explanation-verifier");
exports.INTERVAL_SET_PARAMETER_GENERATOR_VERSION = 'math-interval-set-parameter-generator-v1-bounded';
function createSubjectPracticeMathIntervalSetParameterLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, exactScope = (0, subject_practice_math_interval_set_parameter_solver_1.intervalSetParameterScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.INTERVAL_SET_PARAMETER_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['interval_set_parameter_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 66 || b.topicCode !== 'M-SET-001' || b.difficulty !== 'hard' || b.questionType !== 'single_choice')
            return unsupported;
        const n = seed % 100000, shift = Math.floor(n / 16) % 7 - 3, bit = (k) => !!(n & (1 << k)), seg = (lo, hi, lc = true, hc = true) => ({ lo: lo + shift, hi: hi + shift, lc, hc }), i = subject_practice_math_interval_set_parameter_solver_1.INTERVAL_SET_PARAMETER_SCOPES.indexOf(exactScope);
        const p = { scope: exactScope, T: seg(-6, 6), A: { lo: -1, hi: 1, lc: bit(0), hc: bit(1) }, B: [seg(-8, -2, bit(2), bit(3)), seg(2, 8, bit(3), bit(2))], U: null, C: null };
        if (i === 1) {
            p.T = seg(-12, 12);
            p.B = [seg(-7, -3, bit(2), bit(3)), seg(3, 7, bit(3), bit(2))];
        }
        if (i === 2) {
            p.T = seg(-12, 12);
            p.U = seg(-8, 8);
            p.B = [seg(-6, -2, bit(2), bit(3)), seg(2, 6, bit(3), bit(2))];
        }
        if (i === 3) {
            p.T = seg(-8, 8);
            p.A = { lo: -5, hi: 5, lc: bit(0), hc: bit(1) };
            p.U = seg(-7, 5);
            p.C = seg(-2, 2, bit(2), bit(3));
            p.B = [seg(-4, -1, bit(2), bit(3)), seg(1, 4, bit(3), bit(2))];
        }
        const d = (0, subject_practice_math_interval_set_parameter_solver_1.intervalSetParameterDerive)(p);
        if (!d)
            return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts: 1 };
        const choices = d.errors.map(e => ({ text: e.text, intent: e.intent })), correctAnswer = 'ABCD'[Math.floor(seed / 16) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { text: d.text, intent: '' });
        const options = choices.map((e, j) => ({ id: 'ABCD'[j], text: e.text })), prompt = (0, subject_practice_math_interval_set_parameter_solver_1.intervalSetParameterPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_interval_set_parameter_solver_1.intervalSetParameterPrompt)(p, 'en'), explanation = (0, subject_practice_math_interval_set_parameter_explanation_verifier_1.renderIntervalSetParameterExplanation)(p, d.answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 66, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'hard', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['集合的定义、运算及表示方法', exactScope], optionMetadata: choices.flatMap((e, j) => e.intent ? [{ optionId: 'ABCD'[j], distractorIntent: e.intent, misconceptionTags: [e.intent] }] : []), localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['集合的定义、运算及表示方法', exactScope] }, en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Sets and interval operations', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_interval_set_parameter_solver_1.solveSubjectPracticeMathIntervalSetParameter)(candidate, context), oracleEvidence = (0, subject_practice_math_interval_set_parameter_independent_oracle_1.verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_interval_set_parameter_explanation_verifier_1.verifySubjectPracticeMathIntervalSetParameterExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.expectedAnswer === oracleEvidence.expectedAnswer && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, parameterAttempts: 1, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
