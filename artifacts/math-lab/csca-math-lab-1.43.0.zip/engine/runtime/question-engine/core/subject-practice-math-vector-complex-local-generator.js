"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathVectorComplexLocalGenerator = createSubjectPracticeMathVectorComplexLocalGenerator;
const subject_practice_math_vector_complex_solver_1 = require("./subject-practice-math-vector-complex-solver");
const subject_practice_math_vector_complex_independent_oracle_1 = require("./subject-practice-math-vector-complex-independent-oracle");
const subject_practice_math_vector_complex_explanation_verifier_1 = require("./subject-practice-math-vector-complex-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_LOCAL_GENERATOR_VERSION = 'math-vector-complex-local-generator-v1-bounded-four-scope';
const SCOPES = new Set(['vector_coordinate_addition', 'vector_dot_product', 'complex_addition_subtraction', 'complex_modulus']);
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').trim(); }
function seedOf(v) { const n = Number(v); return Number.isFinite(n) ? Math.abs(Math.trunc(n)) : 0; }
function scopeFrom(v, validate) { const p = object(v), r = object(p?.renderConstraints), s = clean(r?.exactVectorComplexScope); return validate(v).valid && clean(p?.taskFamily) === 'math_vector_complex_direct_calculation' && clean(p?.planTemplate) === 'math_vector_complex_direct_calculation_v1' && SCOPES.has(s) ? s : null; }
function key(v) { return typeof v === 'number' ? `n:${v}` : `p:${v.x},${v.y}`; }
function render(v, complex = false) { if (typeof v === 'number')
    return String(v); return complex ? `${v.x}${v.y >= 0 ? '+' : ''}${v.y}i` : `(${v.x}, ${v.y})`; }
function alternatives(correct, items) { const fallbacks = typeof correct === 'number' ? [1, 2, 3].map((delta) => ({ value: correct + delta, distractorIntent: `arithmetic_offset_${delta}`, misconceptionTags: ['direct_calculation_arithmetic_error'] })) : [{ value: { x: correct.x + 1, y: correct.y }, distractorIntent: 'first_component_unit_offset', misconceptionTags: ['component_arithmetic_error'] }, { value: { x: correct.x, y: correct.y + 1 }, distractorIntent: 'second_component_unit_offset', misconceptionTags: ['component_arithmetic_error'] }, { value: { x: correct.x + 1, y: correct.y + 1 }, distractorIntent: 'both_components_unit_offset', misconceptionTags: ['component_arithmetic_error'] }]; const out = []; const seen = new Set(); const seenIntents = new Set(); for (const item of [{ value: correct, distractorIntent: null, misconceptionTags: [] }, ...items, ...fallbacks]) {
    const k = key(item.value), intent = item.distractorIntent ?? '';
    if (seen.has(k) || (intent && seenIntents.has(intent)))
        continue;
    seen.add(k);
    if (intent)
        seenIntents.add(intent);
    out.push(item);
    if (out.length === 4)
        return out;
} throw new Error('math_vector_complex_distinct_alternatives_unavailable'); }
function candidateFor(b, seed, s) {
    const vals = [-6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6];
    const v = (i) => vals[(seed * 7 + i * 5) % vals.length];
    let prompt = '', promptEn = '', explanation = '', explanationEn = '', correct, alts, complex = false;
    if (s === 'vector_coordinate_addition') {
        const a = { x: v(1), y: v(2) }, bb = { x: v(3), y: v(4) };
        correct = { x: a.x + bb.x, y: a.y + bb.y };
        alts = [{ value: { x: a.x - bb.x, y: a.y - bb.y }, distractorIntent: 'subtracted_vector_instead_of_adding', misconceptionTags: ['vector_operation_sign_error'] }, { value: { x: a.x + bb.y, y: a.y + bb.x }, distractorIntent: 'crossed_second_vector_coordinates', misconceptionTags: ['vector_coordinate_alignment_error'] }, { value: { x: a.x + bb.x, y: a.y - bb.y }, distractorIntent: 'used_wrong_sign_for_second_coordinate', misconceptionTags: ['vector_operation_sign_error'] }];
        prompt = `已知平面向量 a=(${a.x}, ${a.y})，b=(${bb.x}, ${bb.y})，求 a+b 的坐标。`;
        promptEn = `Given plane vectors a=(${a.x}, ${a.y}) and b=(${bb.x}, ${bb.y}), find the coordinates of a+b.`;
        explanation = `对应坐标分别相加：a_x=${a.x}，a_y=${a.y}，b_x=${bb.x}，b_y=${bb.y}，所以 a+b=(a_x+b_x,a_y+b_y)=(${correct.x},${correct.y})。`;
        explanationEn = `Add corresponding coordinates: a_x=${a.x}, a_y=${a.y}, b_x=${bb.x}, b_y=${bb.y}, so a+b=(a_x+b_x,a_y+b_y)=(${correct.x},${correct.y}).`;
    }
    else if (s === 'vector_dot_product') {
        const a = { x: v(1), y: v(2) }, bb = { x: v(3), y: v(4) };
        correct = a.x * bb.x + a.y * bb.y;
        alts = [{ value: a.x * bb.x - a.y * bb.y, distractorIntent: 'subtracted_second_coordinate_product', misconceptionTags: ['dot_product_sign_error'] }, { value: (a.x + bb.x) * (a.y + bb.y), distractorIntent: 'multiplied_coordinate_sums', misconceptionTags: ['dot_product_formula_error'] }, { value: a.x * bb.y + a.y * bb.x, distractorIntent: 'cross_multiplied_coordinates', misconceptionTags: ['vector_coordinate_alignment_error'] }];
        prompt = `已知平面向量 a=(${a.x}, ${a.y})，b=(${bb.x}, ${bb.y})，求数量积 a·b。`;
        promptEn = `Given plane vectors a=(${a.x}, ${a.y}) and b=(${bb.x}, ${bb.y}), find the dot product a·b.`;
        explanation = `数量积 a·b=a_xb_x+a_yb_y。代入 a_x=${a.x}，a_y=${a.y}，b_x=${bb.x}，b_y=${bb.y}，得 a·b=${correct}。`;
        explanationEn = `The dot product is a·b=a_xb_x+a_yb_y. With a_x=${a.x}, a_y=${a.y}, b_x=${bb.x}, b_y=${bb.y}, a·b=${correct}.`;
    }
    else if (s === 'complex_addition_subtraction') {
        complex = true;
        const z1 = { x: v(1), y: v(2) }, z2 = { x: v(3), y: v(4) }, subtract = seed % 2 === 1, sign = subtract ? -1 : 1;
        correct = { x: z1.x + sign * z2.x, y: z1.y + sign * z2.y };
        alts = [{ value: { x: z1.x - sign * z2.x, y: z1.y - sign * z2.y }, distractorIntent: 'used_opposite_complex_operation', misconceptionTags: ['complex_operation_sign_error'] }, { value: { x: z1.x + sign * z2.y, y: z1.y + sign * z2.x }, distractorIntent: 'crossed_real_and_imaginary_parts', misconceptionTags: ['complex_component_alignment_error'] }, { value: { x: z1.x + sign * z2.x, y: z1.y - sign * z2.y }, distractorIntent: 'used_inconsistent_imaginary_sign', misconceptionTags: ['complex_operation_sign_error'] }];
        const op = subtract ? '-' : '+';
        prompt = `复数 z_1 的实部 x_1=${z1.x}、虚部 y_1=${z1.y}，复数 z_2 的实部 x_2=${z2.x}、虚部 y_2=${z2.y}，求 z_1${op}z_2。`;
        promptEn = `For complex numbers z_1 and z_2, x_1=${z1.x}, y_1=${z1.y}, x_2=${z2.x}, and y_2=${z2.y}. Find z_1${op}z_2.`;
        explanation = `复数${subtract ? '相减' : '相加'}时实部、虚部分别${subtract ? '相减' : '相加'}。代入 x_1=${z1.x}、y_1=${z1.y}、x_2=${z2.x}、y_2=${z2.y}，得 z_1${op}z_2=${render(correct, true)}。`;
        explanationEn = `${subtract ? 'Subtract' : 'Add'} real parts and imaginary parts separately. With x_1=${z1.x}, y_1=${z1.y}, x_2=${z2.x}, y_2=${z2.y}, z_1${op}z_2=${render(correct, true)}.`;
    }
    else {
        const triples = [[3, 4, 5], [5, 12, 13], [6, 8, 10], [8, 15, 17]], t = triples[seed % triples.length], x1 = (seed % 2 ? -1 : 1) * t[0], y1 = ((seed >> 1) % 2 ? -1 : 1) * t[1];
        correct = t[2];
        alts = [{ value: Math.abs(x1) + Math.abs(y1), distractorIntent: 'added_absolute_components', misconceptionTags: ['complex_modulus_formula_error'] }, { value: x1 * x1 + y1 * y1, distractorIntent: 'omitted_square_root', misconceptionTags: ['complex_modulus_formula_error'] }, { value: Math.abs(x1 - y1), distractorIntent: 'used_absolute_component_difference', misconceptionTags: ['complex_modulus_formula_error'] }];
        prompt = `复数 z 的实部 x_1=${x1}、虚部 y_1=${y1}，求复数的模 |z|。`;
        promptEn = `For a complex number z with real part x_1=${x1} and imaginary part y_1=${y1}, find its modulus |z|.`;
        explanation = `复数的模 |z|=√(x_1^2+y_1^2)。代入 x_1=${x1}、y_1=${y1}，得 |z|=√(${x1}^2+${y1}^2)=${correct}。`;
        explanationEn = `The modulus is |z|=√(x_1^2+y_1^2). With x_1=${x1} and y_1=${y1}, |z|=√(${x1}^2+${y1}^2)=${correct}.`;
    }
    const set = alternatives(correct, alts), correctIndex = seed % 4, ordered = set.slice(1);
    ordered.splice(correctIndex, 0, set[0]);
    const ids = ['A', 'B', 'C', 'D'], options = ordered.map((x, i) => ({ id: ids[i], text: render(x.value, complex) }));
    return { subject: 'math', topicId: b.topicId, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options, correctAnswer: ids[correctIndex], explanation, knowledgeTags: ['向量与复数', s], optionMetadata: ordered.flatMap((x, i) => i === correctIndex ? [] : [{ optionId: ids[i], distractorIntent: x.distractorIntent ?? 'unclassified_vector_complex_error', misconceptionTags: x.misconceptionTags }]), localizations: { zh: { prompt, options, explanation, knowledgeTags: ['向量与复数'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Vectors and complex numbers'] } }, syllabusVersion: b.syllabusVersion };
}
function createSubjectPracticeMathVectorComplexLocalGenerator(ports) { return function generate(input) { const seed = seedOf(input.seed), exactScope = scopeFrom(input.questionPlan, ports.validate), supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'basic' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice'; if (!exactScope || !supported)
    return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_vector_complex_local_generator_question_plan_not_supported'] }; const candidate = candidateFor(input.blueprint, seed, exactScope), context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_vector_complex_solver_1.solveSubjectPracticeMathVectorComplex)(candidate, context), oracleEvidence = (0, subject_practice_math_vector_complex_independent_oracle_1.verifySubjectPracticeMathVectorComplexWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_vector_complex_explanation_verifier_1.verifySubjectPracticeMathVectorComplexExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate), verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId; return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_vector_complex_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] }; }; }
