"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PLANE_ANALYTIC_GEOMETRY_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathPlaneAnalyticGeometryLocalGenerator = createSubjectPracticeMathPlaneAnalyticGeometryLocalGenerator;
const subject_practice_math_plane_analytic_geometry_solver_1 = require("./subject-practice-math-plane-analytic-geometry-solver");
const subject_practice_math_plane_analytic_geometry_independent_oracle_1 = require("./subject-practice-math-plane-analytic-geometry-independent-oracle");
const subject_practice_math_plane_analytic_geometry_explanation_verifier_1 = require("./subject-practice-math-plane-analytic-geometry-explanation-verifier");
exports.PLANE_ANALYTIC_GEOMETRY_GENERATOR_VERSION = 'math-plane-analytic-geometry-generator-v1-bounded';
function parameters(scope, seed, attempt) {
    const n = seed % 100000, h = n % 13 - 6, k = Math.floor(n / 13) % 13 - 6, sign = n % 2 ? 1 : -1;
    const p = { scope, l1: [], l2: [], circle: [], point: [] };
    const bases = [[1, 0], [0, 1], [3, 4], [4, 3], [5, 12], [12, 5]], base = bases[(Math.floor(n / 2) + attempt) % 6], a = base[0] * (n % 2 ? 1 : -1), b = base[1] * (Math.floor(n / 2) % 2 ? 1 : -1), N = [1, 1, 5, 5, 13, 13][(Math.floor(n / 2) + attempt) % 6];
    if (scope === subject_practice_math_plane_analytic_geometry_solver_1.PLANE_ANALYTIC_GEOMETRY_SCOPES[0]) {
        const pairs = [[[1, 0], [0, 1]], [[0, 1], [1, 0]], [[1, 2], [2, -1]], [[-2, 1], [1, 3]], [[3, -1], [-1, -2]], [[2, 3], [-3, 1]]], pair = pairs[(Math.floor(n / 3) + attempt) % pairs.length];
        p.l1 = [...pair[0], -pair[0][0] * h - pair[0][1] * k];
        p.l2 = [...pair[1], -pair[1][0] * h - pair[1][1] * k];
        const m = 1 + Math.floor(n / 2) % 3, dx = sign * (n % 2 ? 3 : 4) * m, dy = (Math.floor(n / 2) % 2 ? 1 : -1) * (n % 2 ? 4 : 3) * m;
        p.point = [h + dx, k + dy];
        return p;
    }
    if (scope === subject_practice_math_plane_analytic_geometry_solver_1.PLANE_ANALYTIC_GEOMETRY_SCOPES[1]) {
        const lambda = [-3, -2, 2, 3][(Math.floor(n / 3) + attempt) % 4], c = n % 25 - 12, t = sign * (2 + (Math.floor(n / 5) + attempt) % 5);
        p.l1 = [a, b, c];
        p.l2 = [lambda * a, lambda * b, lambda * (c + t * N)];
        return p;
    }
    if (scope === subject_practice_math_plane_analytic_geometry_solver_1.PLANE_ANALYTIC_GEOMETRY_SCOPES[2]) {
        const t = [[5, 3, 4], [5, 4, 3], [13, 5, 12], [13, 12, 5], [17, 8, 15], [17, 15, 8]][(Math.floor(n / 3) + attempt) % 6], scale = 1 + Math.floor(n / 2) % 2, R = t[0] * scale, d = t[1] * scale;
        p.circle = [-2 * h, -2 * k, h * h + k * k - R * R];
        p.l1 = [a, b, -a * h - b * k + sign * d * N];
        return p;
    }
    const vectors = [[1, 0], [0, 1], [3, 4], [-4, 3], [-3, -4], [4, -3], [2, 5], [-5, -2]], v = vectors[(Math.floor(n / 2) + attempt) % 8], u = v[0], w = v[1];
    p.circle = [-2 * h, -2 * k, h * h + k * k - u * u - w * w];
    p.point = [h + u, k + w];
    return p;
}
function createSubjectPracticeMathPlaneAnalyticGeometryLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, exactScope = (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.PLANE_ANALYTIC_GEOMETRY_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['plane_geometry_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 72 || b.topicCode !== 'M-GEO-001' || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        let selected = null, parameterAttempts = 0;
        for (let attempt = 0; attempt < 64; attempt++) {
            parameterAttempts++;
            const p = parameters(exactScope, seed, attempt), derived = (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryDerive)(p);
            if (!derived || !(0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryParametersFrom)((0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryPrompt)(p, 'zh'), exactScope, 'zh'))
                continue;
            const keys = [derived.answer, ...(0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryDistractors)(p).map(x => x.key)].map(x => (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryOptionKey)(x, exactScope));
            if (keys.includes(null) || new Set(keys).size !== 4)
                continue;
            selected = p;
            break;
        }
        if (!selected)
            return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts };
        const p = selected, answer = (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryDerive)(p).answer, choices = (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryDistractors)(p), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
        const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: x.key })), prompt = (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_plane_analytic_geometry_solver_1.planeAnalyticGeometryPrompt)(p, 'en'), explanation = (0, subject_practice_math_plane_analytic_geometry_explanation_verifier_1.renderPlaneAnalyticGeometryExplanation)(p, answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 72, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['平面解析几何', exactScope],
            optionMetadata: choices.flatMap((x, i) => x.intent ? [{ optionId: 'ABCD'[i], distractorIntent: x.intent, misconceptionTags: [x.intent] }] : []),
            localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['平面解析几何', exactScope] }, en: { prompt: enPrompt, options: options.map(x => ({ ...x })), explanation: explanation.en, knowledgeTags: ['Plane analytic geometry', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_plane_analytic_geometry_solver_1.solveSubjectPracticeMathPlaneAnalyticGeometry)(candidate, context), oracleEvidence = (0, subject_practice_math_plane_analytic_geometry_independent_oracle_1.verifySubjectPracticeMathPlaneAnalyticGeometryWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_plane_analytic_geometry_explanation_verifier_1.verifySubjectPracticeMathPlaneAnalyticGeometryExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, parameterAttempts, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
