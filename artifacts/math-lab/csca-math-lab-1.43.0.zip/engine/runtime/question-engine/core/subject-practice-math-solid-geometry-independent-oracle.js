"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathSolidGeometryWithIndependentOracle = verifySubjectPracticeMathSolidGeometryWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_INDEPENDENT_ORACLE_VERSION = 'math-solid-geometry-independent-oracle-v1-lattice-enumeration';
// Intentionally does not import the primary parser, arithmetic, or generator.
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function read(prompt, scope, english) {
    const cylinder = scope === 'cylinder_volume';
    const words = { cuboid_volume: ['体积', 'volume'], cuboid_surface_area: ['总表面积', 'total surface area'], cuboid_space_diagonal: ['体对角线长度', 'space diagonal length'], cylinder_volume: ['体积（保留 π）', 'volume (leave π exact)'] };
    if (!words[scope])
        return null;
    const suffix = english ? `Find its ${words[scope][1]}.` : `求它的${words[scope][0]}。`;
    if (!String(prompt).endsWith(suffix))
        return null;
    const body = prompt.slice(0, -suffix.length);
    const pattern = cylinder ? (english
        ? /^(?:A right circular cylinder|Consider a right circular cylinder) has base radius r=([0-9]+) cm and height h=([0-9]+) cm\. $/
        : /^(?:一个直圆柱|已知一直圆柱)的底面半径 r=([0-9]+) cm，高 h=([0-9]+) cm。$/)
        : (english
            ? /^(?:A cuboid|Consider a cuboid) has three adjacent edge lengths a=([0-9]+) cm, b=([0-9]+) cm, c=([0-9]+) cm\. $/
            : /^(?:一个长方体|已知一长方体)的三条相邻棱长为 a=([0-9]+) cm、b=([0-9]+) cm、c=([0-9]+) cm。$/);
    const m = body.match(pattern);
    if (!m)
        return null;
    const ns = m.slice(1).map(Number);
    return ns.every(n => Number.isInteger(n) && n > 0 && n <= 30) ? ns : null;
}
function enumerate(ns, scope) {
    if (scope === 'cylinder_volume') {
        // Count r by r area coefficients over h unit layers; keep π symbolic.
        let units = 0;
        for (let z = 0; z < ns[1]; z++)
            for (let x = 0; x < ns[0]; x++)
                for (let y = 0; y < ns[0]; y++)
                    units++;
        return units;
    }
    if (scope === 'cuboid_space_diagonal') {
        let squaredDistance = 0;
        for (const edge of ns)
            for (let i = 0; i < edge; i++)
                squaredDistance += edge;
        for (let length = 1; length <= 52; length++) {
            let square = 0;
            for (let i = 0; i < length; i++)
                square += length;
            if (square === squaredDistance)
                return length;
        }
        return null;
    }
    let cells = 0, exposedFaces = 0;
    for (let x = 0; x < ns[0]; x++)
        for (let y = 0; y < ns[1]; y++)
            for (let z = 0; z < ns[2]; z++) {
                cells++;
                for (const [value, limit] of [[x, ns[0]], [y, ns[1]], [z, ns[2]]]) {
                    if (value === 0)
                        exposedFaces++;
                    if (value === limit - 1)
                        exposedFaces++;
                }
            }
    return scope === 'cuboid_surface_area' ? exposedFaces : cells;
}
function verifySubjectPracticeMathSolidGeometryWithIndependentOracle(candidate, context = {}) {
    const plan = object(context.questionPlan), render = object(plan?.renderConstraints), exactScope = String(render?.exactSolidGeometryScope ?? '');
    const planValid = plan?.taskFamily === 'math_solid_geometry_direct_calculation' && plan?.planTemplate === 'math_solid_geometry_direct_calculation_v1'
        && plan?.subject === 'math' && plan?.targetDifficulty === 'basic'
        && render?.maximumDimensionCm === 30 && render?.integerParametersRequired === true
        && render?.oneDirectSolidMeasurementTarget === true && render?.externalContextAllowed === false
        && render?.finalAnswerShape === 'one_unique_dimensioned_integer_or_pi_multiple';
    const ns = planValid ? read(candidate.prompt, exactScope, false) : null;
    const expectedCoefficient = ns ? enumerate(ns, exactScope) : null;
    const scopeMatched = expectedCoefficient !== null;
    const reasonCodes = [];
    if (!scopeMatched)
        reasonCodes.push('math_solid_geometry_oracle_outside_scope');
    for (const lang of ['zh', 'en']) {
        const translated = read(candidate.localizations?.[lang]?.prompt ?? '', exactScope, lang === 'en');
        if (!translated || JSON.stringify(ns) !== JSON.stringify(translated))
            reasonCodes.push(`math_solid_geometry_oracle_${lang}_parameters_or_target_mismatch`);
        if (JSON.stringify(candidate.localizations?.[lang]?.options) !== JSON.stringify(candidate.options))
            reasonCodes.push(`math_solid_geometry_oracle_${lang}_options_mismatch`);
    }
    const unit = exactScope === 'cuboid_surface_area' ? 'cm^2' : exactScope === 'cuboid_space_diagonal' ? 'cm' : 'cm^3';
    const suffix = `${exactScope === 'cylinder_volume' ? 'π' : ''} ${unit}`;
    const optionVerdicts = (candidate.options ?? []).map(option => {
        const raw = option.text.endsWith(suffix) ? option.text.slice(0, -suffix.length) : '';
        const number = /^[1-9][0-9]*$/.test(raw) ? Number(raw) : null;
        return { optionId: option.id, verdict: number === null ? 'unknown' : number === expectedCoefficient ? 'true' : 'false' };
    });
    if (candidate.options?.length !== 4 || new Set(candidate.options.map(o => o.id)).size !== 4 || new Set(candidate.options.map(o => o.text)).size !== 4
        || candidate.options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || optionVerdicts.some(o => o.verdict === 'unknown'))
        reasonCodes.push('math_solid_geometry_oracle_bad_options');
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (trueOptionIds.length !== 1 || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_solid_geometry_oracle_answer_disagreement');
    return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_INDEPENDENT_ORACLE_VERSION, status: reasonCodes.length ? (scopeMatched ? 'disagreed' : 'abstained') : 'verified',
        scopeId: scopeMatched ? `math-basic-solid-geometry-v1:${exactScope}` : null, exactScope, scopeMatched, expectedCoefficient, optionVerdicts, trueOptionIds, selectedOptionId,
        agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
