"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathSequenceTwoConditionExplanation = verifySubjectPracticeMathSequenceTwoConditionExplanation;
const subject_practice_math_sequence_two_condition_solver_1 = require("./subject-practice-math-sequence-two-condition-solver");
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_EXPLANATION_VERIFIER_VERSION = 'math-sequence-two-condition-explanation-verifier-v1-bilingual-parameter-bound';
function compact(value) { return String(value ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ''); }
function escaped(value) { return String(value).replace('-', '\\-'); }
function assignment(text, label, value) { return new RegExp(`${label}=${escaped(value)}(?:[^0-9]|$)`, 'i').test(text); }
function verifySubjectPracticeMathSequenceTwoConditionExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_sequence_two_condition_solver_1.solveSubjectPracticeMathSequenceTwoCondition)(candidate, context);
    const p = solver.parameters;
    const zh = compact(candidate.localizations?.zh?.explanation ?? candidate.explanation);
    const en = compact(candidate.localizations?.en?.explanation);
    const visibleAssignments = p ? [
        ...p.terms.map((item) => [`a_?${item.index}`, item.value]),
        ...p.sums.map((item) => [`S_?${item.index}`, item.value])
    ] : [];
    const derivedAssignments = p
        ? [['a_?1', p.a1], [p.d === null ? 'q' : 'd', Number(p.d === null ? p.q : p.d)], [`a_?${p.targetIndex}`, p.expectedValue]]
        : [];
    const required = [...visibleAssignments, ...derivedAssignments];
    const zhParametersBound = Boolean(p && required.every(([label, value]) => assignment(zh, label, value)));
    const enParametersBound = Boolean(p && required.every(([label, value]) => assignment(en, label, value)));
    const twoConditionReasoningBound = /(联立|两条条件|消元|substitut|eliminat|two conditions)/i.test(`${zh}${en}`);
    const formulaBound = p?.scope.startsWith('arithmetic_')
        ? /(a_?n=a_?1\+\(n-1\)d|S_?n=|等差|arithmetic)/i.test(`${zh}${en}`)
        : /(a_?n=a_?1q\^\(n-1\)|S_?n=|等比|geometric)/i.test(`${zh}${en}`);
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_sequence_two_condition_explanation_primary_solver_not_verified');
    if (!zhParametersBound)
        reasonCodes.push('math_sequence_two_condition_explanation_zh_parameters_not_bound');
    if (!enParametersBound)
        reasonCodes.push('math_sequence_two_condition_explanation_en_parameters_not_bound');
    if (!twoConditionReasoningBound)
        reasonCodes.push('math_sequence_two_condition_explanation_elimination_step_missing');
    if (!formulaBound)
        reasonCodes.push('math_sequence_two_condition_explanation_formula_missing');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solver.scopeId, zhParametersBound, enParametersBound, twoConditionReasoningBound, formulaBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
