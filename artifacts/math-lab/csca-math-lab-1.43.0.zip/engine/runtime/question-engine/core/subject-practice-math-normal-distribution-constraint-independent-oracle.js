"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NORMAL_DISTRIBUTION_CONSTRAINT_ORACLE_VERSION = void 0;
exports.normalDistributionConstraintIndependentCalculation = normalDistributionConstraintIndependentCalculation;
exports.verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle = verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle;
exports.NORMAL_DISTRIBUTION_CONSTRAINT_ORACLE_VERSION = 'math-normal-distribution-constraint-oracle-v1-independent-partition';
const scopes = ["two_standardized_positions_interval_probability", "affine_absolute_value_interval_probability", "interval_union_difference_probability", "empirical_affine_two_tail_threshold_combination"];
function f(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
    throw Error('denominator'); if (b < 0n) {
    a = -a;
    b = -b;
} if (a.toString(2).length > 512 || b.toString(2).length > 512)
    throw Error('bound'); let u = a < 0n ? -a : a, v = b; while (v) {
    const r = u % v;
    u = v;
    v = r;
} return [a / (u || 1n), b / (u || 1n)]; }
const add = (a, b) => f(a[0] * b[1] + b[0] * a[1], a[1] * b[1]), sub = (a, b) => f(a[0] * b[1] - b[0] * a[1], a[1] * b[1]), mul = (a, b) => f(a[0] * b[0], a[1] * b[1]), div = (a, b) => f(a[0] * b[1], a[1] * b[0]), cmp = (a, b) => a[0] * b[1] < b[0] * a[1] ? -1 : a[0] * b[1] > b[0] * a[1] ? 1 : 0, txt = (a) => String(a[0]) + (a[1] === 1n ? '' : '/' + a[1]);
function parse(s) { if (typeof s !== 'string' || s.length > 128 || !/^[-+]?\d+(?:\/[1-9]\d*|\.\d{1,8})?$/.test(s))
    throw Error('rational'); const [a, b] = s.split('/'); if (b)
    return f(BigInt(a), BigInt(b)); const dot = a.indexOf('.'); if (dot < 0)
    return f(BigInt(a)); const sign = a[0] === '-' ? -1n : 1n, plain = a.replace(/^[-+]/, ''), pieces = plain.split('.'); return f(sign * BigInt(pieces.join('')), 10n ** BigInt(pieces[1].length)); }
function integer(s, lo, hi) { const q = parse(s); if (q[1] !== 1n || q[0] < BigInt(lo) || q[0] > BigInt(hi))
    throw Error('integer'); return Number(q[0]); }
const names = [["u", "z1", "v", "z2", "left", "right"], ["mu", "variance", "a", "b", "c", "r"], ["mu", "variance", "Aleft", "Aright", "Bleft", "Bright", "Cleft", "Cright"], ["mu", "variance", "a", "b", "tailL", "tailR"]];
const startsZh = ["X服从正态分布，均值mu、标准差sigma未知，sigma>0。两个精确标准化关系为(u-mu)/sigma=z1及(v-mu)/sigma=z2，求P(left<=X<=right)。", "X服从均值mu、方差variance的正态分布，Y=aX+b，求P(|Y-c|<=r)。", "X服从均值mu、方差variance的正态分布。A=[Aleft,Aright]，B=[Bleft,Bright]，C=[Cleft,Cright]，求X属于(A并B)去掉C的概率。", "X服从均值mu、方差variance的正态分布，Y=aX+b。利用给定经验规律，P(Y<l)约为tailL，P(Y>u)约为tailR，求2l+u的近似值。"];
const startsEn = ["X is normal with unknown mean mu and positive standard deviation sigma. The exact standardized relations are (u-mu)/sigma=z1 and (v-mu)/sigma=z2. Find P(left<=X<=right).", "X is normal with mean mu and variance variance. Let Y=aX+b. Find P(|Y-c|<=r).", "X is normal with mean mu and variance variance. Let A=[Aleft,Aright], B=[Bleft,Bright], C=[Cleft,Cright]. Find the probability that X belongs to (A union B) minus C.", "X is normal with mean mu and variance variance. Let Y=aX+b. Under the supplied empirical rule, P(Y<l) is approximately tailL and P(Y>u) is approximately tailR. Find the approximate value of 2l+u."];
const suffixesZh = [" 给定标准正态累计概率近似值：Phi(-2)=0.0228，Phi(-1)=0.1587，Phi(0)=0.5000，Phi(1)=0.8413，Phi(2)=0.9772。仅按此表求近似概率。", " 给定经验规律：均值左右1、2、3个标准差内的概率分别约为68%、95%、99.7%；阈值及最终结果均为该规律下的近似值。"];
const suffixesEn = [" Given approximate standard normal cumulative probabilities: Phi(-2)=0.0228, Phi(-1)=0.1587, Phi(0)=0.5000, Phi(1)=0.8413, Phi(2)=0.9772. Use this table for approximate probabilities.", " Given empirical rule: probabilities within 1, 2, 3 standard deviations of the mean are approximately 68%, 95%, 99.7%. Thresholds and the final result are approximate under this rule."];
function parameters(text, index, lang) { if (typeof text !== 'string' || text.length > 4000)
    throw Error('prompt'); const leads = lang === 'zh' ? ['计算问题：', '概率模型：', '请分析：'] : ['Calculation: ', 'Probability model: ', 'Analyze: '], suffix = (lang === 'zh' ? suffixesZh : suffixesEn)[index === 3 ? 1 : 0], start = (lang === 'zh' ? startsZh : startsEn)[index] + (lang === 'zh' ? '参数：' : ' Parameters: '); const variant = leads.findIndex(lead => text.startsWith(lead + start)); if (variant < 0 || !text.endsWith(suffix))
    throw Error('prompt'); const tokens = text.slice(leads[variant].length + start.length, -suffix.length).split('; '); if (tokens.length !== names[index].length)
    throw Error('fields'); const data = tokens.map((token, j) => { const prefix = names[index][j] + '=('; if (!token.startsWith(prefix) || !token.endsWith(')'))
    throw Error('label'); return token.slice(prefix.length, -1); }); if (data.join(';').length % 3 !== variant)
    throw Error('variant_binding'); return data; }
const object = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
const units = [228, 1587, 5000, 8413, 9772], zs = [-2, -1, 0, 1, 2];
function nearest(x) { const exact = zs.findIndex(z => cmp(x, f(z)) === 0); if (exact >= 0)
    return [units[exact] - 1, units[exact] + 1]; let lower = 0; while (lower < 5 && cmp(f(zs[lower]), x) < 0)
    lower++; return [lower === 0 ? 0 : units[lower - 1] - 1, lower === 5 ? 10000 : units[lower] + 1]; }
const gi = (q) => { const j = zs.findIndex(z => cmp(q, f(z)) === 0); if (j < 0)
    throw Error('missing_cdf_endpoint'); return j; };
function raw(d, i) {
    if (i < 0 || d.length !== names[i].length)
        throw Error('parameters');
    let mean = 0, sd = 0, bandIndices = [], lo = 0, hi = 0, answer;
    const errors = [];
    const push = (intent, v) => { if (i !== 3 && (cmp(v, f(0)) < 0 || cmp(v, f(1)) > 0))
        return; errors.push({ intent, key: txt(v) }); };
    if (i === 0) {
        const u = integer(d[0], -36, 56), z1 = integer(d[1], -2, 2), v = integer(d[2], -36, 56), z2 = integer(d[3], -2, 2);
        if (z1 >= z2)
            throw Error('positions');
        const valid = [];
        for (let m = -20; m <= 40; m++)
            for (let s = 2; s <= 8; s++)
                if (m + z1 * s === u && m + z2 * s === v)
                    valid.push([m, s]);
        if (valid.length !== 1)
            throw Error('nonunique_parameters');
        [mean, sd] = valid[0];
    }
    else {
        mean = integer(d[0], -20, 40);
        const variance = integer(d[1], 4, 64);
        const roots = [2, 3, 4, 5, 6, 7, 8].filter(x => x * x === variance);
        if (roots.length !== 1)
            throw Error('variance');
        sd = roots[0];
    }
    const coordinate = (s) => div(sub(parse(s), f(mean)), f(sd)), mass = (mask) => mask.reduce((sum, yes, j) => sum + (yes ? units[j + 1] - units[j] : 0), 0);
    if (i === 0) {
        lo = gi(coordinate(d[4]));
        hi = gi(coordinate(d[5]));
        if (lo >= hi)
            throw Error('interval');
        for (let j = 0; j < 4; j++) {
            const midpoint = f(mean * 2 + sd * (zs[j] + zs[j + 1]), 2);
            if (cmp(midpoint, parse(d[4])) > 0 && cmp(midpoint, parse(d[5])) < 0)
                bandIndices.push(j);
        }
        answer = txt(f(bandIndices.reduce((sum, j) => sum + units[j + 1] - units[j], 0), 10000));
    }
    else if (i === 1) {
        const a = integer(d[2], -3, 3), b = integer(d[3], -12, 12), center = parse(d[4]), radius = parse(d[5]);
        if (![-3, -2, 2, 3].includes(a) || radius[0] <= 0n || cmp(center, f(a * mean + b)) === 0)
            throw Error('affine_event');
        const e1 = div(sub(sub(center, radius), f(b)), f(a)), e2 = div(sub(add(center, radius), f(b)), f(a)), l = cmp(e1, e2) < 0 ? e1 : e2, u = cmp(e1, e2) < 0 ? e2 : e1;
        lo = gi(div(sub(l, f(mean)), f(sd)));
        hi = gi(div(sub(u, f(mean)), f(sd)));
        if (lo >= hi)
            throw Error('interval');
        for (let j = 0; j < 4; j++) {
            const x = f(mean * 2 + sd * (zs[j] + zs[j + 1]), 2), y = sub(add(mul(f(a), x), f(b)), center), absolute = f(y[0] < 0n ? -y[0] : y[0], y[1]);
            if (cmp(absolute, radius) < 0)
                bandIndices.push(j);
        }
        answer = txt(f(bandIndices.reduce((sum, j) => sum + units[j + 1] - units[j], 0), 10000));
    }
    else if (i === 2) {
        const ends = d.slice(2).map(coordinate), indices = ends.map(gi);
        if (indices[0] >= indices[1] || indices[2] >= indices[3] || indices[4] >= indices[5])
            throw Error('interval_order');
        const contains = (j, k) => { const midpoint = f(zs[j] + zs[j + 1], 2); return cmp(midpoint, ends[k]) > 0 && cmp(midpoint, ends[k + 1]) < 0; };
        const A = [0, 1, 2, 3].map(j => contains(j, 0)), B = [0, 1, 2, 3].map(j => contains(j, 2)), C = [0, 1, 2, 3].map(j => contains(j, 4));
        const mask = A.map((yes, j) => (yes || B[j]) && !C[j]);
        if (!A.some((yes, j) => yes && !B[j] && !C[j]) || !B.some((yes, j) => yes && !A[j] && !C[j]) || !C.some((yes, j) => yes && (A[j] || B[j])))
            throw Error('ineffective_interval');
        bandIndices = mask.flatMap((yes, j) => yes ? [j] : []);
        answer = txt(f(mass(mask), 10000));
        lo = Math.min(indices[0], indices[2]);
        hi = Math.max(indices[1], indices[3]);
        push('omit_exclusion_interval', f(mass(A.map((yes, j) => yes || B[j])), 10000));
        push('omit_interval_A', f(mass(B.map((yes, j) => yes && !C[j])), 10000));
        push('omit_interval_B', f(mass(A.map((yes, j) => yes && !C[j])), 10000));
        push('double_count_overlap', f(mass(A.map((yes, j) => yes && !C[j])) + mass(B.map((yes, j) => yes && !C[j])), 10000));
    }
    else {
        const a = integer(d[2], -3, 3), b = integer(d[3], -12, 12);
        if (![-3, -2, 2, 3].includes(a))
            throw Error('coefficient');
        const levels = [f(4, 25), f(1, 40), f(3, 2000)], left = levels.findIndex(t => cmp(t, parse(d[4])) === 0) + 1, right = levels.findIndex(t => cmp(t, parse(d[5])) === 0) + 1, m = a * mean + b, s = Math.abs(a) * sd;
        if (!left || !right || left === right || right === 2 * left || m === 0)
            throw Error('tail_levels');
        const L = m - left * s, U = m + right * s;
        answer = txt(add(mul(f(2), f(L)), f(U)));
        push('swap_unequal_tails', f(2 * (m - right * s) + m + left * s));
        push('wrong_lower_tail_side', f(2 * (m + left * s) + m + right * s));
        push('omit_affine_shift', f(2 * (a * mean - left * s) + a * mean + right * s));
        push('variance_as_standard_deviation', f(2 * (m - left * Math.abs(a) * sd * sd) + m + right * Math.abs(a) * sd * sd));
        push('signed_standard_deviation', f(2 * (m - left * a * sd) + m + right * a * sd));
    }
    if (i !== 3) {
        push('use_upper_cumulative_only', f(units[hi], 10000));
        push('complement_event', sub(f(1), parse(answer)));
        push('halve_probability_again', div(parse(answer), f(2)));
        push('use_lower_cumulative_only', f(units[lo], 10000));
        push('add_cumulative_values', f(units[hi] + units[lo], 10000));
    }
    const coefficients = [0, 0, 0, 0, 0];
    for (const j of bandIndices) {
        coefficients[j]--;
        coefficients[j + 1]++;
    }
    const separation = f(coefficients.reduce((a, x) => a + Math.abs(x), 0), 10000);
    const distinct = errors.filter((e, j, all) => { const delta = sub(parse(e.key), parse(answer)), distance = f(delta[0] < 0n ? -delta[0] : delta[0], delta[1]); return e.key !== answer && all.findIndex(x => x.key === e.key) === j && (i === 3 || cmp(distance, separation) > 0); }).slice(0, 3);
    if (distinct.length !== 3)
        throw Error('error_choices');
    return { answer, errors: distinct, mean, sd, bandIndices };
}
function normalDistributionConstraintIndependentCalculation(data, index) {
    const chosen = raw(data, index), witnesses = [];
    const changed = (j, v) => data.map((s, k) => j === k ? v : s);
    const witness = (label, alternatives) => { for (const d of alternatives) {
        try {
            const r = raw(d, index);
            if (r.answer !== chosen.answer) {
                witnesses.push({ omitted: label, completion: d, differentAnswer: r.answer });
                return;
            }
        }
        catch { }
    } throw Error('ineffective_' + label); };
    if (index === 0) {
        for (let omitted = 0; omitted < 2; omitted++) {
            let result = null;
            for (let mean = -20; mean <= 40 && !result; mean++)
                for (let sd = 2; sd <= 8 && !result; sd++) {
                    const ok = [mean + Number(data[1]) * sd === Number(data[0]), mean + Number(data[3]) * sd === Number(data[2])];
                    if (ok[omitted] || !ok[1 - omitted])
                        continue;
                    const L = nearest(div(sub(parse(data[4]), f(mean)), f(sd))), U = nearest(div(sub(parse(data[5]), f(mean)), f(sd))), bounds = [Math.max(0, U[0] - L[1]), Math.min(10000, U[1] - L[0])], ans = mul(parse(chosen.answer), f(10000));
                    if (cmp(f(bounds[1]), sub(ans, f(2))) < 0 || cmp(f(bounds[0]), add(ans, f(2))) > 0)
                        result = { omitted: omitted === 0 ? 'first_standardized_position' : 'second_standardized_position', completion: [String(mean), String(sd)], differentAnswer: 'probability_units_in[' + bounds.join(',') + ']' };
                }
            if (!result)
                throw Error('coordinate_counterexample');
            witnesses.push(result);
        }
        const events = [];
        for (let l = -2; l < 2; l++)
            for (let u = l + 1; u <= 2; u++) {
                const d = data.slice();
                d[4] = String(chosen.mean + l * chosen.sd);
                d[5] = String(chosen.mean + u * chosen.sd);
                events.push(d);
            }
        witness('requested_interval', events);
    }
    else if (index === 1) {
        witness('distribution_location', [-2, -1, 1, 2].map(k => changed(0, String(chosen.mean + k * chosen.sd))));
        witness('affine_shift', [-2, -1, 1, 2].map(k => changed(3, String(Number(data[3]) + k * Number(data[2]) * chosen.sd))));
        witness('absolute_event_location', [-2, -1, 1, 2].map(k => changed(4, txt(add(parse(data[4]), f(k * Math.abs(Number(data[2])) * chosen.sd))))));
    }
    else if (index === 2) {
        for (const label of ['omit_interval_A', 'omit_interval_B', 'omit_exclusion_interval']) {
            const e = chosen.errors.find(x => x.intent === label);
            if (!e)
                throw Error('event_counterexample');
            witnesses.push({ omitted: label, completion: data.slice(), differentAnswer: e.key });
        }
    }
    else {
        witness('transformed_location', [-1, 1].map(k => changed(0, String(chosen.mean + k))));
        witness('transformed_scale', [-1, 1].map(k => changed(1, String((chosen.sd + k) ** 2))));
        witness('tail_levels', ['4/25', '1/40', '3/2000'].flatMap(x => [changed(4, x), changed(5, x)]));
    }
    return { answer: chosen.answer, errors: chosen.errors, certificate: { method: 'independent_bounded_coordinate_enumeration_and_band_membership', complete: true, examined: index === 0 ? 427 : 4, completions: [data], bands: chosen.bandIndices, effectiveConstraints: witnesses, approximate: true } };
}
function verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle(candidate, context = {}) {
    const plan = object(context.questionPlan), render = object(plan?.renderConstraints), scenario = object(plan?.scenarioContract), scope = render?.exactNormalDistributionConstraintScope, index = scopes.indexOf(scope), reasonCodes = [];
    let result = null;
    try {
        const expected = { topicCode: 'M-STAT-002', boundedIntegerAndHalfIntegerParameters: true, maximumConstructionAttempts: 256, maximumEnumeratedParameterCompletions: 4096, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
        if (plan?.schemaVersion !== 'subject-practice-question-plan-v1' || plan?.policyVersion !== 'subject-practice-question-plan-policy-v1' || plan?.subject !== 'math' || plan?.topicId !== 77 || plan?.targetDifficulty !== 'hard' || plan?.representationType !== 'text' || plan?.taskFamily !== 'math_normal_distribution_constraint_reasoning' || plan?.planTemplate !== 'math_normal_distribution_constraint_reasoning_v1' || render?.questionType !== 'single_choice' || index < 0 || !Object.entries(expected).every(([k, v]) => render?.[k] === v) || scenario?.scenarioMode !== 'abstract' || scenario?.scenarioEntity !== 'normal_distribution_constraint_system' || scenario?.scenarioAction !== scope)
            throw Error('contract');
        const data = parameters(candidate.prompt, index, 'zh');
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parameters(candidate.localizations?.[lang]?.prompt ?? '', index, lang)) !== JSON.stringify(data))
                throw Error('bilingual_parameters');
        result = normalDistributionConstraintIndependentCalculation(data, index);
    }
    catch (e) {
        reasonCodes.push('normal_distribution_oracle_' + (e instanceof Error ? e.message : 'invalid'));
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 77 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('normal_distribution_oracle_identity');
    const optionKey = (text) => { try {
        const q = parse(text.trim());
        return index !== 3 && (q[0] < 0n || cmp(q, f(1)) > 0) ? null : txt(q);
    }
    catch {
        return null;
    } }, options = candidate.options ?? [], keys = options.map(x => optionKey(x.text));
    if (options.length !== 4 || new Set(options.map(x => x.id)).size !== 4 || options.some(x => !['A', 'B', 'C', 'D'].includes(x.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('normal_distribution_oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(x => [x.id, optionKey(x.text)])) !== JSON.stringify(options.map((x, j) => [x.id, keys[j]])))
            reasonCodes.push('normal_distribution_oracle_' + lang + '_options');
    const expectedAnswer = result?.answer ?? null, trueOptionIds = options.filter((_, j) => !!result && keys[j] === expectedAnswer).map(x => x.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || candidate.correctAnswer !== selectedOptionId)
        reasonCodes.push('normal_distribution_oracle_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(x => x.optionId)).size !== 3 || new Set(meta.map(x => x.distractorIntent)).size !== 3 || meta.some(x => x.optionId === selectedOptionId || !result?.errors.some(e => e.intent === x.distractorIntent && e.key === keys[options.findIndex(o => o.id === x.optionId)])))
        reasonCodes.push('normal_distribution_oracle_error_intent');
    const scopeId = index >= 0 ? 'math-hard-normal-distribution-constraint-v1:' + scope : null;
    return { oracleVersion: exports.NORMAL_DISTRIBUTION_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId, scopeMatched: index >= 0, expectedAnswer, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: !!selectedOptionId && selectedOptionId === candidate.correctAnswer, certificate: result?.certificate ?? null, completeCertificate: !!result, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
