"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathSequenceTwoConditionLocalGenerator = createSubjectPracticeMathSequenceTwoConditionLocalGenerator;
const subject_practice_math_sequence_two_condition_solver_1 = require("./subject-practice-math-sequence-two-condition-solver");
const subject_practice_math_sequence_two_condition_independent_oracle_1 = require("./subject-practice-math-sequence-two-condition-independent-oracle");
const subject_practice_math_sequence_two_condition_explanation_verifier_1 = require("./subject-practice-math-sequence-two-condition-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_LOCAL_GENERATOR_VERSION = 'math-sequence-two-condition-local-generator-v1-bounded-four-scope';
const SCOPES = new Set([
    'arithmetic_two_terms_target_term',
    'arithmetic_term_and_sum_target_term',
    'geometric_two_terms_target_term',
    'geometric_term_and_sum_target_term'
]);
function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').trim(); }
function normalizedSeed(value) { const number = Number(value); return Number.isFinite(number) ? Math.abs(Math.trunc(number)) : 0; }
function scopeFrom(planValue, validate) {
    const plan = object(planValue);
    const render = object(plan?.renderConstraints);
    const scope = clean(render?.exactSequenceTwoConditionScope);
    return validate(planValue).valid
        && clean(plan?.taskFamily) === 'math_sequence_two_condition_calculation'
        && clean(plan?.planTemplate) === 'math_sequence_two_condition_calculation_v1'
        && SCOPES.has(scope) ? scope : null;
}
function distinctAlternatives(correct, candidates) {
    const output = [];
    const seen = new Set();
    for (const item of candidates) {
        if (!Number.isSafeInteger(item.value) || seen.has(item.value))
            continue;
        seen.add(item.value);
        output.push(item);
        if (output.length === 4)
            return output;
    }
    for (let offset = 1; output.length < 4; offset += 1)
        for (const sign of [1, -1]) {
            const value = correct + sign * offset;
            if (seen.has(value))
                continue;
            seen.add(value);
            output.push({ value, distractorIntent: `fallback_elimination_offset_${sign > 0 ? 'plus' : 'minus'}_${offset}`, misconceptionTags: ['two_condition_arithmetic_error'] });
            if (output.length === 4)
                break;
        }
    return output;
}
function candidateFor(blueprint, seed, scope) {
    const arithmetic = scope.startsWith('arithmetic_');
    const a1 = arithmetic ? [-5, -2, 1, 3, 6, 8][seed % 6] : [1, 2, 3, 4][seed % 4];
    const d = arithmetic ? [-4, -3, -2, 2, 3, 4][(seed * 3 + 1) % 6] : null;
    const q = arithmetic ? null : [2, 3][seed % 2];
    const targetIndex = arithmetic ? 7 + (seed % 2) : 5;
    const twoTerms = scope.endsWith('two_terms_target_term');
    const termIndices = arithmetic ? (twoTerms ? [2, 5] : [2]) : (twoTerms ? [2, 3] : [2]);
    const sumIndex = twoTerms ? null : (arithmetic ? 5 : 3);
    const values = (0, subject_practice_math_sequence_two_condition_solver_1.evaluateMathSequenceTwoCondition)({ scope, a1, d, q, termIndices, sumIndex, targetIndex });
    const correct = values.expectedValue;
    const step = Number(arithmetic ? d : q);
    const providedTerm = values.termValues[0].value;
    const alternatives = distinctAlternatives(correct, [
        { value: correct, distractorIntent: null, misconceptionTags: [] },
        { value: providedTerm, distractorIntent: 'returned_a_given_term_without_solving', misconceptionTags: ['given_target_confusion'] },
        { value: arithmetic ? a1 + targetIndex * step : a1 * (step ** targetIndex), distractorIntent: 'used_target_index_instead_of_index_minus_one', misconceptionTags: ['sequence_index_off_by_one'] },
        { value: arithmetic ? correct - step : correct / step, distractorIntent: 'stopped_one_sequence_step_early', misconceptionTags: ['sequence_index_off_by_one'] },
        { value: arithmetic ? correct + step : correct * step, distractorIntent: 'advanced_one_sequence_step_too_far', misconceptionTags: ['sequence_index_off_by_one'] }
    ]);
    const correctIndex = seed % 4;
    const ordered = alternatives.slice(1);
    ordered.splice(correctIndex, 0, alternatives[0]);
    const ids = ['A', 'B', 'C', 'D'];
    const options = ordered.map((item, index) => ({ id: ids[index], text: String(item.value) }));
    const givensZh = twoTerms
        ? values.termValues.map((item) => `a_${item.index}=${item.value}`).join('，')
        : `a_${values.termValues[0].index}=${values.termValues[0].value}，S_${values.sum.index}=${values.sum.value}`;
    const givensEn = twoTerms
        ? values.termValues.map((item) => `a_${item.index}=${item.value}`).join(' and ')
        : `a_${values.termValues[0].index}=${values.termValues[0].value} and S_${values.sum.index}=${values.sum.value}`;
    const prompt = `已知${arithmetic ? '等差' : '等比'}数列满足${givensZh}，求 a_${targetIndex}。`;
    const promptEn = `A${arithmetic ? 'n arithmetic' : ' geometric'} sequence satisfies ${givensEn}. Find a_${targetIndex}.`;
    const derivationZh = arithmetic
        ? twoTerms
            ? `由 a_n=a_1+(n-1)d，将 a_${values.termValues[0].index}=${values.termValues[0].value} 与 a_${values.termValues[1].index}=${values.termValues[1].value} 两条条件联立消元，得 d=${d}、a_1=${a1}；故 a_${targetIndex}=a_1+(${targetIndex}-1)d=${correct}，即 a_${targetIndex}=${correct}。`
            : `由 a_n=a_1+(n-1)d、S_n=n[2a_1+(n-1)d]/2，将 a_${values.termValues[0].index}=${values.termValues[0].value} 与 S_${values.sum.index}=${values.sum.value} 两条条件联立消元，得 d=${d}、a_1=${a1}；故 a_${targetIndex}=a_1+(${targetIndex}-1)d=${correct}，即 a_${targetIndex}=${correct}。`
        : twoTerms
            ? `由 a_n=a_1q^(n-1)，将 a_${values.termValues[0].index}=${values.termValues[0].value} 与 a_${values.termValues[1].index}=${values.termValues[1].value} 两条条件联立相除，得 q=${q}、a_1=${a1}；故 a_${targetIndex}=a_1q^(${targetIndex}-1)=${correct}，即 a_${targetIndex}=${correct}。`
            : `由 a_n=a_1q^(n-1)、S_n=a_1(q^n-1)/(q-1)，将 a_${values.termValues[0].index}=${values.termValues[0].value} 与 S_${values.sum.index}=${values.sum.value} 两条条件联立消元，得 q=${q}、a_1=${a1}；故 a_${targetIndex}=a_1q^(${targetIndex}-1)=${correct}，即 a_${targetIndex}=${correct}。`;
    const derivationEn = arithmetic
        ? twoTerms
            ? `Using a_n=a_1+(n-1)d, eliminate between the two conditions a_${values.termValues[0].index}=${values.termValues[0].value} and a_${values.termValues[1].index}=${values.termValues[1].value}; this gives d=${d} and a_1=${a1}. Therefore a_${targetIndex}=a_1+(${targetIndex}-1)d=${correct}; hence a_${targetIndex}=${correct}.`
            : `Using a_n=a_1+(n-1)d and S_n=n[2a_1+(n-1)d]/2, eliminate between the two conditions a_${values.termValues[0].index}=${values.termValues[0].value} and S_${values.sum.index}=${values.sum.value}; this gives d=${d} and a_1=${a1}. Therefore a_${targetIndex}=a_1+(${targetIndex}-1)d=${correct}; hence a_${targetIndex}=${correct}.`
        : twoTerms
            ? `Using a_n=a_1q^(n-1), divide the two conditions a_${values.termValues[0].index}=${values.termValues[0].value} and a_${values.termValues[1].index}=${values.termValues[1].value}; this gives q=${q} and a_1=${a1}. Therefore a_${targetIndex}=a_1q^(${targetIndex}-1)=${correct}; hence a_${targetIndex}=${correct}.`
            : `Using a_n=a_1q^(n-1) and S_n=a_1(q^n-1)/(q-1), eliminate between the two conditions a_${values.termValues[0].index}=${values.termValues[0].value} and S_${values.sum.index}=${values.sum.value}; this gives q=${q} and a_1=${a1}. Therefore a_${targetIndex}=a_1q^(${targetIndex}-1)=${correct}; hence a_${targetIndex}=${correct}.`;
    return {
        subject: 'math', topicId: blueprint.topicId, blueprintId: blueprint.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice',
        prompt, options, correctAnswer: ids[correctIndex], explanation: derivationZh,
        knowledgeTags: ['数列', arithmetic ? '等差数列' : '等比数列', '两条件反求', scope],
        optionMetadata: ordered.flatMap((item, index) => index === correctIndex ? [] : [{ optionId: ids[index], distractorIntent: item.distractorIntent ?? 'unclassified_two_condition_error', misconceptionTags: item.misconceptionTags }]),
        localizations: { zh: { prompt, options, explanation: derivationZh, knowledgeTags: ['数列', '两条件反求'] }, en: { prompt: promptEn, options, explanation: derivationEn, knowledgeTags: ['Sequences', 'Two-condition inference'] } },
        syllabusVersion: blueprint.syllabusVersion
    };
}
function createSubjectPracticeMathSequenceTwoConditionLocalGenerator(ports) {
    return function generate(input) {
        const seed = normalizedSeed(input.seed);
        const exactScope = scopeFrom(input.questionPlan, ports.validate);
        const supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'medium' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice';
        if (!exactScope || !supported)
            return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_sequence_two_condition_local_generator_question_plan_not_supported'] };
        const candidate = candidateFor(input.blueprint, seed, exactScope);
        const context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_sequence_two_condition_solver_1.solveSubjectPracticeMathSequenceTwoCondition)(candidate, context);
        const oracleEvidence = (0, subject_practice_math_sequence_two_condition_independent_oracle_1.verifySubjectPracticeMathSequenceTwoConditionWithIndependentOracle)(candidate, context);
        const explanationEvidence = (0, subject_practice_math_sequence_two_condition_explanation_verifier_1.verifySubjectPracticeMathSequenceTwoConditionExplanation)(candidate, context);
        const adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_TWO_CONDITION_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_sequence_two_condition_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
