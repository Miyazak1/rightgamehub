"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SOLID_GEOMETRY_TWO_STEP_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathSolidGeometryTwoStepWithIndependentOracle = verifySubjectPracticeMathSolidGeometryTwoStepWithIndependentOracle;
exports.SOLID_GEOMETRY_TWO_STEP_ORACLE_VERSION = 'math-solid-geometry-two-step-oracle-v1-enumerated-certificates';
// No primary parser, arithmetic, explanation, or generator is imported.
const scopes = ['cuboid_volume_to_surface_area', 'cuboid_surface_area_to_space_diagonal', 'cylinder_volume_to_total_surface_area', 'cone_radius_height_to_lateral_area'];
function read(text, index, english) {
    const patterns = english ? [
        /^A cuboid has adjacent edges a=(\d+) cm and b=(\d+) cm and volume V=(\d+) cm\^3\. Find its total surface area S \(in cm\^2\)\.$/,
        /^A cuboid has adjacent edges a=(\d+) cm and b=(\d+) cm and total surface area S=(\d+) cm\^2\. Find its space diagonal length d \(in cm, keep radicals exact\)\.$/,
        /^A right circular cylinder has base radius r=(\d+) cm and volume V=(\d+)π cm\^3\. Find its total surface area S including both bases \(in cm\^2, keep π exact\)\.$/,
        /^A right circular cone has base radius r=(\d+) cm and height h=(\d+) cm\. Find its lateral area A excluding the base \(in cm\^2, keep π and radicals exact\)\.$/
    ] : [
        /^长方体的两条相邻棱长 a=(\d+) cm、b=(\d+) cm，体积 V=(\d+) cm\^3。求总表面积 S（单位 cm\^2）。$/,
        /^长方体的两条相邻棱长 a=(\d+) cm、b=(\d+) cm，总表面积 S=(\d+) cm\^2。求体对角线长度 d（单位 cm，保留精确根式）。$/,
        /^直圆柱的底面半径 r=(\d+) cm，体积 V=(\d+)π cm\^3。求包含两个底面的总表面积 S（单位 cm\^2，保留 π）。$/,
        /^直圆锥的底面半径 r=(\d+) cm，高 h=(\d+) cm。求不含底面的侧面积 A（单位 cm\^2，保留 π 和精确根式）。$/
    ];
    if (typeof text !== 'string' || text.length > 700)
        return null;
    const match = patterns[index]?.exec(text);
    if (!match)
        return null;
    const values = match.slice(1).map(Number);
    return values.every(n => Number.isSafeInteger(n) && n > 0) ? values : null;
}
function option(text, index) {
    if (typeof text !== 'string' || text.length > 120)
        return null;
    const unit = index === 1 ? ' cm' : ' cm^2';
    if (!text.trim().endsWith(unit))
        return null;
    let expression = text.trim().slice(0, -unit.length);
    const pi = expression.endsWith('π');
    if (pi !== (index >= 2))
        return null;
    if (pi)
        expression = expression.slice(0, -1);
    const parts = expression.split('*sqrt(');
    if (parts.length > 2 || !/^[1-9]\d{0,5}$/.test(parts[0]))
        return null;
    let q = 1n;
    if (parts.length === 2) {
        if (!/^[1-9]\d{0,8}\)$/.test(parts[1]))
            return null;
        q = BigInt(parts[1].slice(0, -1));
    }
    return String(BigInt(parts[0]) * BigInt(parts[0]) * q);
}
function voxels(a, b, c) {
    let volume = 0, surface = 0;
    for (let x = 0; x < a; x++)
        for (let y = 0; y < b; y++)
            for (let z = 0; z < c; z++) {
                volume++;
                for (const [p, n] of [[x, a], [y, b], [z, c]]) {
                    if (p === 0)
                        surface++;
                    if (p + 1 === n)
                        surface++;
                }
            }
    return { volume, surface };
}
function sq(n) { let total = 0; for (let i = 0; i < n; i++)
    total += n; return total; }
function certificate(v, i) {
    const [a, b, k] = v, dim = (n) => Number.isInteger(n) && n >= 1 && n <= 30;
    if (!dim(a) || i < 0 || i > 3 || v.length !== (i < 2 ? 3 : 2) || i < 2 && !dim(b) || i === 3 && !dim(b))
        return null;
    if (i === 0 && k > 27000 || i === 1 && k > 5400 || i === 2 && b > 27000)
        return null;
    let c = 0, answerSquared = 0, method = '', matches = [], surface = 0;
    if (i < 2) {
        for (let edge = 1; edge <= 30; edge++) {
            const test = voxels(a, b, edge);
            if ((i === 0 ? test.volume : test.surface) === k)
                matches.push(edge);
        }
        if (matches.length !== 1)
            return null;
        c = matches[0];
        surface = voxels(a, b, c).surface;
        answerSquared = i === 0 ? surface * surface : sq(a) + sq(b) + sq(c);
        method = 'unique_voxel_reconstruction_and_coordinate_certificate';
    }
    else if (i === 2) {
        let layer = 0;
        for (let x = 0; x < a; x++)
            for (let y = 0; y < a; y++)
                layer++;
        let volume = 0;
        for (let height = 1; height <= 30; height++) {
            volume += layer;
            if (volume === b)
                matches.push(height);
        }
        if (matches.length !== 1)
            return null;
        c = matches[0];
        // Unrolled rectangle: circumference coefficient 2r repeated h times, plus two disks.
        let rectangle = 0;
        for (let strip = 0; strip < c; strip++)
            rectangle += a + a;
        surface = rectangle + layer + layer;
        answerSquared = surface * surface;
        method = 'unique_layer_reconstruction_unrolled_rectangle_and_caps';
    }
    else {
        answerSquared = sq(a) * (sq(a) + sq(b));
        method = 'squared_generatrix_and_sector_arc_certificate';
    }
    const wrong = [];
    const add = (n, q, intent) => wrong.push({ intent, square: String(BigInt(n) * BigInt(n) * BigInt(q)) });
    if (i === 0) {
        add(surface / 2, 1, 'count_each_opposite_face_pair_once');
        add(2 * c * (a + b), 1, 'omit_both_base_faces');
        add(2 * a * b, 1, 'count_only_two_base_faces');
        add(surface - a * b, 1, 'omit_one_base_face');
    }
    else if (i === 1) {
        add(1, sq(a) + sq(b), 'use_base_diagonal');
        add(answerSquared, 1, 'omit_final_square_root');
        add(a + b + c, 1, 'use_edge_path_length');
        add(Math.max(a, b, c), 1, 'use_longest_edge');
    }
    else if (i === 2) {
        add(surface - 2 * sq(a), 1, 'omit_both_cylinder_bases');
        add(surface - sq(a), 1, 'count_only_one_cylinder_base');
        add(2 * sq(a), 1, 'omit_cylinder_lateral_area');
        add(8 * sq(a) + 4 * a * c, 1, 'use_diameter_as_surface_radius');
    }
    else {
        const q = sq(a) + sq(b);
        add(a * b, 1, 'use_height_as_slant_height');
        add(1, q, 'omit_radius_factor');
        add(a * q, 1, 'omit_slant_height_square_root');
        add(2 * a, q, 'use_diameter_in_sector_area');
    }
    return { answerSquared: String(answerSquared), wrong, proof: { method, intermediate: i < 3 ? c : null, uniqueReconstruction: i < 3 ? matches.length === 1 : true, positiveRootRequired: true, complete: true } };
}
function verifySubjectPracticeMathSolidGeometryTwoStepWithIndependentOracle(candidate, context = {}) {
    const p = context.questionPlan, r = p?.renderConstraints, s = p?.scenarioContract, scope = String(r?.exactSolidGeometryTwoStepScope ?? ''), index = scopes.indexOf(scope), reasonCodes = [];
    const valid = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 74 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === 'math_solid_geometry_two_step_calculation' && p?.planTemplate === 'math_solid_geometry_two_step_calculation_v1'
        && r?.questionType === 'single_choice' && r?.topicCode === 'M-GEO-002' && r?.boundedIntegerParameters === true && r?.maximumDimensionCm === 30
        && r?.exactDimensionalArithmetic === true && r?.completeSolidGeometryCertificate === true && r?.externalContextAllowed === false && r?.requiresImage === false && r?.minimumVisibleMoves === 2
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'solid_geometry_two_step_object' && s?.scenarioAction === scope && index >= 0;
    const values = valid ? read(candidate.prompt, index, false) : null, cert = values ? certificate(values, index) : null;
    if (!cert)
        reasonCodes.push('solid_geometry_two_step_oracle_outside_contract');
    if (candidate.subject !== 'math' || candidate.topicId !== 74 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('solid_geometry_two_step_oracle_identity');
    const options = candidate.options ?? [], keys = options.map(o => option(o.text, index));
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!values || JSON.stringify(read(loc?.prompt ?? '', index, lang === 'en')) !== JSON.stringify(values))
            reasonCodes.push('solid_geometry_two_step_oracle_' + lang + '_prompt');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, option(o.text, index)])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('solid_geometry_two_step_oracle_' + lang + '_options');
    }
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('solid_geometry_two_step_oracle_duplicate_or_invalid_options');
    const optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === cert?.answerSquared ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('solid_geometry_two_step_oracle_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3
        || meta.some(m => m.optionId === selectedOptionId || !cert?.wrong.some(w => w.intent === m.distractorIntent && w.square === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('solid_geometry_two_step_oracle_error_intent');
    return { oracleVersion: exports.SOLID_GEOMETRY_TWO_STEP_ORACLE_VERSION, status: reasonCodes.length ? (cert ? 'conflict' : 'unparsed') : 'verified',
        scopeId: cert ? 'math-medium-solid-geometry-two-step-v1:' + scope : null, scopeMatched: Boolean(cert), selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        completeCertificate: Boolean(cert) && reasonCodes.length === 0, certificate: cert?.proof ?? null, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
