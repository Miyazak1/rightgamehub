"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FUNCTION_COMPOSITION_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathFunctionCompositionLocalGenerator = createSubjectPracticeMathFunctionCompositionLocalGenerator;
const math_lab_diversity_parameter_bank_1 = require("./math-lab-diversity-parameter-bank");
const subject_practice_math_function_composition_solver_1 = require("./subject-practice-math-function-composition-solver");
const subject_practice_math_function_composition_independent_oracle_1 = require("./subject-practice-math-function-composition-independent-oracle");
const subject_practice_math_function_composition_explanation_verifier_1 = require("./subject-practice-math-function-composition-explanation-verifier");
exports.FUNCTION_COMPOSITION_GENERATOR_VERSION = 'math-function-composition-generator-v2-diversity-bank';
function createSubjectPracticeMathFunctionCompositionLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, scope = (0, subject_practice_math_function_composition_solver_1.functionCompositionScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.FUNCTION_COMPOSITION_GENERATOR_VERSION, seed, exactScope: scope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['function_composition_local_plan_not_supported'] };
        if (!validSeed || !scope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 68 || b.topicCode !== 'M-FUNC-001' || b.difficulty !== 'hard' || b.questionType !== 'single_choice')
            return unsupported;
        for (let attempt = 0; attempt < 128; attempt++) {
            const data = (0, math_lab_diversity_parameter_bank_1.diversityParameters)(scope, seed, attempt);
            const p = { scope, data }, d = (0, subject_practice_math_function_composition_solver_1.functionCompositionDerive)(p);
            if (!d)
                continue;
            const choices = d.errors.map(e => ({ text: e.text, intent: e.intent })), correctAnswer = 'ABCD'[Math.floor(seed / 4) % 4];
            choices.splice('ABCD'.indexOf(correctAnswer), 0, { text: d.answer, intent: '' });
            const options = choices.map((e, j) => ({ id: 'ABCD'[j], text: e.text })), prompt = (0, subject_practice_math_function_composition_solver_1.functionCompositionPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_function_composition_solver_1.functionCompositionPrompt)(p, 'en'), explanation = (0, subject_practice_math_function_composition_explanation_verifier_1.renderFunctionCompositionExplanation)(p, d.answer, correctAnswer), tags = ['函数的概念与性质', scope];
            const candidate = { subject: 'math', topicId: 68, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'hard', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: tags, optionMetadata: choices.flatMap((e, j) => e.intent ? [{ optionId: 'ABCD'[j], distractorIntent: e.intent, misconceptionTags: [e.intent] }] : []), localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: tags }, en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Functions and properties', scope] } }, syllabusVersion: b.syllabusVersion };
            const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_function_composition_solver_1.solveSubjectPracticeMathFunctionComposition)(candidate, context), oracleEvidence = (0, subject_practice_math_function_composition_independent_oracle_1.verifySubjectPracticeMathFunctionCompositionWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_function_composition_explanation_verifier_1.verifySubjectPracticeMathFunctionCompositionExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
            const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.expectedAnswer === oracleEvidence.expectedAnswer && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
            return { ...common, parameterAttempts: attempt + 1, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
        }
        return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts: 128 };
    };
}
