"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathDescriptiveStatisticsWithIndependentOracle = verifySubjectPracticeMathDescriptiveStatisticsWithIndependentOracle;
exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_INDEPENDENT_ORACLE_VERSION = 'math-descriptive-statistics-independent-oracle-v1-ranks-pairwise';
// No imports from the primary parser, solver, arithmetic helpers or generator.
const scopes = ['arithmetic_mean', 'median', 'population_variance', 'population_standard_deviation'];
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function read(text, scope, english) {
    const targets = { arithmetic_mean: ['算术平均数', 'arithmetic mean'], median: ['中位数', 'median'], population_variance: ['总体方差（分母为 n）', 'population variance (denominator n)'], population_standard_deviation: ['总体标准差（方差的分母为 n）', 'population standard deviation (variance denominator n)'] };
    if (!targets[scope])
        return null;
    const prefix = (english ? ['The data are [', 'A dataset contains ['] : ['给定以下数据：[', '一组观测数据为：[']).find(x => text.startsWith(x));
    const tail = english ? ` values. Find the ${targets[scope][1]} of this dataset.` : ` 个数。求这组数据的${targets[scope][0]}。`;
    if (!prefix || !text.endsWith(tail))
        return null;
    const pieces = text.slice(prefix.length, -tail.length).split(english ? '], with n=' : ']，共 n=');
    if (pieces.length !== 2 || !/^[3-8]$/.test(pieces[1]))
        return null;
    const raw = pieces[0].split(', ');
    if (raw.length !== Number(pieces[1]) || !raw.every(x => /^-?[0-9]{1,2}$/.test(x)))
        return null;
    const data = raw.map(Number);
    return data.every(x => x >= -20 && x <= 50) ? data : null;
}
function compute(data, scope) {
    const count = data.length, frequency = new Map();
    for (const value of data)
        frequency.set(value, (frequency.get(value) ?? 0) + 1);
    if (scope === 'arithmetic_mean') {
        let weighted = 0;
        for (const [value, occurrences] of frequency)
            weighted += value * occurrences;
        return [weighted, count];
    }
    if (scope === 'median') {
        const rank = (position) => {
            for (let value = -20; value <= 50; value++) {
                let below = 0, at = 0;
                for (const x of data) {
                    if (x < value)
                        below++;
                    if (x === value)
                        at++;
                }
                if (below < position && below + at >= position)
                    return value;
            }
            throw new Error('statistics_oracle_rank_unreachable');
        };
        return count % 2 ? [rank((count + 1) / 2), 1] : [rank(count / 2) + rank(count / 2 + 1), 2];
    }
    let pairwise = 0;
    for (let i = 0; i < count; i++)
        for (let j = i + 1; j < count; j++)
            pairwise += (data[i] - data[j]) ** 2;
    if (scope === 'population_variance')
        return [pairwise, count * count];
    // Dataset range is at most 70; enumerate an exact nonnegative integer root.
    for (let root = 0; root <= 70; root++)
        if (root * root * count * count === pairwise)
            return [root, 1];
    return null;
}
function optionValue(text) {
    const parts = text.split('/');
    if (parts.length > 2 || !/^-?(0|[1-9][0-9]{0,8})$/.test(parts[0]) || (parts.length === 2 && !/^[1-9][0-9]{0,5}$/.test(parts[1])))
        return null;
    return [Number(parts[0]), parts.length === 2 ? Number(parts[1]) : 1];
}
function verifySubjectPracticeMathDescriptiveStatisticsWithIndependentOracle(candidate, context = {}) {
    const plan = object(context.questionPlan), r = object(plan?.renderConstraints), exactScope = String(r?.exactStatisticsScope ?? '');
    const planValid = plan?.subject === 'math' && plan?.targetDifficulty === 'basic'
        && plan?.taskFamily === 'math_descriptive_statistics_direct_calculation' && plan?.planTemplate === 'math_descriptive_statistics_direct_calculation_v1'
        && r?.minimumDataCount === 3 && r?.maximumDataCount === 8 && r?.minimumDataValue === -20 && r?.maximumDataValue === 50
        && r?.integerParametersRequired === true && r?.oneDirectStatisticTarget === true && r?.externalContextAllowed === false
        && r?.varianceDenominator === 'n' && r?.standardDeviationPerfectSquareRequired === true && r?.finalAnswerShape === 'one_unique_exact_rational' && scopes.includes(exactScope);
    const data = planValid ? read(candidate.prompt, exactScope, false) : null, expectedValue = data ? compute(data, exactScope) : null;
    const scopeMatched = expectedValue !== null, reasonCodes = [];
    if (!scopeMatched)
        reasonCodes.push('math_descriptive_statistics_oracle_outside_scope');
    if (candidate.subject !== 'math' || candidate.questionType !== 'single_choice' || candidate.designedDifficulty !== 'basic')
        reasonCodes.push('math_descriptive_statistics_oracle_identity_mismatch');
    for (const lang of ['zh', 'en']) {
        const values = read(candidate.localizations?.[lang]?.prompt ?? '', exactScope, lang === 'en');
        if (!values || JSON.stringify(values) !== JSON.stringify(data))
            reasonCodes.push(`math_descriptive_statistics_oracle_${lang}_parameters_or_target_mismatch`);
        if (JSON.stringify(candidate.localizations?.[lang]?.options) !== JSON.stringify(candidate.options))
            reasonCodes.push(`math_descriptive_statistics_oracle_${lang}_options_mismatch`);
    }
    const options = candidate.options ?? [], values = options.map(o => optionValue(o.text));
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, verdict: !values[i] ? 'unknown' : expectedValue && values[i][0] * expectedValue[1] === expectedValue[0] * values[i][1] ? 'true' : 'false' }));
    const duplicate = values.some((v, i) => v && values.slice(0, i).some(w => w && v[0] * w[1] === w[0] * v[1]));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || duplicate || values.some(v => !v))
        reasonCodes.push('math_descriptive_statistics_oracle_invalid_options');
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (trueOptionIds.length !== 1 || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_descriptive_statistics_oracle_answer_disagreement');
    return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_DESCRIPTIVE_STATISTICS_INDEPENDENT_ORACLE_VERSION,
        status: reasonCodes.length ? (scopeMatched ? 'disagreed' : 'abstained') : 'verified',
        scopeId: scopeMatched ? `math-basic-descriptive-statistics-v1:${exactScope}` : null, exactScope, scopeMatched, expectedValue, optionVerdicts, trueOptionIds, selectedOptionId,
        agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
