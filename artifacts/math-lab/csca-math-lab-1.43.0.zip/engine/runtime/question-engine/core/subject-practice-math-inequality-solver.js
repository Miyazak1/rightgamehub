"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SOLVER_VERSION = void 0;
exports.solveSubjectPracticeMathInequality = solveSubjectPracticeMathInequality;
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SOLVER_VERSION = 'math-inequality-solver-v1';
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SCOPE_VERSION = 'math-inequality-scope-v1';
const SCOPES = new Set([
    'linear_gt_positive', 'linear_lt_positive', 'linear_gt_negative', 'linear_le_negative'
]);
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').replace(/[≥]/g, '>=').replace(/[≤]/g, '<=').replace(/[−–—]/g, '-').replace(/\s+/g, ' ').trim(); }
function scopeFrom(context) {
    const plan = record(context.questionPlan);
    const render = record(plan?.renderConstraints);
    const value = clean(render?.exactInequalityScope);
    return clean(plan?.taskFamily) === 'math_linear_inequality_solution'
        && clean(plan?.planTemplate) === 'math_linear_inequality_solution_v1' && SCOPES.has(value) ? value : null;
}
function flip(relation) { return relation === '>' ? '<' : relation === '<' ? '>' : relation === '>=' ? '<=' : '>='; }
function parsePrompt(prompt) {
    const match = clean(prompt).match(/(-?\d+)x\s*([+-])\s*(\d+)\s*(>=|<=|>|<)\s*(-?\d+)/i);
    if (!match)
        return null;
    const coefficient = Number(match[1]);
    const offset = Number(match[3]) * (match[2] === '-' ? -1 : 1);
    const rhs = Number(match[5]);
    const relation = match[4];
    if (!Number.isInteger(coefficient) || coefficient === 0 || !Number.isInteger(offset) || !Number.isInteger(rhs))
        return null;
    const numerator = rhs - offset;
    if (numerator % coefficient !== 0)
        return null;
    return { coefficient, offset, rhs, sourceRelation: relation, answerRelation: coefficient < 0 ? flip(relation) : relation, boundary: numerator / coefficient };
}
function parseOption(text) {
    const match = clean(text).match(/^x\s*(>=|<=|>|<)\s*(-?\d+)$/i);
    return match ? { relation: match[1], boundary: Number(match[2]) } : null;
}
function solveSubjectPracticeMathInequality(candidate, context = {}) {
    const exactScope = scopeFrom(context);
    const parsedPrompt = parsePrompt(candidate.prompt);
    const parsed = Boolean(exactScope && parsedPrompt);
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const value = parseOption(option.text);
        const truth = parsed && value?.relation === parsedPrompt.answerRelation && value.boundary === parsedPrompt.boundary;
        return { optionId: option.id, verdict: value ? (truth ? 'true' : 'false') : 'unknown', semanticValue: value };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!exactScope)
        reasonCodes.push('math_inequality_scope_plan_contract_missing');
    if (!parsedPrompt)
        reasonCodes.push('math_inequality_prompt_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_inequality_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length ? 'math_inequality_multiple_true_options' : 'math_inequality_no_true_option');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_inequality_generator_disagreement');
    const scopeId = parsed ? `math-basic-linear-inequality-v1:${exactScope}` : null;
    return {
        solverVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SOLVER_VERSION,
        status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_linear_inequality_solution',
        scopeId,
        exactScope,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['math_inequality_verification_scope_not_matched'] },
        parsedPrompt,
        optionVerdicts,
        trueOptionIds,
        selectedOptionId,
        uniqueAnswer: trueOptionIds.length === 1,
        agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes
    };
}
