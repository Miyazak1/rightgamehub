"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_CONSTRAINT_ORACLE_VERSION = void 0;
exports.statisticsConstraintIndependentCalculation = statisticsConstraintIndependentCalculation;
exports.verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle = verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle;
exports.STATISTICS_CONSTRAINT_ORACLE_VERSION = 'math-statistics-constraint-oracle-v1-independent-finite-data';
const scopes = ["two_missing_values_moments_order_replacement_variance", "three_missing_frequencies_moments_trimmed_variance", "two_group_moments_order_reweighted_mean", "affine_moments_sign_threshold_subset_variance"];
function f(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
    throw Error('denominator'); if (b < 0n) {
    a = -a;
    b = -b;
} if (a.toString(2).length > 512 || b.toString(2).length > 512)
    throw Error('bound'); let u = a < 0n ? -a : a, v = b; while (v) {
    const r = u % v;
    u = v;
    v = r;
} return [a / (u || 1n), b / (u || 1n)]; }
const add = (a, b) => f(a[0] * b[1] + b[0] * a[1], a[1] * b[1]), sub = (a, b) => f(a[0] * b[1] - b[0] * a[1], a[1] * b[1]), mul = (a, b) => f(a[0] * b[0], a[1] * b[1]), div = (a, b) => f(a[0] * b[1], a[1] * b[0]), cmp = (a, b) => a[0] * b[1] < b[0] * a[1] ? -1 : a[0] * b[1] > b[0] * a[1] ? 1 : 0, txt = (a) => String(a[0]) + (a[1] === 1n ? '' : '/' + a[1]);
function parse(s) { if (typeof s !== 'string' || s.length > 128 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('rational'); const x = s.split('/'); return f(BigInt(x[0]), BigInt(x[1] || '1')); }
function integer(s, lo, hi) { const q = parse(s); if (q[1] !== 1n || q[0] < BigInt(lo) || q[0] > BigInt(hi))
    throw Error('integer'); return Number(q[0]); }
function stats(a) { if (a.length < 1 || a.length > 48)
    throw Error('count'); const sum = a.reduce(add, f(0)), mean = div(sum, f(a.length)), variance = div(a.reduce((v, x) => add(v, mul(sub(x, mean), sub(x, mean))), f(0)), f(a.length)); return { sum, mean, variance, count: a.length, squares: a.reduce((v, x) => add(v, mul(x, x)), f(0)) }; }
function finiteList(s, lo, hi) { return s.split(',').map(v => f(integer(v, lo, hi))); }
const names = [['known', 'mean', 'variance', 'order', 'a', 'b'], ['levels', 'knownIndex', 'knownFrequency', 'total', 'mean', 'variance', 'removedIndex'], ['nA', 'nB', 'varianceA', 'varianceB', 'mean', 'variance', 'order', 'p', 'q'], ['data', 'meanY', 'varianceY', 'signA', 'threshold', 'relation']];
const startsZh = ['六个数据由四个已知数和两个未知整数 x,y 组成，x,y 属于[-16,16]。给定均值、总体方差及大小关系，用 a*x+b 仅替换 x，求更新后六个数的总体方差。参数：', '四个递增整数值的频数表中，已知一个频数，其余三个是[1,12]内的未知整数。给出总频数、均值、总体方差，删除指定值的所有数据后求总体方差。位置从1开始。参数：', '两组数据A,B的数量均为偶数，组内总体方差已知，两个未知均值是[-16,16]内的整数。给出合并均值、合并总体方差和两组均值的大小关系。将A组全部数据重复p次，B组全部数据重复q次，求新均值。参数：', '已知一组整数数据，作变换 y=a*x+b。a 是[-3,3]内非零半整数，b 是[-20,20]内半整数。给出新均值、总体方差及a的正负号，保留满足阈值关系的数据后求总体方差。参数：'];
const startsEn = ['Six data values comprise four known values and unknown integers x,y in[-16,16]. Given their mean, population variance and order, replace only x by a*x+b and find the population variance of the six updated values. Parameters: ', 'A frequency table has four increasing integer levels. One frequency is known; the other three are unknown integers in[1,12]. Given total frequency, mean and population variance, delete all observations at the designated level and find the remaining population variance. Positions are one-based. Parameters: ', 'Groups A,B have even sizes and known within-group population variances. Their unknown means are integers in[-16,16]. Given the combined mean, combined population variance and mean order, repeat every A observation p times and every B observation q times. Find the resulting mean. Parameters: ', 'Transform the displayed integer data by y=a*x+b. Nonzero a belongs to the half-integer grid in[-3,3], and b to the half-integer grid in[-20,20]. Given the transformed mean, population variance and sign of a, retain the values satisfying the threshold relation and find their population variance. Parameters: '];
function parameters(text, index, lang) { const prefix = (lang === 'zh' ? startsZh : startsEn)[index], suffix = lang === 'zh' ? '。总体方差始终以当前数据个数 n 为分母；不得使用 n-1。' : ' . Population variance always divides by the current data count n, never n-1.'; if (typeof text !== 'string' || !text.startsWith(prefix) || !text.endsWith(suffix))
    throw Error('prompt'); const tokens = text.slice(prefix.length, -suffix.length).split('; '); if (tokens.length !== names[index].length)
    throw Error('fields'); return tokens.map((token, j) => { const start = names[index][j] + '=('; if (!token.startsWith(start) || !token.endsWith(')'))
    throw Error('label'); return token.slice(start.length, -1); }); }
const object = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function statisticsConstraintIndependentCalculation(data, index) {
    const ints = Array.from({ length: 33 }, (_, i) => f(i - 16));
    let domain, evaluate, groups;
    if (index === 0) {
        const known = finiteList(data[0], -16, 16), M = parse(data[1]), V = parse(data[2]), order = data[3], a = integer(data[4], -2, 3), b = integer(data[5], -12, 12);
        if (known.length !== 4 || V[0] <= 0n || !['<', '>'].includes(order) || ![-2, -1, 2, 3].includes(a))
            throw Error('replacement_parameters');
        domain = [ints, ints];
        groups = ['mean', 'population_variance', 'order'];
        evaluate = u => { const before = [...known, ...u], z = stats(before); return { before, after: [...known, add(mul(f(a), u[0]), f(b)), u[1]], flags: [cmp(z.mean, M) === 0, cmp(z.variance, V) === 0, order === '<' ? cmp(u[0], u[1]) < 0 : cmp(u[0], u[1]) > 0] }; };
    }
    else if (index === 1) {
        const levels = finiteList(data[0], -8, 16), ki = integer(data[1], 1, 4) - 1, kf = integer(data[2], 1, 12), N = integer(data[3], 4, 48), M = parse(data[4]), V = parse(data[5]), remove = integer(data[6], 1, 4) - 1;
        if (levels.length !== 4 || levels.some((v, j) => j > 0 && cmp(v, levels[j - 1]) <= 0) || V[0] <= 0n)
            throw Error('frequency_parameters');
        const frequencies = Array.from({ length: 12 }, (_, i) => f(i + 1));
        domain = [frequencies, frequencies, frequencies];
        groups = ['total', 'mean', 'population_variance'];
        evaluate = u => { let at = 0; const blocks = levels.map((level, j) => Array.from({ length: j === ki ? kf : Number(u[at++][0]) }, () => level)), before = blocks.flat(), z = stats(before); return { before, after: blocks.filter((_, j) => j !== remove).flat(), flags: [before.length === N, cmp(z.mean, M) === 0, cmp(z.variance, V) === 0] }; };
    }
    else if (index === 2) {
        const nA = integer(data[0], 4, 8), nB = integer(data[1], 4, 8), vA = integer(data[2], 1, 9), vB = integer(data[3], 1, 9), M = parse(data[4]), V = parse(data[5]), order = data[6], p = integer(data[7], 1, 3), q = integer(data[8], 1, 3);
        if (nA % 2 || nB % 2 || ![1, 4, 9].includes(vA) || ![1, 4, 9].includes(vB) || !['<', '>'].includes(order) || p === q)
            throw Error('group_parameters');
        const root = (n) => n === 1 ? 1 : n === 4 ? 2 : 3;
        domain = [ints, ints];
        groups = ['combined_mean', 'combined_population_variance', 'mean_order'];
        evaluate = u => { const A = Array.from({ length: nA }, (_, j) => add(u[0], f(j % 2 ? root(vA) : -root(vA)))), B = Array.from({ length: nB }, (_, j) => add(u[1], f(j % 2 ? root(vB) : -root(vB)))), before = A.concat(B), z = stats(before); return { before, after: Array.from({ length: p }, () => A).flat().concat(Array.from({ length: q }, () => B).flat()), flags: [cmp(z.mean, M) === 0, cmp(z.variance, V) === 0, order === '<' ? cmp(u[0], u[1]) < 0 : cmp(u[0], u[1]) > 0] }; };
    }
    else if (index === 3) {
        const x = finiteList(data[0], -16, 16), M = parse(data[1]), V = parse(data[2]), sign = data[3], cut = parse(data[4]), rel = data[5];
        if (x.length < 5 || x.length > 8 || stats(x).variance[0] <= 0n || V[0] <= 0n || !['+', '-'].includes(sign) || !['>', '>='].includes(rel) || cmp(cut, f(-40)) < 0 || cmp(cut, f(40)) > 0 || 2n % cut[1] !== 0n)
            throw Error('affine_parameters');
        domain = [Array.from({ length: 13 }, (_, j) => f(j - 6, 2)).filter(q => q[0] !== 0n), Array.from({ length: 81 }, (_, j) => f(j - 40, 2))];
        groups = ['transformed_mean', 'transformed_population_variance', 'scale_sign'];
        evaluate = u => { const before = x.map(z => add(mul(u[0], z), u[1])), m = stats(before); return { before, after: before.filter(z => rel === '>' ? cmp(z, cut) > 0 : cmp(z, cut) >= 0), flags: [cmp(m.mean, M) === 0, cmp(m.variance, V) === 0, sign === '+' ? u[0][0] > 0n : u[0][0] < 0n] }; };
    }
    else
        throw Error('scope');
    const valid = (c) => c.after.length >= 2 && c.after.length <= 48 && (index !== 3 || c.after.length < c.before.length) && c.before.concat(c.after).every(x => cmp(x, f(-128)) >= 0 && cmp(x, f(128)) <= 0) && (index === 2 || stats(c.after).variance[0] > 0n);
    const value = (c) => txt(index === 2 ? stats(c.after).mean : stats(c.after).variance), all = [];
    let examined = 0;
    const walk = (u) => { if (u.length < domain.length) {
        for (const x of domain[u.length])
            walk(u.concat([x]));
        return;
    } examined++; const c = evaluate(u); if (valid(c))
        all.push({ u, c, answer: value(c) }); };
    walk([]);
    if (examined > 4096)
        throw Error('enumeration_bound');
    const full = all.filter(x => x.c.flags.every(Boolean));
    if (full.length !== 1)
        throw Error('nonunique_completion');
    const selected = full[0], before = stats(selected.c.before), after = stats(selected.c.after);
    if (selected.answer === txt(index === 2 ? before.mean : before.variance))
        throw Error('ineffective_operation');
    const witnesses = groups.map((group, j) => { const w = all.find(x => !x.c.flags[j] && x.c.flags.every((ok, k) => k === j || ok) && x.answer !== selected.answer); if (!w)
        throw Error('ineffective_constraint'); return { omitted: group, completion: w.u.map(txt), differentAnswer: w.answer }; });
    const errors = [], err = (intent, value) => errors.push({ intent, value });
    if (index === 2) {
        const [a, b] = selected.u, nA = Number(data[0]), nB = Number(data[1]), p = Number(data[7]), q = Number(data[8]);
        err('ignore_new_weights', before.mean);
        err('unweighted_group_means', div(add(a, b), f(2)));
        err('reverse_repeat_weights', div(add(mul(f(q * nA), a), mul(f(p * nB), b)), f(q * nA + p * nB)));
        err('omit_population_count_division', after.sum);
        err('ignore_group_sizes', div(add(mul(f(p), a), mul(f(q), b)), f(p + q)));
    }
    else {
        err('use_sample_variance_denominator', mul(after.variance, f(after.count, after.count - 1)));
        err('divide_population_variance_twice', div(after.variance, f(after.count)));
        err('omit_centering_mean_square', div(after.squares, f(after.count)));
        err('omit_data_operation', before.variance);
        err('square_mean_instead_of_variance', mul(after.mean, after.mean));
    }
    const errorKeys = errors.map(x => ({ intent: x.intent, key: txt(x.value) })).filter((x, j, a) => x.key !== selected.answer && a.findIndex(y => y.key === x.key) === j).slice(0, 3);
    if (errorKeys.length !== 3)
        throw Error('distractors');
    return { answer: selected.answer, errors: errorKeys, certificate: { method: 'independent_complete_parameter_enumeration_centered_data', complete: true, examined, domainSizes: domain.map(x => x.length), completions: full.map(x => x.u.map(txt)), originalCount: before.count, targetCount: after.count, effectiveConstraints: witnesses } };
}
function verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle(candidate, context = {}) {
    const plan = object(context.questionPlan), render = object(plan?.renderConstraints), scenario = object(plan?.scenarioContract), scope = render?.exactStatisticsConstraintScope, index = scopes.indexOf(scope), reasonCodes = [];
    let result = null;
    try {
        const expected = { topicCode: 'M-STAT-001', boundedIntegerAndHalfIntegerParameters: true, maximumConstructionAttempts: 256, maximumEnumeratedParameterCompletions: 4096, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
        if (plan?.schemaVersion !== 'subject-practice-question-plan-v1' || plan?.policyVersion !== 'subject-practice-question-plan-policy-v1' || plan?.subject !== 'math' || plan?.topicId !== 76 || plan?.targetDifficulty !== 'hard' || plan?.representationType !== 'text' || plan?.taskFamily !== 'math_descriptive_statistics_constraint_reasoning' || plan?.planTemplate !== 'math_descriptive_statistics_constraint_reasoning_v1' || render?.questionType !== 'single_choice' || index < 0 || !Object.entries(expected).every(([k, v]) => render?.[k] === v) || scenario?.scenarioMode !== 'abstract' || scenario?.scenarioEntity !== 'statistics_constraint_system' || scenario?.scenarioAction !== scope)
            throw Error('contract');
        const data = parameters(candidate.prompt, index, 'zh');
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parameters(candidate.localizations?.[lang]?.prompt ?? '', index, lang)) !== JSON.stringify(data))
                throw Error('bilingual_parameters');
        result = statisticsConstraintIndependentCalculation(data, index);
    }
    catch (e) {
        reasonCodes.push('statistics_oracle_' + (e instanceof Error ? e.message : 'invalid'));
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 76 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('statistics_oracle_identity');
    const optionKey = (text) => { try {
        const q = parse(text.trim());
        return index !== 2 && q[0] < 0n ? null : txt(q);
    }
    catch {
        return null;
    } }, options = candidate.options ?? [], keys = options.map(x => optionKey(x.text));
    if (options.length !== 4 || new Set(options.map(x => x.id)).size !== 4 || options.some(x => !['A', 'B', 'C', 'D'].includes(x.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('statistics_oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(x => [x.id, optionKey(x.text)])) !== JSON.stringify(options.map((x, j) => [x.id, keys[j]])))
            reasonCodes.push('statistics_oracle_' + lang + '_options');
    const expectedAnswer = result?.answer ?? null, trueOptionIds = options.filter((_, j) => !!result && keys[j] === expectedAnswer).map(x => x.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || candidate.correctAnswer !== selectedOptionId)
        reasonCodes.push('statistics_oracle_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(x => x.optionId)).size !== 3 || new Set(meta.map(x => x.distractorIntent)).size !== 3 || meta.some(x => x.optionId === selectedOptionId || !result?.errors.some(e => e.intent === x.distractorIntent && e.key === keys[options.findIndex(o => o.id === x.optionId)])))
        reasonCodes.push('statistics_oracle_error_intent');
    const scopeId = index >= 0 ? 'math-hard-statistics-constraint-v1:' + scope : null;
    return { oracleVersion: exports.STATISTICS_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId, scopeMatched: index >= 0, expectedAnswer, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: !!selectedOptionId && selectedOptionId === candidate.correctAnswer, certificate: result?.certificate ?? null, completeCertificate: !!result, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
