"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathDerivativeExplanation = verifySubjectPracticeMathDerivativeExplanation;
const subject_practice_math_derivative_tool_verifier_1 = require("./subject-practice-math-derivative-tool-verifier");
exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_EXPLANATION_VERIFIER_VERSION = 'subject-practice-math-derivative-explanation-verifier-v2-bounded-equality-chain';
function verifySubjectPracticeMathDerivativeExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_derivative_tool_verifier_1.verifySubjectPracticeMathDerivativeToolCandidate)({
        candidate,
        taskFamily: 'derivative_direct_evaluation',
        questionPlan: context.questionPlan
    });
    const explanation = String(candidate.explanation ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ' ');
    const expected = solved.expectedValue?.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const hasDerivativeStep = /f\s*['′]\s*\(\s*x\s*\)\s*=/.test(explanation);
    const hasExpectedConclusion = expected
        ? new RegExp(`f\\s*['′]\\s*\\([^)]*\\)\\s*=\\s*(?:[^=。；;\\n]{1,100}=\\s*){0,2}${expected}(?=$|[\\s,，。；;])`).test(explanation)
        : false;
    const reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('math_derivative_explanation_visible_solution_unavailable');
    if (!hasDerivativeStep)
        reasonCodes.push('math_derivative_explanation_derivative_step_missing');
    if (!hasExpectedConclusion)
        reasonCodes.push('math_derivative_explanation_expected_value_missing');
    const status = solved.status !== 'verified'
        ? 'unparsed'
        : hasDerivativeStep && hasExpectedConclusion ? 'verified' : 'failed';
    return {
        verifierVersion: exports.SUBJECT_PRACTICE_MATH_DERIVATIVE_EXPLANATION_VERIFIER_VERSION,
        status,
        scopeId: solved.verificationScopeId
            ? 'math-basic-derivative-v1:direct_polynomial_value'
            : null,
        evidenceBoundary: 'candidate_explanation_checked_against_visible_prompt_solution',
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes
    };
}
