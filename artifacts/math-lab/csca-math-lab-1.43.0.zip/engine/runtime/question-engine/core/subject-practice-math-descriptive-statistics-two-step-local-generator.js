"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_TWO_STEP_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathStatisticsTwoStepLocalGenerator = createSubjectPracticeMathStatisticsTwoStepLocalGenerator;
const subject_practice_math_descriptive_statistics_two_step_solver_1 = require("./subject-practice-math-descriptive-statistics-two-step-solver");
const subject_practice_math_descriptive_statistics_two_step_independent_oracle_1 = require("./subject-practice-math-descriptive-statistics-two-step-independent-oracle");
const subject_practice_math_descriptive_statistics_two_step_explanation_verifier_1 = require("./subject-practice-math-descriptive-statistics-two-step-explanation-verifier");
exports.STATISTICS_TWO_STEP_GENERATOR_VERSION = 'math-descriptive-statistics-two-step-generator-v1-bounded';
function createSubjectPracticeMathStatisticsTwoStepLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, exactScope = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.STATISTICS_TWO_STEP_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['statistics_two_step_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 76 || b.topicCode !== 'M-STAT-001' || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        let selected = null, parameterAttempts = 0;
        for (let attempt = 0; attempt < 64; attempt++) {
            parameterAttempts++;
            const n = seed % 100000 + attempt * 1009, i = subject_practice_math_descriptive_statistics_two_step_solver_1.STATISTICS_TWO_STEP_SCOPES.indexOf(exactScope), count = 3 + n % 6;
            let values = Array.from({ length: count }, (_, j) => 1 + (n * 7 + j * 5) % 19), frequencies = [], known, shift = 0;
            if (i === 0) {
                known = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepFraction)(values.reduce((a, z) => a + z, 0), count);
                values = values.slice(0, -1);
            }
            else if (i === 1 || i === 2) {
                values = [-8 + n % 5, 1 + Math.floor(n / 5) % 5, 12 + Math.floor(n / 7) % 8];
                frequencies = [1 + n % 6, 1 + Math.floor(n / 6) % 6];
                const k = 1 + Math.floor(n / 11) % 6, total = frequencies[0] + frequencies[1] + k;
                known = i === 1 ? String(total) : (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepFraction)(values[0] * frequencies[0] + values[1] * frequencies[1] + values[2] * k, total);
            }
            else {
                const a = [-3, -2, -1, 1, 2, 3][n % 6];
                shift = n % 21 - 10;
                known = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepFraction)(a * values.reduce((x, z) => x + z, 0) + shift * count, count);
            }
            if (known === null)
                continue;
            const p = { scope: exactScope, values, frequencies, known, shift };
            if ((0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepDerive)(p) && (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepDistractors)(p).length === 3) {
                selected = p;
                break;
            }
        }
        if (!selected)
            return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts };
        const p = selected, answer = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepDerive)(p).answer, choices = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepDistractors)(p), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
        const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: x.key })), prompt = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepPrompt)(p, 'en'), explanation = (0, subject_practice_math_descriptive_statistics_two_step_explanation_verifier_1.renderStatisticsTwoStepExplanation)(p, answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 76, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['数据的数字特征', exactScope],
            optionMetadata: choices.flatMap((x, i) => x.intent ? [{ optionId: 'ABCD'[i], distractorIntent: x.intent, misconceptionTags: [x.intent] }] : []),
            localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['数据的数字特征', exactScope] }, en: { prompt: enPrompt, options: options.map(x => ({ ...x })), explanation: explanation.en, knowledgeTags: ['Two-step descriptive statistics', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.solveSubjectPracticeMathStatisticsTwoStep)(candidate, context), oracleEvidence = (0, subject_practice_math_descriptive_statistics_two_step_independent_oracle_1.verifySubjectPracticeMathStatisticsTwoStepWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_descriptive_statistics_two_step_explanation_verifier_1.verifySubjectPracticeMathStatisticsTwoStepExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, parameterAttempts, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
