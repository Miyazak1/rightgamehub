"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_ORACLE_VERSION = void 0;
exports.elementaryExpLogConstraintOracleCalculation = elementaryExpLogConstraintOracleCalculation;
exports.verifySubjectPracticeMathElementaryExpLogConstraintWithIndependentOracle = verifySubjectPracticeMathElementaryExpLogConstraintWithIndependentOracle;
exports.ELEMENTARY_EXP_LOG_CONSTRAINT_ORACLE_VERSION = 'math-elementary-exp-log-constraint-oracle-v1-complete-partition';
const scopes = ['exponential_substitution_rational_inequality', 'logarithmic_difference_domain_inequality', 'exponential_quadratic_closed_interval_range', 'nested_logarithm_rational_domain_intersection'];
const rat = (n, d = 1) => { let x = BigInt(n), y = BigInt(d); if (!y)
    return [x < 0n ? -1n : 1n, 0n]; if (y < 0n) {
    x = -x;
    y = -y;
} let a = x < 0n ? -x : x, b = y; while (b) {
    const t = a % b;
    a = b;
    b = t;
} return [x / a, y / a]; };
const plus = (a, b) => rat(a[0] * b[1] + b[0] * a[1], a[1] * b[1]), minus = (a, b) => rat(a[0] * b[1] - b[0] * a[1], a[1] * b[1]), times = (a, b) => rat(a[0] * b[0], a[1] * b[1]), over = (a, b) => { if (!b[0])
    throw Error('oracle_zero_divisor'); return rat(a[0] * b[1], a[1] * b[0]); };
const order = (a, b) => !a[1] || !b[1] ? (!a[1] && !b[1] ? (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0) : !a[1] ? Number(a[0]) : -Number(b[0])) : (a[0] * b[1] < b[0] * a[1] ? -1 : a[0] * b[1] > b[0] * a[1] ? 1 : 0);
const show = (a) => !a[1] ? (a[0] < 0n ? '-inf' : 'inf') : String(a[0]) + (a[1] === 1n ? '' : '/' + a[1]), zero = rat(0), negInf = rat(-1, 0), posInf = rat(1, 0);
function read(s) { if (s === '-inf')
    return negInf; if (s === 'inf')
    return posInf; if (typeof s !== 'string' || s.length > 32 || !/^(-?\d+)(?:\/([1-9]\d*))?$/.test(s))
    throw Error('oracle_rational'); const m = s.split('/'); return rat(BigInt(m[0]), BigInt(m[1] || '1')); }
function power(b, k) { if (!Number.isInteger(k) || Math.abs(k) > 16 || b[0] <= 0n || !b[1])
    throw Error('oracle_power'); let t = rat(1); for (let j = 0; j < Math.abs(k); j++)
    t = times(t, k < 0 ? rat(b[1], b[0]) : b); return t; }
function merge(v) { const out = []; for (const s of v.filter(x => order(x.l, x.r) < 0 || !order(x.l, x.r) && x.left && x.right).map(x => ({ ...x, left: !!x.l[1] && x.left, right: !!x.r[1] && x.right })).sort((a, b) => order(a.l, b.l) || Number(b.left) - Number(a.left))) {
    const t = out[out.length - 1];
    if (!t || order(t.r, s.l) < 0 || !order(t.r, s.l) && !t.right && !s.left) {
        out.push(s);
        continue;
    }
    if (order(s.r, t.r) > 0) {
        t.r = s.r;
        t.right = s.right;
    }
    else if (!order(s.r, t.r))
        t.right = t.right || s.right;
} return out; }
const format = (v) => merge(v).map(x => (x.left ? '[' : '(') + show(x.l) + ',' + show(x.r) + (x.right ? ']' : ')')).join(' U ') || 'empty';
function parseOption(s) { if (s === 'empty')
    return s; try {
    if (typeof s !== 'string' || s.length > 600)
        return null;
    const chunks = s.split(' U ');
    if (chunks.length > 4)
        return null;
    const is = chunks.map(x => { const m = /^([[(])(-?\d+(?:\/[1-9]\d*)?|-inf),\s*(-?\d+(?:\/[1-9]\d*)?|inf)([\])])$/.exec(x); if (!m)
        throw Error('oracle_interval'); const l = read(m[2]), r = read(m[3]), left = m[1] === '[', right = m[4] === ']'; if (order(l, r) > 0 || !order(l, r) && (!left || !right) || !l[1] && left || !r[1] && right || [l, r].some(t => t[1] && (t[0] < -1000000000000n || t[0] > 1000000000000n || t[1] > 100000000n)))
        throw Error('oracle_interval_bounds'); return { l, r, left, right }; });
    return format(is);
}
catch {
    return null;
} }
const member = (ss, x) => ss.some(s => (order(x, s.l) > 0 || !order(x, s.l) && s.left) && (order(x, s.r) < 0 || !order(x, s.r) && s.right));
const midpoint = (a, b) => !a[1] ? minus(b, rat(1)) : !b[1] ? plus(a, rat(1)) : over(plus(a, b), rat(2));
function cells(points, test) { const cuts = [negInf, ...points.filter(x => x[1]).sort(order).filter((x, j, a) => !j || order(x, a[j - 1])), posInf], ss = [], table = []; for (let j = 0; j < cuts.length; j++) {
    if (cuts[j][1]) {
        const yes = test(cuts[j]);
        table.push({ kind: 'singleton', at: show(cuts[j]), accepted: yes });
        if (yes)
            ss.push({ l: cuts[j], r: cuts[j], left: true, right: true });
    }
    if (j + 1 < cuts.length) {
        const x = midpoint(cuts[j], cuts[j + 1]), yes = test(x);
        table.push({ kind: 'open_cell', at: show(x), accepted: yes });
        if (yes)
            ss.push({ l: cuts[j], r: cuts[j + 1], left: false, right: false });
    }
} return { set: merge(ss), critical: cuts.map(show), table }; }
function witness(a, b) { const edges = [...a, ...b].flatMap(x => [x.l, x.r]); const proof = cells(edges, x => member(a, x) !== member(b, x)); return proof.table.find(x => x.accepted)?.at ?? null; }
// Visible formula decoding is independent of candidate answers and generation metadata.
function visible(index, d, lang) {
    const lead = lang === 'zh' ? '变量 x 为实数，保留区间端点的开闭。' : 'The variable x is real; retain endpoint inclusion. ', tail = lang === 'zh' ? ' 求全部解集。' : ' Find the complete solution set.';
    if (index === 0)
        return lead + 'b=(' + d[0] + '); u(x)=(' + d[1] + ')*x+(' + d[2] + '); t=b^u(x); (t-b^(' + d[3] + '))*(t-b^(' + d[4] + '))/(t-b^(' + d[5] + ')) ' + d[8] + ' 0; x in [' + d[6] + ',' + d[7] + '].' + tail;
    if (index === 1)
        return lead + 'b=(' + d[0] + '); A(x)=(' + d[1] + ')*x+(' + d[2] + '); B(x)=(' + d[3] + ')*x+(' + d[4] + '); log_b(A(x))-log_b(B(x)) ' + d[8] + ' (' + d[5] + '); x in [' + d[6] + ',' + d[7] + '].' + tail;
    if (index === 2)
        return lead + 'b=(' + d[0] + '); u(x)=(' + d[1] + ')*x+(' + d[2] + '); y=(' + d[3] + ')*b^(2*u(x))+(' + d[4] + ')*b^u(x)+(' + d[5] + '); x in [' + d[6] + ',' + d[7] + '].' + (lang === 'zh' ? ' 求 y 的完整值域。' : ' Find the complete range of y.');
    return lead + 'b=(' + d[0] + '); u(x)=(' + d[1] + ')*x+(' + d[2] + '); F(x)=log_b((log_b(u(x))-(' + d[3] + '))/(log_b(u(x))-(' + d[4] + ')))+log_b((' + d[5] + ')-x).' + (lang === 'zh' ? ' 求 F 的定义域。' : ' Find the domain of F.');
}
function readStem(text, index, lang) { if (typeof text !== 'string' || text.length > 2000 || index < 0)
    return null; const chunks = text.split(/; |\. /), nums = []; for (const chunk of chunks)
    for (const m of chunk.matchAll(/\((-?\d+(?:\/[1-9]\d*)?)\)/g))
        nums.push(m[1]); if (nums.length !== 6)
    return null; const range = /x in \[([^,\]]+),([^\]]+)\]/.exec(text), operator = /(?:\) |\)\) )(>=|<=|>|<) /.exec(text); const d = index === 3 ? nums : [...nums, ...(range ? range.slice(1) : []), ...(index < 2 && operator ? [operator[1]] : [])]; return visible(index, d, lang) === text ? d : null; }
function allowed(index, d) { try {
    if (d.length !== [9, 9, 8, 6][index] || !['2', '3', '4', '5', '1/2', '1/3', '1/4', '1/5'].includes(d[0]))
        return false;
    const v = d.slice(0, index < 2 ? 8 : d.length).map(read), int = (x, n) => x[1] === 1n && x[0] >= BigInt(-n) && x[0] <= BigInt(n), slope = (x) => int(x, 4) && x[0] !== 0n;
    if (v.some(x => !x[1] || x[0] < -1000000n || x[0] > 1000000n || x[1] > 10000n) || !slope(v[1]) || !int(v[2], 8))
        return false;
    if (index < 2 && !['>', '>=', '<', '<='].includes(d[8]))
        return false;
    if (index === 0 && (!v.slice(3, 6).every(x => int(x, 4)) || new Set(d.slice(3, 6)).size !== 3))
        return false;
    if (index === 1 && (!slope(v[3]) || !int(v[4], 8) || !int(v[5], 4) || !order(times(v[1], v[4]), times(v[2], v[3]))))
        return false;
    if (index === 2 && (!slope(v[3]) || !v[4][0] || !int(v[5], 8) || !v.slice(6, 8).every(x => int(plus(times(v[1], x), v[2]), 4))))
        return false;
    if (index === 3 && (!v.slice(3, 5).every(x => int(x, 4)) || !order(v[3], v[4])))
        return false;
    return index === 3 || order(v[6], v[7]) < 0;
}
catch {
    return false;
} }
function elementaryExpLogConstraintOracleCalculation(index, d) {
    if (!allowed(index, d))
        return null;
    const v = d.slice(0, index < 2 ? 8 : d.length).map(read), [b, a, c] = v, bdir = order(b, rat(1)), U = (x) => plus(times(a, x), c), root = (k) => over(minus(k, c), a);
    let set = [], critical = [], table = [], witnesses = [], rangeProof = null;
    const comparison = (n) => d[8] === '>' ? n > 0 : d[8] === '>=' ? n >= 0 : d[8] === '<' ? n < 0 : n <= 0;
    if (index === 0) {
        const points = [...v.slice(3, 6).map(root), v[6], v[7]], inside = (x) => order(x, v[6]) >= 0 && order(x, v[7]) <= 0, sign = (x) => { const f = v.slice(3, 6).map(k => order(minus(U(x), k), zero)); return f[2] !== 0 && comparison(f[0] * f[1] * f[2] * bdir); };
        const proof = cells(points, x => inside(x) && sign(x));
        set = proof.set;
        critical = proof.critical;
        table = proof.table;
        for (const relaxed of [cells(points, sign).set, cells(points, inside).set]) {
            const w = witness(set, relaxed);
            if (w === null)
                return null;
            witnesses.push(w);
        }
    }
    else if (index === 1) {
        const K = power(b, Number(v[5][0])), B = (x) => plus(times(v[3], x), v[4]), domain = (x) => U(x)[0] > 0n && B(x)[0] > 0n, inside = (x) => order(x, v[6]) >= 0 && order(x, v[7]) <= 0, slope = minus(a, times(K, v[3])), offset = minus(c, times(K, v[4])), points = [root(zero), over(times(rat(-1), v[4]), v[3]), v[6], v[7], ...(slope[0] ? [over(times(rat(-1), offset), slope)] : [])], sign = (x) => B(x)[0] !== 0n && comparison(order(minus(U(x), times(K, B(x))), zero) * order(B(x), zero) * bdir);
        const proof = cells(points, x => domain(x) && inside(x) && sign(x));
        set = proof.set;
        critical = proof.critical;
        table = proof.table;
        for (const relaxed of [cells(points, x => inside(x) && sign(x)).set, cells(points, x => inside(x) && domain(x)).set]) {
            const w = witness(set, relaxed);
            if (w === null)
                return null;
            witnesses.push(w);
        }
    }
    else if (index === 2) {
        const A = v[3], B = v[4], C = v[5], center = over(times(rat(-1), B), times(rat(2), A)), offset = minus(C, over(times(B, B), times(rat(4), A)));
        if (order(center, zero) <= 0)
            return null;
        const image = (t) => plus(times(A, times(minus(t, center), minus(t, center))), offset), ts = v.slice(6, 8).map(x => power(b, Number(U(x)[0]))).sort(order), ys = [image(ts[0]), image(ts[1])];
        if (order(center, ts[0]) >= 0 && order(center, ts[1]) <= 0)
            ys.push(offset);
        ys.sort(order);
        set = [{ l: ys[0], r: ys[ys.length - 1], left: true, right: true }];
        critical = [...ts, center].map(show);
        for (const x of [minus(v[6], rat(2)), plus(v[7], rat(2))]) {
            const exponent = U(x);
            if (exponent[1] !== 1n || exponent[0] < -16n || exponent[0] > 16n)
                return null;
            const y = image(power(b, Number(exponent[0])));
            if (member(set, y))
                return null;
            witnesses.push('x=' + show(x) + ';y=' + show(y));
        }
        rangeProof = { center: show(center), completedSquareOffset: show(offset), mappedInterval: ts.map(show), values: ys.map(show), attained: true };
    }
    else {
        const uP = power(b, Number(v[3][0])), uQ = power(b, Number(v[4][0])), points = [root(zero), root(uP), root(uQ), v[5]], domain = (x) => U(x)[0] > 0n, outer = (x) => domain(x) && order(U(x), uQ) !== 0 && order(U(x), uP) * order(U(x), uQ) > 0, bound = (x) => order(x, v[5]) < 0;
        const proof = cells(points, x => outer(x) && bound(x));
        set = proof.set;
        critical = proof.critical;
        table = proof.table;
        for (const relaxed of [cells(points, x => domain(x) && bound(x)).set, cells(points, outer).set]) {
            const w = witness(set, relaxed);
            if (w === null)
                return null;
            witnesses.push(w);
        }
    }
    const answer = format(set);
    if (!set.length || set.length > 3 || witnesses.length < 2 || parseOption(answer) === null)
        return null;
    return { answer, criticalPoints: critical, representatives: table.map(x => x.at), cellMembership: table, effectiveConstraintWitnesses: witnesses, rangeProof, completeRealPartition: true, partitionArgument: index === 2 ? 'Completing the square proves the exact extremum; mapped endpoints and the vertex prove bound attainment.' : 'All affine-factor zeros, logarithm domain boundaries, poles and interval ends partition the real line. Monotonicity gives exact factor signs; each open cell and each singleton is checked separately.', studentCalibrated: false };
}
function verifySubjectPracticeMathElementaryExpLogConstraintWithIndependentOracle(candidate, context = {}) { const p = context.questionPlan, r = p?.renderConstraints, scope = r?.exactElementaryExpLogConstraintScope, index = scopes.indexOf(scope), reasons = [], constraints = { topicCode: 'M-FUNC-002', boundedRationalParameters: true, rationalNumeratorMax: 1000000, rationalDenominatorMax: 10000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false }; const identity = p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 69 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === 'math_elementary_exp_log_constraint_reasoning' && p?.planTemplate === 'math_elementary_exp_log_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(constraints).every(([k, v]) => r?.[k] === v) && p?.scenarioContract?.scenarioMode === 'abstract' && p?.scenarioContract?.scenarioEntity === 'elementary_exp_log_constraint_system' && p?.scenarioContract?.scenarioAction === scope && candidate.subject === 'math' && candidate.topicId === 69 && candidate.designedDifficulty === 'hard' && candidate.questionType === 'single_choice'; const data = identity && index >= 0 ? readStem(candidate.prompt, index, 'zh') : null; let proof = null; try {
    if (data)
        proof = elementaryExpLogConstraintOracleCalculation(index, data);
}
catch {
    reasons.push('elementary_exp_log_constraint_oracle_calculation');
} if (!proof)
    reasons.push('elementary_exp_log_constraint_oracle_unparsed'); for (const lang of ['zh', 'en'])
    if (!data || JSON.stringify(readStem(candidate.localizations?.[lang]?.prompt ?? '', index, lang)) !== JSON.stringify(data))
        reasons.push('elementary_exp_log_constraint_oracle_localization'); const options = candidate.options ?? [], keys = options.map(x => parseOption(x.text)); if (options.length !== 4 || keys.includes(null) || new Set(keys).size !== 4 || new Set(options.map(x => x.id)).size !== 4 || options.some(x => !['A', 'B', 'C', 'D'].includes(x.id)))
    reasons.push('elementary_exp_log_constraint_oracle_options'); for (const lang of ['zh', 'en'])
    if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(x => [x.id, parseOption(x.text)])) !== JSON.stringify(options.map((x, j) => [x.id, keys[j]])))
        reasons.push('elementary_exp_log_constraint_oracle_localized_options'); const optionVerdicts = options.map((x, j) => ({ optionId: x.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === proof?.answer ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null; if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
    reasons.push('elementary_exp_log_constraint_oracle_answer'); return { oracleVersion: exports.ELEMENTARY_EXP_LOG_CONSTRAINT_ORACLE_VERSION, status: reasons.length ? 'conflict' : 'verified', taskFamily: 'math_elementary_exp_log_constraint_reasoning', scopeId: data ? 'math-hard-elementary-exp-log-constraint-v1:' + scope : null, exactScope: scope, scopeMatched: !!data, completeCertificate: !!proof, certificate: proof, expectedAnswer: proof?.answer ?? null, selectedOptionId, trueOptionIds, optionVerdicts, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, partitionEvidence: proof, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes: reasons }; }
