"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalTwoStepDecimal = exports.NORMAL_TWO_STEP_CONSTRAINTS = exports.NORMAL_TWO_STEP_SCOPES = exports.NORMAL_TWO_STEP_SCOPE_VERSION = exports.NORMAL_TWO_STEP_SOLVER_VERSION = exports.NORMAL_TWO_STEP_TEMPLATE = exports.NORMAL_TWO_STEP_FAMILY = void 0;
exports.normalTwoStepScopeFrom = normalTwoStepScopeFrom;
exports.normalTwoStepFraction = normalTwoStepFraction;
exports.normalTwoStepOptionKey = normalTwoStepOptionKey;
exports.normalTwoStepPrompt = normalTwoStepPrompt;
exports.normalTwoStepDerive = normalTwoStepDerive;
exports.normalTwoStepParametersFrom = normalTwoStepParametersFrom;
exports.solveSubjectPracticeMathNormalTwoStep = solveSubjectPracticeMathNormalTwoStep;
exports.NORMAL_TWO_STEP_FAMILY = 'math_normal_distribution_two_step_reasoning';
exports.NORMAL_TWO_STEP_TEMPLATE = exports.NORMAL_TWO_STEP_FAMILY + '_v1';
exports.NORMAL_TWO_STEP_SOLVER_VERSION = 'math-normal-distribution-two-step-solver-v1-given-rational';
exports.NORMAL_TWO_STEP_SCOPE_VERSION = 'math-medium-normal-distribution-two-step-v1';
exports.NORMAL_TWO_STEP_SCOPES = ['standardized_interval_from_cdf_values', 'symmetric_interval_from_one_tail_probability', 'empirical_asymmetric_interval_probability', 'empirical_tail_probability_to_threshold'];
exports.NORMAL_TWO_STEP_CONSTRAINTS = { topicCode: 'M-STAT-002', boundedIntegerParameters: true, meanMin: -20, meanMax: 80, sigmaMin: 2, sigmaMax: 12, secondNormalParameter: 'variance', minimumVisibleMoves: 2, probabilityMode: 'given_approximation_only', externalContextAllowed: false, requiresImage: false };
const rec = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function normalTwoStepScopeFrom(value) {
    const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactNormalDistributionTwoStepScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 77 && p?.targetDifficulty === 'medium' && p?.representationType === 'text' && p?.taskFamily === exports.NORMAL_TWO_STEP_FAMILY && p?.planTemplate === exports.NORMAL_TWO_STEP_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.NORMAL_TWO_STEP_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'normal_distribution_object' && s?.scenarioAction === scope && exports.NORMAL_TWO_STEP_SCOPES.includes(scope) ? scope : null;
}
function normalTwoStepFraction(n, d = 1) {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || !d)
        return null;
    if (d < 0) {
        n = -n;
        d = -d;
    }
    let a = Math.abs(n), b = d;
    while (b) {
        const t = a % b;
        a = b;
        b = t;
    }
    return d / a === 1 ? String(n / a) : n / a + '/' + (d / a);
}
function normalTwoStepOptionKey(s) {
    const m = typeof s === 'string' ? /^(-?\d{1,6})(?:\.(\d{1,4}))?$/.exec(s.trim()) : null;
    if (!m)
        return null;
    const d = 10 ** (m[2]?.length ?? 0), sign = m[1].startsWith('-') ? -1 : 1;
    return normalTwoStepFraction(sign * (Math.abs(Number(m[1])) * d + Number(m[2] ?? 0)), d);
}
const normalTwoStepDecimal = (units) => (units / 10000).toFixed(4);
exports.normalTwoStepDecimal = normalTwoStepDecimal;
const cdf = { '-2': 228, '-1': 1587, 0: 5000, 1: 8413, 2: 9772 };
const empirical = { '-3': 15, '-2': 250, '-1': 1600, 0: 5000, 1: 8400, 2: 9750, 3: 9985 };
const empiricalText = { zh: '采用近似经验规律：P(|X-mu|<=sigma)约为0.68，P(|X-mu|<=2*sigma)约为0.95，P(|X-mu|<=3*sigma)约为0.997。', en: 'Use the approximate empirical rule: P(|X-mu|<=sigma) is about 0.68, P(|X-mu|<=2*sigma) about 0.95, and P(|X-mu|<=3*sigma) about 0.997.' };
function normalTwoStepPrompt(p, lang) {
    const zh = lang === 'zh', head = zh ? 'X服从正态分布N(' + p.mu + ',' + p.variance + ')，第二参数为方差，记均值为mu、正标准差为sigma。' : 'X has normal distribution N(' + p.mu + ',' + p.variance + '); the second parameter is the variance. Write mu for its mean and sigma for its positive standard deviation.';
    const i = exports.NORMAL_TWO_STEP_SCOPES.indexOf(p.scope), tail = (0, exports.normalTwoStepDecimal)(p.tail), sign = p.direction === 'left' ? '<=' : '>=';
    if (i === 0)
        return head + (zh ? '给定标准正态累计概率近似值Phi(-2)=0.0228，Phi(-1)=0.1587，Phi(0)=0.5000，Phi(1)=0.8413，Phi(2)=0.9772。先标准化端点，再用所给近似值求P(' + p.a + '<=X<=' + p.b + ')。' : 'Given approximate standard normal cumulative values Phi(-2)=0.0228, Phi(-1)=0.1587, Phi(0)=0.5000, Phi(1)=0.8413, Phi(2)=0.9772. Standardize the endpoints, then use the given approximations to find P(' + p.a + '<=X<=' + p.b + ').');
    if (i === 1)
        return head + (zh ? '已知P(X' + sign + p.a + ')约为' + tail + '。令y为' + p.a + '关于mu的对称点，先求y，再求X位于' + p.a + '与y之间的近似概率。' : 'Given P(X' + sign + p.a + ') is approximately ' + tail + '. Let y be the reflection of ' + p.a + ' about mu. Find y, then the approximate probability that X lies between ' + p.a + ' and y.');
    if (i === 2)
        return head + empiricalText[lang] + (zh ? '先识别两个端点的标准差倍数，再分区求P(' + p.a + '<=X<=' + p.b + ')的近似值。' : 'Identify the standard-deviation multiples of both endpoints, then partition the interval to approximate P(' + p.a + '<=X<=' + p.b + ').');
    return head + empiricalText[lang] + (zh ? '按该近似规律，P(X' + sign + 't)约为' + tail + '。先判断尾部对应的标准差倍数，再求近似阈值t。' : 'According to this approximate rule, P(X' + sign + 't) is about ' + tail + '. Infer the standard-deviation multiple from the tail, then find the approximate threshold t.');
}
function normalTwoStepDerive(p) {
    const i = exports.NORMAL_TWO_STEP_SCOPES.indexOf(p.scope), sigma = Math.sqrt(p.variance);
    if (i < 0 || ![p.mu, p.variance, p.a, p.b, p.tail].every(Number.isSafeInteger) || p.mu < -20 || p.mu > 80 || !Number.isInteger(sigma) || sigma < 2 || sigma > 12 || !['left', 'right'].includes(p.direction))
        return null;
    const za = (p.a - p.mu) / sigma, zb = (p.b - p.mu) / sigma;
    let units, proof, raw, mode;
    if (i === 0 || i === 2) {
        const pairs = i === 0 ? [[-2, -1], [-2, 1], [-1, 2], [1, 2]] : [[-3, -1], [-2, 1], [-1, 2], [1, 3], [-3, 2], [-2, 3]], table = i === 0 ? cdf : empirical;
        if (p.direction !== 'left' || p.tail !== 0 || !pairs.some(([l, u]) => l === za && u === zb))
            return null;
        units = table[zb] - table[za];
        raw = [[table[zb], 'omit_lower_cdf'], [10000 - table[za], 'omit_upper_bound'], [10000 - units, 'use_complement']];
        mode = i === 0 ? 'given_cdf_4dp_approximation' : 'empirical_68_95_997_approximation';
        proof = 'zLower=(' + p.a + '-(' + p.mu + '))/' + sigma + '=' + za + '; zUpper=(' + p.b + '-(' + p.mu + '))/' + sigma + '=' + zb + '; probabilityUnits=' + table[zb] + '-' + table[za] + '=' + units;
    }
    else if (i === 1) {
        const k = Math.abs(za);
        if (p.b !== 0 || ![1, 2].includes(k) || p.direction !== (za < 0 ? 'left' : 'right') || p.tail !== cdf[-k])
            return null;
        units = 10000 - 2 * p.tail;
        raw = [[10000 - p.tail, 'subtract_one_tail'], [p.tail, 'return_one_tail'], [2 * p.tail, 'return_two_tails']];
        mode = 'given_cdf_4dp_approximation';
        proof = 'reflectedEndpoint=2*(' + p.mu + ')-(' + p.a + ')=' + (2 * p.mu - p.a) + '; leftTail=rightTail=' + (0, exports.normalTwoStepDecimal)(p.tail) + '; probabilityUnits=10000-2*' + p.tail + '=' + units;
    }
    else {
        if (p.a !== 0 || p.b !== 0)
            return null;
        const k = [1600, 250, 15].indexOf(p.tail) + 1;
        if (k === 0)
            return null;
        const sign = p.direction === 'left' ? -1 : 1;
        units = p.mu + sign * k * sigma;
        // Omitting sigma stays distinct from the correct, reversed and variance-scaled thresholds for sigma >= 2.
        raw = [[p.mu - sign * k * sigma, 'reverse_tail_direction'], [p.mu + sign * k * p.variance, 'use_variance_as_sigma'], [p.mu + sign * k, 'omit_sigma_scale']];
        mode = 'empirical_68_95_997_approximate_threshold';
        proof = 'tail=' + (0, exports.normalTwoStepDecimal)(p.tail) + '; k=' + k + '; direction=' + p.direction + '; threshold=' + p.mu + '+(' + sign + ')*' + k + '*' + sigma + '=' + units;
    }
    const text = i === 3 ? String(units) : (0, exports.normalTwoStepDecimal)(units), answer = normalTwoStepOptionKey(text);
    const errors = raw.map(([n, intent]) => ({ text: i === 3 ? String(n) : (0, exports.normalTwoStepDecimal)(n), intent })).map(e => ({ ...e, key: normalTwoStepOptionKey(e.text) }));
    if (!answer || errors.some(e => e.key === null) || new Set([answer, ...errors.map(e => e.key)]).size !== 4)
        return null;
    return { sigma, answer, text, errors, mode, proof: 'mu=' + p.mu + '; variance=' + p.variance + '; sigma=sqrt(' + p.variance + ')=' + sigma + '; ' + proof + '; approximationMode=' + mode };
}
function normalTwoStepParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1600)
        return null;
    const head = /N\((-?\d+),(\d+)\)/.exec(text), interval = /P\((-?\d+)<=X<=(-?\d+)\)/.exec(text), tail = /P\(X(<=|>=)(-?\d+|t)\)(?:约为| is approximately | is about )(\d\.\d{4})/.exec(text);
    if (!head)
        return null;
    const i = exports.NORMAL_TWO_STEP_SCOPES.indexOf(scope);
    const p = { scope, mu: +head[1], variance: +head[2], a: i === 0 || i === 2 ? Number(interval?.[1]) : i === 1 ? Number(tail?.[2]) : 0, b: i === 0 || i === 2 ? Number(interval?.[2]) : 0, direction: tail?.[1] === '>=' ? 'right' : 'left', tail: i === 1 || i === 3 ? Math.round(Number(tail?.[3]) * 10000) : 0 };
    return text === normalTwoStepPrompt(p, lang) && normalTwoStepDerive(p) ? p : null;
}
function solveSubjectPracticeMathNormalTwoStep(candidate, context = {}) {
    const scope = normalTwoStepScopeFrom(context.questionPlan), parameters = normalTwoStepParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? normalTwoStepDerive(parameters) : null, reasonCodes = [];
    if (!scope || !parameters || !d)
        reasonCodes.push('normal_two_step_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 77 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('normal_two_step_identity');
    const options = candidate.options ?? [], keys = options.map(o => normalTwoStepOptionKey(o.text)), expected = d?.answer ?? null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('normal_two_step_options');
    if (parameters && scope !== exports.NORMAL_TWO_STEP_SCOPES[3] && options.some(o => Number(o.text) < 0 || Number(o.text) > 1))
        reasonCodes.push('normal_two_step_probability_range');
    // Four-decimal given CDF uncertainty is <= 0.0001 after subtraction; enforce wider option separation.
    if (scope !== exports.NORMAL_TWO_STEP_SCOPES[3] && options.some((o, j) => options.some((v, k) => j < k && Math.abs(Number(o.text) - Number(v.text)) <= 0.0002)))
        reasonCodes.push('normal_two_step_ambiguous_rounding');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(normalTwoStepParametersFrom(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('normal_two_step_' + lang + '_stem');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, normalTwoStepOptionKey(o.text)])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('normal_two_step_' + lang + '_options');
    }
    const optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : expected !== null && keys[j] === expected ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('normal_two_step_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('normal_two_step_error_intent');
    const scopeId = parameters ? exports.NORMAL_TWO_STEP_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.NORMAL_TWO_STEP_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.NORMAL_TWO_STEP_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, approximationMode: d?.mode ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.NORMAL_TWO_STEP_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope: scope, reasonCodes: parameters ? [] : ['normal_two_step_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
