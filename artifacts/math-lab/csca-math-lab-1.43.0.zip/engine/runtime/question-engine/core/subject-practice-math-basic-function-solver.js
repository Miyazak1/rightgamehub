"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_SOLVER_VERSION = void 0;
exports.solveSubjectPracticeMathBasicFunction = solveSubjectPracticeMathBasicFunction;
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_SOLVER_VERSION = 'math-basic-function-solver-v1';
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_SCOPE_VERSION = 'math-basic-function-scope-v1';
const SCOPES = new Set([
    'linear_monotonicity', 'quadratic_axis', 'rational_domain_exclusion', 'polynomial_parity'
]);
function objectFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function clean(value) { return String(value ?? '').replace(/[，]/g, ',').replace(/−/g, '-').replace(/\s+/g, ' ').trim(); }
function numberFrom(value) { const parsed = Number(value); return Number.isFinite(parsed) ? parsed : null; }
function signedCoefficient(value) {
    if (!value || value === '+')
        return 1;
    if (value === '-')
        return -1;
    return numberFrom(value);
}
function scopeFrom(context) {
    const plan = objectFrom(context.questionPlan);
    const render = objectFrom(plan?.renderConstraints);
    const scope = clean(render?.exactBasicFunctionScope);
    return clean(plan?.taskFamily) === 'math_basic_function_property'
        && clean(plan?.planTemplate) === 'math_basic_function_property_v1'
        && SCOPES.has(scope) ? scope : null;
}
function semanticValue(scope, textValue) {
    const text = clean(textValue);
    if (scope === 'linear_monotonicity') {
        if (/单调递增|increasing/i.test(text))
            return 'increasing';
        if (/单调递减|decreasing/i.test(text))
            return 'decreasing';
        if (/常数函数|constant/i.test(text))
            return 'constant';
        if (/不具有单调性|not monotonic/i.test(text))
            return 'not_monotonic';
    }
    if (scope === 'quadratic_axis') {
        const match = text.match(/x\s*=\s*(-?\d+(?:\.\d+)?)/i);
        if (match)
            return numberFrom(match[1]);
    }
    if (scope === 'rational_domain_exclusion') {
        const excluded = text.match(/(?:R|实数集)\s*(?:\\|∖|去掉|except)\s*\{?\s*(-?\d+)\s*\}?/i)
            ?? text.match(/x\s*[≠!=]+\s*(-?\d+)/i);
        if (excluded)
            return numberFrom(excluded[1]);
        if (/全体实数|all real numbers|^R$/i.test(text))
            return 'all_real';
    }
    if (scope === 'polynomial_parity') {
        if (/非奇非偶|neither/i.test(text))
            return 'neither';
        if (/偶函数|even function/i.test(text))
            return 'even';
        if (/奇函数|odd function/i.test(text))
            return 'odd';
        if (/常数函数|constant/i.test(text))
            return 'constant';
    }
    return null;
}
function expectedFrom(scope, promptValue) {
    const prompt = clean(promptValue);
    if (scope === 'linear_monotonicity') {
        const match = prompt.match(/f\s*\(\s*x\s*\)\s*=\s*([+-]?\d*)x(?:\s*[+-]\s*\d+)?/i);
        const slope = match ? signedCoefficient(match[1]) : null;
        return slope === null || slope === 0 ? null : slope > 0 ? 'increasing' : 'decreasing';
    }
    if (scope === 'quadratic_axis') {
        const minus = prompt.match(/\(\s*x\s*-\s*(-?\d+)\s*\)\s*\^?2/i);
        if (minus)
            return numberFrom(minus[1]);
        const plus = prompt.match(/\(\s*x\s*\+\s*(\d+)\s*\)\s*\^?2/i);
        return plus ? -Number(plus[1]) : null;
    }
    if (scope === 'rational_domain_exclusion') {
        const minus = prompt.match(/\/\s*\(\s*x\s*-\s*(-?\d+)\s*\)/i);
        if (minus)
            return numberFrom(minus[1]);
        const plus = prompt.match(/\/\s*\(\s*x\s*\+\s*(\d+)\s*\)/i);
        return plus ? -Number(plus[1]) : null;
    }
    const terms = [...prompt.matchAll(/([+-]?\d*)x\^(\d+)/gi)];
    if (!terms.length)
        return null;
    const exponents = terms.map((term) => Number(term[2]));
    if (exponents.every((value) => value % 2 === 1))
        return 'odd';
    if (exponents.every((value) => value % 2 === 0))
        return 'even';
    return 'neither';
}
function solveSubjectPracticeMathBasicFunction(candidate, context = {}) {
    const exactScope = scopeFrom(context);
    const expected = exactScope ? expectedFrom(exactScope, candidate.prompt) : null;
    const parsed = exactScope !== null && expected !== null;
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const value = exactScope ? semanticValue(exactScope, option.text) : null;
        return { optionId: option.id, verdict: value === null ? 'unknown' : value === expected ? 'true' : 'false', semanticValue: value };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!exactScope)
        reasonCodes.push('math_basic_function_scope_plan_contract_missing');
    if (!parsed)
        reasonCodes.push('math_basic_function_prompt_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_basic_function_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push('math_basic_function_answer_not_unique');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_basic_function_generator_disagreement');
    const scopeId = parsed ? `math-basic-function-property-v1:${exactScope}` : null;
    return {
        solverVersion: exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_SOLVER_VERSION,
        status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_basic_function_property', scopeId, exactScope,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['math_basic_function_verification_scope_not_matched'] },
        expectedValue: expected, optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1,
        agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
