"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMPOUND_INEQUALITY_ORACLE_VERSION = void 0;
exports.independentCompoundInequalityCertificate = independentCompoundInequalityCertificate;
exports.verifySubjectPracticeMathCompoundInequalityWithIndependentOracle = verifySubjectPracticeMathCompoundInequalityWithIndependentOracle;
// No dependency on the solver, generator, explanation verifier, or their derived answer.
exports.COMPOUND_INEQUALITY_ORACLE_VERSION = 'math-compound-inequality-oracle-v1-real-critical-partition';
const scopes = ['quadratic_and_fraction_conjunction', 'absolute_band_and_fraction_conjunction', 'quadratic_domain_implies_absolute_bound', 'fraction_domain_implies_absolute_separation'];
function segment(s) {
    const m = /^([[(])(-?\d{1,3}(?:\/[1-9]\d?)?),(-?\d{1,3}(?:\/[1-9]\d?)?)([\])])$/.exec(s);
    if (!m)
        return null;
    const value = (s) => { const parts = s.split('/').map(Number), a = parts[0], b = parts[1] ?? 1; return a % b === 0 ? a / b : NaN; };
    const v = { lo: value(m[2]), hi: value(m[3]), lc: m[1] === '[', hc: m[4] === ']' };
    return Number.isSafeInteger(v.lo) && Number.isSafeInteger(v.hi) && Math.abs(v.lo) <= 100 && Math.abs(v.hi) <= 100 && (v.lo < v.hi || v.lo === v.hi && v.lc && v.hc) ? v : null;
}
const format = (s) => (s.lc ? '[' : '(') + s.lo + ',' + s.hi + (s.hc ? ']' : ')');
const sorted = (xs) => [...new Set(xs)].sort((a, b) => a - b);
function qRoots(q) {
    if (!q)
        return [];
    return Array.from({ length: 25 }, (_, j) => j - 12).filter(x => q[0] * x * x + q[1] * x + q[2] === 0);
}
function parseVisible(text, index, lang) {
    const prefix = lang === 'zh' ? '所有变量均为实数，区间括号表示端点是否包含。' : 'All variables are real; brackets specify endpoint inclusion.';
    const ask = index < 2 ? (lang === 'zh' ? '求同时满足上述条件的全部x。' : 'Find all x satisfying all these conditions.') :
        (lang === 'zh' ? '令S为D中满足上述不等式的x的集合。求T中使S内每个x均满足下列条件的全部t：' : 'Let S be the set of x in D satisfying the inequality above. Find all t in T such that every x in S satisfies: ');
    if (typeof text !== 'string' || text.length > 1800 || !text.startsWith(prefix))
        return null;
    const split = text.indexOf('.' + ask, prefix.length);
    if (split < 0)
        return null;
    const raw = text.slice(prefix.length, split), pieces = raw.split('; '), tail = text.slice(split + 1 + ask.length);
    const names = index === 0 ? ['D=', 'Q: ', 'F: '] : index === 1 ? ['D=', 'F: ', 'B: '] : index === 2 ? ['D=', 'T=', 'Q: '] : ['D=', 'T=', 'F: '];
    if (pieces.length !== names.length || pieces.some((s, j) => !s.startsWith(names[j])))
        return null;
    const data = Object.fromEntries(pieces.map((s, j) => [names[j], s.slice(names[j].length)])), D = segment(data['D=']), T = data['T='] ? segment(data['T=']) : null;
    const qm = data['Q: '] ? /^\((-?\d+)\)\*x\^2\+\((-?\d+)\)\*x\+\((-?\d+)\)(<=|>=|<|>)0$/.exec(data['Q: ']) : null;
    const fm = data['F: '] ? /^\((-?\d+)\)\*\(x-\((-?\d+)\)\)\/\(x-\((-?\d+)\)\)(<=|>=|<|>)0$/.exec(data['F: ']) : null;
    const bm = data['B: '] ? /^(\d+) (<=|<) \|x-\((-?\d+)\)\| (<=|<) (\d+)$/.exec(data['B: ']) : null;
    const um = index >= 2 ? /^\|x-t\|(<=|>=|<|>)(\d+)\.$/.exec(tail) : null;
    if (!D || D.lo >= D.hi || D.lo < -24 || D.hi > 24 || format(D) !== data['D='] ||
        (index >= 2 && (!T || T.lo >= T.hi || T.lo < -24 || T.hi > 24 || format(T) !== data['T='] || !um)) ||
        (index < 2 && tail !== '') || !!qm !== (index === 0 || index === 2) || !!fm !== (index !== 2) || !!bm !== (index === 1))
        return null;
    const p = { index, D, T, q: qm ? qm.slice(1, 4).map(Number) : null, qr: qm?.[4] ?? null, f: fm ? fm.slice(1, 4).map(Number) : null, fr: fm?.[4] ?? null, band: bm ? [+bm[3], +bm[1], +bm[5]] : null, lc: bm?.[2] === '<=', hc: bm?.[4] === '<=', r: um ? +um[2] : null, relation: um?.[1] ?? null };
    if (p.q && (!p.q.every(Number.isSafeInteger) || !p.q[0] || Math.abs(p.q[0]) > 5 || qRoots(p.q).length !== 2))
        return null;
    if (p.f && (!p.f.every(Number.isSafeInteger) || !p.f[0] || Math.abs(p.f[0]) > 5 || Math.abs(p.f[1]) > 12 || Math.abs(p.f[2]) > 12 || p.f[1] === p.f[2]))
        return null;
    if (p.band && (Math.abs(p.band[0]) > 12 || p.band[1] < 1 || p.band[1] >= p.band[2] || p.band[2] > 8))
        return null;
    if (index >= 2 && (!Number.isSafeInteger(p.r) || p.r < 1 || p.r > 8 || !(index === 2 ? ['<', '<='] : ['>', '>=']).includes(p.relation)))
        return null;
    return p;
}
const member = (x, s, scale) => (x > scale * s.lo || x === scale * s.lo && s.lc) && (x < scale * s.hi || x === scale * s.hi && s.hc);
const cmp = (n, r) => r === '<' ? n < 0 : r === '<=' ? n <= 0 : r === '>' ? n > 0 : n >= 0;
const points = (p) => sorted([p.D.lo, p.D.hi, ...qRoots(p.q), ...(p.f ? p.f.slice(1) : []), ...(p.band ? [p.band[0] - p.band[2], p.band[0] - p.band[1], p.band[0] + p.band[1], p.band[0] + p.band[2]] : [])]);
function direct(p, X, s, omit = null) {
    const inD = omit === 'D' || member(X, p.D, s);
    const q = !p.q || omit === 'first' || cmp(p.q[0] * X * X + p.q[1] * X * s + p.q[2] * s * s, p.qr);
    const f = !p.f || omit === 'F' || cmp(p.f[0] * (X - p.f[1] * s) * (X - p.f[2] * s), p.fr) && X !== p.f[2] * s;
    let band = true;
    if (p.band && omit !== 'first') {
        const d = Math.abs(X - p.band[0] * s);
        band = (omit === 'lower' || (p.lc ? d >= p.band[1] * s : d > p.band[1] * s)) && (omit === 'upper' || (p.hc ? d <= p.band[2] * s : d < p.band[2] * s));
    }
    return inD && q && f && band;
}
function quantified(p, t2, omit = null) {
    // t2=2*t. Fixed endpoints are multiples of4 in x4; moving endpoints are even.
    // Thus every endpoint and open-cell midpoint below is an exact integer, including rays.
    const fixed = points(p), events = sorted([...fixed.map(v => 4 * v), 2 * t2 - 4 * p.r, 2 * t2 + 4 * p.r]);
    const reps = [events[0] - 4, events[events.length - 1] + 4];
    for (let j = 0; j < events.length; j++) {
        reps.push(events[j]);
        if (j + 1 < events.length)
            reps.push((events[j] + events[j + 1]) / 2);
    }
    let hasSource = false, truth = true;
    for (const x4 of reps) {
        if (!Number.isSafeInteger(x4))
            throw new Error('non_exact_partition');
        if (direct(p, x4, 4, omit)) {
            hasSource = true;
            if (!cmp(Math.abs(x4 - 2 * t2) - 4 * p.r, p.relation))
                truth = false;
        }
    }
    return { truth: truth && hasSource, hasSource, criticalX4: events, representativeCount: reps.length };
}
function join(atoms) {
    const result = [];
    for (const s of atoms.sort((a, b) => a.lo - b.lo || Number(b.lc) - Number(a.lc))) {
        const a = result[result.length - 1];
        if (!a || s.lo > a.hi || s.lo === a.hi && !s.lc && !a.hc) {
            result.push({ ...s });
            continue;
        }
        if (s.hi > a.hi) {
            a.hi = s.hi;
            a.hc = s.hc;
        }
        else if (s.hi === a.hi)
            a.hc = a.hc || s.hc;
    }
    return result;
}
const encode = (ss) => join(ss).map(format).join(' U ') || 'empty';
function optionParse(text) {
    if (text === 'empty')
        return [];
    if (typeof text !== 'string' || text.length > 400)
        return null;
    const ss = text.split(' U ').map(segment);
    return ss.length <= 4 && ss.every(Boolean) ? join(ss) : null;
}
function independentCompoundInequalityCertificate(p) {
    const dom = p.index < 2 ? p.D : p.T, fixed = points(p);
    const events = sorted((p.index < 2 ? fixed : [...fixed.flatMap(v => [v - p.r, v + p.r]), dom.lo, dom.hi]).filter(x => x >= dom.lo && x <= dom.hi));
    const parts = [];
    const omissions = p.index < 2 ? (p.index === 1 ? ['F', 'first', 'lower', 'upper'] : ['F', 'first']) : [p.index === 2 ? 'first' : 'F', 'D'];
    for (let j = 0; j < events.length; j++)
        for (const single of [true, false]) {
            if (!single && j + 1 === events.length)
                continue;
            const lo = events[j], hi = single ? lo : events[j + 1], twice = lo + hi, inside = member(twice, dom, 2);
            const evaluation = p.index >= 2 ? quantified(p, twice) : null;
            const truth = inside && (evaluation ? evaluation.truth : direct(p, twice, 2));
            const relaxed = omissions.map(o => inside && (p.index >= 2 ? quantified(p, twice, o).truth : direct(p, twice, 2, o)));
            parts.push({ kind: single ? 'point' : 'open', lo, hi, twice, truth, relaxed, xPartition: evaluation });
        }
    const atom = (c) => ({ lo: c.lo, hi: c.hi, lc: c.kind === 'point', hc: c.kind === 'point' });
    const accepted = join(parts.filter(c => c.truth).map(atom)), answer = encode(accepted);
    const witnesses = omissions.map((_, j) => parts.find(c => c.relaxed[j] !== c.truth)?.twice ?? null);
    const completeCertificate = events[0] === dom.lo && events[events.length - 1] === dom.hi && parts.length === 2 * events.length - 1;
    const validHard = completeCertificate && accepted.length > 0 && accepted.length <= 4 && accepted.every(s => s.lo < s.hi) && answer !== format(dom) && witnesses.every(x => x !== null);
    return { version: 'compound-inequality-critical-partition-v1', criticalValues: events, parts, completeCertificate,
        orderInvariant: 'All polynomial roots, fraction zeros/poles, domain edges, absolute-value boundaries and their +/- radius events are included. Within each open parameter cell their order cannot change; original predicates are constant on each resulting x cell.',
        representativeScale: 2, xEndpointScale: 4, answer, effectiveConstraintWitnessesTwice: witnesses, validHard };
}
function verifySubjectPracticeMathCompoundInequalityWithIndependentOracle(candidate, context = {}) {
    const plan = context.questionPlan, r = plan?.renderConstraints, index = scopes.indexOf(r?.exactCompoundInequalityScope), reasonCodes = [];
    const constraints = { topicCode: 'M-INEQ-001', boundedIntegerParameters: true, coefficientScaleAbsoluteMax: 5, criticalPointMin: -12, criticalPointMax: 12, domainEndpointMin: -24, domainEndpointMax: 24, maximumConstructionAttempts: 128, parameterDomain: 'bounded_real_interval', minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
    const matched = index >= 0 && plan?.schemaVersion === 'subject-practice-question-plan-v1' && plan?.policyVersion === 'subject-practice-question-plan-policy-v1' && plan?.subject === 'math' && plan?.topicId === 67 && plan?.targetDifficulty === 'hard' && plan?.representationType === 'text' && plan?.taskFamily === 'math_compound_inequality_constraint_reasoning' && plan?.planTemplate === 'math_compound_inequality_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(constraints).every(([k, v]) => r?.[k] === v) && plan?.scenarioContract?.scenarioMode === 'abstract' && plan?.scenarioContract?.scenarioEntity === 'compound_inequality_constraint_system' && plan?.scenarioContract?.scenarioAction === scopes[index];
    const p = matched ? parseVisible(candidate.prompt, index, 'zh') : null, cert = p ? independentCompoundInequalityCertificate(p) : null;
    if (!p || !cert?.completeCertificate || !cert?.validHard)
        reasonCodes.push('compound_oracle_incomplete_or_degenerate');
    if (candidate.subject !== 'math' || candidate.topicId !== 67 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('compound_oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => { const s = optionParse(o.text); return s ? encode(s) : null; });
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('compound_oracle_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!p || JSON.stringify(parseVisible(l?.prompt ?? '', index, lang)) !== JSON.stringify(p))
            reasonCodes.push('compound_oracle_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => { const s = optionParse(o.text); return [o.id, s ? encode(s) : null]; })) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('compound_oracle_' + lang + '_options');
    }
    const trueOptionIds = opts.filter((o, j) => cert && keys[j] === cert.answer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('compound_oracle_answer');
    if (cert) {
        const answer = optionParse(cert.answer);
        const left = answer.map(s => ({ ...s })), right = answer.map(s => ({ ...s }));
        if (left.length)
            left[0].lc = !left[0].lc;
        if (right.length)
            right[right.length - 1].hc = !right[right.length - 1].hc;
        const complement = cert.parts.filter(c => !c.truth && (c.kind === 'open' || member(c.twice, p.index < 2 ? p.D : p.T, 2))).map(c => ({ lo: c.lo, hi: c.hi, lc: c.kind === 'point', hc: c.kind === 'point' }));
        const errors = { reverse_left_contact_inclusion: encode(left), reverse_right_contact_inclusion: encode(right), negate_required_set_predicate: encode(complement) }, meta = candidate.optionMetadata ?? [];
        if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || errors[m.distractorIntent ?? ''] !== keys[opts.findIndex(o => o.id === m.optionId)]))
            reasonCodes.push('compound_oracle_error_intent');
    }
    return { oracleVersion: exports.COMPOUND_INEQUALITY_ORACLE_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: p ? 'math-hard-compound-inequality-v1:' + scopes[index] : null, scopeMatched: !!p, completeCertificate: !!cert?.completeCertificate && !!cert.validHard, certificate: cert, expectedAnswer: cert?.answer ?? null, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
