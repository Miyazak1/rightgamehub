"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_SOLVER_VERSION = void 0;
exports.solveSubjectPracticeMathVectorComplex = solveSubjectPracticeMathVectorComplex;
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_SOLVER_VERSION = 'math-vector-complex-solver-v1-exact-integer';
exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_SCOPE_VERSION = 'math-vector-complex-scope-v1';
const SCOPES = new Set(['vector_coordinate_addition', 'vector_dot_product', 'complex_addition_subtraction', 'complex_modulus']);
function record(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/[，]/g, ',').replace(/\s+/g, ' ').trim(); }
function scopeFrom(context) { const p = record(context.questionPlan), r = record(p?.renderConstraints); const s = clean(r?.exactVectorComplexScope); return clean(p?.taskFamily) === 'math_vector_complex_direct_calculation' && clean(p?.planTemplate) === 'math_vector_complex_direct_calculation_v1' && SCOPES.has(s) ? s : null; }
function pairAfter(text, label) { const m = clean(text).match(new RegExp(`${label}\\s*=\\s*\\(\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\\)`, 'i')); return m ? { x: Number(m[1]), y: Number(m[2]) } : null; }
function integerAfter(text, label) { const m = clean(text).match(new RegExp(`${label}\\s*=\\s*(-?\\d+)`, 'i')); return m ? Number(m[1]) : null; }
function parametersFrom(prompt, scope) { if (!scope)
    return null; const t = clean(prompt); if (scope.startsWith('vector_')) {
    const a = pairAfter(t, 'a'), b = pairAfter(t, 'b');
    return a && b ? { a, b, operation: scope === 'vector_coordinate_addition' ? 'add' : 'dot' } : null;
} const x1 = integerAfter(t, 'x_?1'), y1 = integerAfter(t, 'y_?1'); if (scope === 'complex_modulus') {
    return Number.isInteger(x1) && Number.isInteger(y1) ? { z1: { x: Number(x1), y: Number(y1) }, operation: 'modulus' } : null;
} const x2 = integerAfter(t, 'x_?2'), y2 = integerAfter(t, 'y_?2'); const operation = /z_?1\s*-\s*z_?2/i.test(t) ? 'subtract' : 'add'; return [x1, y1, x2, y2].every(Number.isInteger) ? { z1: { x: Number(x1), y: Number(y1) }, z2: { x: Number(x2), y: Number(y2) }, operation } : null; }
function expectedFor(scope, p) { if (scope === 'vector_coordinate_addition')
    return { x: p.a.x + p.b.x, y: p.a.y + p.b.y }; if (scope === 'vector_dot_product')
    return p.a.x * p.b.x + p.a.y * p.b.y; if (scope === 'complex_addition_subtraction') {
    const sign = p.operation === 'subtract' ? -1 : 1;
    return { x: p.z1.x + sign * p.z2.x, y: p.z1.y + sign * p.z2.y };
} return Math.sqrt(p.z1.x * p.z1.x + p.z1.y * p.z1.y); }
function parsePair(text) { const t = clean(text).replace(/\s/g, ''); let m = t.match(/^\((-?\d+),(-?\d+)\)$/); if (m)
    return { x: Number(m[1]), y: Number(m[2]) }; m = t.match(/^(-?\d+)([+-]\d+)i$/i); return m ? { x: Number(m[1]), y: Number(m[2]) } : null; }
function equal(a, b) { return typeof a === 'number' && typeof b === 'number' ? a === b : typeof a === 'object' && a !== null && typeof b === 'object' && b !== null && a.x === b.x && a.y === b.y; }
function solveSubjectPracticeMathVectorComplex(candidate, context = {}) { const exactScope = scopeFrom(context); const parameters = parametersFrom(candidate.prompt, exactScope); const parsed = Boolean(exactScope && parameters); const expectedValue = parsed ? expectedFor(exactScope, parameters) : null; const pairAnswer = exactScope === 'vector_coordinate_addition' || exactScope === 'complex_addition_subtraction'; const optionVerdicts = (candidate.options ?? []).map((o) => { const value = pairAnswer ? parsePair(o.text) : Number(clean(o.text)); const valid = pairAnswer ? value !== null : Number.isSafeInteger(value); return { optionId: o.id, verdict: !valid ? 'unknown' : equal(value, expectedValue) ? 'true' : 'false', semanticValue: value }; }); const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId); const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null; const reasonCodes = []; if (!exactScope)
    reasonCodes.push('math_vector_complex_scope_plan_contract_missing'); if (!parameters)
    reasonCodes.push('math_vector_complex_prompt_unparsed'); if (optionVerdicts.some(x => x.verdict === 'unknown'))
    reasonCodes.push('math_vector_complex_option_unparsed'); if (trueOptionIds.length !== 1)
    reasonCodes.push(trueOptionIds.length ? 'math_vector_complex_multiple_true_options' : 'math_vector_complex_no_true_option'); if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('math_vector_complex_generator_disagreement'); const scopeId = parsed ? `math-basic-vector-complex-v1:${exactScope}` : null; return { solverVersion: exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_SOLVER_VERSION, status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified', taskFamily: 'math_vector_complex_direct_calculation', scopeId, exactScope, parameters, expectedValue, verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_VECTOR_COMPLEX_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['math_vector_complex_verification_scope_not_matched'] }, optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
