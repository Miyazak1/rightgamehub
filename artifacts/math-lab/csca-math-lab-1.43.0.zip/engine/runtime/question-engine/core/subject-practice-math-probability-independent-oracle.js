"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathProbabilityWithIndependentOracle = verifySubjectPracticeMathProbabilityWithIndependentOracle;
const subject_practice_math_probability_solver_1 = require("./subject-practice-math-probability-solver");
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_INDEPENDENT_ORACLE_VERSION = 'math-probability-independent-oracle-v1-finite-enumeration';
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ' ').trim(); }
function scope(context) { const p = object(context.questionPlan), r = object(p?.renderConstraints), s = clean(r?.exactProbabilityScope); return clean(p?.taskFamily) === 'math_classical_probability_basic_calculation' && clean(p?.planTemplate) === 'math_classical_probability_basic_calculation_v1' && ['colored_objects_single_draw', 'uniform_integer_event', 'single_die_event', 'two_coin_outcome_event'].includes(s) ? s : null; }
function n(text, label) { const m = clean(text).match(new RegExp(`(?:^|[^A-Z])${label}\\s*=\\s*(\\d+)`, 'i')); return m ? Number(m[1]) : null; }
function count(prompt, s) { if (!s)
    return null; const t = clean(prompt); if (s === 'colored_objects_single_draw') {
    const red = n(t, 'R'), blue = n(t, 'B');
    if (!red || !blue)
        return null;
    const outcomes = Array.from({ length: red + blue }, (_, i) => i < red ? 'red' : 'blue');
    return { favorable: outcomes.filter(x => x === 'red').length, total: outcomes.length };
} if (s === 'uniform_integer_event') {
    const total = n(t, 'N'), divisor = n(t, 'K');
    if (!total || !divisor)
        return null;
    const outcomes = Array.from({ length: total }, (_, i) => i + 1);
    return { favorable: outcomes.filter(x => x % divisor === 0).length, total: outcomes.length };
} if (s === 'single_die_event') {
    const threshold = n(t, 'T');
    if (!threshold)
        return null;
    const outcomes = [1, 2, 3, 4, 5, 6];
    return { favorable: outcomes.filter(x => x > threshold).length, total: outcomes.length };
} const heads = n(t, 'H'); if (heads === null)
    return null; const outcomes = ['HH', 'HT', 'TH', 'TT']; return { favorable: outcomes.filter(x => x.split('').filter(y => y === 'H').length === heads).length, total: outcomes.length }; }
function parse(value) { const m = clean(value).replace(/\s/g, '').match(/^(\d+)(?:\/(\d+))?$/); return m ? (0, subject_practice_math_probability_solver_1.rational)(Number(m[1]), m[2] ? Number(m[2]) : 1) : null; }
function same(a, b) { return a && b && a.numerator === b.numerator && a.denominator === b.denominator; }
function verifySubjectPracticeMathProbabilityWithIndependentOracle(candidate, context = {}) { const exactScope = scope(context), counts = count(candidate.prompt, exactScope), parsed = Boolean(exactScope && counts), expectedValue = counts ? (0, subject_practice_math_probability_solver_1.rational)(counts.favorable, counts.total) : null; const optionVerdicts = (candidate.options ?? []).map(o => { const value = parse(o.text); return { optionId: o.id, verdict: !value ? 'unknown' : same(value, expectedValue) ? 'true' : 'false' }; }); const trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null, reasonCodes = []; if (!parsed)
    reasonCodes.push('math_probability_oracle_prompt_or_plan_unparsed'); if (optionVerdicts.some(x => x.verdict === 'unknown'))
    reasonCodes.push('math_probability_oracle_option_unparsed'); if (trueOptionIds.length !== 1)
    reasonCodes.push('math_probability_oracle_answer_not_unique'); if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
    reasonCodes.push('math_probability_oracle_generator_disagreement'); return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_PROBABILITY_INDEPENDENT_ORACLE_VERSION, status: reasonCodes.length ? (parsed ? 'disagreed' : 'abstained') : 'verified', scopeId: parsed ? `math-basic-probability-v1:${exactScope}` : null, exactScope, counts, expectedValue, scopeMatched: parsed, optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, independentFromPrimarySolver: true, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
