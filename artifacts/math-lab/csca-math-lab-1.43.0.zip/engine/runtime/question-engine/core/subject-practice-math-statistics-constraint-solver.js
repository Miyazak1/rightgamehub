"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATISTICS_CONSTRAINT_NAMES = exports.sn = exports.scmp = exports.sdiv = exports.smul = exports.ssub = exports.sadd = exports.stxt = exports.STATISTICS_CONSTRAINT_CONSTRAINTS = exports.STATISTICS_CONSTRAINT_SCOPES = exports.STATISTICS_CONSTRAINT_SCOPE_VERSION = exports.STATISTICS_CONSTRAINT_SOLVER_VERSION = exports.STATISTICS_CONSTRAINT_TEMPLATE = exports.STATISTICS_CONSTRAINT_FAMILY = void 0;
exports.sq = sq;
exports.statisticsConstraintScopeFrom = statisticsConstraintScopeFrom;
exports.statisticsConstraintPrompt = statisticsConstraintPrompt;
exports.statisticsConstraintParametersFrom = statisticsConstraintParametersFrom;
exports.statisticsConstraintOptionKey = statisticsConstraintOptionKey;
exports.statisticsMoments = statisticsMoments;
exports.statisticsConstraintDerive = statisticsConstraintDerive;
exports.solveSubjectPracticeMathStatisticsConstraint = solveSubjectPracticeMathStatisticsConstraint;
exports.STATISTICS_CONSTRAINT_FAMILY = 'math_descriptive_statistics_constraint_reasoning';
exports.STATISTICS_CONSTRAINT_TEMPLATE = exports.STATISTICS_CONSTRAINT_FAMILY + '_v1';
exports.STATISTICS_CONSTRAINT_SOLVER_VERSION = 'math-statistics-constraint-solver-v1-exact-rational-moments';
exports.STATISTICS_CONSTRAINT_SCOPE_VERSION = 'math-hard-statistics-constraint-v1';
exports.STATISTICS_CONSTRAINT_SCOPES = ["two_missing_values_moments_order_replacement_variance", "three_missing_frequencies_moments_trimmed_variance", "two_group_moments_order_reweighted_mean", "affine_moments_sign_threshold_subset_variance"];
exports.STATISTICS_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-STAT-001', boundedIntegerAndHalfIntegerParameters: true, maximumConstructionAttempts: 256, maximumEnumeratedParameterCompletions: 4096, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function sq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b)
    throw Error('zero_denominator'); if (b < 0n) {
    a = -a;
    b = -b;
} if (a.toString(2).length > 512 || b.toString(2).length > 512)
    throw Error('statistics_arithmetic_bound'); let x = a < 0n ? -a : a, y = b; while (y)
    [x, y] = [y, x % y]; return { n: a / (x || 1n), d: b / (x || 1n) }; }
const stxt = (v) => String(v.n) + (v.d === 1n ? '' : '/' + v.d), sadd = (a, b) => sq(a.n * b.d + b.n * a.d, a.d * b.d), ssub = (a, b) => sq(a.n * b.d - b.n * a.d, a.d * b.d), smul = (a, b) => sq(a.n * b.n, a.d * b.d), sdiv = (a, b) => sq(a.n * b.d, a.d * b.n), scmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0;
exports.stxt = stxt, exports.sadd = sadd, exports.ssub = ssub, exports.smul = smul, exports.sdiv = sdiv, exports.scmp = scmp;
const sn = (s) => { if (typeof s !== 'string' || s.length > 128 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('invalid_rational'); const [n, d = '1'] = s.split('/'); return sq(BigInt(n), BigInt(d)); };
exports.sn = sn;
const equal = (a, b) => (0, exports.scmp)(a, b) === 0, zero = sq(0), one = sq(1);
const obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function statisticsConstraintScopeFrom(value) { const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactStatisticsConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 76 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.STATISTICS_CONSTRAINT_FAMILY && p?.planTemplate === exports.STATISTICS_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.STATISTICS_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'statistics_constraint_system' && s?.scenarioAction === scope && exports.STATISTICS_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
exports.STATISTICS_CONSTRAINT_NAMES = [['known', 'mean', 'variance', 'order', 'a', 'b'], ['levels', 'knownIndex', 'knownFrequency', 'total', 'mean', 'variance', 'removedIndex'], ['nA', 'nB', 'varianceA', 'varianceB', 'mean', 'variance', 'order', 'p', 'q'], ['data', 'meanY', 'varianceY', 'signA', 'threshold', 'relation']];
const startsZh = ['六个数据由四个已知数和两个未知整数 x,y 组成，x,y 属于[-16,16]。给定均值、总体方差及大小关系，用 a*x+b 仅替换 x，求更新后六个数的总体方差。参数：', '四个递增整数值的频数表中，已知一个频数，其余三个是[1,12]内的未知整数。给出总频数、均值、总体方差，删除指定值的所有数据后求总体方差。位置从1开始。参数：', '两组数据A,B的数量均为偶数，组内总体方差已知，两个未知均值是[-16,16]内的整数。给出合并均值、合并总体方差和两组均值的大小关系。将A组全部数据重复p次，B组全部数据重复q次，求新均值。参数：', '已知一组整数数据，作变换 y=a*x+b。a 是[-3,3]内非零半整数，b 是[-20,20]内半整数。给出新均值、总体方差及a的正负号，保留满足阈值关系的数据后求总体方差。参数：'];
const startsEn = ['Six data values comprise four known values and unknown integers x,y in[-16,16]. Given their mean, population variance and order, replace only x by a*x+b and find the population variance of the six updated values. Parameters: ', 'A frequency table has four increasing integer levels. One frequency is known; the other three are unknown integers in[1,12]. Given total frequency, mean and population variance, delete all observations at the designated level and find the remaining population variance. Positions are one-based. Parameters: ', 'Groups A,B have even sizes and known within-group population variances. Their unknown means are integers in[-16,16]. Given the combined mean, combined population variance and mean order, repeat every A observation p times and every B observation q times. Find the resulting mean. Parameters: ', 'Transform the displayed integer data by y=a*x+b. Nonzero a belongs to the half-integer grid in[-3,3], and b to the half-integer grid in[-20,20]. Given the transformed mean, population variance and sign of a, retain the values satisfying the threshold relation and find their population variance. Parameters: '];
function statisticsConstraintPrompt(p, lang) { const i = exports.STATISTICS_CONSTRAINT_SCOPES.indexOf(p.scope); return (lang === 'zh' ? startsZh : startsEn)[i] + exports.STATISTICS_CONSTRAINT_NAMES[i].map((n, j) => n + '=(' + p.data[j] + ')').join('; ') + (lang === 'zh' ? '。总体方差始终以当前数据个数 n 为分母；不得使用 n-1。' : ' . Population variance always divides by the current data count n, never n-1.'); }
function statisticsConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 4000)
    return null; const data = [...text.matchAll(/=\(([^()]*)\)/g)].map(m => m[1]), p = { scope, data }; return data.length === exports.STATISTICS_CONSTRAINT_NAMES[exports.STATISTICS_CONSTRAINT_SCOPES.indexOf(scope)].length && statisticsConstraintPrompt(p, lang) === text ? p : null; }
function statisticsConstraintOptionKey(text, scope) { try {
    const q = (0, exports.sn)(text.trim());
    return scope !== exports.STATISTICS_CONSTRAINT_SCOPES[2] && q.n < 0n ? null : (0, exports.stxt)(q);
}
catch {
    return null;
} }
function statisticsMoments(data) { if (!data.length || data.length > 48)
    throw Error('data_count'); const N = sq(data.length), sum = data.reduce(exports.sadd, zero), squares = data.reduce((a, x) => (0, exports.sadd)(a, (0, exports.smul)(x, x)), zero), mean = (0, exports.sdiv)(sum, N), variance = (0, exports.ssub)((0, exports.sdiv)(squares, N), (0, exports.smul)(mean, mean)); return { count: data.length, sum, squares, mean, variance }; }
const int = (s, min, max) => { const q = (0, exports.sn)(s); if (q.d !== 1n || q.n < BigInt(min) || q.n > BigInt(max))
    throw Error('integer_domain'); return Number(q.n); };
const list = (s, n, min, max) => { const v = s.split(',').map(x => int(x, min, max)); if (v.length !== n)
    throw Error('list_length'); return v; };
const isqrt = (v) => { if (v < 0n)
    throw Error('negative_square'); let lo = 0n, hi = v + 1n; while (hi - lo > 1n) {
    const mid = (lo + hi) / 2n;
    if (mid * mid <= v)
        lo = mid;
    else
        hi = mid;
} return lo; };
const sqrt = (v) => { const n = isqrt(v.n), d = isqrt(v.d); if (n * n !== v.n || d * d !== v.d)
    throw Error('nonrational_square'); return sq(n, d); };
const grid = (v, min, max) => (0, exports.scmp)(v, sq(min)) >= 0 && (0, exports.scmp)(v, sq(max)) <= 0 && 2n % v.d === 0n;
function model(p) {
    const i = exports.STATISTICS_CONSTRAINT_SCOPES.indexOf(p.scope), d = p.data;
    if (i < 0 || d.length !== exports.STATISTICS_CONSTRAINT_NAMES[i].length)
        throw Error('scope_data');
    const ints = Array.from({ length: 33 }, (_, j) => sq(j - 16));
    let groups, domain, evaluate, solve;
    if (i === 0) {
        const known = list(d[0], 4, -16, 16).map(x => sq(x)), M = (0, exports.sn)(d[1]), V = (0, exports.sn)(d[2]), order = d[3], a = int(d[4], -2, 3), b = int(d[5], -12, 12);
        if (!['<', '>'].includes(order) || ![-2, -1, 2, 3].includes(a) || V.n <= 0n)
            throw Error('replacement_domain');
        groups = ['mean', 'population_variance', 'order'];
        domain = [ints, ints];
        evaluate = u => { const before = [...known, ...u], m = statisticsMoments(before); return { u, before, target: [...known, (0, exports.sadd)((0, exports.smul)(sq(a), u[0]), sq(b)), u[1]], flags: [equal(m.mean, M), equal(m.variance, V), (order === '<' ? (0, exports.scmp)(u[0], u[1]) < 0 : (0, exports.scmp)(u[0], u[1]) > 0)] }; };
        solve = () => { const k = statisticsMoments(known), S = (0, exports.ssub)((0, exports.smul)(sq(6), M), k.sum), Q = (0, exports.ssub)((0, exports.smul)(sq(6), (0, exports.sadd)(V, (0, exports.smul)(M, M))), k.squares), product = (0, exports.sdiv)((0, exports.ssub)((0, exports.smul)(S, S), Q), sq(2)), disc = (0, exports.ssub)((0, exports.smul)(S, S), (0, exports.smul)(sq(4), product)), delta = sqrt(disc), small = (0, exports.sdiv)((0, exports.ssub)(S, delta), sq(2)), large = (0, exports.sdiv)((0, exports.sadd)(S, delta), sq(2)), u = order === '<' ? [small, large] : [large, small]; return { u, steps: ['x+y=' + (0, exports.stxt)(S) + '; x²+y²=' + (0, exports.stxt)(Q), 'xy=' + (0, exports.stxt)(product) + '; discriminant=' + (0, exports.stxt)(disc), 'ordered (x,y)=(' + u.map(exports.stxt) + ')', 'replace x by ' + a + '*x+' + b] }; };
    }
    else if (i === 1) {
        const levels = list(d[0], 4, -8, 16);
        if (levels.some((x, j) => j > 0 && x <= levels[j - 1]))
            throw Error('ordered_levels');
        const ki = int(d[1], 1, 4) - 1, kf = int(d[2], 1, 12), N = int(d[3], 4, 48), M = (0, exports.sn)(d[4]), V = (0, exports.sn)(d[5]), removed = int(d[6], 1, 4) - 1;
        if (V.n <= 0n)
            throw Error('variance_domain');
        const indices = [0, 1, 2, 3].filter(j => j !== ki), freqs = Array.from({ length: 12 }, (_, j) => sq(j + 1));
        groups = ['total', 'mean', 'population_variance'];
        domain = [freqs, freqs, freqs];
        const expand = (u) => { const frequencies = levels.map((_, j) => j === ki ? kf : Number(u[indices.indexOf(j)].n)); return levels.flatMap((x, j) => Array(frequencies[j]).fill(sq(x))); };
        evaluate = u => { const before = expand(u), m = statisticsMoments(before); return { u, before, target: before.filter(x => !equal(x, sq(levels[removed]))), flags: [before.length === N, equal(m.mean, M), equal(m.variance, V)] }; };
        solve = () => { const rhs = [(0, exports.ssub)(sq(N), sq(kf)), (0, exports.ssub)((0, exports.smul)(sq(N), M), sq(kf * levels[ki])), (0, exports.ssub)((0, exports.smul)(sq(N), (0, exports.sadd)(V, (0, exports.smul)(M, M))), sq(kf * levels[ki] ** 2))]; const mat = [0, 1, 2].map(power => [...indices.map(j => sq(levels[j] ** power)), rhs[power]]); for (let col = 0; col < 3; col++) {
            const pivot = mat.findIndex((row, j) => j >= col && row[col].n !== 0n);
            if (pivot < 0)
                throw Error('moment_rank');
            [mat[col], mat[pivot]] = [mat[pivot], mat[col]];
            const divisor = mat[col][col];
            mat[col] = mat[col].map(x => (0, exports.sdiv)(x, divisor));
            for (let j = 0; j < 3; j++)
                if (j !== col) {
                    const scale = mat[j][col];
                    mat[j] = mat[j].map((x, k) => (0, exports.ssub)(x, (0, exports.smul)(scale, mat[col][k])));
                }
        } const u = mat.map(row => row[3]); return { u, steps: ['sum frequencies=' + N + '; first moment=' + (0, exports.stxt)((0, exports.smul)(sq(N), M)), 'second moment=' + (0, exports.stxt)((0, exports.smul)(sq(N), (0, exports.sadd)(V, (0, exports.smul)(M, M)))), 'rank3 moment equations give unknown frequencies=(' + u.map(exports.stxt) + ')', 'delete all observations at level ' + levels[removed]] }; };
    }
    else if (i === 2) {
        const nA = int(d[0], 4, 8), nB = int(d[1], 4, 8), vA = int(d[2], 1, 9), vB = int(d[3], 1, 9), M = (0, exports.sn)(d[4]), V = (0, exports.sn)(d[5]), order = d[6], pW = int(d[7], 1, 3), qW = int(d[8], 1, 3);
        if (nA % 2 || nB % 2 || ![1, 4, 9].includes(vA) || ![1, 4, 9].includes(vB) || !['<', '>'].includes(order) || pW === qW)
            throw Error('group_domain');
        groups = ['combined_mean', 'combined_population_variance', 'mean_order'];
        domain = [ints, ints];
        const build = (mu, n, v) => Array.from({ length: n }, (_, j) => (0, exports.sadd)(mu, sq(j < n / 2 ? -Math.sqrt(v) : Math.sqrt(v))));
        evaluate = u => { const A = build(u[0], nA, vA), B = build(u[1], nB, vB), before = [...A, ...B], m = statisticsMoments(before); return { u, before, target: [...Array.from({ length: pW }, () => A).flat(), ...Array.from({ length: qW }, () => B).flat()], flags: [equal(m.mean, M), equal(m.variance, V), order === '<' ? (0, exports.scmp)(u[0], u[1]) < 0 : (0, exports.scmp)(u[0], u[1]) > 0] }; };
        solve = () => { const N = nA + nB, within = sq(nA * vA + nB * vB, N), delta2 = (0, exports.smul)((0, exports.ssub)(V, within), sq(N * N, nA * nB)), abs = sqrt(delta2), delta = order === '<' ? abs : (0, exports.smul)(sq(-1), abs), muA = (0, exports.ssub)(M, (0, exports.smul)(sq(nB, N), delta)), muB = (0, exports.sadd)(M, (0, exports.smul)(sq(nA, N), delta)); return { u: [muA, muB], steps: ['within-group weighted variance=' + (0, exports.stxt)(within), '(meanB-meanA)²=' + (0, exports.stxt)(delta2) + '; signed difference=' + (0, exports.stxt)(delta), 'meanA=' + (0, exports.stxt)(muA) + '; meanB=' + (0, exports.stxt)(muB), 'new weights=(' + pW * nA + ',' + qW * nB + ')'] }; };
    }
    else {
        const arr = d[0].split(','), known = list(d[0], arr.length, -16, 16).map(x => sq(x));
        if (known.length < 5 || known.length > 8)
            throw Error('affine_count');
        const original = statisticsMoments(known), M = (0, exports.sn)(d[1]), V = (0, exports.sn)(d[2]), sign = d[3], threshold = (0, exports.sn)(d[4]), relation = d[5];
        if (original.variance.n <= 0n || V.n <= 0n || !['+', '-'].includes(sign) || !['>', '>='].includes(relation) || !grid(threshold, -40, 40))
            throw Error('affine_domain');
        groups = ['transformed_mean', 'transformed_population_variance', 'scale_sign'];
        domain = [Array.from({ length: 13 }, (_, j) => sq(j - 6, 2)).filter(x => x.n !== 0n), Array.from({ length: 81 }, (_, j) => sq(j - 40, 2))];
        evaluate = u => { const before = known.map(x => (0, exports.sadd)((0, exports.smul)(u[0], x), u[1])), m = statisticsMoments(before); return { u, before, target: before.filter(x => relation === '>' ? (0, exports.scmp)(x, threshold) > 0 : (0, exports.scmp)(x, threshold) >= 0), flags: [equal(m.mean, M), equal(m.variance, V), sign === '+' ? u[0].n > 0n : u[0].n < 0n] }; };
        solve = () => { const a2 = (0, exports.sdiv)(V, original.variance), a = (0, exports.smul)(sq(sign === '+' ? 1 : -1), sqrt(a2)), b = (0, exports.ssub)(M, (0, exports.smul)(a, original.mean)); return { u: [a, b], steps: ['original mean=' + (0, exports.stxt)(original.mean) + '; original population variance=' + (0, exports.stxt)(original.variance), 'a²=' + (0, exports.stxt)(a2) + '; sign gives a=' + (0, exports.stxt)(a), 'b=' + (0, exports.stxt)(b), 'retain y' + relation + (0, exports.stxt)(threshold)] }; };
    }
    return { index: i, groups, data: d, domain, evaluate, solve };
}
function tupleInDomain(m, u) { return u.length === m.domain.length && u.every((v, j) => m.domain[j].some(x => equal(x, v))); }
function validCompletion(c, i) { if (c.before.some(x => (0, exports.scmp)(x, sq(-128)) < 0 || (0, exports.scmp)(x, sq(128)) > 0) || c.target.length < 2 || c.target.length > 48 || c.target.some(x => (0, exports.scmp)(x, sq(-128)) < 0 || (0, exports.scmp)(x, sq(128)) > 0))
    return false; if (i === 3 && c.target.length >= c.before.length)
    return false; return i === 2 || statisticsMoments(c.target).variance.n > 0n; }
const requested = (c, i) => i === 2 ? statisticsMoments(c.target).mean : statisticsMoments(c.target).variance;
function statisticsConstraintDerive(p) {
    try {
        const m = model(p), solution = m.solve();
        if (!tupleInDomain(m, solution.u))
            return null;
        const chosen = m.evaluate(solution.u);
        if (!chosen.flags.every(Boolean) || !validCompletion(chosen, m.index))
            return null;
        const answer = (0, exports.stxt)(requested(chosen, m.index)), before = statisticsMoments(chosen.before), after = statisticsMoments(chosen.target);
        if (answer === (0, exports.stxt)(m.index === 2 ? before.mean : before.variance))
            return null;
        const witnesses = [], full = [];
        let examined = 0;
        const alternatives = new Map();
        const walk = (u) => { if (u.length < m.domain.length) {
            for (const x of m.domain[u.length])
                walk([...u, x]);
            return;
        } examined++; const c = m.evaluate(u); if (!validCompletion(c, m.index))
            return; const value = (0, exports.stxt)(requested(c, m.index)); if (c.flags.every(Boolean))
            full.push(u.map(exports.stxt)); for (let omitted = 0; omitted < 3; omitted++)
            if (!alternatives.has(omitted) && !c.flags[omitted] && c.flags.every((ok, j) => j === omitted || ok) && value !== answer)
                alternatives.set(omitted, { u, answer: value }); };
        walk([]);
        if (examined > 4096 || full.length !== 1 || JSON.stringify(full[0]) !== JSON.stringify(solution.u.map(exports.stxt)) || alternatives.size !== 3)
            return null;
        for (let j = 0; j < 3; j++) {
            const alt = alternatives.get(j);
            witnesses.push({ omitted: m.groups[j], completion: alt.u.map(exports.stxt), differentAnswer: alt.answer });
        }
        const errorValues = [];
        const err = (intent, value) => errorValues.push({ intent, value });
        if (m.index === 2) {
            const a = solution.u[0], b = solution.u[1], nA = Number(p.data[0]), nB = Number(p.data[1]), wA = Number(p.data[7]), wB = Number(p.data[8]);
            err('ignore_new_weights', before.mean);
            err('unweighted_group_means', (0, exports.sdiv)((0, exports.sadd)(a, b), sq(2)));
            err('reverse_repeat_weights', (0, exports.sdiv)((0, exports.sadd)((0, exports.smul)(sq(wB * nA), a), (0, exports.smul)(sq(wA * nB), b)), sq(wB * nA + wA * nB)));
            err('omit_population_count_division', after.sum);
            err('ignore_group_sizes', (0, exports.sdiv)((0, exports.sadd)((0, exports.smul)(sq(wA), a), (0, exports.smul)(sq(wB), b)), sq(wA + wB)));
        }
        else {
            err('use_sample_variance_denominator', (0, exports.smul)(after.variance, sq(after.count, after.count - 1)));
            err('divide_population_variance_twice', (0, exports.sdiv)(after.variance, sq(after.count)));
            err('omit_centering_mean_square', (0, exports.sdiv)(after.squares, sq(after.count)));
            err('omit_data_operation', before.variance);
            err('square_mean_instead_of_variance', (0, exports.smul)(after.mean, after.mean));
        }
        const errors = errorValues.map(e => ({ intent: e.intent, text: (0, exports.stxt)(e.value), key: (0, exports.stxt)(e.value) })).filter((e, j, a) => e.key !== answer && a.findIndex(x => x.key === e.key) === j).slice(0, 3);
        if (errors.length !== 3)
            return null;
        const steps = [...solution.steps, 'updated count=' + after.count + '; mean=' + (0, exports.stxt)(after.mean) + '; sum of squares=' + (0, exports.stxt)(after.squares), (m.index === 2 ? 'weighted mean=' : 'population variance=') + answer, 'substitution verifies all givens and exactly one admissible completion'];
        const certificate = { method: 'exhaustive_bounded_parameters_and_exact_moment_elimination', complete: true, examined, domainSizes: m.domain.map(d => d.length), completions: full, selected: solution.u.map(exports.stxt), originalCount: before.count, targetCount: after.count };
        const hardEvidence = { version: 'statistics-constraint-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 3, reasoningSteps: steps.length, quantitativeRelations: 2, groups: m.groups, effectiveConstraints: witnesses, completeStatisticsCertificate: certificate, criticalPoints: [], answer, visibleProof: steps.join('; '), studentCalibrated: false };
        return { answer, text: answer, errors, steps, proof: steps.join('; '), hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathStatisticsConstraint(candidate, context = {}) {
    const scope = statisticsConstraintScopeFrom(context.questionPlan), parameters = statisticsConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? statisticsConstraintDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('statistics_constraint_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 76 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('statistics_constraint_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? statisticsConstraintOptionKey(o.text, scope) : null);
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('statistics_constraint_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(statisticsConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('statistics_constraint_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, scope ? statisticsConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('statistics_constraint_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('statistics_constraint_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('statistics_constraint_error_intent');
    const scopeId = parameters ? exports.STATISTICS_CONSTRAINT_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.STATISTICS_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.STATISTICS_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.STATISTICS_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['statistics_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
