"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROBABILITY_TWO_STAGE_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathProbabilityTwoStageLocalGenerator = createSubjectPracticeMathProbabilityTwoStageLocalGenerator;
const subject_practice_math_probability_two_stage_solver_1 = require("./subject-practice-math-probability-two-stage-solver");
const subject_practice_math_probability_two_stage_independent_oracle_1 = require("./subject-practice-math-probability-two-stage-independent-oracle");
const subject_practice_math_probability_two_stage_explanation_verifier_1 = require("./subject-practice-math-probability-two-stage-explanation-verifier");
exports.PROBABILITY_TWO_STAGE_GENERATOR_VERSION = 'math-probability-two-stage-generator-v1-bounded';
function createSubjectPracticeMathProbabilityTwoStageLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, exactScope = (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStageScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.PROBABILITY_TWO_STAGE_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['probability_two_stage_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 75 || b.topicCode !== 'M-PROB-001' || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        let selected = null, parameterAttempts = 0;
        for (let attempt = 0; attempt < 64; attempt++) {
            parameterAttempts++;
            const n = seed % 100000 + attempt * 1009, r = 2 + n % 11, b = 2 + Math.floor(n / 11) % 11, u = 2 + (n * 3 + 1) % 11, v = 2 + Math.floor(n / 7) % 11, index = subject_practice_math_probability_two_stage_solver_1.PROBABILITY_TWO_STAGE_SCOPES.indexOf(exactScope);
            const values = index < 2 ? [r, b] : [r, b, u, v];
            const p = { scope: exactScope, values, variant: seed % 4 };
            if ((0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStageDerive)(p) && (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStageDistractors)(p).length === 3) {
                selected = p;
                break;
            }
        }
        if (!selected)
            return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts };
        const p = selected, answer = (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStageDerive)(p).answer, choices = (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStageDistractors)(p), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
        const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: x.key })), prompt = (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStagePrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_probability_two_stage_solver_1.probabilityTwoStagePrompt)(p, 'en'), explanation = (0, subject_practice_math_probability_two_stage_explanation_verifier_1.renderProbabilityTwoStageExplanation)(p, answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 75, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['古典概型与概率计算', exactScope],
            optionMetadata: choices.flatMap((x, i) => x.intent ? [{ optionId: 'ABCD'[i], distractorIntent: x.intent, misconceptionTags: [x.intent] }] : []),
            localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['古典概型与概率计算', exactScope] }, en: { prompt: enPrompt, options: options.map(x => ({ ...x })), explanation: explanation.en, knowledgeTags: ['Two-stage classical probability', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_probability_two_stage_solver_1.solveSubjectPracticeMathProbabilityTwoStage)(candidate, context), oracleEvidence = (0, subject_practice_math_probability_two_stage_independent_oracle_1.verifySubjectPracticeMathProbabilityTwoStageWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_probability_two_stage_explanation_verifier_1.verifySubjectPracticeMathProbabilityTwoStageExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, parameterAttempts, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
