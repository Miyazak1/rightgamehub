"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DERIVATIVE_CONSTRAINT_EXPLANATION_VERSION = void 0;
exports.renderDerivativeConstraintExplanation = renderDerivativeConstraintExplanation;
exports.verifySubjectPracticeMathDerivativeConstraintExplanation = verifySubjectPracticeMathDerivativeConstraintExplanation;
const subject_practice_math_derivative_constraint_solver_1 = require("./subject-practice-math-derivative-constraint-solver");
exports.DERIVATIVE_CONSTRAINT_EXPLANATION_VERSION = 'math-derivative-constraint-explanation-v1-bound-bilingual';
function renderDerivativeConstraintExplanation(p, answer, option) {
    const d = (0, subject_practice_math_derivative_constraint_solver_1.derivativeConstraintDerive)(p);
    if (!d || d.answer !== answer)
        throw Error('derivative_constraint_explanation_input');
    const i = subject_practice_math_derivative_constraint_solver_1.DERIVATIVE_CONSTRAINT_SCOPES.indexOf(p.scope), zh = [
        '切线斜率给出 f\'(t)=m，切点在曲线上给出 f(t)=mt+n。先联立求 C,D，再求导并列出全部驻点；只保留闭区间内的点，与两端点逐一代入比较，最后按题意取最大值或最小值。',
        '先求导，将两个区间上的单调性转成导数的恒定符号要求。利用平方项的顶点及区间端点求其上下界，再联立两个参数约束。边界上导数可在孤立点为零，故参数端点包含等号。',
        '先求全部驻点，把闭区间切分为严格单调的开区间及边界单点。逐项比较函数值与给定水平线；每个开区间至多贡献一个根。边界等号单独计数，重根与相邻区间的公共端点都只算一次。',
        '由导数得到两个驻点，用导数符号区分局部极大与极小。极值差给出正参数的唯一取值，再由已知函数值恢复常数。最后求指定位置的斜率和切点，代入点斜式并整理截距。'
    ][i], en = [
        'The tangent supplies both f\'(t)=m and f(t)=mt+n. Solve for C,D, differentiate the recovered cubic, and find every stationary point. Compare the values at all stationary points inside the closed interval and both endpoints, then select the requested extremum.',
        'Differentiate and convert both monotonicity conditions to quantified derivative signs. Use the vertex and endpoints to bound the square on each interval, then intersect the two parameter restrictions. An isolated zero derivative is allowed, so include both equality endpoints.',
        'Find every stationary point and partition the closed interval into strict monotone open pieces and boundary singletons. Compare the level with each endpoint value. Each open piece has at most one crossing; count equality points separately and count a multiple or shared root only once.',
        'Use derivative signs to classify the two stationary points. The positive extrema gap determines the unique positive parameter. Recover the vertical constant from the given point, then calculate the requested tangent slope, point and intercept.'
    ][i];
    return { zh: zh + ' 本题逐步代入：' + d.steps.join('；') + '。因此答案为 ' + answer + '，选' + option + '。', en: en + ' Substitution for this problem: ' + d.steps.join('; ') + '. Therefore the answer is ' + answer + '; choose ' + option + '.' };
}
function verifySubjectPracticeMathDerivativeConstraintExplanation(candidate, context = {}) { const s = (0, subject_practice_math_derivative_constraint_solver_1.solveSubjectPracticeMathDerivativeConstraint)(candidate, context), e = s.status === 'verified' && s.parameters && s.expectedAnswer && s.selectedOptionId ? renderDerivativeConstraintExplanation(s.parameters, s.expectedAnswer, s.selectedOptionId) : null, zhBound = !!e && candidate.explanation === e.zh && candidate.localizations?.zh?.explanation === e.zh, enBound = !!e && candidate.localizations?.en?.explanation === e.en, reasonCodes = zhBound && enBound ? [] : ['derivative_constraint_explanation_not_bound']; return { verifierVersion: exports.DERIVATIVE_CONSTRAINT_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: s.scopeId, zhBound, enBound, hardEvidence: s.hardEvidence, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' }; }
