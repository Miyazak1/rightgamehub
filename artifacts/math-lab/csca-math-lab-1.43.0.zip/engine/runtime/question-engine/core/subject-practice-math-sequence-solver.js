"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_SCOPE_VERSION = exports.SUBJECT_PRACTICE_MATH_SEQUENCE_SOLVER_VERSION = void 0;
exports.evaluateMathSequence = evaluateMathSequence;
exports.solveSubjectPracticeMathSequence = solveSubjectPracticeMathSequence;
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_SOLVER_VERSION = 'math-sequence-solver-v1';
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_SCOPE_VERSION = 'math-sequence-scope-v1';
const SCOPES = new Set([
    'arithmetic_explicit_term', 'geometric_explicit_term',
    'arithmetic_partial_sum', 'geometric_partial_sum'
]);
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').replace(/[−–—]/g, '-').replace(/[，]/g, ',').replace(/\s+/g, ' ').trim(); }
function scopeFrom(context) {
    const plan = record(context.questionPlan);
    const render = record(plan?.renderConstraints);
    const value = clean(render?.exactSequenceScope);
    return clean(plan?.taskFamily) === 'math_basic_sequence_direct_calculation'
        && clean(plan?.planTemplate) === 'math_basic_sequence_direct_calculation_v1'
        && SCOPES.has(value) ? value : null;
}
function integerAfter(text, label) {
    const match = clean(text).match(new RegExp(`${label}\\s*=\\s*(-?\\d+)`, 'i'));
    return match ? Number(match[1]) : null;
}
function parsePrompt(prompt, scope) {
    if (!scope)
        return null;
    const text = clean(prompt);
    const a1 = integerAfter(text, 'a_?1');
    const difference = integerAfter(text, 'd');
    const ratio = integerAfter(text, 'q');
    const targetMatch = text.match(scope.endsWith('partial_sum') ? /S_?(\d+)/i : /a_?(\d+)/gi);
    const targetToken = Array.isArray(targetMatch) ? targetMatch[targetMatch.length - 1] : null;
    const nMatch = targetToken?.match(/(\d+)/);
    const n = nMatch ? Number(nMatch[1]) : null;
    if (!Number.isInteger(a1) || !Number.isInteger(n) || Number(n) < 2)
        return null;
    if (scope.startsWith('arithmetic_') && (!Number.isInteger(difference) || difference === 0))
        return null;
    if (scope.startsWith('geometric_') && (!Number.isInteger(ratio) || [0, 1, -1].includes(Number(ratio))))
        return null;
    return { a1: Number(a1), d: difference, q: ratio, n: Number(n) };
}
function evaluateMathSequence(scope, parameters) {
    const { a1, d, q, n } = parameters;
    if (scope === 'arithmetic_explicit_term')
        return a1 + (n - 1) * Number(d);
    if (scope === 'geometric_explicit_term')
        return a1 * (Number(q) ** (n - 1));
    if (scope === 'arithmetic_partial_sum')
        return n * (2 * a1 + (n - 1) * Number(d)) / 2;
    return a1 * ((Number(q) ** n) - 1) / (Number(q) - 1);
}
function parseOption(text) { const value = Number(clean(text)); return Number.isSafeInteger(value) ? value : null; }
function solveSubjectPracticeMathSequence(candidate, context = {}) {
    const exactScope = scopeFrom(context);
    const parameters = parsePrompt(candidate.prompt, exactScope);
    const parsed = Boolean(exactScope && parameters);
    const expectedValue = parsed ? evaluateMathSequence(exactScope, parameters) : null;
    const optionVerdicts = (candidate.options ?? []).map((option) => {
        const value = parseOption(option.text);
        const truth = parsed && value === expectedValue;
        return { optionId: option.id, verdict: value === null ? 'unknown' : truth ? 'true' : 'false', semanticValue: value };
    });
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    const reasonCodes = [];
    if (!exactScope)
        reasonCodes.push('math_sequence_scope_plan_contract_missing');
    if (!parameters)
        reasonCodes.push('math_sequence_prompt_unparsed');
    if (optionVerdicts.some((item) => item.verdict === 'unknown'))
        reasonCodes.push('math_sequence_option_unparsed');
    if (trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length ? 'math_sequence_multiple_true_options' : 'math_sequence_no_true_option');
    if (selectedOptionId && selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('math_sequence_generator_disagreement');
    const scopeId = parsed ? `math-basic-sequence-v1:${exactScope}` : null;
    return {
        solverVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_SOLVER_VERSION,
        status: reasonCodes.length ? (parsed ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: 'math_basic_sequence_direct_calculation',
        scopeId, exactScope, parameters, expectedValue,
        verificationScope: { scopeVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_SCOPE_VERSION, scopeId, matched: parsed, exactScope, reasonCodes: parsed ? [] : ['math_sequence_verification_scope_not_matched'] },
        optionVerdicts, trueOptionIds, selectedOptionId, uniqueAnswer: trueOptionIds.length === 1,
        agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
