"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathBasicFunctionExplanation = verifySubjectPracticeMathBasicFunctionExplanation;
const subject_practice_math_basic_function_solver_1 = require("./subject-practice-math-basic-function-solver");
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_EXPLANATION_VERIFIER_VERSION = 'math-basic-function-explanation-verifier-v1';
function verifySubjectPracticeMathBasicFunctionExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_basic_function_solver_1.solveSubjectPracticeMathBasicFunction)(candidate, context);
    const text = String(candidate.explanation ?? '').replace(/\s+/g, ' ');
    const hasRule = solver.exactScope === 'linear_monotonicity' ? /斜率|slope/i.test(text)
        : solver.exactScope === 'quadratic_axis' ? /顶点式|对称轴|vertex form|axis/i.test(text)
            : solver.exactScope === 'rational_domain_exclusion' ? /分母|denominator/i.test(text)
                : /f\s*\(\s*-x\s*\)|奇函数|偶函数|odd|even/i.test(text);
    const conclusion = solver.exactScope === 'linear_monotonicity' ? /单调递增|单调递减|increasing|decreasing/i.test(text)
        : solver.exactScope === 'quadratic_axis' ? /x\s*=\s*-?\d+/i.test(text)
            : solver.exactScope === 'rational_domain_exclusion' ? /x\s*[≠!=]+\s*-?\d+|R\s*(?:\\|∖)/i.test(text)
                : /奇函数|偶函数|非奇非偶|odd function|even function|neither/i.test(text);
    const parityRelationMatches = solver.exactScope !== 'polynomial_parity'
        || (solver.expectedValue === 'odd'
            ? /(?:=|所以|therefore|thus).{0,12}-f\s*\(\s*x\s*\)/i.test(text)
            : solver.expectedValue === 'even'
                ? /(?:=|所以|therefore|thus).{0,12}(?<!-)f\s*\(\s*x\s*\)/i.test(text)
                : true);
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_basic_function_explanation_primary_solver_not_verified');
    if (!hasRule)
        reasonCodes.push('math_basic_function_explanation_rule_missing');
    if (!conclusion)
        reasonCodes.push('math_basic_function_explanation_conclusion_missing');
    if (!parityRelationMatches)
        reasonCodes.push('math_basic_function_explanation_parity_relation_mismatch');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solver.scopeId, ruleVisible: hasRule, conclusionVisible: conclusion, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
