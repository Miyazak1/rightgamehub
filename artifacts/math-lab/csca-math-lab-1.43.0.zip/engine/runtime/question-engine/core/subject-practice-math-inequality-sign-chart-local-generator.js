"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathInequalitySignChartLocalGenerator = createSubjectPracticeMathInequalitySignChartLocalGenerator;
const subject_practice_math_inequality_sign_chart_solver_1 = require("./subject-practice-math-inequality-sign-chart-solver");
const subject_practice_math_inequality_sign_chart_independent_oracle_1 = require("./subject-practice-math-inequality-sign-chart-independent-oracle");
const subject_practice_math_inequality_sign_chart_explanation_verifier_1 = require("./subject-practice-math-inequality-sign-chart-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_LOCAL_GENERATOR_VERSION = 'math-inequality-sign-chart-generator-v1-bounded';
function candidateFor(b, scope, seed) {
    let state = (seed ^ 0x5a17b9c3) >>> 0;
    const random = (max) => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return (state >>> 0) % max; };
    const first = seed % 8 === 0 ? 0 : random(19) - 9;
    let second = random(19) - 9;
    if (second === first)
        second = first === 9 ? -9 : first + 1;
    const lower = Math.min(first, second), upper = Math.max(first, second);
    const a = (seed % 2 ? -1 : 1) * (random(5) + 1), inclusive = scope.includes('inclusive');
    const relation = (Math.floor(seed / 2) % 2 ? '>' : '<') + (inclusive ? '=' : '');
    const kind = scope.startsWith('quadratic') ? 'quadratic' : 'linear_fraction';
    const pole = kind === 'quadratic' ? null : Math.floor(seed / 4) % 2 ? lower : upper;
    const zero = pole === lower ? upper : lower;
    const p = { scope, kind, a, b: kind === 'quadratic' ? -a * (lower + upper) : -a * zero,
        c: kind === 'quadratic' ? a * lower * upper : 0, pole, zeros: kind === 'quadratic' ? [lower, upper] : [zero],
        lower, upper, relation: relation };
    const outside = relation[0] === '>' ? a > 0 : a < 0;
    const allowedBoundary = (x) => inclusive && x !== pole;
    const region = (exterior) => exterior
        ? [{ lower: -Infinity, upper: lower, leftClosed: false, rightClosed: allowedBoundary(lower) }, { lower: upper, upper: Infinity, leftClosed: allowedBoundary(upper), rightClosed: false }]
        : [{ lower, upper, leftClosed: allowedBoundary(lower), rightClosed: allowedBoundary(upper) }];
    const correct = region(outside);
    const wrongBoundary = correct.map(i => ({ ...i,
        leftClosed: Number.isFinite(i.lower) && (pole === null ? !i.leftClosed : i.lower === pole ? true : i.leftClosed),
        rightClosed: Number.isFinite(i.upper) && (pole === null ? !i.rightClosed : i.upper === pole ? true : i.rightClosed) }));
    const choices = [
        { text: (0, subject_practice_math_inequality_sign_chart_solver_1.formatSignChartIntervals)(region(!outside)), intent: 'reversed_interval_sign' },
        { text: (0, subject_practice_math_inequality_sign_chart_solver_1.formatSignChartIntervals)(wrongBoundary), intent: pole === null ? 'incorrect_root_inclusion' : 'included_denominator_zero' },
        { text: (0, subject_practice_math_inequality_sign_chart_solver_1.formatSignChartIntervals)([{ lower: -Infinity, upper: lower, leftClosed: false, rightClosed: false }]), intent: 'ignored_second_critical_boundary' }
    ];
    const answer = (0, subject_practice_math_inequality_sign_chart_solver_1.formatSignChartIntervals)(correct), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
    choices.splice('ABCD'.indexOf(correctAnswer), 0, { text: answer, intent: '' });
    if (new Set(choices.map(o => o.text)).size !== 4)
        throw new Error('inequality_sign_chart_bounded_choices_exhausted');
    const options = choices.map((o, i) => ({ id: 'ABCD'[i], text: o.text }));
    const expression = (0, subject_practice_math_inequality_sign_chart_solver_1.signChartExpression)(p), alternate = Math.floor(seed / 16) % 2 === 1;
    const prompt = (alternate ? '求下列不等式的实数解集' : '解不等式') + '：' + expression + '。请结合临界点、区间符号与端点开闭选择解集。';
    const promptEn = (alternate ? 'Find the real solution set' : 'Solve the inequality over the real numbers') + ': ' + expression + '. Use critical points, interval signs and endpoint inclusion to select the solution set.';
    const factorization = kind === 'quadratic'
        ? 'a=' + a + '; b=' + p.b + '; c=' + p.c + '; Delta=(' + p.b + ')^2-4*(' + a + ')*(' + p.c + ')=' + (p.b * p.b - 4 * a * p.c) + '; roots={' + lower + ', ' + upper + '}; f(x)=' + a + '*(x-(' + lower + '))*(x-(' + upper + ')); domain=R'
        : 'numerator=' + a + '*(x-(' + zero + ')); zero=' + zero + '; denominator=x-(' + pole + '); pole=' + pole + '; domain: x!=' + pole;
    const sign = a > 0 ? '+' : '-', middle = a > 0 ? '-' : '+';
    const proof = expression + '; ' + factorization
        + '; signs: (-inf, ' + lower + '):' + sign + ', (' + lower + ', ' + upper + '):' + middle + ', (' + upper + ', +inf):' + sign
        + '; endpoints: ' + lower + ':' + (allowedBoundary(lower) ? 'included' : 'excluded') + ', ' + upper + ':' + (allowedBoundary(upper) ? 'included' : 'excluded')
        + '; solution=' + answer;
    const explanation = '先求临界点，再由各因子符号判定区间，最后按不等号及定义域处理端点：' + proof + '。对应选项 ' + correctAnswer + '。';
    const explanationEn = 'Find the critical points, determine each interval sign, then apply the relation and domain at endpoints: ' + proof + '. Option ' + correctAnswer + '.';
    return { subject: 'math', topicId: b.topicId, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice',
        prompt, options, correctAnswer, explanation, knowledgeTags: ['不等式的基本性质与解法', '符号区间', scope],
        optionMetadata: choices.flatMap((o, i) => o.intent ? [{ optionId: 'ABCD'[i], distractorIntent: o.intent, misconceptionTags: [o.intent] }] : []),
        localizations: { zh: { prompt, options, explanation, knowledgeTags: ['不等式', scope] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Inequality', scope] } },
        syllabusVersion: b.syllabusVersion };
}
function createSubjectPracticeMathInequalitySignChartLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0;
        const seed = validSeed ? input.seed : 0, exactScope = (0, subject_practice_math_inequality_sign_chart_solver_1.signChartScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_LOCAL_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call',
            estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['inequality_sign_chart_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 67 || b.topicCode !== 'M-INEQ-001' || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        let candidate;
        try {
            candidate = candidateFor(b, exactScope, seed);
        }
        catch {
            return { ...unsupported, status: 'bounded_generation_exhausted' };
        }
        const context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_inequality_sign_chart_solver_1.solveSubjectPracticeMathInequalitySignChart)(candidate, context), oracleEvidence = (0, subject_practice_math_inequality_sign_chart_independent_oracle_1.verifySubjectPracticeMathInequalitySignChartWithIndependentOracle)(candidate, context);
        const explanationEvidence = (0, subject_practice_math_inequality_sign_chart_explanation_verifier_1.verifySubjectPracticeMathInequalitySignChartExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres
            && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed',
            candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
            reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
