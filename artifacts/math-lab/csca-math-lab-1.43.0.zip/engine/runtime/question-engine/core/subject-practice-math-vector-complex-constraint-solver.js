"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.gnorm = exports.gtxt = exports.gcmp = exports.gsq = exports.gdiv = exports.gmul = exports.gsub = exports.gneg = exports.gadd = exports.VECTOR_COMPLEX_CONSTRAINT_CONSTRAINTS = exports.VECTOR_COMPLEX_CONSTRAINT_SCOPES = exports.VECTOR_COMPLEX_CONSTRAINT_SCOPE_VERSION = exports.VECTOR_COMPLEX_CONSTRAINT_SOLVER_VERSION = exports.VECTOR_COMPLEX_CONSTRAINT_TEMPLATE = exports.VECTOR_COMPLEX_CONSTRAINT_FAMILY = void 0;
exports.gq = gq;
exports.gread = gread;
exports.vectorComplexConstraintScopeFrom = vectorComplexConstraintScopeFrom;
exports.vectorComplexConstraintPrompt = vectorComplexConstraintPrompt;
exports.vectorComplexConstraintParametersFrom = vectorComplexConstraintParametersFrom;
exports.vectorComplexConstraintOptionKey = vectorComplexConstraintOptionKey;
exports.gsqrt = gsqrt;
exports.vectorComplexConstraintDerive = vectorComplexConstraintDerive;
exports.solveSubjectPracticeMathVectorComplexConstraint = solveSubjectPracticeMathVectorComplexConstraint;
exports.VECTOR_COMPLEX_CONSTRAINT_FAMILY = 'math_vector_complex_constraint_reasoning';
exports.VECTOR_COMPLEX_CONSTRAINT_TEMPLATE = exports.VECTOR_COMPLEX_CONSTRAINT_FAMILY + '_v1';
exports.VECTOR_COMPLEX_CONSTRAINT_SOLVER_VERSION = 'math-vector-complex-constraint-solver-v1-exact-rational';
exports.VECTOR_COMPLEX_CONSTRAINT_SCOPE_VERSION = 'math-hard-vector-complex-constraint-v1';
exports.VECTOR_COMPLEX_CONSTRAINT_SCOPES = ["vector_gram_constraints_linear_combination_norm_squared", "vector_angle_interval_parameter_combination_norm_squared", "complex_two_moduli_real_constraint_quotient_norm_squared", "complex_unit_modulus_real_constraint_cubic_reciprocal_real_part"];
exports.VECTOR_COMPLEX_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-ALG-001', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function gq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || (a < 0n ? -a : a).toString(2).length > 512 || (b < 0n ? -b : b).toString(2).length > 512)
    throw Error('geometry_arithmetic_bound'); if (b < 0n) {
    a = -a;
    b = -b;
} let x = a < 0n ? -a : a, y = b; while (y) {
    [x, y] = [y, x % y];
} return { n: a / x, d: b / x }; }
const gadd = (a, b) => gq(a.n * b.d + b.n * a.d, a.d * b.d), gneg = (a) => gq(-a.n, a.d), gsub = (a, b) => (0, exports.gadd)(a, (0, exports.gneg)(b)), gmul = (a, b) => gq(a.n * b.n, a.d * b.d), gdiv = (a, b) => gq(a.n * b.d, a.d * b.n), gsq = (a) => (0, exports.gmul)(a, a);
exports.gadd = gadd, exports.gneg = gneg, exports.gsub = gsub, exports.gmul = gmul, exports.gdiv = gdiv, exports.gsq = gsq;
const gcmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0, gtxt = (a) => String(a.n) + (a.d === 1n ? '' : '/' + a.d);
exports.gcmp = gcmp, exports.gtxt = gtxt;
function gread(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('geometry_rational_syntax'); const [n, d = '1'] = s.split('/'); return gq(BigInt(n), BigInt(d)); }
const bounded = (q) => q.n >= -1000000000000n && q.n <= 1000000000000n && q.d <= 1000000000n;
const Z = gq(0), T = gq(2), F = gq(4), obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
const gnorm = (a, b) => (0, exports.gadd)((0, exports.gsq)(a), (0, exports.gsq)(b));
exports.gnorm = gnorm;
const dot = (a, b, x, y) => (0, exports.gadd)((0, exports.gmul)(a, x), (0, exports.gmul)(b, y));
const lineValue = (l, x, y) => (0, exports.gadd)(dot(l[0], l[1], x, y), l[2]);
function intersect(l, m) { const determinant = (0, exports.gsub)((0, exports.gmul)(l[0], m[1]), (0, exports.gmul)(l[1], m[0])); if (!determinant.n)
    throw Error('nonunique_intersection'); return { x: (0, exports.gdiv)((0, exports.gsub)((0, exports.gmul)(l[1], m[2]), (0, exports.gmul)(l[2], m[1])), determinant), y: (0, exports.gdiv)((0, exports.gsub)((0, exports.gmul)(l[2], m[0]), (0, exports.gmul)(l[0], m[2])), determinant), determinant }; }
function vectorComplexConstraintScopeFrom(value) { const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactVectorComplexConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 73 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.VECTOR_COMPLEX_CONSTRAINT_FAMILY && p?.planTemplate === exports.VECTOR_COMPLEX_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.VECTOR_COMPLEX_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'vector_complex_constraint_system' && s?.scenarioAction === scope && exports.VECTOR_COMPLEX_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
const names = [['P', 'Q', 'R', 'a', 'b'], ['p', 'q', 'r', 's', 'c', 'L', 'H', 'lc', 'hc', 'a', 'b'], ['Ar', 'Ai', 'Br', 'Bi', 'R', 'S', 'm', 'n', 'h', 'Cr', 'Ci', 'Dr', 'Di'], ['a', 'b', 'c', 'sign', 'k']];
const startsZh = ['不共线的平面向量u、v满足 |u+v|^2=P，|2u-v|^2=Q，(u+2v)·(2u-v)=R。已知 ', '平面向量u=(t+p,q)、v=(r,s)的夹角余弦为c，实数t在区间L至H内；lc、hc分别取1表示包含对应端点，取0表示不含。已知 ', '复数z满足 |z-(Ar+Ai*i)|^2=R，|z-(Br+Bi*i)|^2=S，Re((m+n*i)z)=h，其中i^2=-1。已知 ', '复数z满足 |z|=1，Re((a+b*i)z)=c，sign*Im(z)>0，其中i^2=-1。已知 '];
const startsEn = ['Noncollinear plane vectors u,v satisfy |u+v|^2=P, |2u-v|^2=Q and (u+2v) dot (2u-v)=R. Given ', 'Plane vectors u=(t+p,q), v=(r,s) have angle cosine c. The real parameter t lies between L and H; lc,hc equal 1 for an included endpoint and 0 for an excluded endpoint. Given ', 'A complex number z satisfies |z-(Ar+Ai*i)|^2=R, |z-(Br+Bi*i)|^2=S and Re((m+n*i)z)=h, where i^2=-1. Given ', 'A complex number z satisfies |z|=1, Re((a+b*i)z)=c and sign*Im(z)>0, where i^2=-1. Given '];
const endsZh = ['求 |a*u+b*v|^2。', '先确定t，再求 |a*u+b*v|^2。', '求 |(z-(Cr+Ci*i))/(z-(Dr+Di*i))|^2，分母不得为零。', '求 Re(z^3+k/z)。'];
const endsEn = ['Find |a*u+b*v|^2.', 'Determine t and find |a*u+b*v|^2.', 'Find |(z-(Cr+Ci*i))/(z-(Dr+Di*i))|^2; the denominator must be nonzero.', 'Find Re(z^3+k/z).'];
function vectorComplexConstraintPrompt(p, lang) { const i = exports.VECTOR_COMPLEX_CONSTRAINT_SCOPES.indexOf(p.scope); return (lang === 'zh' ? startsZh : startsEn)[i] + names[i].map((n, j) => n + '=(' + p.data[j] + ')').join(', ') + '. ' + (lang === 'zh' ? endsZh : endsEn)[i]; }
function vectorComplexConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 3000)
    return null; const i = exports.VECTOR_COMPLEX_CONSTRAINT_SCOPES.indexOf(scope), data = [...text.matchAll(/=\(([-+]?\d+(?:\/[1-9]\d*)?)\)/g)].map(m => m[1]), p = { scope, data }; return data.length === names[i].length && vectorComplexConstraintPrompt(p, lang) === text ? p : null; }
function vectorComplexConstraintOptionKey(text, _scope) { try {
    const x = gread(text.trim());
    return bounded(x) ? (0, exports.gtxt)(x) : null;
}
catch {
    return null;
} }
function gsqrt(a) { if (a.n < 0n)
    throw Error('negative_square_root'); const root = (x) => { if (x < 2n)
    return x; let r = x, s = (r + 1n) / 2n; while (s < r) {
    r = s;
    s = (s + x / s) / 2n;
} if (r * r !== x)
    throw Error('unsupported_irrational_construction'); return r; }; return gq(root(a.n), root(a.d)); }
function quadratic(A, B, C) { if (!A.n) {
    if (!B.n)
        throw Error('degenerate_polynomial');
    return [(0, exports.gdiv)((0, exports.gneg)(C), B)];
} const d = (0, exports.gsub)((0, exports.gsq)(B), (0, exports.gmul)(F, (0, exports.gmul)(A, C))); if (d.n < 0n)
    return []; const s = gsqrt(d), r = [(0, exports.gdiv)((0, exports.gsub)((0, exports.gneg)(B), s), (0, exports.gmul)(T, A)), (0, exports.gdiv)((0, exports.gadd)((0, exports.gneg)(B), s), (0, exports.gmul)(T, A))]; return r.filter((x, j) => !j || (0, exports.gcmp)(x, r[0])); }
const det3 = (m) => (0, exports.gadd)((0, exports.gsub)((0, exports.gmul)(m[0][0], (0, exports.gsub)((0, exports.gmul)(m[1][1], m[2][2]), (0, exports.gmul)(m[1][2], m[2][1]))), (0, exports.gmul)(m[0][1], (0, exports.gsub)((0, exports.gmul)(m[1][0], m[2][2]), (0, exports.gmul)(m[1][2], m[2][0])))), (0, exports.gmul)(m[0][2], (0, exports.gsub)((0, exports.gmul)(m[1][0], m[2][1]), (0, exports.gmul)(m[1][1], m[2][0]))));
function cramer(m, v) { const d = det3(m); if (!d.n)
    throw Error('singular_system'); return [0, 1, 2].map(j => (0, exports.gdiv)(det3(m.map((r, i) => r.map((x, k) => k === j ? v[i] : x))), d)); }
function circleLine(cx, cy, r2, a, b, h) {
    const K = (0, exports.gnorm)(a, b);
    if (!K.n || r2.n <= 0n)
        throw Error('invalid_circle_line');
    const e = (0, exports.gsub)(h, (0, exports.gadd)((0, exports.gmul)(a, cx), (0, exports.gmul)(b, cy))), fx = (0, exports.gadd)(cx, (0, exports.gdiv)((0, exports.gmul)(a, e), K)), fy = (0, exports.gadd)(cy, (0, exports.gdiv)((0, exports.gmul)(b, e), K)), rho = (0, exports.gsub)(r2, (0, exports.gdiv)((0, exports.gsq)(e), K));
    if (rho.n < 0n)
        return [];
    const t = gsqrt((0, exports.gdiv)(rho, K));
    return [[(0, exports.gsub)(fx, (0, exports.gmul)(b, t)), (0, exports.gadd)(fy, (0, exports.gmul)(a, t))], [(0, exports.gadd)(fx, (0, exports.gmul)(b, t)), (0, exports.gsub)(fy, (0, exports.gmul)(a, t))]].filter((r, j, a0) => !j || r.some((x, k) => (0, exports.gcmp)(x, a0[0][k])));
}
const positiveGram = (v) => v[0].n > 0n && v[1].n > 0n && (0, exports.gsub)((0, exports.gmul)(v[0], v[1]), (0, exports.gsq)(v[2])).n > 0n;
function vectorComplexConstraintDerive(p) {
    try {
        const i = exports.VECTOR_COMPLEX_CONSTRAINT_SCOPES.indexOf(p.scope);
        if (i < 0 || p.data.length !== names[i].length)
            return null;
        const v = p.data.map(gread);
        if (!v.every(bounded))
            return null;
        let answer = Z, steps = [], groups = [], certificate = {}, witnesses = [];
        const errors = [], err = (intent, value) => { if (bounded(value))
            errors.push({ intent, text: (0, exports.gtxt)(value) }); };
        if (i === 0) {
            const [P, Q, R, a, b] = v;
            if (!a.n || !b.n)
                return null;
            const matrix = [[1, 1, 2], [4, 1, -4], [2, -2, 3]].map(r => r.map(x => gq(x))), rhs = [P, Q, R], gram = cramer(matrix, rhs), [X, Y, Z0] = gram;
            if (!positiveGram(gram))
                return null;
            const target = (g) => (0, exports.gadd)((0, exports.gadd)((0, exports.gmul)((0, exports.gsq)(a), g[0]), (0, exports.gmul)((0, exports.gsq)(b), g[1])), (0, exports.gmul)((0, exports.gmul)(T, (0, exports.gmul)(a, b)), g[2]));
            answer = target(gram);
            if (answer.n <= 0n)
                return null;
            for (let j = 0; j < 3; j++) {
                let witness = null;
                for (const delta of [gq(1, 20), gq(-1, 20), gq(1, 10), gq(-1, 10)]) {
                    const changed = rhs.map((x, k) => k === j ? (0, exports.gadd)(x, delta) : x), other = cramer(matrix, changed);
                    if (positiveGram(other) && (0, exports.gcmp)(target(other), answer)) {
                        witness = { omitted: ['first_norm', 'second_norm', 'mixed_dot'][j], alternativeGiven: (0, exports.gtxt)(changed[j]), gram: other.map(exports.gtxt), differentAnswer: (0, exports.gtxt)(target(other)) };
                        break;
                    }
                }
                if (!witness)
                    return null;
                witnesses.push(witness);
            }
            certificate = { kind: 'unique_positive_gram_system', matrix: matrix.map(r => r.map(exports.gtxt)), rhs: rhs.map(exports.gtxt), determinant: (0, exports.gtxt)(det3(matrix)), gram: gram.map(exports.gtxt), positiveDeterminant: (0, exports.gtxt)((0, exports.gsub)((0, exports.gmul)(X, Y), (0, exports.gsq)(Z0))) };
            groups = ['first norm relation', 'second norm relation', 'mixed dot relation', 'target coefficients'];
            steps = ['X+Y+2Z=' + (0, exports.gtxt)(P) + '; 4X+Y-4Z=' + (0, exports.gtxt)(Q) + '; 2X-2Y+3Z=' + (0, exports.gtxt)(R), 'det=-45; (X,Y,Z)=(' + gram.map(exports.gtxt).join(',') + ')', 'X>0,Y>0,XY-Z^2=' + (0, exports.gtxt)((0, exports.gsub)((0, exports.gmul)(X, Y), (0, exports.gsq)(Z0))) + '>0', 'a^2*X=(' + (0, exports.gtxt)(a) + ')^2*(' + (0, exports.gtxt)(X) + '); b^2*Y=(' + (0, exports.gtxt)(b) + ')^2*(' + (0, exports.gtxt)(Y) + ')', '2*a*b*Z=2*(' + (0, exports.gtxt)(a) + ')*(' + (0, exports.gtxt)(b) + ')*(' + (0, exports.gtxt)(Z0) + '); sum=' + (0, exports.gtxt)(answer)];
            err('omit_dot_cross_term', (0, exports.gadd)((0, exports.gmul)((0, exports.gsq)(a), X), (0, exports.gmul)((0, exports.gsq)(b), Y)));
            err('reverse_dot_cross_term', (0, exports.gsub)((0, exports.gadd)((0, exports.gmul)((0, exports.gsq)(a), X), (0, exports.gmul)((0, exports.gsq)(b), Y)), (0, exports.gmul)((0, exports.gmul)(T, (0, exports.gmul)(a, b)), Z0)));
            err('omit_second_vector', (0, exports.gmul)((0, exports.gsq)(a), X));
            err('unsquared_coefficients', (0, exports.gadd)((0, exports.gadd)((0, exports.gmul)(a, X), (0, exports.gmul)(b, Y)), (0, exports.gmul)((0, exports.gmul)(T, (0, exports.gmul)(a, b)), Z0)));
        }
        else if (i === 1) {
            const [p0, q, r, s, c, L, H, lc, hc, a, b] = v;
            if (!q.n || !(0, exports.gnorm)(r, s).n || c.n <= 0n || (0, exports.gcmp)(c, gq(1)) >= 0 || (0, exports.gcmp)(L, H) >= 0 || ![0n, 1n].includes(lc.n) || lc.d !== 1n || ![0n, 1n].includes(hc.n) || hc.d !== 1n || !a.n || !b.n)
                return null;
            const K = (0, exports.gnorm)(r, s), cc = (0, exports.gsq)(c), A = (0, exports.gsub)((0, exports.gsq)(r), (0, exports.gmul)(cc, K)), B = (0, exports.gmul)(T, (0, exports.gmul)((0, exports.gmul)(r, q), s)), C = (0, exports.gmul)((0, exports.gsq)(q), (0, exports.gsub)((0, exports.gsq)(s), (0, exports.gmul)(cc, K)));
            const all = quadratic(A, B, C).filter(x => (0, exports.gadd)((0, exports.gmul)(r, x), (0, exports.gmul)(s, q)).n > 0n), ts = all.map(x => (0, exports.gsub)(x, p0)).sort(exports.gcmp);
            const inside = (t) => ((0, exports.gcmp)(t, L) > 0 || !!lc.n && (0, exports.gcmp)(t, L) === 0) && ((0, exports.gcmp)(t, H) < 0 || !!hc.n && (0, exports.gcmp)(t, H) === 0);
            const admitted = ts.filter(inside), target = (t) => (0, exports.gnorm)((0, exports.gadd)((0, exports.gmul)(a, (0, exports.gadd)(t, p0)), (0, exports.gmul)(b, r)), (0, exports.gadd)((0, exports.gmul)(a, q), (0, exports.gmul)(b, s)));
            if (ts.length !== 2 || admitted.length !== 1)
                return null;
            const t = admitted[0], x = (0, exports.gadd)(t, p0), other = ts.find(t0 => (0, exports.gcmp)(t0, t));
            answer = target(t);
            if (answer.n <= 0n || !(0, exports.gcmp)(target(other), answer))
                return null;
            let noAngle = null;
            for (const delta of [gq(1, 20), gq(-1, 20), gq(1, 10), gq(-1, 10)]) {
                const nt = (0, exports.gadd)(t, delta);
                if (inside(nt) && (0, exports.gcmp)(target(nt), answer)) {
                    noAngle = nt;
                    break;
                }
            }
            if (!noAngle)
                return null;
            witnesses = [{ omitted: 'interval', otherParameter: (0, exports.gtxt)(other), differentAnswer: (0, exports.gtxt)(target(other)) }, { omitted: 'angle', otherParameter: (0, exports.gtxt)(noAngle), differentAnswer: (0, exports.gtxt)(target(noAngle)) }];
            certificate = { kind: 'complete_angle_quadratic_with_unsquared_filter', coefficients: [A, B, C].map(exports.gtxt), squaredRoots: quadratic(A, B, C).map(exports.gtxt), validRealParameters: ts.map(exports.gtxt), admittedParameters: admitted.map(exports.gtxt), originalDot: (0, exports.gtxt)((0, exports.gadd)((0, exports.gmul)(x, r), (0, exports.gmul)(q, s))), interval: [L, H, lc, hc].map(exports.gtxt) };
            groups = ['angle relation', 'real interval selector', 'combination coefficients'];
            steps = ['w=t+p; (r*w+s*q)^2=c^2*(r^2+s^2)*(w^2+q^2)', 'quadratic coefficients=(' + [A, B, C].map(exports.gtxt).join(',') + '); require r*w+s*q>0', 'all valid t=' + ts.map(exports.gtxt).join(',') + '; endpoint flags=' + (0, exports.gtxt)(lc) + ',' + (0, exports.gtxt)(hc), 'unique t=' + (0, exports.gtxt)(t) + '; u=(' + (0, exports.gtxt)(x) + ',' + (0, exports.gtxt)(q) + ')', 'a*u+b*v=(' + (0, exports.gtxt)((0, exports.gadd)((0, exports.gmul)(a, x), (0, exports.gmul)(b, r))) + ',' + (0, exports.gtxt)((0, exports.gadd)((0, exports.gmul)(a, q), (0, exports.gmul)(b, s))) + '); norm^2=' + (0, exports.gtxt)(answer)];
            err('ignore_interval_use_other_root', target(other));
            err('omit_combination_cross_term', (0, exports.gadd)((0, exports.gmul)((0, exports.gsq)(a), (0, exports.gnorm)(x, q)), (0, exports.gmul)((0, exports.gsq)(b), K)));
            err('omit_vertical_component', (0, exports.gsq)((0, exports.gadd)((0, exports.gmul)(a, x), (0, exports.gmul)(b, r))));
            err('subtract_second_vector', (0, exports.gnorm)((0, exports.gsub)((0, exports.gmul)(a, x), (0, exports.gmul)(b, r)), (0, exports.gsub)((0, exports.gmul)(a, q), (0, exports.gmul)(b, s))));
        }
        else if (i === 2) {
            const [Ar, Ai, Br, Bi, R, S, m, n, h, Cr, Ci, Dr, Di] = v;
            if (R.n <= 0n || S.n <= 0n || !(0, exports.gnorm)((0, exports.gsub)(Ar, Br), (0, exports.gsub)(Ai, Bi)).n || !m.n || !n.n)
                return null;
            const l = [(0, exports.gmul)(T, (0, exports.gsub)(Br, Ar)), (0, exports.gmul)(T, (0, exports.gsub)(Bi, Ai)), (0, exports.gneg)((0, exports.gadd)((0, exports.gsub)(R, S), (0, exports.gsub)((0, exports.gnorm)(Br, Bi), (0, exports.gnorm)(Ar, Ai))))];
            const z = intersect(l, [m, (0, exports.gneg)(n), (0, exports.gneg)(h)]), x = z.x, y = z.y;
            if ((0, exports.gcmp)((0, exports.gnorm)((0, exports.gsub)(x, Ar), (0, exports.gsub)(y, Ai)), R) || (0, exports.gcmp)((0, exports.gnorm)((0, exports.gsub)(x, Br), (0, exports.gsub)(y, Bi)), S))
                return null;
            const target = (r) => (0, exports.gdiv)((0, exports.gnorm)((0, exports.gsub)(r[0], Cr), (0, exports.gsub)(r[1], Ci)), (0, exports.gnorm)((0, exports.gsub)(r[0], Dr), (0, exports.gsub)(r[1], Di)));
            const roots = circleLine(Ar, Ai, R, l[0], l[1], (0, exports.gneg)(l[2]));
            if (roots.length !== 2)
                return null;
            const valid = roots.filter(r => !(0, exports.gcmp)((0, exports.gsub)((0, exports.gmul)(m, r[0]), (0, exports.gmul)(n, r[1])), h));
            if (valid.length !== 1)
                return null;
            answer = target([x, y]);
            if (answer.n <= 0n)
                return null;
            const omissions = [roots, circleLine(Br, Bi, S, m, (0, exports.gneg)(n), h), circleLine(Ar, Ai, R, m, (0, exports.gneg)(n), h)];
            for (let j = 0; j < 3; j++) {
                let witness = null;
                for (const z0 of omissions[j]) {
                    if (!z0.some((c, k) => (0, exports.gcmp)(c, [x, y][k])) || !(0, exports.gnorm)((0, exports.gsub)(z0[0], Dr), (0, exports.gsub)(z0[1], Di)).n)
                        continue;
                    const alt = target(z0);
                    if ((0, exports.gcmp)(alt, answer)) {
                        witness = { omitted: ['real_part', 'first_modulus', 'second_modulus'][j], complex: z0.map(exports.gtxt), differentAnswer: (0, exports.gtxt)(alt) };
                        break;
                    }
                }
                if (!witness)
                    return null;
                witnesses.push(witness);
            }
            const numerator = (0, exports.gnorm)((0, exports.gsub)(x, Cr), (0, exports.gsub)(y, Ci)), denominator = (0, exports.gnorm)((0, exports.gsub)(x, Dr), (0, exports.gsub)(y, Di));
            certificate = { kind: 'two_moduli_and_independent_real_selector', differenceLine: l.map(exports.gtxt), twoModulusSolutions: roots.map(r => r.map(exports.gtxt)), selectedComplex: [x, y].map(exports.gtxt), selector: [m, n, h].map(exports.gtxt), denominatorSquared: (0, exports.gtxt)(denominator) };
            groups = ['first modulus', 'second modulus', 'real part constraint', 'quotient target'];
            steps = ['z=x+y*i; subtract moduli => (' + (0, exports.gtxt)(l[0]) + ')x+(' + (0, exports.gtxt)(l[1]) + ')y+(' + (0, exports.gtxt)(l[2]) + ')=0', '(' + (0, exports.gtxt)(m) + ')x-(' + (0, exports.gtxt)(n) + ')y=' + (0, exports.gtxt)(h) + '; z=' + (0, exports.gtxt)(x) + '+(' + (0, exports.gtxt)(y) + ')i', 'both squared moduli=' + (0, exports.gtxt)(R) + ',' + (0, exports.gtxt)(S) + '; all two-modulus solutions=' + JSON.stringify(roots.map(r => r.map(exports.gtxt))), 'numerator modulus squared=' + (0, exports.gtxt)(numerator) + '; denominator modulus squared=' + (0, exports.gtxt)(denominator) + '>0', 'quotient modulus squared=' + (0, exports.gtxt)(numerator) + '/' + (0, exports.gtxt)(denominator) + '=' + (0, exports.gtxt)(answer)];
            err('omit_divisor_modulus', numerator);
            err('invert_modulus_ratio', (0, exports.gdiv)(denominator, numerator));
            err('square_denominator_twice', (0, exports.gdiv)(numerator, (0, exports.gsq)(denominator)));
            err('add_modulus_squares', (0, exports.gadd)(numerator, denominator));
        }
        else {
            const [a, b, c, sign, k] = v;
            if (!a.n || !b.n || !k.n || sign.d !== 1n || ![1n, -1n].includes(sign.n))
                return null;
            const roots = circleLine(Z, Z, gq(1), a, (0, exports.gneg)(b), c);
            if (roots.length !== 2 || roots[0][1].n * roots[1][1].n >= 0n)
                return null;
            const admitted = roots.filter(r => r[1].n * sign.n > 0n);
            if (admitted.length !== 1)
                return null;
            const [x, y] = admitted[0], target = (r) => (0, exports.gadd)((0, exports.gsub)((0, exports.gmul)((0, exports.gsq)(r[0]), r[0]), (0, exports.gmul)(gq(3), (0, exports.gmul)(r[0], (0, exports.gsq)(r[1])))), (0, exports.gmul)(k, r[0]));
            answer = target([x, y]);
            const other = roots.find(r => r[1].n * sign.n < 0n);
            if (!(0, exports.gcmp)(target(other), answer))
                return null;
            witnesses = [{ omitted: 'imaginary_sign', complex: other.map(exports.gtxt), differentAnswer: (0, exports.gtxt)(target(other)) }];
            // A second unit-circle point in the selected half-plane witnesses the effective real-part constraint.
            let alternate = null;
            for (const r of [[gq(3, 5), (0, exports.gmul)(sign, gq(4, 5))], [gq(-5, 13), (0, exports.gmul)(sign, gq(12, 13))]])
                if ((0, exports.gcmp)((0, exports.gsub)((0, exports.gmul)(a, r[0]), (0, exports.gmul)(b, r[1])), c) && (0, exports.gcmp)(target(r), answer)) {
                    alternate = r;
                    break;
                }
            if (!alternate)
                return null;
            witnesses.push({ omitted: 'real_part', complex: alternate.map(exports.gtxt), differentAnswer: (0, exports.gtxt)(target(alternate)) });
            certificate = { kind: 'complete_unit_circle_real_line_and_sign', allComplexSolutions: roots.map(r => r.map(exports.gtxt)), selectedComplex: [x, y].map(exports.gtxt), conjugate: [x, (0, exports.gneg)(y)].map(exports.gtxt), modulusSquared: '1', originalRealPart: (0, exports.gtxt)((0, exports.gsub)((0, exports.gmul)(a, x), (0, exports.gmul)(b, y))) };
            groups = ['unit modulus', 'real part relation', 'imaginary sign', 'cubic reciprocal target'];
            steps = ['x^2+y^2=1; (' + (0, exports.gtxt)(a) + ')x-(' + (0, exports.gtxt)(b) + ')y=' + (0, exports.gtxt)(c), 'all solutions=' + JSON.stringify(roots.map(r => r.map(exports.gtxt))), 'sign=' + (0, exports.gtxt)(sign) + ' selects z=' + (0, exports.gtxt)(x) + '+(' + (0, exports.gtxt)(y) + ')i', '1/z=conj(z)=' + (0, exports.gtxt)(x) + '+(' + (0, exports.gtxt)((0, exports.gneg)(y)) + ')i', 'Re(z^3)=(' + (0, exports.gtxt)(x) + ')^3-3*(' + (0, exports.gtxt)(x) + ')*(' + (0, exports.gtxt)(y) + ')^2', 'Re(z^3+k/z)=' + (0, exports.gtxt)(answer)];
            err('omit_reciprocal_term', (0, exports.gsub)((0, exports.gmul)((0, exports.gsq)(x), x), (0, exports.gmul)(gq(3), (0, exports.gmul)(x, (0, exports.gsq)(y)))));
            err('omit_cubic_cross_term', (0, exports.gadd)((0, exports.gmul)((0, exports.gsq)(x), x), (0, exports.gmul)(k, x)));
            err('use_positive_i_squared', (0, exports.gadd)((0, exports.gadd)((0, exports.gmul)((0, exports.gsq)(x), x), (0, exports.gmul)(gq(3), (0, exports.gmul)(x, (0, exports.gsq)(y)))), (0, exports.gmul)(k, x)));
            err('ignore_imaginary_sign', target(other));
        }
        if (!bounded(answer))
            return null;
        const key = (0, exports.gtxt)(answer), distinct = errors.filter((e, j, a) => e.text !== key && a.findIndex(t => t.text === e.text) === j).slice(0, 3);
        if (distinct.length !== 3)
            return null;
        const proof = 'givens=' + p.data.join(',') + '; ' + steps.join('; '), hardEvidence = { version: 'vector-complex-constraint-hard-evidence-v1', evidenceSlots: p.data.length, independentEvidenceGroups: groups.length, reasoningSteps: steps.length, quantitativeRelations: 2, groups, effectiveConstraints: witnesses, completeVectorComplexCertificate: certificate, criticalPoints: [], answer: key, visibleProof: proof, studentCalibrated: false };
        return { answer: key, text: key, errors: distinct.map(e => ({ ...e, key: e.text })), proof, steps, hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathVectorComplexConstraint(candidate, context = {}) {
    const scope = vectorComplexConstraintScopeFrom(context.questionPlan), parameters = vectorComplexConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? vectorComplexConstraintDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('vector_complex_constraint_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 73 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('vector_complex_constraint_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? vectorComplexConstraintOptionKey(o.text, scope) : null);
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('vector_complex_constraint_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(vectorComplexConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('vector_complex_constraint_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, scope ? vectorComplexConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('vector_complex_constraint_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('vector_complex_constraint_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('vector_complex_constraint_error_intent');
    const scopeId = parameters ? exports.VECTOR_COMPLEX_CONSTRAINT_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.VECTOR_COMPLEX_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.VECTOR_COMPLEX_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.VECTOR_COMPLEX_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['vector_complex_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
