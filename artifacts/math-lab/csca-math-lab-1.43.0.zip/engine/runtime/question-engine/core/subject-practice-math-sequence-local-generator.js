"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathSequenceLocalGenerator = createSubjectPracticeMathSequenceLocalGenerator;
const subject_practice_math_sequence_solver_1 = require("./subject-practice-math-sequence-solver");
const subject_practice_math_sequence_independent_oracle_1 = require("./subject-practice-math-sequence-independent-oracle");
const subject_practice_math_sequence_explanation_verifier_1 = require("./subject-practice-math-sequence-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_LOCAL_GENERATOR_VERSION = 'math-sequence-local-generator-v1-bounded-four-scope';
const SCOPES = new Set(['arithmetic_explicit_term', 'geometric_explicit_term', 'arithmetic_partial_sum', 'geometric_partial_sum']);
function object(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').trim(); }
function normalizedSeed(value) { const n = Number(value); return Number.isFinite(n) ? Math.abs(Math.trunc(n)) : 0; }
function scopeFrom(planValue, validate) { const plan = object(planValue); const render = object(plan?.renderConstraints); const scope = clean(render?.exactSequenceScope); return validate(planValue).valid && clean(plan?.taskFamily) === 'math_basic_sequence_direct_calculation' && clean(plan?.planTemplate) === 'math_basic_sequence_direct_calculation_v1' && SCOPES.has(scope) ? scope : null; }
function distinctAlternatives(correct, primary) { const out = []; const seen = new Set(); for (const item of primary) {
    if (!Number.isSafeInteger(item.value) || seen.has(item.value))
        continue;
    seen.add(item.value);
    out.push(item);
    if (out.length === 4)
        return out;
} for (let offset = 1; out.length < 4; offset += 1) {
    for (const sign of [1, -1]) {
        const value = correct + sign * offset;
        if (seen.has(value))
            continue;
        seen.add(value);
        out.push({ value, distractorIntent: `fallback_computation_offset_${sign > 0 ? 'plus' : 'minus'}_${offset}`, misconceptionTags: ['sequence_arithmetic_computation_error'] });
        if (out.length === 4)
            break;
    }
} return out; }
function candidateFor(blueprint, seed, scope) {
    const arithmeticA1 = [-4, -2, 1, 3, 5, 7][seed % 6];
    const d = [-5, -3, -2, 2, 3, 4][(seed * 3 + 1) % 6];
    const geometricA1 = [-3, -2, 1, 2, 3, 4][seed % 6];
    const q = [-3, -2, 2, 3][(seed * 5 + 2) % 4];
    const n = scope.startsWith('geometric_') ? 3 + (seed % 4) : 4 + (seed % 5);
    const a1 = scope.startsWith('arithmetic_') ? arithmeticA1 : geometricA1;
    const parameters = { a1, d: scope.startsWith('arithmetic_') ? d : null, q: scope.startsWith('geometric_') ? q : null, n };
    const result = (0, subject_practice_math_sequence_solver_1.evaluateMathSequence)(scope, parameters);
    const primary = [{ value: result, distractorIntent: null, misconceptionTags: [] }];
    if (scope === 'arithmetic_explicit_term')
        primary.push({ value: a1 + n * d, distractorIntent: 'used_n_instead_of_n_minus_one', misconceptionTags: ['sequence_index_off_by_one'] }, { value: a1 + (n - 2) * d, distractorIntent: 'used_n_minus_two_instead_of_n_minus_one', misconceptionTags: ['sequence_index_off_by_one'] }, { value: a1 + (n - 1) + d, distractorIntent: 'added_index_and_difference_separately', misconceptionTags: ['arithmetic_sequence_formula_error'] });
    if (scope === 'geometric_explicit_term')
        primary.push({ value: a1 * (q ** n), distractorIntent: 'used_exponent_n_instead_of_n_minus_one', misconceptionTags: ['sequence_index_off_by_one'] }, { value: a1 * (q ** (n - 2)), distractorIntent: 'used_exponent_n_minus_two', misconceptionTags: ['sequence_index_off_by_one'] }, { value: a1 + (n - 1) * q, distractorIntent: 'treated_geometric_sequence_as_arithmetic', misconceptionTags: ['wrong_sequence_model'] });
    if (scope === 'arithmetic_partial_sum')
        primary.push({ value: n * (2 * a1 + (n - 1) * d), distractorIntent: 'omitted_division_by_two', misconceptionTags: ['arithmetic_sum_formula_error'] }, { value: n * (2 * a1 + n * d) / 2, distractorIntent: 'used_n_instead_of_n_minus_one_in_last_term', misconceptionTags: ['sequence_index_off_by_one'] }, { value: a1 + (n - 1) * d, distractorIntent: 'returned_last_term_instead_of_partial_sum', misconceptionTags: ['term_sum_confusion'] });
    if (scope === 'geometric_partial_sum')
        primary.push({ value: a1 * ((q ** (n + 1)) - 1) / (q - 1), distractorIntent: 'used_exponent_n_plus_one', misconceptionTags: ['sequence_index_off_by_one'] }, { value: a1 * (q ** (n - 1)), distractorIntent: 'returned_last_term_instead_of_partial_sum', misconceptionTags: ['term_sum_confusion'] }, { value: n * (2 * a1 + (n - 1) * q) / 2, distractorIntent: 'applied_arithmetic_sum_formula_to_geometric_sequence', misconceptionTags: ['wrong_sequence_model'] });
    const alternatives = distinctAlternatives(result, primary);
    const correctIndex = seed % 4;
    const ordered = alternatives.slice(1);
    ordered.splice(correctIndex, 0, alternatives[0]);
    const ids = ['A', 'B', 'C', 'D'];
    const options = ordered.map((item, index) => ({ id: ids[index], text: String(item.value) }));
    const arithmetic = scope.startsWith('arithmetic_');
    const sum = scope.endsWith('partial_sum');
    const parameterText = arithmetic ? `首项 a_1=${a1}，公差 d=${d}` : `首项 a_1=${a1}，公比 q=${q}`;
    const target = sum ? `前 ${n} 项和 S_${n}` : `第 ${n} 项 a_${n}`;
    const prompt = `已知${arithmetic ? '等差' : '等比'}数列${parameterText}，求${target}。`;
    const promptEn = `For a${arithmetic ? 'n arithmetic' : ' geometric'} sequence with a_1=${a1} and ${arithmetic ? `d=${d}` : `q=${q}`}, find ${sum ? `the sum S_${n} of the first n=${n} terms` : `the term a_${n} where n=${n}`}.`;
    let explanation;
    let explanationEn;
    if (scope === 'arithmetic_explicit_term') {
        explanation = `由 a_n=a_1+(n-1)d，代入 a_1=${a1}、n=${n}、d=${d}，得 a_${n}=${a1}+(${n}-1)×(${d})=${result}。`;
        explanationEn = `Using a_n=a_1+(n-1)d with a_1=${a1}, n=${n}, and d=${d}, a_${n}=${a1}+(${n}-1)×(${d})=${result}.`;
    }
    else if (scope === 'geometric_explicit_term') {
        explanation = `由 a_n=a_1q^(n-1)，代入 a_1=${a1}、n=${n}、q=${q}，得 a_${n}=${a1}×(${q})^(${n}-1)=${result}。`;
        explanationEn = `Using a_n=a_1q^(n-1) with a_1=${a1}, n=${n}, and q=${q}, a_${n}=${a1}×(${q})^(${n}-1)=${result}.`;
    }
    else if (scope === 'arithmetic_partial_sum') {
        explanation = `由 S_n=n/2[2a_1+(n-1)d]，代入 a_1=${a1}、n=${n}、d=${d}，得 S_${n}=${n}/2×[2×(${a1})+(${n}-1)×(${d})]=${result}。`;
        explanationEn = `Using S_n=n/2[2a_1+(n-1)d] with a_1=${a1}, n=${n}, and d=${d}, S_${n}=${n}/2×[2×(${a1})+(${n}-1)×(${d})]=${result}.`;
    }
    else {
        explanation = `由 S_n=a_1(q^n-1)/(q-1)，代入 a_1=${a1}、n=${n}、q=${q}，得 S_${n}=${a1}×[(${q})^${n}-1]/(${q}-1)=${result}。`;
        explanationEn = `Using S_n=a_1(q^n-1)/(q-1) with a_1=${a1}, n=${n}, and q=${q}, S_${n}=${a1}×[(${q})^${n}-1]/(${q}-1)=${result}.`;
    }
    return { subject: 'math', topicId: blueprint.topicId, blueprintId: blueprint.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options, correctAnswer: ids[correctIndex], explanation, knowledgeTags: ['数列', arithmetic ? '等差数列' : '等比数列', sum ? '前n项和' : '通项', scope], optionMetadata: ordered.flatMap((item, index) => index === correctIndex ? [] : [{ optionId: ids[index], distractorIntent: item.distractorIntent ?? 'unclassified_sequence_error', misconceptionTags: item.misconceptionTags }]), localizations: { zh: { prompt, options, explanation, knowledgeTags: ['数列', arithmetic ? '等差数列' : '等比数列'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Sequences', arithmetic ? 'Arithmetic sequence' : 'Geometric sequence'] } }, syllabusVersion: blueprint.syllabusVersion };
}
function createSubjectPracticeMathSequenceLocalGenerator(ports) { return function generate(input) { const seed = normalizedSeed(input.seed); const exactScope = scopeFrom(input.questionPlan, ports.validate); const supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'basic' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice'; if (!exactScope || !supported)
    return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_sequence_local_generator_question_plan_not_supported'] }; const candidate = candidateFor(input.blueprint, seed, exactScope); const context = { questionPlan: input.questionPlan }; const solverEvidence = (0, subject_practice_math_sequence_solver_1.solveSubjectPracticeMathSequence)(candidate, context); const oracleEvidence = (0, subject_practice_math_sequence_independent_oracle_1.verifySubjectPracticeMathSequenceWithIndependentOracle)(candidate, context); const explanationEvidence = (0, subject_practice_math_sequence_explanation_verifier_1.verifySubjectPracticeMathSequenceExplanation)(candidate, context); const adherence = ports.adherenceFor(input.questionPlan, candidate); const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId; return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_sequence_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] }; }; }
