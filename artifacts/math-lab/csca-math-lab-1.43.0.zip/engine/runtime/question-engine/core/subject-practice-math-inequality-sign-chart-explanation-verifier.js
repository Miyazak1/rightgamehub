"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathInequalitySignChartExplanation = verifySubjectPracticeMathInequalitySignChartExplanation;
const subject_practice_math_inequality_sign_chart_solver_1 = require("./subject-practice-math-inequality-sign-chart-solver");
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_EXPLANATION_VERIFIER_VERSION = 'math-inequality-sign-chart-explanation-v1-bound-bilingual';
function verifySubjectPracticeMathInequalitySignChartExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_inequality_sign_chart_solver_1.solveSubjectPracticeMathInequalitySignChart)(candidate, context), p = solver.parameters;
    let proof = '';
    if (p) {
        const boundaryIncluded = (x) => p.relation.includes('=') && p.pole !== x;
        const factors = p.kind === 'quadratic'
            ? 'a=' + p.a + '; b=' + p.b + '; c=' + p.c + '; Delta=(' + p.b + ')^2-4*(' + p.a + ')*(' + p.c + ')=' + (p.b * p.b - 4 * p.a * p.c)
                + '; roots={' + p.lower + ', ' + p.upper + '}; f(x)=' + p.a + '*(x-(' + p.lower + '))*(x-(' + p.upper + ')); domain=R'
            : 'numerator=' + p.a + '*(x-(' + p.zeros[0] + ')); zero=' + p.zeros[0] + '; denominator=x-(' + p.pole + '); pole=' + p.pole + '; domain: x!=' + p.pole;
        proof = (0, subject_practice_math_inequality_sign_chart_solver_1.signChartExpression)(p) + '; ' + factors
            + '; signs: (-inf, ' + p.lower + '):' + (p.a > 0 ? '+' : '-') + ', (' + p.lower + ', ' + p.upper + '):' + (p.a > 0 ? '-' : '+') + ', (' + p.upper + ', +inf):' + (p.a > 0 ? '+' : '-')
            + '; endpoints: ' + p.lower + ':' + (boundaryIncluded(p.lower) ? 'included' : 'excluded') + ', ' + p.upper + ':' + (boundaryIncluded(p.upper) ? 'included' : 'excluded')
            + '; solution=' + solver.expectedAnswer;
    }
    const zh = '先求临界点，再由各因子符号判定区间，最后按不等号及定义域处理端点：' + proof + '。对应选项 ' + solver.selectedOptionId + '。';
    const en = 'Find the critical points, determine each interval sign, then apply the relation and domain at endpoints: ' + proof + '. Option ' + solver.selectedOptionId + '.';
    const zhBound = Boolean(p) && candidate.explanation === zh && candidate.localizations?.zh?.explanation === zh;
    const enBound = Boolean(p) && candidate.localizations?.en?.explanation === en;
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('inequality_sign_chart_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('inequality_sign_chart_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('inequality_sign_chart_explanation_en_mismatch');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified',
        scopeId: solver.scopeId, zhBound, enBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
