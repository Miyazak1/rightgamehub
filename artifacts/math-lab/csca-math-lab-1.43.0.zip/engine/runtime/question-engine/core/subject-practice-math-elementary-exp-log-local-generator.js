"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ELEMENTARY_EXP_LOG_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathElementaryExpLogLocalGenerator = createSubjectPracticeMathElementaryExpLogLocalGenerator;
const subject_practice_math_elementary_exp_log_solver_1 = require("./subject-practice-math-elementary-exp-log-solver");
const subject_practice_math_elementary_exp_log_independent_oracle_1 = require("./subject-practice-math-elementary-exp-log-independent-oracle");
const subject_practice_math_elementary_exp_log_explanation_verifier_1 = require("./subject-practice-math-elementary-exp-log-explanation-verifier");
exports.ELEMENTARY_EXP_LOG_GENERATOR_VERSION = 'math-elementary-exp-log-generator-v1-bounded';
function parameters(scope, n) {
    const sign = Math.floor(n / 2) % 2 ? -1 : 1, range = scope === subject_practice_math_elementary_exp_log_solver_1.ELEMENTARY_EXP_LOG_SCOPES[2], inequality = scope === subject_practice_math_elementary_exp_log_solver_1.ELEMENTARY_EXP_LOG_SCOPES[3];
    const intervals = [[-3, -1], [1, 3], [-2, 2], [-1, 0]], [l, u] = intervals[Math.floor(n / 4) % 4];
    return { scope, q: 2 + Math.floor(n / 4) % 4, reciprocal: n % 2 === 1,
        a: sign * ((range || inequality ? 1 : 2) + Math.floor(n / 16) % (range ? 3 : inequality ? 4 : 3)),
        c: range ? Math.floor(n / 32) % 7 - 3 : (1 + Math.floor(n / 32) % 4) * (Math.floor(n / 8) % 2 ? -1 : 1),
        k: scope === subject_practice_math_elementary_exp_log_solver_1.ELEMENTARY_EXP_LOG_SCOPES[0] ? 2 + Math.floor(n / 32) % 2 : 0,
        r: range ? 0 : scope === subject_practice_math_elementary_exp_log_solver_1.ELEMENTARY_EXP_LOG_SCOPES[0] ? [-3, -2, -1, 1, 2, 3][Math.floor(n / 8) % 6] : Math.floor(n / 8) % 7 - 3,
        d: range ? (1 + Math.floor(n / 16) % 4) * (Math.floor(n / 8) % 2 ? -1 : 1) : 0,
        l: range ? l : 0, u: range ? u : 0, op: inequality ? ['<', '<=', '>', '>='][Math.floor(n / 8) % 4] : '<' };
}
function createSubjectPracticeMathElementaryExpLogLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0;
        const exactScope = (0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.ELEMENTARY_EXP_LOG_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call',
            estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null,
            explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['elementary_exp_log_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 69 || b.topicCode !== 'M-FUNC-002'
            || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        let selected = null;
        // Finite rejection search changes only bounded parameters, never source material or model input.
        for (let attempt = 0; attempt < 128; attempt++) {
            const p = parameters(exactScope, seed % 107520 + attempt * 32);
            if (!(0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogParametersFrom)((0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogPrompt)(p, 'zh'), exactScope, 'zh'))
                continue;
            if (new Set([(0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogAnswer)(p), ...(0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogDistractors)(p).map(o => o.key)]).size !== 4)
                continue;
            selected = p;
            break;
        }
        if (!selected)
            return { ...unsupported, status: 'bounded_generation_exhausted' };
        const p = selected, answer = (0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogAnswer)(p), choices = (0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogDistractors)(p), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
        const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: x.key })), alternate = Math.floor(seed / 16) % 2 === 1;
        const prompt = (0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogPrompt)(p, 'zh', alternate), enPrompt = (0, subject_practice_math_elementary_exp_log_solver_1.elementaryExpLogPrompt)(p, 'en', alternate), explanation = (0, subject_practice_math_elementary_exp_log_explanation_verifier_1.renderElementaryExpLogExplanation)(p, answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 69, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice',
            prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['基本初等函数', exactScope],
            optionMetadata: choices.flatMap((o, i) => o.intent ? [{ optionId: 'ABCD'[i], distractorIntent: o.intent, misconceptionTags: [o.intent] }] : []),
            localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['基本初等函数', exactScope] },
                en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Elementary functions', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_elementary_exp_log_solver_1.solveSubjectPracticeMathElementaryExpLog)(candidate, context);
        const oracleEvidence = (0, subject_practice_math_elementary_exp_log_independent_oracle_1.verifySubjectPracticeMathElementaryExpLogWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_elementary_exp_log_explanation_verifier_1.verifySubjectPracticeMathElementaryExpLogExplanation)(candidate, context);
        const adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres
            && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null,
            solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
            reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
