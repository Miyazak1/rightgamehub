"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ELEMENTARY_EXP_LOG_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathElementaryExpLogWithIndependentOracle = verifySubjectPracticeMathElementaryExpLogWithIndependentOracle;
// Separate parser, arithmetic and proof path. No generator/Solver/answer imports.
exports.ELEMENTARY_EXP_LOG_ORACLE_VERSION = 'math-elementary-exp-log-oracle-v1-complete-certificates';
const scopes = ['exponential_common_base_linear_equation', 'logarithmic_affine_argument_equation', 'exponential_affine_closed_interval_range', 'logarithmic_affine_inequality'];
const object = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function fraction(n, d = 1) {
    let a = BigInt(n), b = BigInt(d);
    if (!b)
        throw new Error('oracle_zero_denominator');
    if (b < 0n) {
        a = -a;
        b = -b;
    }
    let x = a < 0n ? -a : a, y = b;
    while (y) {
        const t = x % y;
        x = y;
        y = t;
    }
    return [a / x, b / x];
}
const plus = (a, b) => fraction(a[0] * b[1] + b[0] * a[1], a[1] * b[1]);
const minus = (a, b) => fraction(a[0] * b[1] - b[0] * a[1], a[1] * b[1]);
const times = (a, b) => fraction(a[0] * b[0], a[1] * b[1]);
const divide = (a, b) => fraction(a[0] * b[1], a[1] * b[0]);
const compare = (a, b) => { const d = a[0] * b[1] - b[0] * a[1]; return d < 0n ? -1 : d > 0n ? 1 : 0; };
const show = (a) => String(a[0]) + (a[1] === 1n ? '' : '/' + a[1]);
function power(m, exponent) {
    // Repeated multiplication, independently of the Solver's exponentiation implementation.
    let result = fraction(1);
    const invert = (exponent < 0) !== m.inverse;
    for (let i = 0; i < Math.abs(exponent); i++)
        result = times(result, invert ? fraction(1, m.base) : fraction(m.base));
    return result;
}
function rational(s) {
    const pieces = s.trim().split('/');
    if (pieces.length > 2 || !/^[+-]?\d{1,10}$/.test(pieces[0]) || pieces[1] !== undefined && !/^\d{1,10}$/.test(pieces[1]))
        return null;
    const denominator = BigInt(pieces[1] ?? '1');
    if (!denominator)
        return null;
    const q = fraction(BigInt(pieces[0]), denominator);
    return q[0] < -1000000000n || q[0] > 1000000000n || q[1] > 1000000000n ? null : q;
}
function edgeCompare(a, b) {
    if (a === b)
        return 0;
    if (a === '-inf' || b === '+inf')
        return -1;
    if (a === '+inf' || b === '-inf')
        return 1;
    return compare(a, b);
}
function interval(s) {
    const t = s.trim(), ends = t.slice(1, -1).split(',');
    if (!['(', '['].includes(t[0]) || ![')', ']'].includes(t[t.length - 1]) || ends.length !== 2)
        return null;
    const edge = (v) => v.trim() === '-inf' ? '-inf' : v.trim() === '+inf' ? '+inf' : rational(v);
    const left = edge(ends[0]), right = edge(ends[1]), closedLeft = t[0] === '[', closedRight = t[t.length - 1] === ']';
    if (!left || !right || edgeCompare(left, right) >= 0 || typeof left === 'string' && closedLeft || typeof right === 'string' && closedRight)
        return null;
    return { left, right, closedLeft, closedRight };
}
const intervalKey = (i) => (i.closedLeft ? '[' : '(') + (typeof i.left === 'string' ? i.left : show(i.left)) + ',' + (typeof i.right === 'string' ? i.right : show(i.right)) + (i.closedRight ? ']' : ')');
function contains(i, x) { const l = edgeCompare(x, i.left), r = edgeCompare(x, i.right); return (l > 0 || l === 0 && i.closedLeft) && (r < 0 || r === 0 && i.closedRight); }
function read(text, scope, lang) {
    if (typeof text !== 'string' || text.length > 1000)
        return null;
    const zh = lang === 'zh', head = zh ? /^(已知 |考虑 )/ : /^(Given |Consider )/;
    if (!head.test(text))
        return null;
    const suffixes = zh ? ['。先化为同底幂，再求实数 x。', '。先确定真数为正的条件，再用指数关系求实数 x 并检验。',
        '。结合复合单调方向和端点值，求闭区间上的值域。', '。先确定真数为正的条件，再按底数与系数的符号求实数解集。']
        : ['. Convert to a common base, then solve for real x.', '. Require a positive argument, then use the exponential relation to solve for real x and check it.',
            '. Use composite monotonicity and endpoint values to find the range on this closed interval.', '. Require a positive argument, then use the base and coefficient signs to find the real solution set.'];
    const suffix = suffixes[scopes.indexOf(scope)];
    if (!suffix || !text.endsWith(suffix))
        return null;
    const body = text.replace(head, '').slice(0, -suffix.length), range = scope === scopes[2], equation = scope === scopes[0];
    const lead = body.match(range ? /^f\(x\)=\((1\/)?([2-5])\)\^\(/ : equation ? /^\((1\/)?([2-5])\)\^\(/ : /^log_\((1\/)?([2-5])\)\(/);
    if (!lead)
        return null;
    const base = Number(lead[2]), inverse = Boolean(lead[1]), rest = body.slice(lead[0].length), aff = rest.match(/^(-?\d+)\*x\+\((-?\d+)\)\)/);
    if (!aff)
        return null;
    const coefficient = Number(aff[1]), intercept = Number(aff[2]), tail = rest.slice(aff[0].length);
    const m = { base, inverse, coefficient, intercept, power: 0, value: 0, offset: 0, left: 0, right: 0, operator: '=' };
    if (!Number.isSafeInteger(coefficient) || !Number.isSafeInteger(intercept) || !coefficient)
        return null;
    if (equation) {
        const rhs = tail.match(/^=\(\((1\/)?([2-5])\)\^([23])\)\^\((-?[123])\)$/);
        if (!rhs || Boolean(rhs[1]) !== inverse || Number(rhs[2]) !== base)
            return null;
        m.power = Number(rhs[3]);
        m.value = Number(rhs[4]);
        if (Math.abs(m.power * m.value) > 8)
            return null;
    }
    else if (range) {
        const limits = tail.match(/^\+\((-?\d+)\), x in \[(-?\d+), (-?\d+)\]$/);
        if (!limits)
            return null;
        m.offset = Number(limits[1]);
        m.left = Number(limits[2]);
        m.right = Number(limits[3]);
        if (![m.offset, m.left, m.right].every(Number.isSafeInteger) || Math.abs(m.offset) > 4 || Math.abs(m.left) > 3 || Math.abs(m.right) > 3 || m.left >= m.right
            || Math.abs(coefficient) > 3 || Math.abs(intercept) > 3 || Math.abs(coefficient * m.left + intercept) > 8 || Math.abs(coefficient * m.right + intercept) > 8)
            return null;
    }
    else {
        const relation = tail.match(/^(=|<=|>=|<|>)(-?\d+)$/);
        if (!relation)
            return null;
        m.operator = relation[1];
        m.value = Number(relation[2]);
        if (!Number.isSafeInteger(m.value) || Math.abs(m.value) > 3 || (scope === scopes[1]) !== (m.operator === '='))
            return null;
    }
    if (equation || scope === scopes[1]) {
        if (Math.abs(coefficient) < 2 || Math.abs(coefficient) > 4 || !intercept || Math.abs(intercept) > 4)
            return null;
    }
    else if (!range && (Math.abs(coefficient) > 4 || Math.abs(intercept) > 4))
        return null;
    return m;
}
function partition(boundaries) {
    const sorted = [...new Map(boundaries.map(x => [show(x), x])).values()].sort(compare), points = [...sorted];
    if (!sorted.length)
        return [fraction(0)];
    points.push(minus(sorted[0], fraction(1)), plus(sorted[sorted.length - 1], fraction(1)));
    for (let i = 1; i < sorted.length; i++)
        points.push(divide(plus(sorted[i - 1], sorted[i]), fraction(2)));
    return points;
}
function verifySubjectPracticeMathElementaryExpLogWithIndependentOracle(candidate, context = {}) {
    const plan = object(context.questionPlan), r = object(plan?.renderConstraints), s = object(plan?.scenarioContract), scope = String(r?.exactElementaryExpLogScope ?? '');
    const required = { topicCode: 'M-FUNC-002', boundedIntegerParameters: true, exactRationalArithmetic: true, baseIntegerOrReciprocal: true,
        maximumBaseInteger: 5, maximumEndpointExponent: 8, externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
    const bound = plan?.schemaVersion === 'subject-practice-question-plan-v1' && plan?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && plan?.subject === 'math' && plan?.topicId === 69 && plan?.targetDifficulty === 'medium' && plan?.representationType === 'text'
        && plan?.taskFamily === 'math_elementary_exp_log_relation_reasoning' && plan?.planTemplate === 'math_elementary_exp_log_relation_reasoning_v1'
        && r?.questionType === 'single_choice' && scopes.includes(scope) && Object.entries(required).every(([k, v]) => r?.[k] === v)
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'elementary_exp_log_object' && s?.scenarioAction === scope;
    const model = bound ? read(candidate.prompt, scope, 'zh') : null, reasonCodes = [];
    if (!model)
        reasonCodes.push('elementary_exp_log_oracle_scope_unparsed');
    if (candidate.subject !== 'math' || candidate.topicId !== 69 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('elementary_exp_log_oracle_identity_mismatch');
    const scalar = scopes.indexOf(scope) < 2, options = candidate.options ?? [], sets = options.map(o => interval(o.text));
    const key = (v) => { const x = scalar ? rational(v) : interval(v); return x ? scalar ? show(x) : intervalKey(x) : null; };
    const keys = options.map(o => key(o.text));
    if (options.length !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || new Set(options.map(o => o.id)).size !== 4 || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('elementary_exp_log_oracle_invalid_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!model || JSON.stringify(read(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(model))
            reasonCodes.push('elementary_exp_log_oracle_' + lang + '_parameters');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, key(o.text)])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('elementary_exp_log_oracle_' + lang + '_options');
    }
    let truths = options.map(() => false), certificate = '', boundaryEvidence = [];
    if (model) {
        const m = model, affine = (x) => plus(times(fraction(m.coefficient), x), fraction(m.intercept));
        if (scalar) {
            truths = options.map(o => {
                const x = rational(o.text);
                if (!x)
                    return false;
                return scope === scopes[0] ? compare(affine(x), fraction(m.power * m.value)) === 0
                    : compare(affine(x), fraction(0)) > 0 && compare(affine(x), power(m, m.value)) === 0;
            });
            certificate = scope === scopes[0] ? 'positive_nonunit_base_injective_and_nonzero_affine_coefficient_unique_root_nested_power_product'
                : 'positive_argument_exact_power_substitution_and_nonzero_affine_coefficient_unique_root';
        }
        else {
            let boundaries, predicate;
            if (scope === scopes[2]) {
                const ascending = (m.coefficient > 0) !== m.inverse;
                const at = (x) => plus(power(m, m.coefficient * x + m.intercept), fraction(m.offset));
                const low = at(ascending ? m.left : m.right), high = at(ascending ? m.right : m.left);
                boundaries = [low, high];
                predicate = y => compare(y, low) >= 0 && compare(y, high) <= 0;
                certificate = 'strict_monotonicity_and_continuity_on_entire_closed_interval_unique_preimage_iff_between_attained_endpoints';
            }
            else {
                const threshold = power(m, m.value), zero = divide(fraction(-m.intercept), fraction(m.coefficient));
                boundaries = [zero, divide(minus(threshold, fraction(m.intercept)), fraction(m.coefficient))];
                predicate = x => {
                    const arg = affine(x);
                    if (compare(arg, fraction(0)) <= 0)
                        return false;
                    const order = compare(arg, threshold) * (m.inverse ? -1 : 1);
                    return m.operator === '<' ? order < 0 : m.operator === '<=' ? order <= 0 : m.operator === '>' ? order > 0 : order >= 0;
                };
                certificate = 'complete_partition_at_argument_zero_power_threshold_and_all_option_endpoints_linear_sign_constant_in_each_open_cell';
            }
            for (const i of sets)
                if (i)
                    for (const e of [i.left, i.right])
                        if (typeof e !== 'string')
                            boundaries.push(e);
            const probes = partition(boundaries);
            boundaryEvidence = [...new Set(boundaries.map(show))];
            truths = sets.map(i => Boolean(i) && probes.every(x => contains(i, x) === predicate(x)));
        }
    }
    const trueOptionIds = options.filter((_, i) => truths[i]).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('elementary_exp_log_oracle_answer_disagreement');
    return { oracleVersion: exports.ELEMENTARY_EXP_LOG_ORACLE_VERSION, status: reasonCodes.length ? (model ? 'disagreed' : 'unparsed') : 'verified',
        scopeMatched: Boolean(model), scopeId: model ? 'math-medium-elementary-exp-log-v1:' + scope : null, exactScope: scope,
        selectedOptionId, trueOptionIds, uniqueAnswer: trueOptionIds.length === 1, certificate, boundaryEvidence, completeCertificate: Boolean(model),
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
