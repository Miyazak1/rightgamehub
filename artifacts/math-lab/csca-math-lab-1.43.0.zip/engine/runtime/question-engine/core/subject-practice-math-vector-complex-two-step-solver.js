"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.algComplex = exports.algText = exports.algAbs = exports.VECTOR_COMPLEX_TWO_STEP_CONSTRAINTS = exports.VECTOR_COMPLEX_TWO_STEP_SCOPES = exports.VECTOR_COMPLEX_TWO_STEP_SCOPE_VERSION = exports.VECTOR_COMPLEX_TWO_STEP_SOLVER_VERSION = exports.VECTOR_COMPLEX_TWO_STEP_TEMPLATE = exports.VECTOR_COMPLEX_TWO_STEP_FAMILY = void 0;
exports.vectorComplexTwoStepScopeFrom = vectorComplexTwoStepScopeFrom;
exports.algQ = algQ;
exports.vectorComplexTwoStepPrompt = vectorComplexTwoStepPrompt;
exports.vectorComplexTwoStepDerive = vectorComplexTwoStepDerive;
exports.vectorComplexTwoStepParametersFrom = vectorComplexTwoStepParametersFrom;
exports.vectorComplexTwoStepOptionKey = vectorComplexTwoStepOptionKey;
exports.vectorComplexTwoStepDistractors = vectorComplexTwoStepDistractors;
exports.solveSubjectPracticeMathVectorComplexTwoStep = solveSubjectPracticeMathVectorComplexTwoStep;
exports.VECTOR_COMPLEX_TWO_STEP_FAMILY = 'math_vector_complex_two_step_calculation';
exports.VECTOR_COMPLEX_TWO_STEP_TEMPLATE = exports.VECTOR_COMPLEX_TWO_STEP_FAMILY + '_v1';
exports.VECTOR_COMPLEX_TWO_STEP_SOLVER_VERSION = 'math-vector-complex-two-step-solver-v1-exact-rational';
exports.VECTOR_COMPLEX_TWO_STEP_SCOPE_VERSION = 'math-medium-vector-complex-two-step-v1';
exports.VECTOR_COMPLEX_TWO_STEP_SCOPES = ['vector_linear_combination_norm_squared', 'vector_perpendicular_parameter',
    'complex_multiply_then_add', 'complex_affine_equation'];
exports.VECTOR_COMPLEX_TWO_STEP_CONSTRAINTS = { topicCode: 'M-ALG-001', boundedIntegerParameters: true,
    exactRationalArithmetic: true, maximumAbsoluteValue: 10000, completeVectorComplexCertificate: true,
    maximumVisibleObjects: 3, externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
const obj = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
function vectorComplexTwoStepScopeFrom(value) {
    const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactVectorComplexTwoStepScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 73 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === exports.VECTOR_COMPLEX_TWO_STEP_FAMILY && p?.planTemplate === exports.VECTOR_COMPLEX_TWO_STEP_TEMPLATE && r?.questionType === 'single_choice'
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'vector_or_complex_two_step_object' && s?.scenarioAction === scope
        && Object.entries(exports.VECTOR_COMPLEX_TWO_STEP_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && exports.VECTOR_COMPLEX_TWO_STEP_SCOPES.includes(scope) ? scope : null;
}
const algAbs = (n) => n < 0n ? -n : n;
exports.algAbs = algAbs;
function algQ(n, d = 1) {
    let a = BigInt(n), b = BigInt(d);
    if (!b)
        throw Error('zero_denominator');
    if (b < 0n) {
        a = -a;
        b = -b;
    }
    let x = (0, exports.algAbs)(a), y = b;
    while (y) {
        [x, y] = [y, x % y];
    }
    return [a / x, b / x];
}
const algText = (q) => String(q[0]) + (q[1] === 1n ? '' : '/' + q[1]);
exports.algText = algText;
const algComplex = (r, i) => '(' + (0, exports.algText)(r) + ')+(' + (0, exports.algText)(i) + ')i';
exports.algComplex = algComplex;
const vec = (a) => '(' + a.join(',') + ')';
const cmp = (a) => '(' + a[0] + ')+(' + a[1] + ')i';
function vectorComplexTwoStepPrompt(p, lang) {
    if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[0])
        return lang === 'zh'
            ? '平面向量 a=' + vec(p.a) + '，b=' + vec(p.b) + '。求 |(' + p.p + ')a+(' + p.q + ')b|^2。'
            : 'Plane vectors a=' + vec(p.a) + ' and b=' + vec(p.b) + '. Find |(' + p.p + ')a+(' + p.q + ')b|^2.';
    if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[1])
        return lang === 'zh'
            ? '平面向量 a=' + vec(p.a) + '，b=' + vec(p.b) + '，c=' + vec(p.c) + '。若 (a+t*b) 与 c 垂直，求实数 t。'
            : 'Plane vectors a=' + vec(p.a) + ', b=' + vec(p.b) + ', c=' + vec(p.c) + '. If (a+t*b) is perpendicular to c, find the real number t.';
    if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[2])
        return lang === 'zh'
            ? '复数 z1=' + cmp(p.a) + '，z2=' + cmp(p.b) + '，z3=' + cmp(p.c) + '，其中 i^2=-1。求 z1*z2+z3。'
            : 'Complex numbers z1=' + cmp(p.a) + ', z2=' + cmp(p.b) + ', z3=' + cmp(p.c) + ', where i^2=-1. Find z1*z2+z3.';
    return lang === 'zh'
        ? '复数 z1=' + cmp(p.a) + '，z2=' + cmp(p.b) + '，z3=' + cmp(p.c) + '，其中 i^2=-1。解方程 z1*z+z2=z3，求复数 z。'
        : 'Complex numbers z1=' + cmp(p.a) + ', z2=' + cmp(p.b) + ', z3=' + cmp(p.c) + ', where i^2=-1. Solve z1*z+z2=z3 for the complex number z.';
}
const dot = (a, b) => a[0] * b[0] + a[1] * b[1];
function vectorComplexTwoStepDerive(p) {
    const bounded = (a, limit) => a.length === 2 && a.every(x => Number.isSafeInteger(x) && Math.abs(x) <= limit);
    const nonzero = (a) => a.some(x => x !== 0);
    if (!exports.VECTOR_COMPLEX_TWO_STEP_SCOPES.includes(p.scope) || !bounded(p.a, 6) || !bounded(p.b, p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[3] ? 12 : 6))
        return null;
    const [x, y] = p.a.map(BigInt), [u, v] = p.b.map(BigInt);
    if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[0]) {
        if (p.c.length || !nonzero(p.a) || !nonzero(p.b) || ![-3, -2, -1, 1, 2, 3].includes(p.p) || ![-3, -2, -1, 1, 2, 3].includes(p.q) || x * v - y * u === 0n)
            return null;
        const P = BigInt(p.p), Q = BigInt(p.q), X = P * x + Q * u, Y = P * y + Q * v, answer = String(X * X + Y * Y);
        return { answer, proof: 'u=(' + P + ')*(' + x + ',' + y + ')+(' + Q + ')*(' + u + ',' + v + ')=(' + X + ',' + Y + '); |u|^2=(' + X + ')^2+(' + Y + ')^2=' + answer, values: [x, y, u, v, P, Q, X, Y] };
    }
    if (p.p !== 0 || p.q !== 0 || !bounded(p.c, p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[1] ? 6 : 12))
        return null;
    const [r, s] = p.c.map(BigInt);
    if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[1]) {
        if (!nonzero(p.a) || !nonzero(p.b) || !nonzero(p.c))
            return null;
        const A = x * r + y * s, B = u * r + v * s;
        if (!B)
            return null;
        const answer = (0, exports.algText)(algQ(-A, B));
        return { answer, proof: 'a.c=(' + x + ')*(' + r + ')+(' + y + ')*(' + s + ')=' + A + '; b.c=(' + u + ')*(' + r + ')+(' + v + ')*(' + s + ')=' + B + '!=0; ' + A + '+(' + B + ')*t=0; t=-(' + A + ')/(' + B + ')=' + answer + '; unique_real_solution', values: [x, y, u, v, r, s, A, B] };
    }
    if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[2]) {
        if (!y || !v || !nonzero(p.c))
            return null;
        const re = x * u - y * v, im = x * v + y * u, answer = (0, exports.algComplex)(algQ(re + r), algQ(im + s));
        return { answer, proof: 'i^2=-1; product_real=(' + x + ')*(' + u + ')-(' + y + ')*(' + v + ')=' + re + '; product_imag=(' + x + ')*(' + v + ')+(' + y + ')*(' + u + ')=' + im + '; final_real=' + re + '+(' + r + ')=' + (re + r) + '; final_imag=' + im + '+(' + s + ')=' + (im + s), values: [x, y, u, v, r, s, re, im] };
    }
    if (!x || !y || !nonzero(p.b))
        return null;
    const R = r - u, I = s - v, D = x * x + y * y, real = algQ(R * x + I * y, D), imag = algQ(I * x - R * y, D), answer = (0, exports.algComplex)(real, imag);
    return { answer, proof: 'z3-z2=(' + r + '-(' + u + '))+(' + s + '-(' + v + '))i=' + (0, exports.algComplex)(algQ(R), algQ(I)) + '; conjugate_z1=(' + x + ')+(' + (-y) + ')i; denominator=(' + x + ')^2+(' + y + ')^2=' + D + '>0; real=(' + R + '*' + x + '+' + I + '*' + y + ')/' + D + '=' + (0, exports.algText)(real) + '; imag=(' + I + '*' + x + '-' + R + '*' + y + ')/' + D + '=' + (0, exports.algText)(imag) + '; unique_complex_solution', values: [x, y, u, v, r, s, R, I, D] };
}
function vectorComplexTwoStepParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1600)
        return null;
    const vals = [...text.matchAll(/\((-?\d{1,5}),(-?\d{1,5})\)/g)].map(m => m.slice(1).map(Number));
    const zs = [...text.matchAll(/\((-?\d{1,5})\)\+\((-?\d{1,5})\)i/g)].map(m => m.slice(1).map(Number));
    const coeff = text.match(/\|\((-?\d{1,5})\)a\+\((-?\d{1,5})\)b\|\^2/), pairs = scope.startsWith('vector_') ? vals : zs;
    const p = { scope, a: pairs[0] ?? [], b: pairs[1] ?? [], c: pairs[2] ?? [], p: Number(coeff?.[1] ?? 0), q: Number(coeff?.[2] ?? 0) };
    return vectorComplexTwoStepPrompt(p, lang) === text && vectorComplexTwoStepDerive(p) ? p : null;
}
function scalar(text) {
    const m = text.trim().match(/^([+-]?\d{1,6})(?:\/([+-]?\d{1,6}))?$/);
    if (!m || !BigInt(m[2] ?? 1))
        return null;
    const r = algQ(BigInt(m[1]), BigInt(m[2] ?? 1));
    return (0, exports.algAbs)(r[0]) <= 10000n && r[1] <= 10000n ? r : null;
}
function vectorComplexTwoStepOptionKey(text, scope) {
    if (typeof text !== 'string' || text.length > 160)
        return null;
    if (scope.startsWith('vector_')) {
        const r = scalar(text);
        return r ? (0, exports.algText)(r) : null;
    }
    const m = text.trim().match(/^\(([^)]+)\)\+\(([^)]+)\)i$/);
    if (!m)
        return null;
    const re = scalar(m[1]), im = scalar(m[2]);
    return re && im ? (0, exports.algComplex)(re, im) : null;
}
function vectorComplexTwoStepDistractors(p) {
    const d = vectorComplexTwoStepDerive(p);
    if (!d)
        return [];
    const [x, y, u, v] = d.values, choices = [];
    const add = (key, intent) => choices.push({ key, intent });
    if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[0]) {
        const P = BigInt(p.p), Q = BigInt(p.q), aa = x * x + y * y, bb = u * u + v * v;
        add(String(P * P * aa + Q * Q * bb), 'omit_combination_cross_term');
        add(String(P * P * aa), 'omit_second_scaled_vector');
        add(String((P * x - Q * u) ** 2n + (P * y - Q * v) ** 2n), 'subtract_second_vector');
        add(String((P * x + Q * u) ** 2n), 'omit_vertical_component_square');
        add(String(P * aa + Q * bb), 'replace_squared_coefficients_by_coefficients');
    }
    else if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[1]) {
        const [, , , , r, s, A, B] = d.values;
        add((0, exports.algText)(algQ(A, B)), 'reverse_linear_solution_sign');
        if (A)
            add((0, exports.algText)(algQ(-B, A)), 'invert_linear_solution_ratio');
        add((0, exports.algText)(algQ(-(x * u + y * v), B)), 'use_a_dot_b_instead_of_a_dot_c');
        add((0, exports.algText)(algQ(-(A + r * r + s * s), B)), 'add_c_to_parameterized_vector');
        add((0, exports.algText)(algQ(-A - B, B)), 'replace_t_by_t_plus_one');
    }
    else if (p.scope === exports.VECTOR_COMPLEX_TWO_STEP_SCOPES[2]) {
        const [, , , , r, s, re, im] = d.values;
        add((0, exports.algComplex)(algQ(x * u + y * v + r), algQ(im + s)), 'use_i_squared_positive_one');
        add((0, exports.algComplex)(algQ(re), algQ(im)), 'omit_addition_of_z3');
        add((0, exports.algComplex)(algQ(re + r), algQ(x * v + s)), 'omit_second_imaginary_cross_product');
        add((0, exports.algComplex)(algQ(re - r), algQ(im - s)), 'subtract_z3_instead_of_add');
        add((0, exports.algComplex)(algQ(re + r), algQ(y * u + s)), 'omit_first_imaginary_cross_product');
    }
    else {
        const [, , , , r, s, R, I, D] = d.values;
        add((0, exports.algComplex)(algQ((r + u) * x + (s + v) * y, D), algQ((s + v) * x - (r + u) * y, D)), 'move_z2_with_wrong_sign');
        add((0, exports.algComplex)(algQ(r * x + s * y, D), algQ(s * x - r * y, D)), 'omit_subtraction_of_z2');
        add((0, exports.algComplex)(algQ(r * x + s * y - u * D, D), algQ(s * x - r * y - v * D, D)), 'divide_z3_but_not_z2');
        add((0, exports.algComplex)(algQ(R * x - I * y, D), algQ(I * x + R * y, D)), 'multiply_without_conjugating_divisor');
        add((0, exports.algComplex)(algQ(R * x + I * y, D), algQ(R * y - I * x, D)), 'reverse_imaginary_numerator');
        add((0, exports.algComplex)(algQ(R * x + I * y), algQ(I * x - R * y)), 'omit_squared_modulus_denominator');
    }
    const correct = vectorComplexTwoStepOptionKey(d.answer, p.scope), seen = new Set([correct]);
    return choices.filter(c => { const k = vectorComplexTwoStepOptionKey(c.key, p.scope); if (k === null || seen.has(k))
        return false; seen.add(k); return true; }).slice(0, 3);
}
function solveSubjectPracticeMathVectorComplexTwoStep(candidate, context = {}) {
    const scope = vectorComplexTwoStepScopeFrom(context.questionPlan), parameters = vectorComplexTwoStepParametersFrom(candidate.prompt, scope, 'zh'), derived = parameters ? vectorComplexTwoStepDerive(parameters) : null, reasonCodes = [];
    if (!parameters || !derived)
        reasonCodes.push('vector_complex_two_step_prompt_or_plan_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 73 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('vector_complex_two_step_identity_mismatch');
    const options = candidate.options ?? [], keys = options.map(o => scope ? vectorComplexTwoStepOptionKey(o.text, scope) : null), expectedKey = derived && scope ? vectorComplexTwoStepOptionKey(derived.answer, scope) : null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('vector_complex_two_step_invalid_or_duplicate_options');
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(vectorComplexTwoStepParametersFrom(loc?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('vector_complex_two_step_' + lang + '_prompt_mismatch');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, scope ? vectorComplexTwoStepOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('vector_complex_two_step_' + lang + '_options_mismatch');
    }
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : keys[i] === expectedKey ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('vector_complex_two_step_answer_disagreement');
    const wrong = parameters ? vectorComplexTwoStepDistractors(parameters) : [], meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(x => x.optionId)).size !== 3 || new Set(meta.map(x => x.distractorIntent)).size !== 3 || meta.some(x => x.optionId === selectedOptionId || !wrong.some(w => w.intent === x.distractorIntent && scope && vectorComplexTwoStepOptionKey(w.key, scope) === keys[options.findIndex(o => o.id === x.optionId)])))
        reasonCodes.push('vector_complex_two_step_distractor_intent_mismatch');
    const scopeId = parameters ? exports.VECTOR_COMPLEX_TWO_STEP_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.VECTOR_COMPLEX_TWO_STEP_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: exports.VECTOR_COMPLEX_TWO_STEP_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: derived?.answer ?? null, proof: derived?.proof ?? null, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.VECTOR_COMPLEX_TWO_STEP_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope: scope, reasonCodes: parameters ? [] : ['vector_complex_two_step_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
