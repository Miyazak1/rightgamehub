"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathProbabilityLocalGenerator = createSubjectPracticeMathProbabilityLocalGenerator;
const subject_practice_math_probability_solver_1 = require("./subject-practice-math-probability-solver");
const subject_practice_math_probability_independent_oracle_1 = require("./subject-practice-math-probability-independent-oracle");
const subject_practice_math_probability_explanation_verifier_1 = require("./subject-practice-math-probability-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_LOCAL_GENERATOR_VERSION = 'math-probability-local-generator-v2-diverse-die-expression';
const SCOPES = new Set(['colored_objects_single_draw', 'uniform_integer_event', 'single_die_event', 'two_coin_outcome_event']);
function object(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function clean(v) { return String(v ?? '').trim(); }
function seedOf(v) { const n = Number(v); return Number.isFinite(n) ? Math.abs(Math.trunc(n)) : 0; }
function scopeFrom(v, validate) { const p = object(v), r = object(p?.renderConstraints), s = clean(r?.exactProbabilityScope); return validate(v).valid && clean(p?.taskFamily) === 'math_classical_probability_basic_calculation' && clean(p?.planTemplate) === 'math_classical_probability_basic_calculation_v1' && SCOPES.has(s) ? s : null; }
function key(v) { return `${v.numerator}/${v.denominator}`; }
function render(v) { return v.denominator === 1 ? String(v.numerator) : `${v.numerator}/${v.denominator}`; }
function alternatives(correct, favorable, total) { const raw = [{ value: correct, distractorIntent: null, misconceptionTags: [] }, { value: (0, subject_practice_math_probability_solver_1.rational)(total - favorable, total), distractorIntent: 'used_complement_event', misconceptionTags: ['probability_complement_confusion'] }, { value: (0, subject_practice_math_probability_solver_1.rational)(favorable, Math.max(1, total - favorable)), distractorIntent: 'used_unfavorable_count_as_denominator', misconceptionTags: ['probability_denominator_error'] }, { value: (0, subject_practice_math_probability_solver_1.rational)(1, total), distractorIntent: 'counted_one_favorable_outcome_only', misconceptionTags: ['probability_favorable_count_error'] }, { value: (0, subject_practice_math_probability_solver_1.rational)(favorable + 1, total), distractorIntent: 'included_one_extra_favorable_outcome', misconceptionTags: ['probability_counting_error'] }, { value: (0, subject_practice_math_probability_solver_1.rational)(Math.max(1, favorable - 1), total), distractorIntent: 'omitted_one_favorable_outcome', misconceptionTags: ['probability_counting_error'] }]; const out = [], seen = new Set(), intents = new Set(); for (const item of raw) {
    const k = key(item.value), intent = item.distractorIntent ?? '';
    if (seen.has(k) || (intent && intents.has(intent)))
        continue;
    seen.add(k);
    if (intent)
        intents.add(intent);
    out.push(item);
    if (out.length === 4)
        return out;
} throw new Error('math_probability_distinct_alternatives_unavailable'); }
function candidateFor(b, seed, s) {
    let prompt = '', promptEn = '', explanation = '', explanationEn = '', favorable = 0, total = 0;
    const formulaZh = '古典概型中，P=有利结果数/总结果数。', formulaEn = 'For equally likely outcomes, P=favorable outcomes/total outcomes.';
    if (s === 'colored_objects_single_draw') {
        const red = 2 + (seed * 3) % 7, blue = 3 + (seed * 5) % 6;
        favorable = red;
        total = red + blue;
        prompt = `袋中有 R=${red} 个红色筹码和 B=${blue} 个蓝色筹码，随机抽取 1 个，每个筹码被抽到的可能性相同。抽到红色筹码的概率是多少？`;
        promptEn = `A bag contains R=${red} red tokens and B=${blue} blue tokens. One token is drawn uniformly at random. What is the probability of drawing a red token?`;
        const answer = render((0, subject_practice_math_probability_solver_1.rational)(favorable, total));
        explanation = `${formulaZh}本题有利结果数为 R=${red}，总结果数为 R+B=${red}+${blue}=${total}，所以 P=${red}/${total}=${answer}。`;
        explanationEn = `${formulaEn} Here the favorable count is R=${red}, and the total is R+B=${red}+${blue}=${total}, so P=${red}/${total}=${answer}.`;
    }
    else if (s === 'uniform_integer_event') {
        const n = 10 + (seed * 5) % 9, k = 2 + (seed % 4);
        favorable = Math.floor(n / k);
        total = n;
        prompt = `从整数 1 到 N=${n} 中等可能地随机选取 1 个整数。若 K=${k}，选中的整数能被 K 整除的概率是多少？`;
        promptEn = `One integer is selected uniformly from 1 through N=${n}. With K=${k}, what is the probability that the selected integer is divisible by K?`;
        const answer = render((0, subject_practice_math_probability_solver_1.rational)(favorable, total));
        explanation = `${formulaZh}1 到 N=${n} 中能被 K=${k} 整除的数有 floor(N/K)=${favorable} 个，总结果数为 ${total}，所以 P=${favorable}/${total}=${answer}。`;
        explanationEn = `${formulaEn} From 1 through N=${n}, floor(N/K)=floor(${n}/${k})=${favorable} integers are divisible by K=${k}, out of ${total}, so P=${favorable}/${total}=${answer}.`;
    }
    else if (s === 'single_die_event') {
        const threshold = 2 + (seed % 3), expressionVariant = Math.floor(seed / 3) % 4;
        favorable = 6 - threshold;
        total = 6;
        const expressions = [
            {
                zh: `一个正方体的六个面依次标有 1 至 6，随机落定后每个面朝上的机会相同。令 T=${threshold}，朝上数字大于 T 的概率是多少？`,
                en: `A numbered cube has faces 1 through 6, each equally likely to land upward. Let T=${threshold}. Find the probability that the upward number exceeds T.`
            },
            {
                zh: `进行一次公平骰子试验，其可能点数为 1,2,3,4,5,6。设 T=${threshold}，所得点数超过 T 的概率是多少？`,
                en: `One die experiment has the equally likely results 1, 2, 3, 4, 5, and 6. Set T=${threshold}. What is the probability that the observed number exceeds T?`
            },
            {
                zh: `从六个等可能结果 {1,2,3,4,5,6} 中随机得到一个数，这对应投掷一次公平骰子。若 T=${threshold}，结果大于 T 的概率是多少？`,
                en: `Choose one equally likely value X from {1,2,3,4,5,6}, as in a single fair-die trial. If T=${threshold}, determine P(X>T).`
            },
            {
                zh: `一枚各面等可能出现的骰子只投一次，样本空间为 {1,2,3,4,5,6}。取 T=${threshold}，事件“点数大于 T”的概率是多少？`,
                en: `For one throw of an unbiased die, the sample space is {1,2,3,4,5,6}. Take T=${threshold}. Determine the probability of the event “result greater than T”.`
            }
        ];
        prompt = expressions[expressionVariant].zh;
        promptEn = expressions[expressionVariant].en;
        const answer = render((0, subject_practice_math_probability_solver_1.rational)(favorable, total));
        explanation = `${formulaZh}大于 T=${threshold} 的点数有 ${favorable} 个，总结果数为 ${total}，所以 P=${favorable}/${total}=${answer}。`;
        explanationEn = `${formulaEn} There are ${favorable} outcomes greater than T=${threshold}, out of ${total}, so P=${favorable}/${total}=${answer}.`;
    }
    else {
        const heads = seed % 3;
        favorable = heads === 1 ? 2 : 1;
        total = 4;
        prompt = `同时抛掷两枚均匀硬币，令 H=${heads}。恰好出现 H 次正面的概率是多少？`;
        promptEn = `Two fair coins are tossed. Let H=${heads}. What is the probability of obtaining exactly H heads?`;
        const answer = render((0, subject_practice_math_probability_solver_1.rational)(favorable, total));
        explanation = `${formulaZh}两枚硬币共有 ${total} 个等可能结果，其中恰好 H=${heads} 次正面的结果有 ${favorable} 个，所以 P=${favorable}/${total}=${answer}。`;
        explanationEn = `${formulaEn} Two coins have ${total} equally likely outcomes, and ${favorable} have exactly H=${heads} heads, so P=${favorable}/${total}=${answer}.`;
    }
    const correct = (0, subject_practice_math_probability_solver_1.rational)(favorable, total), set = alternatives(correct, favorable, total), correctIndex = seed % 4, ordered = set.slice(1);
    ordered.splice(correctIndex, 0, set[0]);
    const ids = ['A', 'B', 'C', 'D'], options = ordered.map((x, i) => ({ id: ids[i], text: render(x.value) }));
    return { subject: 'math', topicId: b.topicId, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options, correctAnswer: ids[correctIndex], explanation, knowledgeTags: ['古典概型与概率计算', s], optionMetadata: ordered.flatMap((x, i) => i === correctIndex ? [] : [{ optionId: ids[i], distractorIntent: x.distractorIntent ?? 'unclassified_probability_error', misconceptionTags: x.misconceptionTags }]), localizations: { zh: { prompt, options, explanation, knowledgeTags: ['古典概型与概率计算'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Classical probability'] } }, syllabusVersion: b.syllabusVersion };
}
function createSubjectPracticeMathProbabilityLocalGenerator(ports) { return function generate(input) { const seed = seedOf(input.seed), exactScope = scopeFrom(input.questionPlan, ports.validate), supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'basic' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice'; if (!exactScope || !supported)
    return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_PROBABILITY_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_probability_local_generator_question_plan_not_supported'] }; const candidate = candidateFor(input.blueprint, seed, exactScope), context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_probability_solver_1.solveSubjectPracticeMathProbability)(candidate, context), oracleEvidence = (0, subject_practice_math_probability_independent_oracle_1.verifySubjectPracticeMathProbabilityWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_probability_explanation_verifier_1.verifySubjectPracticeMathProbabilityExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate), verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId; return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_PROBABILITY_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_probability_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] }; }; }
