"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MATH_SOLID_GEOMETRY_INTEGER_DIAGONAL_TRIPLES = exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathSolidGeometryLocalGenerator = createSubjectPracticeMathSolidGeometryLocalGenerator;
const subject_practice_math_solid_geometry_solver_1 = require("./subject-practice-math-solid-geometry-solver");
const subject_practice_math_solid_geometry_independent_oracle_1 = require("./subject-practice-math-solid-geometry-independent-oracle");
const subject_practice_math_solid_geometry_explanation_verifier_1 = require("./subject-practice-math-solid-geometry-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_LOCAL_GENERATOR_VERSION = 'math-solid-geometry-local-generator-v1-bounded-solids';
// Enumerate the entire bounded integer-diagonal domain, not a few handpicked examples.
exports.MATH_SOLID_GEOMETRY_INTEGER_DIAGONAL_TRIPLES = (() => {
    const triples = [];
    for (let a = 1; a <= 30; a++)
        for (let b = a; b <= 30; b++)
            for (let c = b; c <= 30; c++) {
                if (Number.isInteger(Math.sqrt(a * a + b * b + c * c)))
                    triples.push([a, b, c]);
            }
    return Object.freeze(triples.map(triple => Object.freeze(triple)));
})();
function candidateFor(b, seed, s) {
    let a = 2 + seed % 11, sideB = 3 + Math.floor(seed / 11) % 11, c = 4 + Math.floor(seed / 121) % 11;
    let correct = 0, unit = 'cm^3', pi = '', prompt = '', promptEn = '', equation = '', explanation = '', explanationEn = '';
    let wrong = [];
    const variant = Math.floor(seed / 3) % 2;
    if (s === 'cylinder_volume') {
        const r = 2 + seed % 12, h = 3 + Math.floor(seed / 12) % 15;
        correct = r * r * h;
        pi = 'π';
        prompt = `${variant ? '已知一直圆柱' : '一个直圆柱'}的底面半径 r=${r} cm，高 h=${h} cm。求它的体积（保留 π）。`;
        promptEn = `${variant ? 'Consider a right circular cylinder' : 'A right circular cylinder'} has base radius r=${r} cm and height h=${h} cm. Find its volume (leave π exact).`;
        equation = `V=πr^2h=π×${r}^2×${h}=${correct}π cm^3`;
        explanation = `圆柱体积等于底面积乘高：${equation}。`;
        explanationEn = `Cylinder volume is base area times height: ${equation}.`;
        wrong = [{ value: r * h, intent: 'omitted_radius_square' }, { value: 4 * correct, intent: 'used_diameter_as_radius' }, { value: r * r, intent: 'omitted_height_factor' },
            { value: r * r * h * h, intent: 'squared_height_as_well_as_radius' }, { value: 2 * correct, intent: 'counted_two_cylinders' }];
    }
    else {
        if (s === 'cuboid_space_diagonal') {
            const triples = exports.MATH_SOLID_GEOMETRY_INTEGER_DIAGONAL_TRIPLES;
            [a, sideB, c] = triples[seed % triples.length];
        }
        const zhTarget = s === 'cuboid_volume' ? '体积' : s === 'cuboid_surface_area' ? '总表面积' : '体对角线长度';
        const enTarget = s === 'cuboid_volume' ? 'volume' : s === 'cuboid_surface_area' ? 'total surface area' : 'space diagonal length';
        prompt = `${variant ? '已知一长方体' : '一个长方体'}的三条相邻棱长为 a=${a} cm、b=${sideB} cm、c=${c} cm。求它的${zhTarget}。`;
        promptEn = `${variant ? 'Consider a cuboid' : 'A cuboid'} has three adjacent edge lengths a=${a} cm, b=${sideB} cm, c=${c} cm. Find its ${enTarget}.`;
        if (s === 'cuboid_volume') {
            correct = a * sideB * c;
            equation = `V=abc=${a}×${sideB}×${c}=${correct} cm^3`;
            explanation = `长方体体积等于三条相邻棱长的乘积：${equation}。`;
            explanationEn = `Cuboid volume is the product of three adjacent edge lengths: ${equation}.`;
            wrong = [{ value: a * sideB, intent: 'omitted_third_edge' }, { value: a + sideB + c, intent: 'added_edges_instead_of_multiplying' }, { value: 2 * correct, intent: 'doubled_volume_like_opposite_faces' }, { value: 2 * (a * sideB + a * c + sideB * c), intent: 'used_surface_area_formula' }];
        }
        else if (s === 'cuboid_surface_area') {
            correct = 2 * (a * sideB + a * c + sideB * c);
            unit = 'cm^2';
            equation = `S=2(ab+ac+bc)=2×(${a}×${sideB}+${a}×${c}+${sideB}×${c})=${correct} cm^2`;
            explanation = `长方体的三对相对面面积相等：${equation}。`;
            explanationEn = `A cuboid has three pairs of equal opposite faces: ${equation}.`;
            wrong = [{ value: correct / 2, intent: 'counted_each_face_pair_once' }, { value: 2 * (a * c + sideB * c), intent: 'omitted_both_base_faces' }, { value: 2 * a * sideB, intent: 'counted_only_base_faces' }, { value: correct - a * sideB, intent: 'omitted_one_base_face' }, { value: a * sideB, intent: 'counted_only_one_base_face' }];
        }
        else {
            correct = Math.sqrt(a * a + sideB * sideB + c * c);
            unit = 'cm';
            equation = `d=sqrt(a^2+b^2+c^2)=sqrt(${a}^2+${sideB}^2+${c}^2)=${correct} cm`;
            explanation = `连续应用两次勾股定理：${equation}。`;
            explanationEn = `Apply the Pythagorean theorem twice: ${equation}.`;
            wrong = [{ value: correct * correct, intent: 'omitted_final_square_root' }, { value: a + sideB + c, intent: 'used_edge_path_length' }, { value: Math.max(a, sideB, c), intent: 'used_longest_edge' }];
        }
    }
    const alternatives = [{ value: correct, intent: '' }], used = new Set([correct]);
    for (const item of wrong)
        if (!used.has(item.value)) {
            used.add(item.value);
            alternatives.push(item);
            if (alternatives.length === 4)
                break;
        }
    if (alternatives.length !== 4 || !Number.isSafeInteger(correct))
        throw new Error(`math_solid_geometry_alternatives_unavailable:${s}:${seed}`);
    const correctIndex = seed % 4, ordered = alternatives.slice(1);
    ordered.splice(correctIndex, 0, alternatives[0]);
    const options = ordered.map((o, i) => ({ id: 'ABCD'[i], text: `${o.value}${pi} ${unit}` }));
    return { subject: 'math', topicId: b.topicId, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options,
        correctAnswer: 'ABCD'[correctIndex], explanation, knowledgeTags: ['空间几何', s],
        optionMetadata: ordered.flatMap((o, i) => o.intent ? [{ optionId: 'ABCD'[i], distractorIntent: o.intent, misconceptionTags: [o.intent] }] : []),
        localizations: { zh: { prompt, options, explanation, knowledgeTags: ['空间几何'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Solid geometry'] } }, syllabusVersion: b.syllabusVersion };
}
function createSubjectPracticeMathSolidGeometryLocalGenerator(ports) {
    return function generate(input) {
        const seed = Number.isSafeInteger(input.seed) ? Math.abs(input.seed) : 0, exactScope = (0, subject_practice_math_solid_geometry_solver_1.solidGeometryScopeFrom)(input.questionPlan);
        const common = { generatorVersion: exports.SUBJECT_PRACTICE_MATH_SOLID_GEOMETRY_LOCAL_GENERATOR_VERSION, seed, exactScope,
            providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const b = input.blueprint;
        if (!exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.difficulty !== 'basic' || b.questionType !== 'single_choice')
            return { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['math_solid_geometry_local_generator_question_plan_not_supported'] };
        const candidate = candidateFor(b, seed, exactScope), context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_solid_geometry_solver_1.solveSubjectPracticeMathSolidGeometry)(candidate, context), oracleEvidence = (0, subject_practice_math_solid_geometry_independent_oracle_1.verifySubjectPracticeMathSolidGeometryWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_solid_geometry_explanation_verifier_1.verifySubjectPracticeMathSolidGeometryExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres
            && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null,
            solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
            reasonCodes: verified ? [] : ['math_solid_geometry_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
