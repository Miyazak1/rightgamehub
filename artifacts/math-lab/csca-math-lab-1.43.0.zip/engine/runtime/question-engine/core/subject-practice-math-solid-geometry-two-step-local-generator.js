"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SOLID_GEOMETRY_TWO_STEP_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathSolidGeometryTwoStepLocalGenerator = createSubjectPracticeMathSolidGeometryTwoStepLocalGenerator;
const subject_practice_math_solid_geometry_two_step_solver_1 = require("./subject-practice-math-solid-geometry-two-step-solver");
const subject_practice_math_solid_geometry_two_step_independent_oracle_1 = require("./subject-practice-math-solid-geometry-two-step-independent-oracle");
const subject_practice_math_solid_geometry_two_step_explanation_verifier_1 = require("./subject-practice-math-solid-geometry-two-step-explanation-verifier");
exports.SOLID_GEOMETRY_TWO_STEP_GENERATOR_VERSION = 'math-solid-geometry-two-step-generator-v1-bounded';
function createSubjectPracticeMathSolidGeometryTwoStepLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, exactScope = (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.SOLID_GEOMETRY_TWO_STEP_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['solid_geometry_two_step_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 74 || b.topicCode !== 'M-GEO-002' || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        let selected = null, parameterAttempts = 0;
        for (let attempt = 0; attempt < 64; attempt++) {
            parameterAttempts++;
            const n = seed % 100000 + attempt * 1009, a = 1 + n % 30, side = 1 + Math.floor(n / 30) % 30, c = 1 + Math.floor(n / 900) % 30, index = subject_practice_math_solid_geometry_two_step_solver_1.SOLID_GEOMETRY_TWO_STEP_SCOPES.indexOf(exactScope);
            const values = index === 0 ? [a, side, a * side * c] : index === 1 ? [a, side, 2 * (a * side + a * c + side * c)] : index === 2 ? [a, a * a * side] : [a, side];
            const p = { scope: exactScope, values };
            if ((0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepDerive)(p) && (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepDistractors)(p).length === 3) {
                selected = p;
                break;
            }
        }
        if (!selected)
            return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts };
        const p = selected, answer = (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepDerive)(p).answer, choices = (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepDistractors)(p), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
        const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: x.key })), prompt = (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepPrompt)(p, 'en'), explanation = (0, subject_practice_math_solid_geometry_two_step_explanation_verifier_1.renderSolidGeometryTwoStepExplanation)(p, answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 74, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['空间几何', exactScope],
            optionMetadata: choices.flatMap((x, i) => x.intent ? [{ optionId: 'ABCD'[i], distractorIntent: x.intent, misconceptionTags: [x.intent] }] : []),
            localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['空间几何', exactScope] }, en: { prompt: enPrompt, options: options.map(x => ({ ...x })), explanation: explanation.en, knowledgeTags: ['Solid geometry two-step calculation', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_solid_geometry_two_step_solver_1.solveSubjectPracticeMathSolidGeometryTwoStep)(candidate, context), oracleEvidence = (0, subject_practice_math_solid_geometry_two_step_independent_oracle_1.verifySubjectPracticeMathSolidGeometryTwoStepWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_solid_geometry_two_step_explanation_verifier_1.verifySubjectPracticeMathSolidGeometryTwoStepExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, parameterAttempts, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
