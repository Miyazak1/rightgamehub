"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FUNCTION_MONOTONICITY_LABELS = exports.functionSigned = exports.formatRat = exports.cmpRat = exports.addRat = exports.FUNCTION_INTERVAL_CONSTRAINTS = exports.FUNCTION_INTERVAL_SCOPES = exports.FUNCTION_INTERVAL_SCOPE_VERSION = exports.FUNCTION_INTERVAL_SOLVER_VERSION = exports.FUNCTION_INTERVAL_TEMPLATE = exports.FUNCTION_INTERVAL_FAMILY = void 0;
exports.rat = rat;
exports.formatFunctionIntervals = formatFunctionIntervals;
exports.parseFunctionIntervals = parseFunctionIntervals;
exports.functionIntervalScopeFrom = functionIntervalScopeFrom;
exports.functionExpression = functionExpression;
exports.functionIntervalPrompt = functionIntervalPrompt;
exports.functionIntervalParametersFrom = functionIntervalParametersFrom;
exports.removeFunctionPole = removeFunctionPole;
exports.functionDomain = functionDomain;
exports.functionEndpointValue = functionEndpointValue;
exports.functionMonotonicity = functionMonotonicity;
exports.functionIntervalAnswer = functionIntervalAnswer;
exports.functionOptionKey = functionOptionKey;
exports.functionIntervalDistractors = functionIntervalDistractors;
exports.solveSubjectPracticeMathFunctionInterval = solveSubjectPracticeMathFunctionInterval;
exports.FUNCTION_INTERVAL_FAMILY = 'math_function_interval_property_reasoning';
exports.FUNCTION_INTERVAL_TEMPLATE = exports.FUNCTION_INTERVAL_FAMILY + '_v1';
exports.FUNCTION_INTERVAL_SOLVER_VERSION = 'math-function-interval-solver-v1-exact-rational';
exports.FUNCTION_INTERVAL_SCOPE_VERSION = 'math-medium-function-interval-v1';
exports.FUNCTION_INTERVAL_SCOPES = ['quadratic_closed_interval_range', 'quadratic_interval_monotonicity',
    'radical_fraction_domain_intersection', 'linear_fraction_closed_interval_range'];
exports.FUNCTION_INTERVAL_CONSTRAINTS = { topicCode: 'M-FUNC-001', maximumAbsoluteScale: 4,
    boundedIntegerParameters: true, closedNondegenerateInputInterval: true, exactRationalArithmetic: true,
    externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
const rec = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function rat(n, d = 1) {
    let x = BigInt(n), y = BigInt(d);
    if (!y)
        throw new Error('zero_denominator');
    if (y < 0n) {
        x = -x;
        y = -y;
    }
    let a = x < 0n ? -x : x, b = y;
    while (b) {
        const t = a % b;
        a = b;
        b = t;
    }
    return { n: x / a, d: y / a };
}
const addRat = (x, y) => rat(x.n * y.d + y.n * x.d, x.d * y.d);
exports.addRat = addRat;
const cmpRat = (x, y) => Math.sign(Number(x.n * y.d - y.n * x.d));
exports.cmpRat = cmpRat;
const formatRat = (x) => String(x.n) + (x.d === 1n ? '' : '/' + x.d);
exports.formatRat = formatRat;
function cmp(x, y) {
    if (x === y)
        return 0;
    if (x === '-inf' || y === '+inf')
        return -1;
    if (x === '+inf' || y === '-inf')
        return 1;
    return (0, exports.cmpRat)(x, y);
}
const fmt = (v) => typeof v === 'string' ? v : (0, exports.formatRat)(v);
function formatFunctionIntervals(v) {
    return v.map(i => (i.lc ? '[' : '(') + fmt(i.lo) + ', ' + fmt(i.hi) + (i.rc ? ']' : ')')).join(' U ');
}
function parseFunctionIntervals(text) {
    const parts = String(text ?? '').trim().split(/\s+U\s+/);
    if (!parts.length || parts.length > 2)
        return null;
    const out = [];
    const bound = (s) => {
        if (s === '-inf' || s === '+inf')
            return s;
        if (!/^[+-]?\d{1,6}(?:\/\d{1,6})?$/.test(s))
            return null;
        const [n, d = '1'] = s.split('/');
        if (BigInt(d) === 0n)
            return null;
        const v = rat(BigInt(n), BigInt(d));
        return (v.n < -4096n || v.n > 4096n || v.d > 256n) ? null : v;
    };
    for (const t of parts) {
        const m = t.match(/^([\[(])\s*([^,]+),\s*([^\])]+)([\])])$/);
        if (!m)
            return null;
        const lo = bound(m[2].trim()), hi = bound(m[3].trim()), lc = m[1] === '[', rc = m[4] === ']';
        if (!lo || !hi || cmp(lo, hi) >= 0 || (typeof lo === 'string' && lc) || (typeof hi === 'string' && rc))
            return null;
        out.push({ lo, hi, lc, rc });
    }
    out.sort((a, b) => cmp(a.lo, b.lo) || Number(b.lc) - Number(a.lc));
    if (out.length === 2) {
        const [a, b] = out, order = cmp(a.hi, b.lo);
        if (order > 0 || (order === 0 && (a.rc || b.lc)))
            return [{ lo: a.lo, hi: cmp(a.hi, b.hi) >= 0 ? a.hi : b.hi,
                    lc: a.lc, rc: cmp(a.hi, b.hi) > 0 ? a.rc : cmp(a.hi, b.hi) < 0 ? b.rc : a.rc || b.rc }];
    }
    return out;
}
function functionIntervalScopeFrom(value) {
    const p = rec(value), r = rec(p?.renderConstraints), s = rec(p?.scenarioContract), scope = r?.exactFunctionIntervalScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 68 && p?.targetDifficulty === 'medium'
        && p?.taskFamily === exports.FUNCTION_INTERVAL_FAMILY && p?.planTemplate === exports.FUNCTION_INTERVAL_TEMPLATE
        && p?.representationType === 'text' && r?.questionType === 'single_choice'
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'function_interval_object' && s?.scenarioAction === scope
        && Object.entries(exports.FUNCTION_INTERVAL_CONSTRAINTS).every(([k, v]) => r?.[k] === v)
        && exports.FUNCTION_INTERVAL_SCOPES.includes(scope) ? scope : null;
}
const functionSigned = (n) => (n < 0 ? ' - ' : ' + ') + Math.abs(n);
exports.functionSigned = functionSigned;
function functionExpression(p) {
    return p.scope.startsWith('quadratic') ? p.a + 'x^2' + (0, exports.functionSigned)(p.b) + 'x' + (0, exports.functionSigned)(p.c)
        : (p.scope.startsWith('radical') ? 'sqrt(' : '(') + p.a + 'x' + (0, exports.functionSigned)(p.b) + ')/(x' + (0, exports.functionSigned)(-p.p) + ')';
}
function functionIntervalPrompt(p, lang, alternate = false) {
    const start = lang === 'zh' ? (alternate ? '设函数 ' : '已知函数 ') : (alternate ? 'Consider ' : 'Given ');
    const object = 'f(x)=' + functionExpression(p);
    if (p.scope.startsWith('radical'))
        return start + object + (lang === 'zh' ? '。求其定义域，需同时考虑根式与分母条件。' : '. Find its domain using both the radicand and denominator conditions.');
    const range = p.scope !== 'quadratic_interval_monotonicity';
    return start + object + (lang === 'zh' ? '，在闭区间 ' : ' on the closed interval ') + '[' + p.l + ', ' + p.r + ']'
        + (lang === 'zh' ? (range ? ' 上的值域是？请结合区间内的函数变化及边界值判断。' : ' 上的单调性是？请先求对称轴，再结合区间位置判断。')
            : (range ? '. What is its range? Use its variation within the interval and boundary values.' : '. What is its monotonicity? Find the axis first, then use the interval position.'));
}
function functionIntervalParametersFrom(text, scope, lang) {
    if (!scope || String(text).length > 1000)
        return null;
    const body = String(text).match(/f\(x\)=(.+?)(?:，在闭区间 | on the closed interval |。求其定义域|\. Find its domain)/);
    if (!body)
        return null;
    const quadratic = scope.startsWith('quadratic'), radical = scope.startsWith('radical');
    const m = body[1].match(quadratic ? /^(-?\d+)x\^2 ([+-]) (\d+)x ([+-]) (\d+)$/
        : radical ? /^sqrt\((-?\d+)x ([+-]) (\d+)\)\/\(x ([+-]) (\d+)\)$/
            : /^\((-?\d+)x ([+-]) (\d+)\)\/\(x ([+-]) (\d+)\)$/);
    if (!m)
        return null;
    const a = Number(m[1]), b = Number(m[3]) * (m[2] === '-' ? -1 : 1), last = Number(m[5]) * (m[4] === '-' ? -1 : 1);
    if (![a, b, last].every(Number.isSafeInteger) || !a || Math.abs(a) > 4)
        return null;
    const im = String(text).match(/(?:闭区间 |closed interval )\[(-?\d+), (-?\d+)\]/);
    const l = im ? Number(im[1]) : 0, r = im ? Number(im[2]) : 0;
    if (!radical && (!im || ![l, r].every(v => Number.isInteger(v) && Math.abs(v) <= 9) || l >= r))
        return null;
    const c = quadratic ? last : 0, p = quadratic ? 0 : -last, h = quadratic ? -b / (2 * a) : 0;
    const k = quadratic ? c - a * h * h : 0, z = radical ? -b / a : 0;
    if (quadratic && (!Number.isInteger(h) || Math.abs(h) > 6 || !Number.isInteger(k) || Math.abs(k) > 9))
        return null;
    if (!quadratic && (!Number.isInteger(p) || Math.abs(p) > 9))
        return null;
    if (radical && (!Number.isInteger(z) || Math.abs(z) > 6))
        return null;
    if (!quadratic && !radical && (Math.abs(b) > 12 || a * p + b === 0 || (p >= l && p <= r)))
        return null;
    const result = { scope, a, b, c, h, k, z, p, l, r };
    return [false, true].some(alt => functionIntervalPrompt(result, lang, alt) === text) ? result : null;
}
function removeFunctionPole(intervals, pole) {
    const p = rat(pole), out = [];
    for (const i of intervals) {
        if (cmp(p, i.lo) < 0 || cmp(p, i.hi) > 0) {
            out.push(i);
            continue;
        }
        if (cmp(i.lo, p) < 0)
            out.push({ ...i, hi: p, rc: false });
        if (cmp(p, i.hi) < 0)
            out.push({ ...i, lo: p, lc: false });
    }
    return out;
}
function functionDomain(p, z = p.z, direction = p.a > 0) {
    return removeFunctionPole(direction ? [{ lo: rat(z), hi: '+inf', lc: true, rc: false }]
        : [{ lo: '-inf', hi: rat(z), lc: false, rc: true }], p.p);
}
function functionEndpointValue(p, x) {
    return p.scope.startsWith('quadratic') ? rat(p.a * x * x + p.b * x + p.c) : rat(p.a * x + p.b, x - p.p);
}
exports.FUNCTION_MONOTONICITY_LABELS = {
    increasing: ['严格递增', 'strictly increasing'], decreasing: ['严格递减', 'strictly decreasing'],
    neither: ['不单调', 'not monotonic'], constant: ['常数函数', 'constant function']
};
function functionMonotonicity(p) {
    return p.l < p.h && p.h < p.r ? 'neither' : ((p.l >= p.h) === (p.a > 0) ? 'increasing' : 'decreasing');
}
function functionIntervalAnswer(p) {
    if (p.scope === 'quadratic_interval_monotonicity')
        return functionMonotonicity(p);
    if (p.scope.startsWith('radical'))
        return formatFunctionIntervals(functionDomain(p));
    const values = [functionEndpointValue(p, p.l), functionEndpointValue(p, p.r)];
    if (p.scope.startsWith('quadratic') && p.h >= p.l && p.h <= p.r)
        values.push(rat(p.k));
    values.sort(exports.cmpRat);
    return formatFunctionIntervals([{ lo: values[0], hi: values[values.length - 1], lc: true, rc: true }]);
}
function functionOptionKey(text, scope) {
    if (scope === 'quadratic_interval_monotonicity')
        return Object.entries(exports.FUNCTION_MONOTONICITY_LABELS).find(([, labels]) => labels.includes(text))?.[0] ?? null;
    const parsed = parseFunctionIntervals(text);
    return parsed ? formatFunctionIntervals(parsed) : null;
}
function functionIntervalDistractors(p) {
    const answer = functionIntervalAnswer(p);
    if (p.scope === 'quadratic_interval_monotonicity')
        return Object.keys(exports.FUNCTION_MONOTONICITY_LABELS).filter(x => x !== answer)
            .map(key => ({ key, intent: 'incorrect_interval_' + key }));
    if (p.scope.startsWith('radical'))
        return [
            { key: formatFunctionIntervals(functionDomain(p, p.z, p.a < 0)), intent: 'reversed_radicand_sign' },
            { key: formatFunctionIntervals(functionDomain(p, p.z + (p.a > 0 ? 1 : -1))), intent: 'wrong_radicand_boundary' },
            { key: formatFunctionIntervals(removeFunctionPole([{ lo: '-inf', hi: '+inf', lc: false, rc: false }], p.p)), intent: 'ignored_radicand_condition' }
        ];
    const i = parseFunctionIntervals(answer)[0];
    return [
        { key: formatFunctionIntervals([{ ...i, lo: (0, exports.addRat)(i.lo, rat(-1)) }]), intent: 'incorrect_lower_value' },
        { key: formatFunctionIntervals([{ ...i, hi: (0, exports.addRat)(i.hi, rat(1)) }]), intent: 'incorrect_upper_value' },
        { key: formatFunctionIntervals([{ ...i, lc: false, rc: false }]), intent: 'excluded_attained_endpoints' }
    ];
}
function solveSubjectPracticeMathFunctionInterval(candidate, context = {}) {
    const exactScope = functionIntervalScopeFrom(context.questionPlan), parameters = functionIntervalParametersFrom(candidate.prompt, exactScope, 'zh');
    const reasonCodes = [];
    if (!parameters)
        reasonCodes.push('function_interval_prompt_or_plan_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 68 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('function_interval_identity_mismatch');
    const options = candidate.options ?? [], keys = options.map(o => exactScope ? functionOptionKey(o.text, exactScope) : null);
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(functionIntervalParametersFrom(loc?.prompt ?? '', exactScope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('function_interval_' + lang + '_prompt_mismatch');
        if (!loc?.options || JSON.stringify(loc.options.map(o => ({ id: o.id, key: exactScope ? functionOptionKey(o.text, exactScope) : null }))) !== JSON.stringify(options.map((o, i) => ({ id: o.id, key: keys[i] }))))
            reasonCodes.push('function_interval_' + lang + '_options_mismatch');
    }
    const expectedAnswer = parameters ? functionIntervalAnswer(parameters) : null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !'ABCD'.split('').includes(o.id))
        || keys.some(k => k === null) || new Set(keys).size !== 4)
        reasonCodes.push('function_interval_invalid_or_duplicate_options');
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : keys[i] === expectedAnswer ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(v => v.verdict === 'true').map(v => v.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('function_interval_answer_disagreement');
    const wrong = parameters ? functionIntervalDistractors(parameters) : [], metadata = candidate.optionMetadata ?? [];
    if (metadata.length !== 3 || new Set(metadata.map(x => x.optionId)).size !== 3 || new Set(metadata.map(x => x.distractorIntent)).size !== 3
        || metadata.some(x => x.optionId === selectedOptionId || !wrong.some(w => w.intent === x.distractorIntent && w.key === keys[options.findIndex(o => o.id === x.optionId)])))
        reasonCodes.push('function_interval_distractor_intent_mismatch');
    const scopeId = parameters ? exports.FUNCTION_INTERVAL_SCOPE_VERSION + ':' + exactScope : null;
    return { solverVersion: exports.FUNCTION_INTERVAL_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: exports.FUNCTION_INTERVAL_FAMILY, scopeId, exactScope, parameters, expectedAnswer, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.FUNCTION_INTERVAL_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope, reasonCodes: parameters ? [] : ['function_interval_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
