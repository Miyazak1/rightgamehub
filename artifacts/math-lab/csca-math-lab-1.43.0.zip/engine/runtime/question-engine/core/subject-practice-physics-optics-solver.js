"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_SCOPE_VERSION = exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_SOLVER_VERSION = void 0;
exports.solveSubjectPracticePhysicsOptics = solveSubjectPracticePhysicsOptics;
exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_SOLVER_VERSION = 'physics-optics-two-relation-solver-v1';
exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_SCOPE_VERSION = 'physics-optics-two-relation-scope-v1';
function recordFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function normalized(value) {
    return String(value ?? '').replace(/[，；]/g, ',').replace(/[。]/g, '.').replace(/[＝]/g, '=').replace(/\s+/g, ' ').trim().toLowerCase();
}
function sameNumber(a, b) { return Math.abs(a - b) <= Math.max(1e-6, Math.abs(b) * 1e-6); }
function labelledNumber(source, labels, unit) {
    const match = source.match(new RegExp(`(?:${labels})[^0-9]{0,12}(\\d+(?:\\.\\d+)?)\\s*${unit}`, 'i'));
    return match ? Number(match[1]) : null;
}
function imageScaleFor(f, u) {
    if (sameNumber(u, 2 * f))
        return 'same_size';
    return u > 2 * f ? 'diminished' : 'enlarged';
}
function parseLens(prompt) {
    const source = normalized(prompt);
    if (!/凸透镜|convex lens/.test(source))
        return null;
    const f = labelledNumber(source, '焦距(?:为|是)?|focal length(?: is)?', 'cm');
    const u = labelledNumber(source, '物距(?:为|是)?|object distance(?: is)?', 'cm');
    if (f === null || u === null || f <= 0 || u <= f)
        return null;
    const v = f * u / (u - f);
    if (/(放大率|magnification)/.test(source) && /(?:求|calculate|find|what is)/.test(source)) {
        return { scope: 'convex_lens_magnification', focalLengthCm: f, objectDistanceCm: u, imageDistanceCm: v, magnification: v / u };
    }
    if (/(像距|image distance)/.test(source) && /(像的性质|image nature|image property|nature of the image)/.test(source)) {
        return { scope: 'convex_lens_image_distance_and_nature', focalLengthCm: f, objectDistanceCm: u, imageDistanceCm: v, imageScale: imageScaleFor(f, u) };
    }
    return null;
}
function parseRatio(source) {
    const compact = source.replace(/\s+/g, '');
    if (/n[₂2]\/n[₁1]=√2|n2\/n1=sqrt\(?2\)?/.test(compact))
        return Math.SQRT2;
    if (/n[₂2]\/n[₁1]=1\/√2|n2\/n1=1\/sqrt\(?2\)?/.test(compact))
        return 1 / Math.SQRT2;
    const match = compact.match(/n[₂2]\/n[₁1]=(\d+(?:\.\d+)?)/);
    return match ? Number(match[1]) : null;
}
function parseRefraction(prompt) {
    const source = normalized(prompt);
    if (!/(折射|refraction)/.test(source) || !/(法线|normal)/.test(source))
        return null;
    const ratio = parseRatio(source);
    const incidence = labelledNumber(source, '入射角(?:为|是)?|incidence angle(?: is)?', '(?:°|degrees?)');
    if (ratio === null || incidence === null || ratio <= 0 || incidence <= 0 || incidence >= 90)
        return null;
    const sinR = Math.sin(incidence * Math.PI / 180) / ratio;
    if (sinR <= 0 || sinR >= 1)
        return null;
    const refractionAngleDeg = Math.asin(sinR) * 180 / Math.PI;
    const rounded = Number(refractionAngleDeg.toFixed(6));
    return {
        scope: 'refraction_angle_and_direction', refractiveIndexRatio: ratio, incidenceAngleDeg: incidence,
        refractionAngleDeg: rounded, refractionDirection: ratio > 1 ? 'toward_normal' : 'away_from_normal'
    };
}
function parseModel(prompt) { return parseLens(prompt) ?? parseRefraction(prompt); }
function optionVerdict(optionId, raw, model) {
    const source = normalized(raw);
    if (model.scope === 'convex_lens_magnification') {
        const match = source.match(/(?:放大率(?:大小)?|magnification(?: magnitude)?)[^0-9]{0,8}(\d+(?:\.\d+)?)/i);
        if (!match || model.magnification === undefined)
            return { optionId, verdict: 'unknown', reasonCode: 'physics_optics_option_magnification_unparsed' };
        return { optionId, verdict: sameNumber(Number(match[1]), model.magnification) ? 'true' : 'false', reasonCode: 'physics_optics_option_magnification_compared' };
    }
    if (model.scope === 'convex_lens_image_distance_and_nature') {
        const distance = labelledNumber(source, '像距(?:为|是)?|image distance(?: is)?', 'cm');
        const inverted = /倒立|inverted/.test(source);
        const upright = /正立|upright/.test(source);
        const real = /实像|real image/.test(source);
        const virtual = /虚像|virtual image/.test(source);
        const scales = [
            ['diminished', /缩小|diminished|smaller/], ['same_size', /等大|same size/], ['enlarged', /放大|enlarged|larger/]
        ];
        const scaleHits = scales.filter(([, pattern]) => pattern.test(source));
        if (distance === null || inverted === upright || real === virtual || scaleHits.length !== 1 || model.imageDistanceCm === undefined) {
            return { optionId, verdict: 'unknown', reasonCode: 'physics_optics_option_image_bundle_unparsed' };
        }
        const correct = sameNumber(distance, model.imageDistanceCm) && inverted && real && scaleHits[0][0] === model.imageScale;
        return { optionId, verdict: correct ? 'true' : 'false', reasonCode: 'physics_optics_option_image_bundle_compared' };
    }
    const angle = labelledNumber(source, '折射角(?:为|是)?|refraction angle(?: is)?', '(?:°|degrees?)');
    const toward = /向法线偏折|靠近法线|toward the normal/.test(source);
    const away = /离开法线偏折|远离法线|away from the normal/.test(source);
    if (angle === null || toward === away || model.refractionAngleDeg === undefined) {
        return { optionId, verdict: 'unknown', reasonCode: 'physics_optics_option_refraction_bundle_unparsed' };
    }
    const correct = sameNumber(angle, model.refractionAngleDeg)
        && (model.refractionDirection === 'toward_normal' ? toward : away);
    return { optionId, verdict: correct ? 'true' : 'false', reasonCode: 'physics_optics_option_refraction_bundle_compared' };
}
function verificationScopeFor(questionPlan, model) {
    const plan = recordFrom(questionPlan);
    const constraints = recordFrom(plan?.renderConstraints);
    const contractPresent = Boolean(normalized(plan?.schemaVersion) === 'subject-practice-question-plan-v1'
        && normalized(plan?.policyVersion) === 'subject-practice-question-plan-policy-v1'
        && normalized(plan?.planTemplate) === 'physics_medium_optics_two_relation_v1'
        && normalized(plan?.taskFamily) === 'waves_optics_interference_refraction'
        && normalized(plan?.targetDifficulty) === 'medium'
        && constraints?.requireTextCompleteOpticalSetup === true
        && constraints?.requireTwoLinkedOpticalRelations === true
        && constraints?.forbidUnseenDiagramDependency === true
        && Number(constraints?.maxIndependentRelations) === 2);
    const planned = normalized(constraints?.exactPhysicsOpticsScope);
    const reasonCodes = [];
    if (!contractPresent)
        reasonCodes.push('physics_optics_scope_plan_contract_missing');
    if (contractPresent && !model)
        reasonCodes.push('physics_optics_scope_prompt_unparsed');
    if (contractPresent && model && planned !== model.scope)
        reasonCodes.push('physics_optics_scope_plan_prompt_mismatch');
    const matched = contractPresent && Boolean(model) && planned === model?.scope && reasonCodes.length === 0;
    return {
        scopeVersion: exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_SCOPE_VERSION,
        scopeId: contractPresent && model ? `physics-optics-two-relation-v1:${model.scope}` : null,
        status: !contractPresent ? 'missing_plan_contract' : matched ? 'matched' : 'mismatch',
        matched,
        opticsScope: model?.scope ?? null,
        reasonCodes
    };
}
function solveSubjectPracticePhysicsOptics(candidate, context = {}) {
    const model = parseModel(candidate.prompt);
    const verificationScope = verificationScopeFor(context.questionPlan, model);
    const optionVerdicts = model
        ? candidate.options.map((option) => optionVerdict(option.id, option.text, model))
        : candidate.options.map((option) => ({ optionId: option.id, verdict: 'unknown', reasonCode: 'physics_optics_prompt_unparsed' }));
    const hasUnknown = optionVerdicts.some((item) => item.verdict === 'unknown');
    const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
    const uniqueAnswer = !hasUnknown && trueOptionIds.length === 1;
    const selectedOptionId = uniqueAnswer ? trueOptionIds[0] : null;
    const agreesWithGenerator = uniqueAnswer && selectedOptionId === candidate.correctAnswer;
    const reasonCodes = [...verificationScope.reasonCodes];
    if (!model)
        reasonCodes.push('physics_optics_prompt_unparsed');
    if (hasUnknown)
        reasonCodes.push('physics_optics_option_unparsed');
    if (!hasUnknown && trueOptionIds.length !== 1)
        reasonCodes.push(trueOptionIds.length ? 'physics_optics_multiple_true_options' : 'physics_optics_no_true_option');
    if (uniqueAnswer && !agreesWithGenerator)
        reasonCodes.push('physics_optics_generator_answer_disagrees');
    const status = !model || hasUnknown ? 'unparsed'
        : uniqueAnswer && agreesWithGenerator && verificationScope.matched ? 'verified' : 'conflict';
    return {
        solverVersion: exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_SOLVER_VERSION,
        taskFamily: 'waves_optics_interference_refraction', status, parsed: Boolean(model) && !hasUnknown,
        opticsScope: model?.scope ?? null, canonicalTask: model, optionVerdicts, trueOptionIds, selectedOptionId,
        uniqueAnswer, agreesWithGenerator, evidenceBoundary: 'prompt_and_visible_options_only',
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only',
        reasonCodes: Array.from(new Set(reasonCodes)), verificationScope
    };
}
