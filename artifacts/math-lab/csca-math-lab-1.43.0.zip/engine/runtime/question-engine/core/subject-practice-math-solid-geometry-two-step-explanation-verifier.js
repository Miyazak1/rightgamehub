"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SOLID_GEOMETRY_TWO_STEP_EXPLANATION_VERSION = void 0;
exports.renderSolidGeometryTwoStepExplanation = renderSolidGeometryTwoStepExplanation;
exports.verifySubjectPracticeMathSolidGeometryTwoStepExplanation = verifySubjectPracticeMathSolidGeometryTwoStepExplanation;
const subject_practice_math_solid_geometry_two_step_solver_1 = require("./subject-practice-math-solid-geometry-two-step-solver");
exports.SOLID_GEOMETRY_TWO_STEP_EXPLANATION_VERSION = 'math-solid-geometry-two-step-explanation-v1-bound-bilingual';
function renderSolidGeometryTwoStepExplanation(p, answer, option) {
    const d = (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepDerive)(p);
    if (!d)
        throw Error('solid_geometry_two_step_invalid_explanation_parameters');
    const notes = {
        cuboid_volume_to_surface_area: ['先由体积求第三条棱长，再计入全部三对相对面的面积。', 'Recover the third edge from the volume, then count all three pairs of opposite faces.'],
        cuboid_surface_area_to_space_diagonal: ['先由总表面积解出第三条棱长，再应用两次勾股定理并取正平方根。', 'Recover the third edge from the total surface area, then apply the Pythagorean theorem twice and take the positive root.'],
        cylinder_volume_to_total_surface_area: ['先由体积求高，再将侧面积和两个底面积相加。', 'Recover the height from the volume, then add the lateral area and both base areas.'],
        cone_radius_height_to_lateral_area: ['先在轴截面内由勾股定理求正母线长度，再求展开扇形的面积；不计底面积。', 'Find the positive slant height in an axial section, then the area of the unfolded sector, excluding the base.']
    };
    return { zh: (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepPrompt)(p, 'zh') + ' ' + notes[p.scope][0] + ' ' + d.proof + '; result=' + answer + '。对应选项 ' + option + '。',
        en: (0, subject_practice_math_solid_geometry_two_step_solver_1.solidGeometryTwoStepPrompt)(p, 'en') + ' ' + notes[p.scope][1] + ' ' + d.proof + '; result=' + answer + '. Option ' + option + '.' };
}
function verifySubjectPracticeMathSolidGeometryTwoStepExplanation(candidate, context = {}) {
    const solved = (0, subject_practice_math_solid_geometry_two_step_solver_1.solveSubjectPracticeMathSolidGeometryTwoStep)(candidate, context), expected = solved.parameters && solved.expectedAnswer && solved.selectedOptionId ? renderSolidGeometryTwoStepExplanation(solved.parameters, solved.expectedAnswer, solved.selectedOptionId) : null;
    const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh), enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes = [];
    if (solved.status !== 'verified')
        reasonCodes.push('solid_geometry_two_step_explanation_solver_not_verified');
    if (!zhBound)
        reasonCodes.push('solid_geometry_two_step_explanation_zh_mismatch');
    if (!enBound)
        reasonCodes.push('solid_geometry_two_step_explanation_en_mismatch');
    return { verifierVersion: exports.SOLID_GEOMETRY_TWO_STEP_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solved.scopeId, zhBound, enBound, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
