"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathSetCompositeExplanation = verifySubjectPracticeMathSetCompositeExplanation;
const subject_practice_math_set_composite_solver_1 = require("./subject-practice-math-set-composite-solver");
exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_EXPLANATION_VERIFIER_VERSION = 'math-set-composite-explanation-verifier-v1';
function verifySubjectPracticeMathSetCompositeExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_set_composite_solver_1.solveSubjectPracticeMathSetComposite)(candidate, context);
    const explanation = String(candidate.explanation ?? '').replace(/[，]/g, ',');
    const expected = `{${(solver.expectedSet ?? []).join(',')}}`;
    const operationCount = (explanation.match(/并集|交集|差集|补集|union|intersection|difference|complement|∪|∩|\\/gi) ?? []).length;
    const conclusionVisible = explanation.replace(/\s+/g, '').includes(expected);
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_set_composite_explanation_primary_solver_not_verified');
    if (operationCount < 2)
        reasonCodes.push('math_set_composite_explanation_two_operations_missing');
    if (!conclusionVisible)
        reasonCodes.push('math_set_composite_explanation_conclusion_missing_or_wrong');
    return {
        verifierVersion: exports.SUBJECT_PRACTICE_MATH_SET_COMPOSITE_EXPLANATION_VERIFIER_VERSION,
        status: reasonCodes.length ? 'failed' : 'verified',
        scopeId: solver.scopeId, operationCount, conclusionVisible,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes
    };
}
