"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathSequenceExplanation = verifySubjectPracticeMathSequenceExplanation;
const subject_practice_math_sequence_solver_1 = require("./subject-practice-math-sequence-solver");
exports.SUBJECT_PRACTICE_MATH_SEQUENCE_EXPLANATION_VERIFIER_VERSION = 'math-sequence-explanation-verifier-v1-bilingual-parameter-bound';
function compact(value) { return String(value ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ''); }
function containsAssignment(text, label, value) { return new RegExp(`${label}=${String(value).replace('-', '\\-')}(?:[^0-9]|$)`, 'i').test(text); }
function verifySubjectPracticeMathSequenceExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_sequence_solver_1.solveSubjectPracticeMathSequence)(candidate, context);
    const p = solver.parameters;
    const zh = compact(candidate.localizations?.zh?.explanation ?? candidate.explanation);
    const en = compact(candidate.localizations?.en?.explanation);
    const expected = solver.expectedValue;
    const required = p
        ? [['a_?1', p.a1], ['n', p.n], p.d === null ? ['q', Number(p.q)] : ['d', Number(p.d)]]
        : [];
    const zhParametersBound = Boolean(p && required.every(([label, value]) => containsAssignment(zh, label, value)));
    const enParametersBound = Boolean(p && required.every(([label, value]) => containsAssignment(en, label, value)));
    const zhConclusionBound = expected !== null && new RegExp(`=${String(expected).replace('-', '\\-')}(?:[^0-9]|$)`).test(zh);
    const enConclusionBound = expected !== null && new RegExp(`=${String(expected).replace('-', '\\-')}(?:[^0-9]|$)`).test(en);
    const formulaBound = solver.exactScope?.startsWith('arithmetic_') ? /(n-1|n\/2|等差|arithmetic)/i.test(`${zh}${en}`) : /(q\^|公比|geometric)/i.test(`${zh}${en}`);
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_sequence_explanation_primary_solver_not_verified');
    if (!zhParametersBound)
        reasonCodes.push('math_sequence_explanation_zh_parameters_not_bound');
    if (!enParametersBound)
        reasonCodes.push('math_sequence_explanation_en_parameters_not_bound');
    if (!zhConclusionBound)
        reasonCodes.push('math_sequence_explanation_zh_conclusion_missing_or_wrong');
    if (!enConclusionBound)
        reasonCodes.push('math_sequence_explanation_en_conclusion_missing_or_wrong');
    if (!formulaBound)
        reasonCodes.push('math_sequence_explanation_formula_missing');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_SEQUENCE_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solver.scopeId, zhParametersBound, enParametersBound, zhConclusionBound, enConclusionBound, formulaBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
