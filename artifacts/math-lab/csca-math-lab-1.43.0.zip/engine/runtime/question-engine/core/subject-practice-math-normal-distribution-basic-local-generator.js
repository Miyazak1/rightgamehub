"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathNormalDistributionBasicLocalGenerator = createSubjectPracticeMathNormalDistributionBasicLocalGenerator;
const subject_practice_math_normal_distribution_basic_solver_1 = require("./subject-practice-math-normal-distribution-basic-solver");
const subject_practice_math_normal_distribution_basic_independent_oracle_1 = require("./subject-practice-math-normal-distribution-basic-independent-oracle");
const subject_practice_math_normal_distribution_basic_explanation_verifier_1 = require("./subject-practice-math-normal-distribution-basic-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_LOCAL_GENERATOR_VERSION = 'math-normal-distribution-basic-local-generator-v1-bounded-concepts';
function randomFor(seed) {
    let state = ((seed % 4294967296) ^ 0x6d2b79f5) || 0x9e3779b9;
    return (max) => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return (state >>> 0) % max; };
}
function render(p, english, alternate) {
    const start = english
        ? (alternate ? 'Assume X has' : 'Let X have') + ' a continuous normal distribution N(' + p.mu + ', ' + p.variance + '), where the second parameter is the variance. '
        : (alternate ? '已知' : '设') + '连续随机变量 X 服从正态分布 N(' + p.mu + ', ' + p.variance + ')，其中第二个参数为方差。';
    if (p.target === 'mean' || p.target === 'variance' || p.target === 'standard_deviation') {
        const word = p.target === 'mean' ? ['均值', 'mean'] : p.target === 'variance' ? ['方差', 'variance'] : ['正标准差', 'positive standard deviation'];
        return start + (english ? 'Find the ' + word[1] + ' of X.' : '求 X 的' + word[0] + '。');
    }
    if (p.target === 'z')
        return start + (english ? 'For the threshold x=' + p.x + ', find the standardized value z=(x-mu)/sigma.' : '对阈值 x=' + p.x + '，求标准化值 z=(x-mu)/sigma。');
    if (p.target === 'symmetry')
        return start + (english ? 'Find the probability P(X' + p.comparison + p.mu + ').' : '求概率 P(X' + p.comparison + p.mu + ')。');
    const event = p.target === 'central' ? p.lower + '<=X<=' + p.upper : p.target === 'outside' ? 'X<' + p.lower + (english ? ' or ' : ' 或 ') + 'X>' + p.upper : p.target === 'left' ? 'X<' + p.lower : 'X>' + p.upper;
    const rule = 'P(mu-' + p.k + '*sigma<=X<=mu+' + p.k + '*sigma)≈' + ['68', '95', '99.7'][p.k - 1] + '%';
    return start + (english ? 'Use the empirical approximation: ' + rule + '. Find the approximate probability of ' + event + '.' : '已知经验规律：' + rule + '。求事件 ' + event + ' 的近似概率。');
}
function candidateFor(b, scope, seed) {
    const random = randomFor(seed);
    for (let attempt = 0; attempt < 64; attempt++) {
        const mu = seed % 16 === 0 && attempt === 0 ? 0 : random(101) - 20;
        const sigma = seed % 16 === 0 && attempt === 0 ? 1 : random(12) + 1, variance = sigma * sigma;
        let p = { scope, mu, variance, sigma, target: 'mean' }, answer, alternatives = [];
        const add = (n, d, intent) => alternatives.push({ value: (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(n, d), intent });
        if (scope === 'normal_parameter_identification') {
            p.target = ['mean', 'variance', 'standard_deviation'][seed % 3];
            answer = (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(p.target === 'mean' ? mu : p.target === 'variance' ? variance : sigma);
            if (p.target === 'mean') {
                add(sigma, 1, 'reported_standard_deviation_as_mean');
                add(variance, 1, 'reported_variance_as_mean');
                add(-mu, 1, 'reversed_location_sign');
                add(mu - sigma, 1, 'reported_lower_one_sigma_bound');
                add(mu + 2 * sigma, 1, 'reported_upper_two_sigma_bound');
            }
            else if (p.target === 'variance') {
                add(sigma, 1, 'reported_standard_deviation_as_variance');
                add(-variance, 1, 'negative_variance');
                add(variance, 2, 'halved_variance');
                add(2 * sigma, 1, 'doubled_sigma_without_squaring');
            }
            else {
                add(variance, 1, 'omitted_square_root');
                add(-sigma, 1, 'negative_square_root');
                add(variance, 2, 'halved_variance_instead_of_root');
                add(mu, 1, 'reported_mean_as_standard_deviation');
                add(2 * sigma, 1, 'doubled_standard_deviation');
            }
        }
        else if (scope === 'normal_standardization_z_score') {
            const twiceZ = [-6, -4, -2, -1, 0, 1, 2, 4, 6][seed % 9], x = mu + sigma * twiceZ / 2;
            if (!Number.isInteger(x))
                continue;
            p = { ...p, target: 'z', x };
            answer = (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(x - mu, sigma);
            add(x - mu, variance, 'divided_by_variance');
            add(x, sigma, 'omitted_mean_centering');
            add(mu - x, sigma, 'reversed_centering_sign');
            add(x - mu, 1, 'omitted_standard_deviation_division');
            add(x + mu, sigma, 'added_mean_instead_of_subtracting');
            add(x - mu + sigma, sigma, 'shifted_standardized_origin');
            add(x - mu - sigma, sigma, 'subtracted_extra_standard_deviation');
        }
        else if (scope === 'normal_symmetry_probability') {
            p = { ...p, target: 'symmetry', x: mu, comparison: ['<', '<=', '>', '>='][seed % 4] };
            answer = (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(1, 2);
            add(0, 1, 'confused_half_line_with_point_mass');
            add(1, 1, 'used_whole_distribution_mass');
            add(1, 4, 'halved_one_side_twice');
        }
        else {
            const k = seed % 3 + 1, target = ['central', 'outside', 'left', 'right'][Math.floor(seed / 3) % 4];
            p = { ...p, target, k, lower: mu - k * sigma, upper: mu + k * sigma };
            const c = [680, 950, 997][k - 1], rest = 1000 - c;
            answer = target === 'central' ? (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(c, 1000) : (0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(rest, target === 'outside' ? 1000 : 2000);
            if (target !== 'central')
                add(c, 1000, 'used_central_interval_mass');
            if (target !== 'outside')
                add(rest, 1000, 'used_two_tail_mass');
            if (target !== 'left' && target !== 'right')
                add(rest, 2000, 'used_single_tail_mass');
            add(c, 2000, 'halved_central_mass');
            add(1000 + c, 2000, 'used_cumulative_upper_bound_mass');
        }
        const ordered = [{ value: answer, intent: '' }], seen = new Set([(0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(answer)]);
        for (const a of alternatives)
            if (!seen.has((0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(a.value))) {
                ordered.push(a);
                seen.add((0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(a.value));
                if (ordered.length === 4)
                    break;
            }
        if (ordered.length !== 4)
            continue;
        const correctAnswer = 'ABCD'[seed % 4], right = ordered.shift();
        ordered.splice(seed % 4, 0, right);
        const options = ordered.map((v, i) => ({ id: 'ABCD'[i], text: (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(v.value) }));
        const prompt = render(p, false, seed % 2 === 1), promptEn = render(p, true, seed % 2 === 1);
        // Generator equations are constructed independently of the explanation verifier.
        let equation;
        if (p.target === 'mean')
            equation = 'mu=' + mu;
        else if (p.target === 'variance')
            equation = 'sigma^2=' + variance;
        else if (p.target === 'standard_deviation')
            equation = 'sigma=sqrt(' + variance + ')=' + sigma + '>0';
        else if (p.target === 'z')
            equation = 'sigma=sqrt(' + variance + ')=' + sigma + '; z=(' + p.x + '-(' + mu + '))/' + sigma + '=' + (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(answer);
        else if (p.target === 'symmetry')
            equation = 'mu=' + mu + '; P(X' + p.comparison + mu + ')=1/2; P(X=' + mu + ')=0';
        else {
            const c = [680, 950, 997][p.k - 1], center = (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)((0, subject_practice_math_normal_distribution_basic_solver_1.normalRational)(c, 1000));
            equation = 'sigma=sqrt(' + variance + ')=' + sigma + '; L=' + mu + '-' + p.k + '*' + sigma + '=' + p.lower + '; U=' + mu + '+' + p.k + '*' + sigma + '=' + p.upper + '; central≈' + center;
            if (p.target === 'central')
                equation += '; P(L<=X<=U)≈' + (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(answer);
            else if (p.target === 'outside')
                equation += '; P(X<L or X>U)≈1-(' + center + ')=' + (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(answer);
            else
                equation += '; P(X' + (p.target === 'left' ? '<L' : '>U') + ')≈(1-(' + center + '))/2=' + (0, subject_practice_math_normal_distribution_basic_solver_1.normalRationalText)(answer);
        }
        const bound = 'N(' + mu + ', ' + variance + '); ';
        const zh = p.target === 'symmetry' ? '连续正态分布关于均值对称，均值处单点概率为零：' : scope === 'normal_empirical_interval_probability' ? '使用题给近似经验规律（不是精确正态积分值）：' : '按题中正态分布参数计算：';
        const en = p.target === 'symmetry' ? 'Continuity and symmetry about the mean give: ' : scope === 'normal_empirical_interval_probability' ? 'Using the stated empirical approximation, not an exact normal integral: ' : 'Using the stated normal parameters: ';
        const explanation = zh + bound + equation + '。对应选项 ' + correctAnswer + '。', explanationEn = en + bound + equation + '. Option ' + correctAnswer + '.';
        return { subject: 'math', topicId: b.topicId, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options, correctAnswer, explanation,
            knowledgeTags: ['正态分布的基本概念', scope], optionMetadata: ordered.flatMap((v, i) => v.intent ? [{ optionId: 'ABCD'[i], distractorIntent: v.intent, misconceptionTags: [v.intent] }] : []),
            localizations: { zh: { prompt, options, explanation, knowledgeTags: ['正态分布'] }, en: { prompt: promptEn, options, explanation: explanationEn, knowledgeTags: ['Normal distribution'] } }, syllabusVersion: b.syllabusVersion };
    }
    throw new Error('math_normal_basic_bounded_generation_exhausted');
}
function createSubjectPracticeMathNormalDistributionBasicLocalGenerator(ports) {
    return (input) => {
        const seed = Number.isSafeInteger(input.seed) ? Math.abs(input.seed) : 0, exactScope = (0, subject_practice_math_normal_distribution_basic_solver_1.normalScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.SUBJECT_PRACTICE_MATH_NORMAL_DISTRIBUTION_BASIC_LOCAL_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        if (!exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 77 || b.topicCode !== 'M-STAT-002' || b.difficulty !== 'basic' || b.questionType !== 'single_choice')
            return { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['math_normal_basic_local_generator_question_plan_not_supported'] };
        const candidate = candidateFor(b, exactScope, seed), context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_normal_distribution_basic_solver_1.solveSubjectPracticeMathNormalDistributionBasic)(candidate, context), oracleEvidence = (0, subject_practice_math_normal_distribution_basic_independent_oracle_1.verifySubjectPracticeMathNormalDistributionBasicWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_normal_distribution_basic_explanation_verifier_1.verifySubjectPracticeMathNormalDistributionBasicExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
            reasonCodes: verified ? [] : ['math_normal_basic_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
