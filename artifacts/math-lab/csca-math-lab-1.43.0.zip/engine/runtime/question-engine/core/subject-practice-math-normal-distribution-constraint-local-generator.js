"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NORMAL_DISTRIBUTION_CONSTRAINT_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathNormalDistributionConstraintLocalGenerator = createSubjectPracticeMathNormalDistributionConstraintLocalGenerator;
const subject_practice_math_normal_distribution_constraint_solver_1 = require("./subject-practice-math-normal-distribution-constraint-solver");
const subject_practice_math_normal_distribution_constraint_independent_oracle_1 = require("./subject-practice-math-normal-distribution-constraint-independent-oracle");
const subject_practice_math_normal_distribution_constraint_explanation_verifier_1 = require("./subject-practice-math-normal-distribution-constraint-explanation-verifier");
exports.NORMAL_DISTRIBUTION_CONSTRAINT_GENERATOR_VERSION = 'math-normal-distribution-constraint-generator-v1-bounded';
function createSubjectPracticeMathNormalDistributionConstraintLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0, scope = (0, subject_practice_math_normal_distribution_constraint_solver_1.normalDistributionConstraintScopeFrom)(input.questionPlan), b = input.blueprint, common = { generatorVersion: exports.NORMAL_DISTRIBUTION_CONSTRAINT_GENERATOR_VERSION, seed, exactScope: scope, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false }, unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['normal_distribution_constraint_local_plan_not_supported'] };
        if (!validSeed || !scope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 77 || b.topicCode !== 'M-STAT-002' || b.difficulty !== 'hard' || b.questionType !== 'single_choice')
            return unsupported;
        for (let attempt = 0; attempt < 256; attempt++) {
            const i = subject_practice_math_normal_distribution_constraint_solver_1.NORMAL_DISTRIBUTION_CONSTRAINT_SCOPES.indexOf(scope);
            let state = ((seed + 1) * 2654435761 + attempt * 2246822519) >>> 0;
            const next = (max) => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return (state >>> 0) % max; };
            const mu = next(61) - 20, sigma = 2 + next(7);
            let data;
            const intervals = [[-2, -1], [-2, 0], [-2, 1], [-2, 2], [-1, 0], [-1, 1], [-1, 2], [0, 1], [0, 2], [1, 2]];
            if (i === 0) {
                const known = intervals[next(intervals.length)], event = intervals[next(intervals.length)];
                if (known[0] === event[0] && known[1] === event[1])
                    continue;
                data = [mu + known[0] * sigma, known[0], mu + known[1] * sigma, known[1], mu + event[0] * sigma, mu + event[1] * sigma].map(String);
            }
            else if (i === 1) {
                const a = [-3, -2, 2, 3][seed % 4], b = next(25) - 12, event = intervals[next(intervals.length)];
                if (event[0] + event[1] === 0)
                    continue;
                const c = (0, subject_practice_math_normal_distribution_constraint_solver_1.sq)(2 * (a * mu + b) + a * sigma * (event[0] + event[1]), 2), r = (0, subject_practice_math_normal_distribution_constraint_solver_1.sq)(Math.abs(a) * sigma * (event[1] - event[0]), 2);
                data = [String(mu), String(sigma * sigma), String(a), String(b), (0, subject_practice_math_normal_distribution_constraint_solver_1.stxt)(c), (0, subject_practice_math_normal_distribution_constraint_solver_1.stxt)(r)];
            }
            else if (i === 2) {
                const A = intervals[next(10)], B = intervals[next(10)], C = intervals[next(10)];
                data = [mu, sigma * sigma, ...A.concat(B, C).map(z => mu + sigma * z)].map(String);
            }
            else {
                const a = [-3, -2, 2, 3][seed % 4], b = next(25) - 12, pair = [[1, 3], [2, 1], [2, 3], [3, 1], [3, 2]][seed % 5], tails = ['4/25', '1/40', '3/2000'];
                data = [String(mu), String(sigma * sigma), String(a), String(b), tails[pair[0] - 1], tails[pair[1] - 1]];
            }
            const p = { scope, data }, d = (0, subject_practice_math_normal_distribution_constraint_solver_1.normalDistributionConstraintDerive)(p);
            if (!d)
                continue;
            const choices = d.errors.map(e => ({ text: e.text, intent: e.intent })), correctAnswer = 'ABCD'[Math.floor(seed / 4) % 4];
            choices.splice('ABCD'.indexOf(correctAnswer), 0, { text: d.answer, intent: '' });
            const options = choices.map((e, j) => ({ id: 'ABCD'[j], text: e.text })), prompt = (0, subject_practice_math_normal_distribution_constraint_solver_1.normalDistributionConstraintPrompt)(p, 'zh'), enPrompt = (0, subject_practice_math_normal_distribution_constraint_solver_1.normalDistributionConstraintPrompt)(p, 'en'), explanation = (0, subject_practice_math_normal_distribution_constraint_explanation_verifier_1.renderNormalDistributionConstraintExplanation)(p, d.answer, correctAnswer), tags = ['正态分布的基本概念', '多条件标准化与概率区间推理', scope];
            const candidate = { subject: 'math', topicId: 77, blueprintId: input.blueprint.id, sourceType: 'ai', designedDifficulty: 'hard', questionType: 'single_choice', prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: tags, optionMetadata: choices.flatMap((e, j) => e.intent ? [{ optionId: 'ABCD'[j], distractorIntent: e.intent, misconceptionTags: [e.intent] }] : []), localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: tags }, en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Normal distribution', 'Constrained standardization and probability', scope] } }, syllabusVersion: input.blueprint.syllabusVersion };
            const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_normal_distribution_constraint_solver_1.solveSubjectPracticeMathNormalDistributionConstraint)(candidate, context), oracleEvidence = (0, subject_practice_math_normal_distribution_constraint_independent_oracle_1.verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_normal_distribution_constraint_explanation_verifier_1.verifySubjectPracticeMathNormalDistributionConstraintExplanation)(candidate, context), adherence = ports.adherenceFor(input.questionPlan, candidate), verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.expectedAnswer === oracleEvidence.expectedAnswer && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
            return { ...common, parameterAttempts: attempt + 1, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null, reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
        }
        return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts: 256 };
    };
}
