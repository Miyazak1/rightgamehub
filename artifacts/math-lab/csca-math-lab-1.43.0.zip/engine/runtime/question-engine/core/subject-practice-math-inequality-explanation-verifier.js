"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathInequalityExplanation = verifySubjectPracticeMathInequalityExplanation;
const subject_practice_math_inequality_solver_1 = require("./subject-practice-math-inequality-solver");
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_EXPLANATION_VERIFIER_VERSION = 'math-inequality-explanation-verifier-v1';
function verifySubjectPracticeMathInequalityExplanation(candidate, context = {}) {
    const solver = (0, subject_practice_math_inequality_solver_1.solveSubjectPracticeMathInequality)(candidate, context);
    const explanation = String(candidate.explanation ?? '').replace(/[≥]/g, '>=').replace(/[≤]/g, '<=').replace(/\s+/g, '');
    const answer = solver.parsedPrompt ? `x${solver.parsedPrompt.answerRelation}${solver.parsedPrompt.boundary}` : '';
    const operationVisible = /(移项|除以|不等号|divide|inequality sign|isolate x)/i.test(explanation);
    const signRuleVisible = solver.parsedPrompt?.coefficient && solver.parsedPrompt.coefficient < 0 ? /(改变方向|方向改变|reverse|flip)/i.test(explanation) : true;
    const conclusionVisible = Boolean(answer && explanation.includes(answer));
    const reasonCodes = [];
    if (solver.status !== 'verified')
        reasonCodes.push('math_inequality_explanation_primary_solver_not_verified');
    if (!operationVisible)
        reasonCodes.push('math_inequality_explanation_operation_missing');
    if (!signRuleVisible)
        reasonCodes.push('math_inequality_explanation_negative_divisor_sign_rule_missing');
    if (!conclusionVisible)
        reasonCodes.push('math_inequality_explanation_conclusion_missing_or_wrong');
    return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solver.scopeId, operationVisible, signRuleVisible, conclusionVisible, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
