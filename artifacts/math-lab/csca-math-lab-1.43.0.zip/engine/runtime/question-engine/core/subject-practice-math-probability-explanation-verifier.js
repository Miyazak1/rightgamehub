"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticeMathProbabilityExplanation = verifySubjectPracticeMathProbabilityExplanation;
const subject_practice_math_probability_solver_1 = require("./subject-practice-math-probability-solver");
exports.SUBJECT_PRACTICE_MATH_PROBABILITY_EXPLANATION_VERIFIER_VERSION = 'math-probability-explanation-verifier-v1-bilingual-parameter-bound';
function compact(v) { return String(v ?? '').replace(/[−–—]/g, '-').replace(/\s+/g, ''); }
function valueText(v) { return v ? `${v.numerator}${v.denominator === 1 ? '' : `/${v.denominator}`}` : ''; }
function verifySubjectPracticeMathProbabilityExplanation(candidate, context = {}) { const solver = (0, subject_practice_math_probability_solver_1.solveSubjectPracticeMathProbability)(candidate, context), p = solver.parameters, zh = compact(candidate.localizations?.zh?.explanation ?? candidate.explanation), en = compact(candidate.localizations?.en?.explanation), required = Object.entries(p ?? {}).filter(([k]) => !['favorable', 'total'].includes(k)).map(([, v]) => String(v)), zhParametersBound = Boolean(p && required.every(v => zh.includes(v))), enParametersBound = Boolean(p && required.every(v => en.includes(v))), expected = valueText(solver.expectedValue), zhConclusionBound = Boolean(expected && zh.includes(expected)), enConclusionBound = Boolean(expected && en.includes(expected)), formulaBound = /(有利结果数.*总结果数|favorable.*total|P\s*=)/i.test(`${zh}${en}`), countBound = Boolean(p && zh.includes(String(p.favorable)) && zh.includes(String(p.total)) && en.includes(String(p.favorable)) && en.includes(String(p.total))), reasonCodes = []; if (solver.status !== 'verified')
    reasonCodes.push('math_probability_explanation_primary_solver_not_verified'); if (!zhParametersBound)
    reasonCodes.push('math_probability_explanation_zh_parameters_not_bound'); if (!enParametersBound)
    reasonCodes.push('math_probability_explanation_en_parameters_not_bound'); if (!countBound)
    reasonCodes.push('math_probability_explanation_counts_not_bound'); if (!zhConclusionBound)
    reasonCodes.push('math_probability_explanation_zh_conclusion_missing_or_wrong'); if (!enConclusionBound)
    reasonCodes.push('math_probability_explanation_en_conclusion_missing_or_wrong'); if (!formulaBound)
    reasonCodes.push('math_probability_explanation_formula_missing'); return { verifierVersion: exports.SUBJECT_PRACTICE_MATH_PROBABILITY_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' : 'verified', scopeId: solver.scopeId, zhParametersBound, enParametersBound, countBound, zhConclusionBound, enConclusionBound, formulaBound, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes }; }
