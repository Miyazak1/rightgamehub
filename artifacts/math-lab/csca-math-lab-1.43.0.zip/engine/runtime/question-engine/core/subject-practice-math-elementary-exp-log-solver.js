"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.elThreshold = exports.elAffine = exports.elBase = exports.elShowInterval = exports.elPower = exports.elShow = exports.elCmp = exports.elMul = exports.elAdd = exports.ELEMENTARY_EXP_LOG_CONSTRAINTS = exports.ELEMENTARY_EXP_LOG_SCOPES = exports.ELEMENTARY_EXP_LOG_SCOPE_VERSION = exports.ELEMENTARY_EXP_LOG_SOLVER_VERSION = exports.ELEMENTARY_EXP_LOG_TEMPLATE = exports.ELEMENTARY_EXP_LOG_FAMILY = void 0;
exports.elRat = elRat;
exports.elParseRational = elParseRational;
exports.elCompareBounds = elCompareBounds;
exports.elParseInterval = elParseInterval;
exports.elementaryExpLogScopeFrom = elementaryExpLogScopeFrom;
exports.elementaryExpLogPrompt = elementaryExpLogPrompt;
exports.elementaryExpLogParametersFrom = elementaryExpLogParametersFrom;
exports.elInequalityInterval = elInequalityInterval;
exports.elementaryExpLogAnswer = elementaryExpLogAnswer;
exports.elementaryExpLogDistractors = elementaryExpLogDistractors;
exports.elementaryExpLogOptionKey = elementaryExpLogOptionKey;
exports.solveSubjectPracticeMathElementaryExpLog = solveSubjectPracticeMathElementaryExpLog;
exports.ELEMENTARY_EXP_LOG_FAMILY = 'math_elementary_exp_log_relation_reasoning';
exports.ELEMENTARY_EXP_LOG_TEMPLATE = exports.ELEMENTARY_EXP_LOG_FAMILY + '_v1';
exports.ELEMENTARY_EXP_LOG_SOLVER_VERSION = 'math-elementary-exp-log-solver-v1-exact-rational';
exports.ELEMENTARY_EXP_LOG_SCOPE_VERSION = 'math-medium-elementary-exp-log-v1';
exports.ELEMENTARY_EXP_LOG_SCOPES = ['exponential_common_base_linear_equation', 'logarithmic_affine_argument_equation',
    'exponential_affine_closed_interval_range', 'logarithmic_affine_inequality'];
exports.ELEMENTARY_EXP_LOG_CONSTRAINTS = { topicCode: 'M-FUNC-002', boundedIntegerParameters: true,
    exactRationalArithmetic: true, baseIntegerOrReciprocal: true, maximumBaseInteger: 5, maximumEndpointExponent: 8,
    externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
const obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function elRat(n, d = 1) {
    let a = BigInt(n), b = BigInt(d);
    if (!b)
        throw new Error('exp_log_zero_denominator');
    if (b < 0n) {
        a = -a;
        b = -b;
    }
    let x = a < 0n ? -a : a, y = b;
    while (y) {
        const t = x % y;
        x = y;
        y = t;
    }
    return { n: a / x, d: b / x };
}
const elAdd = (a, b) => elRat(a.n * b.d + b.n * a.d, a.d * b.d);
exports.elAdd = elAdd;
const elMul = (a, b) => elRat(a.n * b.n, a.d * b.d);
exports.elMul = elMul;
const elCmp = (a, b) => { const x = a.n * b.d - b.n * a.d; return x < 0n ? -1 : x > 0n ? 1 : 0; };
exports.elCmp = elCmp;
const elShow = (a) => String(a.n) + (a.d === 1n ? '' : '/' + a.d);
exports.elShow = elShow;
const elPower = (p, e) => {
    const exponent = p.reciprocal ? -e : e, value = BigInt(p.q) ** BigInt(Math.abs(exponent));
    return exponent >= 0 ? elRat(value) : elRat(1, value);
};
exports.elPower = elPower;
function elParseRational(text) {
    if (!/^[+-]?\d{1,10}(?:\/\d{1,10})?$/.test(text.trim()))
        return null;
    const [n, d = '1'] = text.trim().split('/');
    if (!BigInt(d))
        return null;
    const v = elRat(BigInt(n), BigInt(d));
    return v.n < -1000000000n || v.n > 1000000000n || v.d > 1000000000n ? null : v;
}
const showBound = (x) => typeof x === 'string' ? x : (0, exports.elShow)(x);
function elCompareBounds(a, b) {
    if (a === b)
        return 0;
    if (a === '-inf' || b === '+inf')
        return -1;
    if (a === '+inf' || b === '-inf')
        return 1;
    return (0, exports.elCmp)(a, b);
}
const elShowInterval = (i) => (i.lc ? '[' : '(') + showBound(i.lo) + ', ' + showBound(i.hi) + (i.rc ? ']' : ')');
exports.elShowInterval = elShowInterval;
function elParseInterval(text) {
    const m = text.trim().match(/^([\[(])\s*([^,]+),\s*([^\])]+)([\])])$/);
    if (!m)
        return null;
    const bound = (s) => ['-inf', '+inf'].includes(s.trim()) ? s.trim() : elParseRational(s);
    const lo = bound(m[2]), hi = bound(m[3]), lc = m[1] === '[', rc = m[4] === ']';
    return !lo || !hi || elCompareBounds(lo, hi) >= 0 || typeof lo === 'string' && lc || typeof hi === 'string' && rc ? null : { lo, hi, lc, rc };
}
function elementaryExpLogScopeFrom(value) {
    const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactElementaryExpLogScope;
    return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p?.subject === 'math' && p?.topicId === 69 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
        && p?.taskFamily === exports.ELEMENTARY_EXP_LOG_FAMILY && p?.planTemplate === exports.ELEMENTARY_EXP_LOG_TEMPLATE && r?.questionType === 'single_choice'
        && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'elementary_exp_log_object' && s?.scenarioAction === scope
        && Object.entries(exports.ELEMENTARY_EXP_LOG_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && exports.ELEMENTARY_EXP_LOG_SCOPES.includes(scope) ? scope : null;
}
const elBase = (p) => p.reciprocal ? '1/' + p.q : String(p.q);
exports.elBase = elBase;
const elAffine = (p) => p.a + '*x+(' + p.c + ')';
exports.elAffine = elAffine;
function elementaryExpLogPrompt(p, lang, alternate = false) {
    const zh = lang === 'zh', start = zh ? (alternate ? '考虑 ' : '已知 ') : (alternate ? 'Consider ' : 'Given ');
    const base = '(' + (0, exports.elBase)(p) + ')', affine = (0, exports.elAffine)(p);
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[0])
        return start + base + '^(' + affine + ')=(' + base + '^' + p.k + ')^(' + p.r + ')'
            + (zh ? '。先化为同底幂，再求实数 x。' : '. Convert to a common base, then solve for real x.');
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[1])
        return start + 'log_' + base + '(' + affine + ')=' + p.r
            + (zh ? '。先确定真数为正的条件，再用指数关系求实数 x 并检验。' : '. Require a positive argument, then use the exponential relation to solve for real x and check it.');
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[2])
        return start + 'f(x)=' + base + '^(' + affine + ')+(' + p.d + '), x in [' + p.l + ', ' + p.u + ']'
            + (zh ? '。结合复合单调方向和端点值，求闭区间上的值域。' : '. Use composite monotonicity and endpoint values to find the range on this closed interval.');
    return start + 'log_' + base + '(' + affine + ')' + p.op + p.r
        + (zh ? '。先确定真数为正的条件，再按底数与系数的符号求实数解集。' : '. Require a positive argument, then use the base and coefficient signs to find the real solution set.');
}
function elementaryExpLogParametersFrom(text, scope, lang) {
    if (!scope || typeof text !== 'string' || text.length > 1000)
        return null;
    const body = text.replace(/^(已知 |考虑 |Given |Consider )/, '').split(lang === 'zh' ? '。' : '. ')[0];
    const eq = scope === exports.ELEMENTARY_EXP_LOG_SCOPES[0], range = scope === exports.ELEMENTARY_EXP_LOG_SCOPES[2];
    const m = body.match(eq ? /^\((1\/)?(\d+)\)\^\((-?\d+)\*x\+\((-?\d+)\)\)=\(\((1\/)?(\d+)\)\^(\d+)\)\^\((-?\d+)\)$/
        : range ? /^f\(x\)=\((1\/)?(\d+)\)\^\((-?\d+)\*x\+\((-?\d+)\)\)\+\((-?\d+)\), x in \[(-?\d+), (-?\d+)\]$/
            : /^log_\((1\/)?(\d+)\)\((-?\d+)\*x\+\((-?\d+)\)\)(=|<=|>=|<|>)(-?\d+)$/);
    if (!m)
        return null;
    const q = Number(m[2]), reciprocal = Boolean(m[1]), a = Number(m[3]), c = Number(m[4]);
    const p = { scope, q, reciprocal, a, c, k: eq ? Number(m[7]) : 0, r: eq ? Number(m[8]) : range ? 0 : Number(m[6]),
        d: range ? Number(m[5]) : 0, l: range ? Number(m[6]) : 0, u: range ? Number(m[7]) : 0, op: !range && !eq && m[5] !== '=' ? m[5] : '<' };
    if (![q, a, c, p.k, p.r, p.d, p.l, p.u].every(Number.isSafeInteger) || ![2, 3, 4, 5].includes(q) || !a)
        return null;
    if (eq || scope === exports.ELEMENTARY_EXP_LOG_SCOPES[1]) {
        if (Math.abs(a) < 2 || Math.abs(a) > 4 || !c || Math.abs(c) > 4 || Math.abs(p.r) > 3)
            return null;
        if (eq && (Boolean(m[5]) !== reciprocal || Number(m[6]) !== q || ![2, 3].includes(p.k) || !p.r || Math.abs(p.k * p.r) > 8))
            return null;
        if (!eq && m[5] !== '=')
            return null;
    }
    else if (range) {
        if (Math.abs(a) > 3 || Math.abs(c) > 3 || Math.abs(p.d) > 4 || Math.abs(p.l) > 3 || Math.abs(p.u) > 3 || p.l >= p.u
            || Math.abs(a * p.l + c) > 8 || Math.abs(a * p.u + c) > 8)
            return null;
    }
    else if (Math.abs(a) > 4 || Math.abs(c) > 4 || Math.abs(p.r) > 3 || m[5] === '=')
        return null;
    return [false, true].some(alt => elementaryExpLogPrompt(p, lang, alt) === text) ? p : null;
}
const elThreshold = (p, power = (0, exports.elPower)(p, p.r)) => (0, exports.elMul)((0, exports.elAdd)(power, elRat(-p.c)), elRat(1, p.a));
exports.elThreshold = elThreshold;
function elInequalityInterval(p) {
    const zero = elRat(-p.c, p.a), threshold = (0, exports.elThreshold)(p), argumentGreater = p.op.startsWith('>') !== p.reciprocal, closed = p.op.endsWith('=');
    if (argumentGreater)
        return p.a > 0 ? { lo: threshold, hi: '+inf', lc: closed, rc: false } : { lo: '-inf', hi: threshold, lc: false, rc: closed };
    return p.a > 0 ? { lo: zero, hi: threshold, lc: false, rc: closed } : { lo: threshold, hi: zero, lc: closed, rc: false };
}
function elementaryExpLogAnswer(p) {
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[0])
        return (0, exports.elShow)(elRat(p.k * p.r - p.c, p.a));
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[1])
        return (0, exports.elShow)((0, exports.elThreshold)(p));
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[3])
        return (0, exports.elShowInterval)(elInequalityInterval(p));
    const ends = [p.l, p.u].map(x => (0, exports.elAdd)((0, exports.elPower)(p, p.a * x + p.c), elRat(p.d))).sort(exports.elCmp);
    return (0, exports.elShowInterval)({ lo: ends[0], hi: ends[1], lc: true, rc: true });
}
function elementaryExpLogDistractors(p) {
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[0])
        return [
            { key: (0, exports.elShow)(elRat(p.k + p.r - p.c, p.a)), intent: 'add_instead_of_multiply_nested_exponents' },
            { key: (0, exports.elShow)(elRat(p.k * p.r + p.c, p.a)), intent: 'wrong_sign_moving_intercept' },
            { key: (0, exports.elShow)(elRat(p.k * p.r - p.c)), intent: 'omit_division_by_affine_coefficient' }
        ];
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[1])
        return [
            { key: (0, exports.elShow)((0, exports.elThreshold)(p, (0, exports.elMul)((0, exports.elPower)(p, 1), elRat(p.r)))), intent: 'multiply_base_by_log_value' },
            { key: (0, exports.elShow)((0, exports.elMul)((0, exports.elAdd)((0, exports.elPower)(p, p.r), elRat(p.c)), elRat(1, p.a))), intent: 'wrong_sign_moving_intercept' },
            { key: (0, exports.elShow)((0, exports.elAdd)((0, exports.elPower)(p, p.r), elRat(-p.c))), intent: 'omit_division_by_affine_coefficient' }
        ];
    if (p.scope === exports.ELEMENTARY_EXP_LOG_SCOPES[2]) {
        const interval = elParseInterval(elementaryExpLogAnswer(p));
        return [{ key: elementaryExpLogAnswer({ ...p, d: 0 }), intent: 'omit_vertical_translation' },
            { key: elementaryExpLogAnswer({ ...p, d: -p.d }), intent: 'reverse_vertical_translation' },
            { key: (0, exports.elShowInterval)({ ...interval, lc: false, rc: false }), intent: 'exclude_attained_endpoint_values' }];
    }
    const reverse = { '<': '>', '>': '<', '<=': '>=', '>=': '<=' };
    const flipClosure = { '<': '<=', '<=': '<', '>': '>=', '>=': '>' };
    return [{ key: (0, exports.elShowInterval)(elInequalityInterval({ ...p, op: reverse[p.op] })), intent: 'reverse_logarithmic_order' },
        { key: (0, exports.elShowInterval)(elInequalityInterval({ ...p, op: flipClosure[p.op] })), intent: 'wrong_threshold_inclusion' },
        { key: (0, exports.elShowInterval)(elInequalityInterval({ ...p, r: p.r + 1 })), intent: 'use_log_value_plus_one_as_threshold' }];
}
function elementaryExpLogOptionKey(text, scope) {
    if (scope === exports.ELEMENTARY_EXP_LOG_SCOPES[0] || scope === exports.ELEMENTARY_EXP_LOG_SCOPES[1]) {
        const q = elParseRational(text);
        return q ? (0, exports.elShow)(q) : null;
    }
    const i = elParseInterval(text);
    return i ? (0, exports.elShowInterval)(i) : null;
}
function solveSubjectPracticeMathElementaryExpLog(candidate, context = {}) {
    const exactScope = elementaryExpLogScopeFrom(context.questionPlan), parameters = elementaryExpLogParametersFrom(candidate.prompt, exactScope, 'zh'), reasonCodes = [];
    if (!parameters)
        reasonCodes.push('elementary_exp_log_prompt_or_plan_outside_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 69 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('elementary_exp_log_identity_mismatch');
    const options = candidate.options ?? [], keys = options.map(o => exactScope ? elementaryExpLogOptionKey(o.text, exactScope) : null);
    for (const lang of ['zh', 'en']) {
        const loc = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(elementaryExpLogParametersFrom(loc?.prompt ?? '', exactScope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('elementary_exp_log_' + lang + '_prompt_mismatch');
        if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, exactScope ? elementaryExpLogOptionKey(o.text, exactScope) : null])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]])))
            reasonCodes.push('elementary_exp_log_' + lang + '_options_mismatch');
    }
    const expectedAnswer = parameters ? elementaryExpLogAnswer(parameters) : null;
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('elementary_exp_log_invalid_or_duplicate_options');
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' : keys[i] === expectedAnswer ? 'true' : 'false' }));
    const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('elementary_exp_log_answer_disagreement');
    const wrong = parameters ? elementaryExpLogDistractors(parameters) : [], metadata = candidate.optionMetadata ?? [];
    if (metadata.length !== 3 || new Set(metadata.map(x => x.optionId)).size !== 3 || new Set(metadata.map(x => x.distractorIntent)).size !== 3
        || metadata.some(x => x.optionId === selectedOptionId || !wrong.some(w => w.intent === x.distractorIntent && w.key === keys[options.findIndex(o => o.id === x.optionId)])))
        reasonCodes.push('elementary_exp_log_distractor_intent_mismatch');
    const scopeId = parameters ? exports.ELEMENTARY_EXP_LOG_SCOPE_VERSION + ':' + exactScope : null;
    return { solverVersion: exports.ELEMENTARY_EXP_LOG_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified',
        taskFamily: exports.ELEMENTARY_EXP_LOG_FAMILY, scopeId, exactScope, parameters, expectedAnswer, optionVerdicts, trueOptionIds, selectedOptionId,
        verificationScope: { scopeVersion: exports.ELEMENTARY_EXP_LOG_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope, reasonCodes: parameters ? [] : ['elementary_exp_log_scope_not_matched'] },
        uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
