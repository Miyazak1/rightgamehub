"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_LOCAL_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathBasicFunctionLocalGenerator = createSubjectPracticeMathBasicFunctionLocalGenerator;
const subject_practice_math_basic_function_solver_1 = require("./subject-practice-math-basic-function-solver");
const subject_practice_math_basic_function_independent_oracle_1 = require("./subject-practice-math-basic-function-independent-oracle");
const subject_practice_math_basic_function_explanation_verifier_1 = require("./subject-practice-math-basic-function-explanation-verifier");
exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_LOCAL_GENERATOR_VERSION = 'math-basic-function-local-generator-v1';
const SCOPES = new Set(['linear_monotonicity', 'quadratic_axis', 'rational_domain_exclusion', 'polynomial_parity']);
function objectFrom(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : null; }
function clean(value) { return String(value ?? '').trim(); }
function seedFrom(value) { const number = Number(value); return Number.isFinite(number) ? Math.abs(Math.trunc(number)) : 0; }
function scopeFrom(planValue, validate) {
    const plan = objectFrom(planValue);
    const render = objectFrom(plan?.renderConstraints);
    const scope = clean(render?.exactBasicFunctionScope);
    return validate(planValue).valid && clean(plan?.taskFamily) === 'math_basic_function_property'
        && clean(plan?.planTemplate) === 'math_basic_function_property_v1' && SCOPES.has(scope) ? scope : null;
}
function signed(value) { return value >= 0 ? `+${value}` : String(value); }
function shifted(variable, root) { return root >= 0 ? `${variable}-${root}` : `${variable}+${Math.abs(root)}`; }
function choices(values, correctIndex) {
    const correct = values[0];
    const ordered = values.slice(1);
    ordered.splice(correctIndex, 0, correct);
    const ids = ['A', 'B', 'C', 'D'];
    return {
        zh: ordered.map((value, index) => ({ id: ids[index], text: value.zh })),
        en: ordered.map((value, index) => ({ id: ids[index], text: value.en })),
        correctAnswer: ids[correctIndex],
        metadata: ordered.flatMap((value, index) => index === correctIndex ? [] : [{ optionId: ids[index], distractorIntent: value.intent, misconceptionTags: [value.intent] }])
    };
}
function candidateFor(blueprint, seed, scope) {
    const correctIndex = seed % 4;
    let prompt = '';
    let promptEn = '';
    let explanation = '';
    let explanationEn = '';
    let answerChoices;
    let tags;
    if (scope === 'linear_monotonicity') {
        const slope = [2, 3, 4, 5, -2, -3, -4, -5][seed % 8];
        const intercept = (Math.floor(seed / 8) % 17) - 8;
        const correct = slope > 0 ? { zh: '在 R 上单调递增', en: 'Increasing on R', intent: 'correct_monotonicity' } : { zh: '在 R 上单调递减', en: 'Decreasing on R', intent: 'correct_monotonicity' };
        const reverse = slope > 0 ? { zh: '在 R 上单调递减', en: 'Decreasing on R', intent: 'reversed_slope_sign' } : { zh: '在 R 上单调递增', en: 'Increasing on R', intent: 'reversed_slope_sign' };
        answerChoices = choices([correct, reverse, { zh: '是常数函数', en: 'It is a constant function', intent: 'ignored_nonzero_slope' }, { zh: '在 R 上不具有单调性', en: 'It is not monotonic on R', intent: 'confused_linear_with_turning_function' }], correctIndex);
        prompt = `已知一次函数 f(x)=${slope}x${signed(intercept)}，判断它在 R 上的单调性。`;
        promptEn = `For the linear function f(x)=${slope}x${signed(intercept)}, determine its monotonicity on R.`;
        explanation = `一次函数的斜率为 ${slope}。斜率${slope > 0 ? '大于' : '小于'} 0，所以函数在 R 上单调${slope > 0 ? '递增' : '递减'}。`;
        explanationEn = `The slope is ${slope}. Since it is ${slope > 0 ? 'positive' : 'negative'}, the function is ${slope > 0 ? 'increasing' : 'decreasing'} on R.`;
        tags = ['函数', '一次函数', '单调性'];
    }
    else if (scope === 'quadratic_axis') {
        const coefficient = [1, 2, 3, -1, -2, -3][seed % 6];
        const axis = (Math.floor(seed / 6) % 15) - 7;
        const offset = (Math.floor(seed / 90) % 13) - 6;
        const alternatives = [axis, axis + 1, -axis || 2, axis - 2].filter((value, index, all) => all.indexOf(value) === index);
        while (alternatives.length < 4)
            alternatives.push(axis + alternatives.length + 2);
        answerChoices = choices(alternatives.slice(0, 4).map((value, index) => ({ zh: `x=${value}`, en: `x=${value}`, intent: index === 0 ? 'correct_axis' : index === 1 ? 'used_vertical_shift' : index === 2 ? 'reversed_horizontal_shift' : 'arithmetic_shift_error' })), correctIndex);
        prompt = `已知二次函数 f(x)=${coefficient}(${shifted('x', axis)})^2${signed(offset)}，下列关于其对称轴的判断正确的是？`;
        promptEn = `For the quadratic function f(x)=${coefficient}(${shifted('x', axis)})^2${signed(offset)}, which statement about its axis of symmetry is correct?`;
        explanation = `该式已经是顶点式 a(x-h)^2+k，其中 h=${axis}，所以对称轴为 x=${axis}。`;
        explanationEn = `This is vertex form a(x-h)^2+k with h=${axis}, so the axis is x=${axis}.`;
        tags = ['函数', '二次函数', '对称轴'];
    }
    else if (scope === 'rational_domain_exclusion') {
        const numerator = [1, 2, 3, 5, 7][seed % 5];
        const excluded = (Math.floor(seed / 5) % 17) - 8;
        const distractors = [excluded + 1, -excluded || 2];
        if (distractors[1] === distractors[0])
            distractors[1] += 2;
        answerChoices = choices([
            { zh: `R\\{${excluded}}`, en: `R\\{${excluded}}`, intent: 'correct_domain' },
            { zh: `R\\{${distractors[0]}}`, en: `R\\{${distractors[0]}}`, intent: 'shifted_excluded_value' },
            { zh: `R\\{${distractors[1]}}`, en: `R\\{${distractors[1]}}`, intent: 'sign_error_in_denominator_root' },
            { zh: '全体实数 R', en: 'All real numbers R', intent: 'ignored_zero_denominator' }
        ], correctIndex);
        prompt = `函数 f(x)=${numerator}/(${shifted('x', excluded)}) 的定义域是什么？`;
        promptEn = `What is the domain of f(x)=${numerator}/(${shifted('x', excluded)})?`;
        explanation = `分母不能为 0。由 ${shifted('x', excluded)}≠0 得 x≠${excluded}，所以定义域为 R\\{${excluded}}。`;
        explanationEn = `The denominator cannot be zero. From ${shifted('x', excluded)}!=0, x!=${excluded}; hence the domain is R\\{${excluded}}.`;
        tags = ['函数', '分式函数', '定义域'];
    }
    else {
        const parity = seed % 2 === 0 ? 'odd' : 'even';
        const firstPower = parity === 'odd' ? [3, 5, 7][Math.floor(seed / 2) % 3] : [2, 4, 6][Math.floor(seed / 2) % 3];
        const secondPower = parity === 'odd' ? 1 : 2;
        const a = [2, 3, 4, 5][Math.floor(seed / 6) % 4];
        const b = [1, 3, 5, 7][Math.floor(seed / 24) % 4];
        const correct = parity === 'odd' ? { zh: '奇函数', en: 'Odd function', intent: 'correct_parity' } : { zh: '偶函数', en: 'Even function', intent: 'correct_parity' };
        const reverse = parity === 'odd' ? { zh: '偶函数', en: 'Even function', intent: 'confused_parity' } : { zh: '奇函数', en: 'Odd function', intent: 'confused_parity' };
        answerChoices = choices([correct, reverse, { zh: '非奇非偶函数', en: 'Neither odd nor even', intent: 'ignored_common_power_parity' }, { zh: '常数函数', en: 'Constant function', intent: 'ignored_variable_terms' }], correctIndex);
        prompt = `判断函数 f(x)=${a}x^${firstPower}+${b}x^${secondPower} 的奇偶性。`;
        promptEn = `Determine the parity of f(x)=${a}x^${firstPower}+${b}x^${secondPower}.`;
        explanation = parity === 'odd'
            ? `代入 -x 得 f(-x)=${a}(-x)^${firstPower}+${b}(-x)^${secondPower}=-${a}x^${firstPower}-${b}x^${secondPower}=-f(x)，所以该函数是奇函数。`
            : `代入 -x 得 f(-x)=${a}(-x)^${firstPower}+${b}(-x)^${secondPower}=${a}x^${firstPower}+${b}x^${secondPower}=f(x)，所以该函数是偶函数。`;
        explanationEn = parity === 'odd'
            ? `Substitution gives f(-x)=${a}(-x)^${firstPower}+${b}(-x)^${secondPower}=-${a}x^${firstPower}-${b}x^${secondPower}=-f(x), so the function is odd.`
            : `Substitution gives f(-x)=${a}(-x)^${firstPower}+${b}(-x)^${secondPower}=${a}x^${firstPower}+${b}x^${secondPower}=f(x), so the function is even.`;
        tags = ['函数', '函数奇偶性', '多项式'];
    }
    return { subject: 'math', topicId: blueprint.topicId, blueprintId: blueprint.id, sourceType: 'ai', designedDifficulty: 'basic', questionType: 'single_choice', prompt, options: answerChoices.zh, correctAnswer: answerChoices.correctAnswer, explanation, knowledgeTags: [...tags, scope], optionMetadata: answerChoices.metadata, localizations: { zh: { prompt, options: answerChoices.zh, explanation, knowledgeTags: tags }, en: { prompt: promptEn, options: answerChoices.en, explanation: explanationEn, knowledgeTags: ['Functions', 'Basic function properties'] } }, syllabusVersion: blueprint.syllabusVersion };
}
function createSubjectPracticeMathBasicFunctionLocalGenerator(ports) {
    return function generate(input) {
        const seed = seedFrom(input.seed);
        const exactScope = scopeFrom(input.questionPlan, ports.validate);
        const supported = clean(input.blueprint.subject).toLowerCase() === 'math' && clean(input.blueprint.difficulty).toLowerCase() === 'basic' && clean(input.blueprint.questionType).toLowerCase() === 'single_choice';
        if (!exactScope || !supported)
            return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_LOCAL_GENERATOR_VERSION, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null, explanationEvidence: null, adherence: null, seed, exactScope, scopeId: null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: ['math_basic_function_local_generator_question_plan_not_supported'] };
        const candidate = candidateFor(input.blueprint, seed, exactScope);
        const context = { questionPlan: input.questionPlan };
        const solverEvidence = (0, subject_practice_math_basic_function_solver_1.solveSubjectPracticeMathBasicFunction)(candidate, context);
        const oracleEvidence = (0, subject_practice_math_basic_function_independent_oracle_1.verifySubjectPracticeMathBasicFunctionWithIndependentOracle)(candidate, context);
        const explanationEvidence = (0, subject_practice_math_basic_function_explanation_verifier_1.verifySubjectPracticeMathBasicFunctionExplanation)(candidate, context);
        const adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { generatorVersion: exports.SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_LOCAL_GENERATOR_VERSION, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null, solverEvidence, oracleEvidence, explanationEvidence, adherence, seed, exactScope, scopeId: verified ? solverEvidence.scopeId : null, providerImpact: 'none_no_provider_call', estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false, reasonCodes: verified ? [] : ['math_basic_function_local_generator_triple_verification_failed', ...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
