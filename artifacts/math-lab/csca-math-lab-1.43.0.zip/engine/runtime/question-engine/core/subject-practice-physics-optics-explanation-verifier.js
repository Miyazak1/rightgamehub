"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_EXPLANATION_VERIFIER_VERSION = void 0;
exports.verifySubjectPracticePhysicsOpticsExplanation = verifySubjectPracticePhysicsOpticsExplanation;
const subject_practice_physics_optics_solver_1 = require("./subject-practice-physics-optics-solver");
exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_EXPLANATION_VERIFIER_VERSION = 'physics-optics-explanation-verifier-v1';
function compact(value) {
    return String(value ?? '').replace(/[＝]/g, '=').replace(/[×·]/g, '*').replace(/\s+/g, '').toLowerCase();
}
function numberToken(value) {
    if (value === undefined)
        return null;
    return Number(value.toFixed(6)).toString();
}
function check(input) {
    const text = compact(input.text);
    const task = input.evidence.canonicalTask;
    let firstRelationMatched = false;
    let secondRelationMatched = false;
    let conclusionMatched = false;
    if (task?.scope === 'convex_lens_image_distance_and_nature') {
        firstRelationMatched = /1\/f=1\/u\+1\/v/.test(text);
        secondRelationMatched = /u>2f|u=2f|f<u<2f/.test(text)
            && /倒立|inverted/.test(text) && /实像|realimage|andreal|isreal/.test(text);
        const v = numberToken(task.imageDistanceCm);
        const scale = task.imageScale === 'diminished' ? /缩小|diminished|smaller/
            : task.imageScale === 'same_size' ? /等大|same-?size/ : /放大|enlarged|larger/;
        conclusionMatched = Boolean(v && text.includes(`${v}cm`) && scale.test(text));
    }
    else if (task?.scope === 'convex_lens_magnification') {
        firstRelationMatched = /1\/f=1\/u\+1\/v/.test(text);
        secondRelationMatched = /\|?m\|?=v\/u/.test(text);
        const m = numberToken(task.magnification);
        conclusionMatched = Boolean(m && text.includes(m) && /放大率|magnification/.test(text));
    }
    else if (task?.scope === 'refraction_angle_and_direction') {
        firstRelationMatched = /n1sin\(?i\)?=n2sin\(?r\)?|n₁sin\(?i\)?=n₂sin\(?r\)?/.test(text);
        secondRelationMatched = /n2>n1|n₂>n₁|n2<n1|n₂<n₁/.test(text)
            && /法线|normal/.test(text);
        const angle = numberToken(task.refractionAngleDeg);
        const direction = task.refractionDirection === 'toward_normal'
            ? /向法线偏折|靠近法线|towardthenormal/
            : /离开法线偏折|远离法线|awayfromthenormal/;
        conclusionMatched = Boolean(angle && (text.includes(`${angle}°`) || text.includes(`${angle}degrees`)) && direction.test(text));
    }
    const reasonCodes = [];
    if (!firstRelationMatched)
        reasonCodes.push(`physics_optics_explanation_${input.language}_first_relation_missing`);
    if (!secondRelationMatched)
        reasonCodes.push(`physics_optics_explanation_${input.language}_second_relation_missing`);
    if (!conclusionMatched)
        reasonCodes.push(`physics_optics_explanation_${input.language}_conclusion_missing_or_wrong`);
    return { language: input.language, firstRelationMatched, secondRelationMatched, conclusionMatched, reasonCodes };
}
function verifySubjectPracticePhysicsOpticsExplanation(candidate, context = {}) {
    const solverEvidence = (0, subject_practice_physics_optics_solver_1.solveSubjectPracticePhysicsOptics)(candidate, context);
    const checks = [
        check({ language: 'zh', text: candidate.explanation, evidence: solverEvidence }),
        check({ language: 'en', text: candidate.localizations?.en?.explanation ?? '', evidence: solverEvidence })
    ];
    const reasonCodes = checks.flatMap((item) => item.reasonCodes);
    if (solverEvidence.status !== 'verified' || !solverEvidence.verificationScope.matched) {
        reasonCodes.unshift('physics_optics_explanation_answer_recomputation_not_verified');
    }
    const status = solverEvidence.status === 'unparsed' ? 'unparsed'
        : reasonCodes.length === 0 ? 'verified' : 'failed';
    return {
        verifierVersion: exports.SUBJECT_PRACTICE_PHYSICS_OPTICS_EXPLANATION_VERIFIER_VERSION,
        status, solverEvidence, linkedRelationsAndConclusionChecked: true, checks,
        mismatchCount: reasonCodes.length, providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only', reasonCodes: Array.from(new Set(reasonCodes))
    };
}
