"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.choose = exports.falling = exports.pcmp = exports.ptxt = exports.PROBABILITY_CONSTRAINT_CONSTRAINTS = exports.PROBABILITY_CONSTRAINT_SCOPES = exports.PROBABILITY_CONSTRAINT_SCOPE_VERSION = exports.PROBABILITY_CONSTRAINT_SOLVER_VERSION = exports.PROBABILITY_CONSTRAINT_TEMPLATE = exports.PROBABILITY_CONSTRAINT_FAMILY = void 0;
exports.pq = pq;
exports.probabilityConstraintScopeFrom = probabilityConstraintScopeFrom;
exports.probabilityConstraintPrompt = probabilityConstraintPrompt;
exports.probabilityConstraintParametersFrom = probabilityConstraintParametersFrom;
exports.probabilityConstraintOptionKey = probabilityConstraintOptionKey;
exports.probabilityConstraintCount = probabilityConstraintCount;
exports.probabilityConstraintDerive = probabilityConstraintDerive;
exports.solveSubjectPracticeMathProbabilityConstraint = solveSubjectPracticeMathProbabilityConstraint;
exports.PROBABILITY_CONSTRAINT_FAMILY = 'math_classical_probability_constraint_reasoning';
exports.PROBABILITY_CONSTRAINT_TEMPLATE = exports.PROBABILITY_CONSTRAINT_FAMILY + '_v1';
exports.PROBABILITY_CONSTRAINT_SOLVER_VERSION = 'math-probability-constraint-solver-v1-exact-combinatorial-rational';
exports.PROBABILITY_CONSTRAINT_SCOPE_VERSION = 'math-hard-probability-constraint-v1';
exports.PROBABILITY_CONSTRAINT_SCOPES = ['without_replacement_nonadjacent_target_count', 'without_replacement_all_colors_distinct_endpoints', 'independent_boxes_three_red_each_box_nonempty', 'numbered_cards_odd_sum_window_and_span'];
exports.PROBABILITY_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-PROB-001', boundedIntegerParameters: true, maximumConstructionAttempts: 256, maximumExplicitOrderedOutcomes: 1000000, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function pq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (b <= 0n || a < 0n || a.toString(2).length > 128 || b.toString(2).length > 128)
    throw Error('probability_arithmetic_bound'); let x = a, y = b; while (y)
    [x, y] = [y, x % y]; return { n: a / x, d: b / x }; }
const ptxt = (q) => String(q.n) + (q.d === 1n ? '' : '/' + q.d), pcmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0;
exports.ptxt = ptxt, exports.pcmp = pcmp;
const falling = (n, k) => { if (k < 0 || k > n)
    return 0n; let r = 1n; for (let j = 0; j < k; j++)
    r *= BigInt(n - j); return r; };
exports.falling = falling;
const choose = (n, k) => k < 0 || k > n ? 0n : (0, exports.falling)(n, k) / (0, exports.falling)(k, k);
exports.choose = choose;
const object = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
function probabilityConstraintScopeFrom(value) { const p = object(value), r = object(p?.renderConstraints), s = object(p?.scenarioContract), scope = r?.exactProbabilityConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 75 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.PROBABILITY_CONSTRAINT_FAMILY && p?.planTemplate === exports.PROBABILITY_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.PROBABILITY_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'finite_probability_constraint_experiment' && s?.scenarioAction === scope && exports.PROBABILITY_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
const names = [['R', 'B', 'n', 'k'], ['R', 'B', 'G', 'n'], ['R1', 'B1', 'R2', 'B2'], ['N', 'L', 'U', 'w']];
const startsZh = ['袋中有 R 个红球和 B 个蓝球，球有不同编号。每次从余下球中等概率抽一个，连续抽 n 次且不放回。已知 ', '袋中有 R 个红球、B 个蓝球和 G 个绿球，球有不同编号。每次从余下球中等概率抽一个，连续抽 n 次且不放回。已知 ', '甲盒有 R1 个红球和 B1 个蓝球，乙盒有 R2 个红球和 B2 个蓝球，球有不同编号。两盒实验相互独立，每盒均连续等概率不放回抽取 3 个球。已知 ', 'N 张不同卡片依次编号为 1 到 N，从中等概率不放回抽取 3 张。已知 '];
const startsEn = ['A bag contains R red and B blue individually labelled balls. Draw n balls sequentially without replacement, uniformly from the remaining balls at each step. Given ', 'A bag contains R red, B blue and G green individually labelled balls. Draw n balls sequentially without replacement, uniformly from the remaining balls at each step. Given ', 'Box A contains R1 red and B1 blue labelled balls; box B contains R2 red and B2 blue labelled balls. The experiments in the two boxes are independent; draw 3 balls sequentially and uniformly without replacement from each box. Given ', 'N distinct cards are numbered 1 through N. Draw 3 cards uniformly without replacement. Given '];
const endsZh = ['求恰好抽到 k 个红球且任意两个红球的抽取位置均不相邻的概率。', '求三种颜色均被抽到且第一个与最后一个球的颜色不同的概率。', '求总共恰好抽到 3 个红球且每盒至少抽到 1 个红球的概率。', '记卡片编号和为 S，最大编号与最小编号之差为 D。求 S 为奇数、L≤S≤U 且 D≤w 同时成立的概率。'];
const endsEn = ['Find the probability of exactly k red balls with no adjacent red draw positions.', 'Find the probability that all three colors occur and the first and last balls have different colors.', 'Find the probability of exactly 3 red balls in total and at least 1 red ball from each box.', 'Let S be the sum of the numbers and D their maximum minus minimum. Find the probability that S is odd, L≤S≤U and D≤w all hold.'];
function probabilityConstraintPrompt(p, lang) { const i = exports.PROBABILITY_CONSTRAINT_SCOPES.indexOf(p.scope); return (lang === 'zh' ? startsZh : startsEn)[i] + names[i].map((n, j) => n + '=(' + p.data[j] + ')').join(', ') + '. ' + (lang === 'zh' ? endsZh : endsEn)[i]; }
function probabilityConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 3000)
    return null; const data = [...text.matchAll(/=\(([1-9]\d*)\)/g)].map(m => m[1]), p = { scope, data }; return data.length === 4 && probabilityConstraintPrompt(p, lang) === text ? p : null; }
function probabilityConstraintOptionKey(text, _scope) { try {
    if (typeof text !== 'string' || text.length > 64 || !/^\+?\d+(?:\/[1-9]\d*)?$/.test(text.trim()))
        return null;
    const [n, d = '1'] = text.trim().replace(/^\+/, '').split('/'), q = pq(BigInt(n), BigInt(d));
    return q.n > 0n && q.n < q.d ? (0, exports.ptxt)(q) : null;
}
catch {
    return null;
} }
function probabilityConstraintCount(data, i) {
    try {
        if (i < 0 || i > 3 || data.length !== 4 || data.some(x => !/^[1-9]\d{0,2}$/.test(x)))
            return null;
        const v = data.map(Number);
        let favorable = 0n, total = 0n;
        const steps = [], errors = [], details = {};
        const err = (intent, n, d) => { if (d > 0n && n > 0n && n < d)
            errors.push({ intent, value: pq(n, d) }); };
        if (i === 0) {
            const [R, B, n, k] = v, N = R + B;
            if (R < 2 || B < 2 || N > 12 || ![5, 6].includes(n) || ![2, 3].includes(k) || R < k || B < n - k || 2 * k > n + 1 || n > N)
                return null;
            total = (0, exports.falling)(N, n);
            const arrangements = (0, exports.choose)(n - k + 1, k), labelAssignments = (0, exports.falling)(R, k) * (0, exports.falling)(B, n - k), unrestricted = (0, exports.choose)(n, k) * labelAssignments;
            favorable = arrangements * labelAssignments;
            if (unrestricted <= favorable)
                return null;
            Object.assign(details, { nonadjacentPatterns: String(arrangements), unrestrictedPatterns: String((0, exports.choose)(n, k)), labelAssignments: String(labelAssignments), omittedAdjacencyFavorable: String(unrestricted) });
            steps.push('N=R+B=' + N + '; ordered total=(' + N + ')_' + n + '=' + total, 'choose ' + k + ' separated positions: C(' + (n - k + 1) + ',' + k + ')=' + arrangements, 'assign labels: (' + R + ')_' + k + '*(' + B + ')_' + (n - k) + '=' + labelAssignments, 'favorable=' + arrangements + '*' + labelAssignments + '=' + favorable);
            err('omit_nonadjacency', unrestricted, total);
            err('treat_color_patterns_as_uniform', arrangements, 2n ** BigInt(n));
            err('draw_with_replacement', arrangements * BigInt(R) ** BigInt(k) * BigInt(B) ** BigInt(n - k), BigInt(N) ** BigInt(n));
            err('omit_position_multiplicity', labelAssignments, total);
        }
        else if (i === 1) {
            const [R, B, G, n] = v, counts = [R, B, G], N = R + B + G;
            if (counts.some(x => x < 1 || x > 6) || N > 12 || ![4, 5].includes(n) || n > N)
                return null;
            total = (0, exports.falling)(N, n);
            let allColors = 0n, allDifferentEnds = 0n;
            const occupancy = [];
            for (let a = 0; a <= n; a++)
                for (let b = 0; b <= n - a; b++) {
                    const c = n - a - b, q = [a, b, c];
                    if (q.some((x, j) => x > counts[j]))
                        continue;
                    const strings = (0, exports.falling)(n, n) / q.reduce((m, x) => m * (0, exports.falling)(x, x), 1n);
                    let equal = 0n;
                    for (let j = 0; j < 3; j++)
                        if (q[j] >= 2)
                            equal += (0, exports.falling)(n - 2, n - 2) / q.reduce((m, x, l) => m * (0, exports.falling)(x - (j === l ? 2 : 0), x - (j === l ? 2 : 0)), 1n);
                    const labels = q.reduce((m, x, j) => m * (0, exports.falling)(counts[j], x), 1n);
                    allDifferentEnds += (strings - equal) * labels;
                    if (q.every(x => x > 0)) {
                        allColors += strings * labels;
                        const count = (strings - equal) * labels;
                        favorable += count;
                        occupancy.push({ counts: q, colorStrings: String(strings), equalEndpoints: String(equal), labels: String(labels), contribution: String(count) });
                    }
                }
            if (allColors <= favorable || allDifferentEnds <= favorable)
                return null;
            Object.assign(details, { occupancy, omittedEndpointsFavorable: String(allColors), omittedAllColorsFavorable: String(allDifferentEnds) });
            steps.push('N=R+B+G=' + N + '; ordered total=(' + N + ')_' + n + '=' + total, 'partition by r+b+g=' + n + ' with r,b,g>=1 and capacities', 'for each occupancy: (n!/(r!b!g!)-sum equal-end strings)*(R)_r*(B)_b*(G)_g', 'occupancies=' + JSON.stringify(occupancy) + '; favorable=' + favorable);
            err('omit_distinct_endpoints', allColors, total);
            err('omit_all_colors', allDifferentEnds, total);
            err('count_only_one_endpoint_order', favorable, 2n * total);
            err('replace_ordered_denominator_by_with_replacement', favorable, BigInt(N) ** BigInt(n));
        }
        else if (i === 2) {
            const [R1, B1, R2, B2] = v, N1 = R1 + B1, N2 = R2 + B2;
            if (v.some(x => x < 2 || x > 12) || N1 > 18 || N2 > 18)
                return null;
            const t1 = (0, exports.choose)(N1, 3), t2 = (0, exports.choose)(N2, 3);
            total = t1 * t2;
            const allocation = (a) => (0, exports.choose)(R1, a) * (0, exports.choose)(B1, 3 - a) * (0, exports.choose)(R2, 3 - a) * (0, exports.choose)(B2, a), c1 = allocation(1), c2 = allocation(2), excluded = allocation(0) + allocation(3);
            favorable = c1 + c2;
            if (c1 <= 0n || c2 <= 0n || excluded <= 0n)
                return null;
            Object.assign(details, { allocationCounts: [String(c1), String(c2)], excludedEmptyBox: String(excluded), marginalUnorderedTotals: [String(t1), String(t2)] });
            steps.push('independent unordered totals=C(' + N1 + ',3)*C(' + N2 + ',3)=' + total, 'allowed red allocations=(1,2),(2,1); excluded=(0,3),(3,0)', 'allocation(1,2)=C(' + R1 + ',1)C(' + B1 + ',2)C(' + R2 + ',2)C(' + B2 + ',1)=' + c1, 'allocation(2,1)=' + c2 + '; favorable=' + favorable);
            err('omit_each_box_red_requirement', favorable + excluded, total);
            err('omit_allocation_2_1', c1, total);
            err('omit_allocation_1_2', c2, total);
            err('double_count_box_allocations', 2n * favorable, total);
        }
        else {
            const [N, L, U, w] = v;
            if (N < 6 || N > 12 || L < 3 || L >= U || U > 3 * N - 3 || w < 2 || w > N - 1)
                return null;
            total = (0, exports.choose)(N, 3);
            const countsFor = (lower, upper, span, odd) => {
                let count = 0n;
                for (let a = 1; a <= N - 2; a++)
                    for (let c = a + 2; c <= Math.min(N, a + span); c++) {
                        const lo = Math.max(a + 1, lower - a - c), hi = Math.min(c - 1, upper - a - c);
                        if (lo > hi)
                            continue;
                        if (!odd)
                            count += BigInt(hi - lo + 1);
                        else {
                            const parity = 1 - (a + c) % 2, first = lo + (lo % 2 === parity ? 0 : 1);
                            if (first <= hi)
                                count += BigInt(Math.floor((hi - first) / 2) + 1);
                        }
                    }
                return count;
            };
            favorable = countsFor(L, U, w, true);
            const omitted = [countsFor(3, U, w, true), countsFor(L, 3 * N - 3, w, true), countsFor(L, U, N - 1, true), countsFor(L, U, w, false)];
            if (omitted.some(x => x <= favorable))
                return null;
            Object.assign(details, { omittedLower: String(omitted[0]), omittedUpper: String(omitted[1]), omittedSpan: String(omitted[2]), omittedOdd: String(omitted[3]) });
            steps.push('unordered total=C(' + N + ',3)=' + total, 'partition by minimum a and maximum c, 1<=a<c<=' + N + ', c-a<=' + w, 'middle b: max(a+1,' + L + '-a-c)<=b<=min(c-1,' + U + '-a-c); parity(b)=1-parity(a+c)', 'sum the disjoint parity interval counts; favorable=' + favorable);
            ['omit_lower_bound', 'omit_upper_bound', 'omit_span_bound', 'omit_odd_sum'].forEach((intent, j) => err(intent, omitted[j], total));
        }
        if (favorable <= 0n || favorable >= total)
            return null;
        steps.push('probability=' + favorable + '/' + total + '=' + (0, exports.ptxt)(pq(favorable, total)));
        err('take_complement_event', total - favorable, total);
        return { favorable, total, steps, errors, certificate: { method: 'exact_combinatorial_partition', complete: true, ...details, favorable: String(favorable), total: String(total) } };
    }
    catch {
        return null;
    }
}
function probabilityConstraintDerive(p) {
    try {
        const i = exports.PROBABILITY_CONSTRAINT_SCOPES.indexOf(p.scope), d = probabilityConstraintCount(p.data, i);
        if (!d)
            return null;
        const answer = (0, exports.ptxt)(pq(d.favorable, d.total)), witnesses = [];
        for (let j = 0; j < 4; j++) {
            let found = false;
            for (const delta of [1, -1, 2, -2, 3, -3]) {
                const alt = p.data.slice();
                alt[j] = String(Number(alt[j]) + delta);
                const other = probabilityConstraintCount(alt, i);
                if (other) {
                    const differentAnswer = (0, exports.ptxt)(pq(other.favorable, other.total));
                    if (differentAnswer !== answer) {
                        witnesses.push({ omitted: names[i][j], alternativeData: alt, differentAnswer });
                        found = true;
                        break;
                    }
                }
            }
            if (!found)
                return null;
        }
        const errors = d.errors.map(e => ({ intent: e.intent, text: (0, exports.ptxt)(e.value), key: (0, exports.ptxt)(e.value) })).filter((e, j, a) => e.key !== answer && a.findIndex(x => x.key === e.key) === j).slice(0, 3);
        if (errors.length !== 3)
            return null;
        const proof = 'givens=' + p.data.join(',') + '; ' + d.steps.join('; '), hardEvidence = { version: 'probability-constraint-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 4, reasoningSteps: d.steps.length, quantitativeRelations: 2, groups: names[i].slice(), effectiveConstraints: witnesses, completeProbabilityCertificate: d.certificate, criticalPoints: [], answer, visibleProof: proof, studentCalibrated: false };
        return { answer, text: answer, errors, proof, steps: d.steps, hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathProbabilityConstraint(candidate, context = {}) {
    const scope = probabilityConstraintScopeFrom(context.questionPlan), parameters = probabilityConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? probabilityConstraintDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('probability_constraint_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 75 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('probability_constraint_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? probabilityConstraintOptionKey(o.text, scope) : null);
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('probability_constraint_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(probabilityConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('probability_constraint_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, scope ? probabilityConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('probability_constraint_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('probability_constraint_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('probability_constraint_error_intent');
    const scopeId = parameters ? exports.PROBABILITY_CONSTRAINT_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.PROBABILITY_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.PROBABILITY_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.PROBABILITY_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['probability_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
