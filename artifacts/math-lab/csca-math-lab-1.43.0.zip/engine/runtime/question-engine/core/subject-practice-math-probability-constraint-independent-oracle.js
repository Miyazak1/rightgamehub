"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROBABILITY_CONSTRAINT_ORACLE_VERSION = void 0;
exports.probabilityConstraintIndependentCalculation = probabilityConstraintIndependentCalculation;
exports.verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle = verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle;
// Independent visible-text parser and arithmetic; no runtime dependency on the Solver or generator.
exports.PROBABILITY_CONSTRAINT_ORACLE_VERSION = 'math-probability-constraint-oracle-v1-independent-labelled-enumeration';
const scopes = ['without_replacement_nonadjacent_target_count', 'without_replacement_all_colors_distinct_endpoints', 'independent_boxes_three_red_each_box_nonempty', 'numbered_cards_odd_sum_window_and_span'];
const abs = (n) => n < 0n ? -n : n;
class R {
    n;
    d;
    constructor(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || abs(a).toString(2).length > 512 || abs(b).toString(2).length > 512)
        throw Error('oracle_arithmetic_bound'); if (b < 0n) {
        a = -a;
        b = -b;
    } let x = abs(a), y = b; while (y) {
        const t = x % y;
        x = y;
        y = t;
    } this.n = a / x; this.d = b / x; }
    add(q) { return new R(this.n * q.d + q.n * this.d, this.d * q.d); }
    neg() { return new R(-this.n, this.d); }
    sub(q) { return this.add(q.neg()); }
    mul(q) { return new R(this.n * q.n, this.d * q.d); }
    div(q) { return new R(this.n * q.d, this.d * q.n); }
    sq() { return this.mul(this); }
    eq(q) { return this.n === q.n && this.d === q.d; }
    cmp(q) { const n = this.n * q.d - q.n * this.d; return n < 0n ? -1 : n > 0n ? 1 : 0; }
    toString() { return String(this.n) + (this.d === 1n ? '' : '/' + this.d); }
}
const z = new R(0), one = new R(1), two = new R(2), four = new R(4);
function read(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('oracle_rational_syntax'); const [a, b = '1'] = s.split('/'), q = new R(BigInt(a), BigInt(b)); if (abs(q.n) > 1000000000000n || q.d > 1000000000n)
    throw Error('oracle_input_bound'); return q; }
const object = (x) => x && typeof x === 'object' && !Array.isArray(x) ? x : null;
const names = [['R', 'B', 'n', 'k'], ['R', 'B', 'G', 'n'], ['R1', 'B1', 'R2', 'B2'], ['N', 'L', 'U', 'w']];
const startsZh = ['袋中有 R 个红球和 B 个蓝球，球有不同编号。每次从余下球中等概率抽一个，连续抽 n 次且不放回。已知 ', '袋中有 R 个红球、B 个蓝球和 G 个绿球，球有不同编号。每次从余下球中等概率抽一个，连续抽 n 次且不放回。已知 ', '甲盒有 R1 个红球和 B1 个蓝球，乙盒有 R2 个红球和 B2 个蓝球，球有不同编号。两盒实验相互独立，每盒均连续等概率不放回抽取 3 个球。已知 ', 'N 张不同卡片依次编号为 1 到 N，从中等概率不放回抽取 3 张。已知 '];
const startsEn = ['A bag contains R red and B blue individually labelled balls. Draw n balls sequentially without replacement, uniformly from the remaining balls at each step. Given ', 'A bag contains R red, B blue and G green individually labelled balls. Draw n balls sequentially without replacement, uniformly from the remaining balls at each step. Given ', 'Box A contains R1 red and B1 blue labelled balls; box B contains R2 red and B2 blue labelled balls. The experiments in the two boxes are independent; draw 3 balls sequentially and uniformly without replacement from each box. Given ', 'N distinct cards are numbered 1 through N. Draw 3 cards uniformly without replacement. Given '];
const endsZh = ['求恰好抽到 k 个红球且任意两个红球的抽取位置均不相邻的概率。', '求三种颜色均被抽到且第一个与最后一个球的颜色不同的概率。', '求总共恰好抽到 3 个红球且每盒至少抽到 1 个红球的概率。', '记卡片编号和为 S，最大编号与最小编号之差为 D。求 S 为奇数、L≤S≤U 且 D≤w 同时成立的概率。'];
const endsEn = ['Find the probability of exactly k red balls with no adjacent red draw positions.', 'Find the probability that all three colors occur and the first and last balls have different colors.', 'Find the probability of exactly 3 red balls in total and at least 1 red ball from each box.', 'Let S be the sum of the numbers and D their maximum minus minimum. Find the probability that S is odd, L≤S≤U and D≤w all hold.'];
function parse(text, i, lang) {
    if (i < 0 || typeof text !== 'string' || text.length > 3000)
        throw Error('oracle_text');
    const prefix = (lang === 'zh' ? startsZh : startsEn)[i], suffix = '. ' + (lang === 'zh' ? endsZh : endsEn)[i];
    if (!text.startsWith(prefix) || !text.endsWith(suffix))
        throw Error('oracle_protocol');
    const parts = text.slice(prefix.length, -suffix.length).split(', ');
    if (parts.length !== 4)
        throw Error('oracle_fields');
    return parts.map((v, j) => { const m = /^([A-Za-z][A-Za-z0-9]*)=\(([1-9]\d{0,2})\)$/.exec(v); if (!m || m[1] !== names[i][j])
        throw Error('oracle_parameter_binding'); return m[2]; });
}
function enumerate(labels, length, visit) {
    const used = new Uint8Array(labels.length), tuple = [];
    let visited = 0;
    function walk() {
        if (tuple.length === length) {
            if (++visited > 1000000)
                throw Error('oracle_enumeration_limit');
            visit(tuple);
            return;
        }
        for (let j = 0; j < labels.length; j++)
            if (!used[j]) {
                used[j] = 1;
                tuple.push(labels[j]);
                walk();
                tuple.pop();
                used[j] = 0;
            }
    }
    walk();
    return visited;
}
function labels(counts) { return counts.flatMap((n, j) => Array.from({ length: n }, () => j)); }
function calculate(data, i) {
    if (data.length !== 4 || data.some(s => !/^[1-9]\d{0,2}$/.test(s)))
        throw Error('oracle_integer_bounds');
    const v = data.map(Number);
    let hit = 0n, total = 0n;
    const relaxed = [], detail = {};
    if (i === 0) {
        const [r, b, n, k] = v;
        if (r < 2 || b < 2 || r + b > 12 || (n !== 5 && n !== 6) || (k !== 2 && k !== 3) || r < k || b < n - k || 2 * k > n + 1 || n > r + b)
            throw Error('oracle_scope_bounds');
        let plain = 0n;
        const visited = enumerate(labels([r, b]), n, t => { total++; if (t.filter(c => c === 0).length !== k)
            return; plain++; if (!t.some((c, j) => j > 0 && c === 0 && t[j - 1] === 0))
            hit++; });
        relaxed.push(plain);
        Object.assign(detail, { visited, omittedAdjacencyFavorable: String(plain) });
    }
    else if (i === 1) {
        const [r, b, g, n] = v;
        if ([r, b, g].some(x => x < 1 || x > 6) || r + b + g > 12 || (n !== 4 && n !== 5) || n > r + b + g)
            throw Error('oracle_scope_bounds');
        let all = 0n, ends = 0n;
        const visited = enumerate(labels([r, b, g]), n, t => { total++; const a = new Set(t).size === 3, e = t[0] !== t[n - 1]; if (a)
            all++; if (e)
            ends++; if (a && e)
            hit++; });
        relaxed.push(all, ends);
        Object.assign(detail, { visited, omittedEndpointsFavorable: String(all), omittedAllColorsFavorable: String(ends) });
    }
    else if (i === 2) {
        const [r1, b1, r2, b2] = v;
        if (v.some(x => x < 2 || x > 12) || r1 + b1 > 18 || r2 + b2 > 18)
            throw Error('oracle_scope_bounds');
        const h1 = [0n, 0n, 0n, 0n], h2 = [0n, 0n, 0n, 0n], t1 = enumerate(labels([r1, b1]), 3, t => { h1[t.filter(c => c === 0).length]++; }), t2 = enumerate(labels([r2, b2]), 3, t => { h2[t.filter(c => c === 0).length]++; });
        total = BigInt(t1) * BigInt(t2);
        let plain = 0n;
        for (let a = 0; a <= 3; a++)
            for (let b = 0; b <= 3; b++)
                if (a + b === 3) {
                    plain += h1[a] * h2[b];
                    if (a >= 1 && b >= 1)
                        hit += h1[a] * h2[b];
                }
        if (h1[1] * h2[2] === 0n || h1[2] * h2[1] === 0n)
            throw Error('oracle_empty_branch');
        relaxed.push(plain);
        Object.assign(detail, { method: 'independent_complete_marginal_labelled_enumeration_product', marginalVisited: [t1, t2], histograms: [h1.map(String), h2.map(String)], cartesianCardinality: String(total), omittedEachBoxRedFavorable: String(plain) });
    }
    else if (i === 3) {
        const [N, L, U, w] = v;
        if (N < 6 || N > 12 || L < 3 || L >= U || U > 3 * N - 3 || w < 2 || w > N - 1)
            throw Error('oracle_scope_bounds');
        const counts = [0n, 0n, 0n, 0n];
        const visited = enumerate(Array.from({ length: N }, (_, j) => j + 1), 3, t => { total++; const sum = t[0] + t[1] + t[2], span = Math.max(...t) - Math.min(...t), flags = [sum >= L, sum <= U, span <= w, sum % 2 === 1]; if (flags.every(Boolean))
            hit++; for (let j = 0; j < 4; j++)
            if (flags.every((ok, k) => ok || k === j))
                counts[j]++; });
        relaxed.push(...counts);
        Object.assign(detail, { visited, unorderedEquivalenceFactor: 6, unorderedFavorable: String(hit / 6n), omittedConstraintsFavorable: counts.map(String) });
        if (hit % 6n !== 0n || total % 6n !== 0n)
            throw Error('oracle_order_equivalence');
    }
    else
        throw Error('oracle_scope');
    if (hit <= 0n || hit >= total || relaxed.some(c => c <= hit))
        throw Error('oracle_ineffective_event');
    const answer = new R(hit, total);
    return { answer, certificate: { method: 'independent_labelled_ordered_enumeration', complete: true, ...detail, favorable: String(hit), total: String(total) } };
}
function probabilityConstraintIndependentCalculation(data, i) {
    const d = calculate(data, i), witnesses = [];
    for (let j = 0; j < 4; j++) {
        let found = false;
        for (const delta of [1, -1, 2, -2, 3, -3]) {
            const alternativeData = data.slice();
            alternativeData[j] = String(Number(alternativeData[j]) + delta);
            try {
                const other = calculate(alternativeData, i);
                if (!other.answer.eq(d.answer)) {
                    witnesses.push({ omitted: names[i][j], alternativeData, differentAnswer: String(other.answer) });
                    found = true;
                    break;
                }
            }
            catch { }
        }
        if (!found)
            throw Error('oracle_ineffective_numeric_constraint');
    }
    return { answer: String(d.answer), certificate: { ...d.certificate, effectiveConstraints: witnesses } };
}
function option(text, _i) { try {
    const q = read(text.trim());
    return q.n > 0n && q.n < q.d ? String(q) : null;
}
catch {
    return null;
} }
function verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle(candidate, context = {}) {
    const p = object(context.questionPlan), r = object(p?.renderConstraints), s = object(p?.scenarioContract), scope = String(r?.exactProbabilityConstraintScope ?? ''), i = scopes.indexOf(scope), required = { topicCode: 'M-PROB-001', boundedIntegerParameters: true, maximumConstructionAttempts: 256, maximumExplicitOrderedOutcomes: 1000000, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
    const bound = i >= 0 && p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 75 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === 'math_classical_probability_constraint_reasoning' && p?.planTemplate === 'math_classical_probability_constraint_reasoning_v1' && r?.questionType === 'single_choice' && Object.entries(required).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'finite_probability_constraint_experiment' && s?.scenarioAction === scope;
    const reasonCodes = [];
    let expectedAnswer = null, certificate = null, data = null;
    try {
        if (!bound)
            throw Error('oracle_exact_plan');
        data = parse(candidate.prompt, i, 'zh');
        const d = probabilityConstraintIndependentCalculation(data, i);
        expectedAnswer = d.answer;
        certificate = d.certificate;
        for (const lang of ['zh', 'en'])
            if (JSON.stringify(parse(candidate.localizations?.[lang]?.prompt ?? '', i, lang)) !== JSON.stringify(data))
                throw Error('oracle_translation_parameters');
    }
    catch (e) {
        reasonCodes.push(e instanceof Error ? e.message : 'oracle_unparsed');
    }
    if (candidate.subject !== 'math' || candidate.topicId !== 75 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('oracle_identity');
    const opts = candidate.options ?? [], keys = opts.map(o => option(o.text, i));
    if (opts.length !== 4 || new Set(opts.map(o => o.id)).size !== 4 || opts.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('oracle_options');
    for (const lang of ['zh', 'en'])
        if (JSON.stringify(candidate.localizations?.[lang]?.options?.map(o => [o.id, option(o.text, i)])) !== JSON.stringify(opts.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('oracle_' + lang + '_options');
    const trueOptionIds = opts.filter((_, j) => keys[j] !== null && keys[j] === expectedAnswer).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('oracle_answer_disagreement');
    return { oracleVersion: exports.PROBABILITY_CONSTRAINT_ORACLE_VERSION, status: reasonCodes.length ? (data ? 'disagreed' : 'unparsed') : 'verified', scopeMatched: bound && !!data, scopeId: bound && data ? 'math-hard-probability-constraint-v1:' + scope : null, exactScope: scope, expectedAnswer, selectedOptionId, trueOptionIds, certificate, complete: !!certificate, completeCertificate: !!certificate, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, reasonCodes, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only' };
}
