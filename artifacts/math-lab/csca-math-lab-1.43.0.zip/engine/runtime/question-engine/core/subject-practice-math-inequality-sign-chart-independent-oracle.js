"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_INDEPENDENT_ORACLE_VERSION = void 0;
exports.verifySubjectPracticeMathInequalitySignChartWithIndependentOracle = verifySubjectPracticeMathInequalitySignChartWithIndependentOracle;
// Deliberately no imports from the generator, primary solver, or explanation verifier.
exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_INDEPENDENT_ORACLE_VERSION = 'math-inequality-sign-chart-oracle-v1-complete-real-partition';
const scopes = ['quadratic_strict_sign_interval', 'quadratic_inclusive_sign_interval', 'linear_fraction_strict_sign_interval', 'linear_fraction_inclusive_sign_interval'];
function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
function scopeOf(value) {
    const p = obj(value), r = obj(p.renderConstraints), s = String(r.exactInequalitySignChartScope ?? ''), scenario = obj(p.scenarioContract);
    const required = { topicCode: 'M-INEQ-001', maximumAbsoluteScale: 5, minimumCriticalPoint: -9, maximumCriticalPoint: 9,
        distinctCriticalPointsRequired: true, integerCriticalPointsRequired: true, maximumOptionEndpoint: 12,
        realSolutionSetRequired: true, externalContextAllowed: false, requiresImage: false,
        finalAnswerShape: 'one_unique_union_of_at_most_two_exact_intervals' };
    return p.schemaVersion === 'subject-practice-question-plan-v1' && p.policyVersion === 'subject-practice-question-plan-policy-v1'
        && p.subject === 'math' && p.topicId === 67 && p.targetDifficulty === 'medium' && p.representationType === 'text'
        && p.taskFamily === 'math_quadratic_rational_inequality_solution' && p.planTemplate === 'math_quadratic_rational_inequality_solution_v1'
        && r.questionType === 'single_choice' && scopes.includes(s) && Object.entries(required).every(([k, v]) => r[k] === v)
        && scenario.scenarioMode === 'abstract' && scenario.scenarioEntity === 'inequality_sign_chart_object' && scenario.scenarioAction === s ? s : null;
}
function parse(text, scope, english) {
    if (!scope)
        return null;
    const start = english ? /^(?:Solve the inequality over the real numbers|Find the real solution set): / : /^(?:解不等式|求下列不等式的实数解集)：/;
    const end = english ? '. Use critical points, interval signs and endpoint inclusion to select the solution set.' : '。请结合临界点、区间符号与端点开闭选择解集。';
    if (!start.test(text) || !text.endsWith(end))
        return null;
    const expression = text.replace(start, '').slice(0, -end.length);
    const parts = expression.match(/^(.*) (<=|>=|<|>) 0$/);
    if (!parts || parts[2].includes('=') !== scope.includes('inclusive'))
        return null;
    const quadratic = scope.startsWith('quadratic'), body = parts[1];
    const tokens = body.match(quadratic
        ? /^(-?\d+)x\^2 ([+-]) (\d+)x ([+-]) (\d+)$/
        : /^\((-?\d+)x ([+-]) (\d+)\)\/\(x ([+-]) (\d+)\)$/);
    if (!tokens)
        return null;
    const a = Number(tokens[1]), b = Number(tokens[3]) * (tokens[2] === '-' ? -1 : 1);
    const last = Number(tokens[5]) * (tokens[4] === '-' ? -1 : 1);
    if (![a, b, last].every(Number.isSafeInteger) || !a || Math.abs(a) > 5 || Math.abs(b) > 90 || Math.abs(last) > 405)
        return null;
    // Reject noncanonical negative zero rather than interpreting ambiguous surface strings.
    if ((tokens[2] === '-' && b === 0) || (tokens[4] === '-' && last === 0) || tokens[1] === '-0')
        return null;
    const roots = [];
    for (let x = -9; x <= 9; x++)
        if (quadratic ? a * x * x + b * x + last === 0 : a * x + b === 0)
            roots.push(x);
    const pole = quadratic ? null : -last;
    if (quadratic ? roots.length !== 2 : roots.length !== 1 || !Number.isInteger(pole) || Math.abs(pole) > 9 || roots.includes(pole))
        return null;
    return { a, b, c: quadratic ? last : 0, pole, roots, relation: parts[2] };
}
function intervals(text) {
    const raw = text.trim().split(/\s+U\s+/);
    if (raw.length > 2 || !raw.length)
        return null;
    const parsed = [];
    for (const piece of raw) {
        const first = piece[0], last = piece[piece.length - 1], pair = piece.slice(1, -1).split(',').map(s => s.trim());
        if (!['[', '('].includes(first) || ![']', ')'].includes(last) || pair.length !== 2)
            return null;
        if (!/^(?:-inf|[+-]?\d+)$/.test(pair[0]) || !/^(?:\+inf|[+-]?\d+)$/.test(pair[1]))
            return null;
        const lo = pair[0] === '-inf' ? -Infinity : Number(pair[0]), hi = pair[1] === '+inf' ? Infinity : Number(pair[1]);
        if ((pair[0] !== '-inf' && !Number.isSafeInteger(lo)) || (pair[1] !== '+inf' && !Number.isSafeInteger(hi)))
            return null;
        if (!(lo < hi) || (lo === -Infinity && first === '[') || (hi === Infinity && last === ']')
            || [lo, hi].some(n => Number.isFinite(n) && (!Number.isInteger(n) || Math.abs(n) > 12)))
            return null;
        parsed.push({ lo, hi, lc: first === '[', rc: last === ']' });
    }
    return parsed;
}
function originalTruth(p, numerator, denominator) {
    const n = BigInt(numerator), d = BigInt(denominator);
    const a = BigInt(p.a), b = BigInt(p.b);
    let signValue;
    if (p.pole === null)
        signValue = a * n * n + b * n * d + BigInt(p.c) * d * d;
    else {
        const divisor = n - BigInt(p.pole) * d;
        if (divisor === 0n)
            return false;
        // Multiplying numerator and denominator preserves the quotient's sign.
        signValue = (a * n + b * d) * divisor;
    }
    return p.relation === '<' ? signValue < 0n : p.relation === '>' ? signValue > 0n : p.relation === '<=' ? signValue <= 0n : signValue >= 0n;
}
function membership(parts, n, d) {
    return parts.some(i => (i.lo === -Infinity || (i.lc ? n >= i.lo * d : n > i.lo * d))
        && (i.hi === Infinity || (i.rc ? n <= i.hi * d : n < i.hi * d)));
}
function verifySubjectPracticeMathInequalitySignChartWithIndependentOracle(candidate, context = {}) {
    const exactScope = scopeOf(context.questionPlan), p = parse(candidate.prompt, exactScope, false), reasonCodes = [];
    if (!p)
        reasonCodes.push('inequality_sign_chart_oracle_unparsed');
    if (candidate.subject !== 'math' || candidate.topicId !== 67 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice')
        reasonCodes.push('inequality_sign_chart_oracle_identity');
    for (const lang of ['zh', 'en']) {
        if (!p || JSON.stringify(parse(candidate.localizations?.[lang]?.prompt ?? '', exactScope, lang === 'en')) !== JSON.stringify(p)
            || JSON.stringify(candidate.localizations?.[lang]?.options) !== JSON.stringify(candidate.options))
            reasonCodes.push('inequality_sign_chart_oracle_' + lang + '_mismatch');
    }
    const options = candidate.options ?? [], sets = options.map(o => intervals(o.text));
    const boundaries = [...new Set([...(p?.roots ?? []), ...(p?.pole == null ? [] : [p.pole]), ...sets.flatMap(s => s?.flatMap(i => [i.lo, i.hi]).filter(Number.isFinite) ?? [])])].sort((a, b) => a - b);
    const probes = boundaries.map(x => [x, 1]);
    if (boundaries.length) {
        probes.push([boundaries[0] - 1, 1], [boundaries[boundaries.length - 1] + 1, 1]);
        for (let i = 1; i < boundaries.length; i++)
            probes.push([boundaries[i - 1] + boundaries[i], 2]);
    }
    const truth = p ? probes.map(([n, d]) => originalTruth(p, n, d)) : [];
    const signatures = sets.map(s => s ? probes.map(([n, d]) => membership(s, n, d)) : null);
    const optionVerdicts = options.map((o, i) => ({ optionId: o.id,
        verdict: !signatures[i] ? 'unknown' : p && JSON.stringify(signatures[i]) === JSON.stringify(truth) ? 'true' : 'false' }));
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !'ABCD'.split('').includes(o.id))
        || sets.some(s => !s) || new Set(signatures.map(s => JSON.stringify(s))).size !== 4)
        reasonCodes.push('inequality_sign_chart_oracle_invalid_or_equivalent_options');
    const trueOptionIds = optionVerdicts.filter(v => v.verdict === 'true').map(v => v.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('inequality_sign_chart_oracle_answer_disagreement');
    return { oracleVersion: exports.SUBJECT_PRACTICE_MATH_INEQUALITY_SIGN_CHART_INDEPENDENT_ORACLE_VERSION,
        status: reasonCodes.length ? (p ? 'disagreed' : 'abstained') : 'verified',
        scopeId: p ? 'math-medium-inequality-sign-chart-v1:' + exactScope : null, exactScope, scopeMatched: Boolean(p),
        optionVerdicts, trueOptionIds, selectedOptionId, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
        independentFromPrimarySolver: true, partitionBoundaries: boundaries, exactRationalProbeCount: probes.length,
        completenessBasis: 'all_real_zeros_poles_and_option_endpoints_partition_whitelisted_degree_at_most_two',
        providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
