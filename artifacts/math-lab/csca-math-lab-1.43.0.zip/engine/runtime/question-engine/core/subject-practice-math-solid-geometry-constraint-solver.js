"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.gnorm = exports.gtxt = exports.gcmp = exports.gsq = exports.gdiv = exports.gmul = exports.gsub = exports.gneg = exports.gadd = exports.SOLID_GEOMETRY_CONSTRAINT_CONSTRAINTS = exports.SOLID_GEOMETRY_CONSTRAINT_SCOPES = exports.SOLID_GEOMETRY_CONSTRAINT_SCOPE_VERSION = exports.SOLID_GEOMETRY_CONSTRAINT_SOLVER_VERSION = exports.SOLID_GEOMETRY_CONSTRAINT_TEMPLATE = exports.SOLID_GEOMETRY_CONSTRAINT_FAMILY = void 0;
exports.gq = gq;
exports.gread = gread;
exports.solidGeometryConstraintScopeFrom = solidGeometryConstraintScopeFrom;
exports.solidGeometryConstraintPrompt = solidGeometryConstraintPrompt;
exports.solidGeometryConstraintParametersFrom = solidGeometryConstraintParametersFrom;
exports.solidGeometryConstraintOptionKey = solidGeometryConstraintOptionKey;
exports.solidGeometryConstraintDerive = solidGeometryConstraintDerive;
exports.solveSubjectPracticeMathSolidGeometryConstraint = solveSubjectPracticeMathSolidGeometryConstraint;
exports.SOLID_GEOMETRY_CONSTRAINT_FAMILY = 'math_solid_geometry_constraint_reasoning';
exports.SOLID_GEOMETRY_CONSTRAINT_TEMPLATE = exports.SOLID_GEOMETRY_CONSTRAINT_FAMILY + '_v1';
exports.SOLID_GEOMETRY_CONSTRAINT_SOLVER_VERSION = 'math-solid-geometry-constraint-solver-v1-exact-dimensional-rational';
exports.SOLID_GEOMETRY_CONSTRAINT_SCOPE_VERSION = 'math-hard-solid-geometry-constraint-v1';
exports.SOLID_GEOMETRY_CONSTRAINT_SCOPES = ["cuboid_face_diagonals_division_point_plane_distance_squared", "cuboid_volume_face_areas_skew_lines_cosine_squared", "rectangular_pyramid_lateral_edge_section_plane_cosine_squared", "cone_two_sections_frustum_total_surface_area"];
exports.SOLID_GEOMETRY_CONSTRAINT_CONSTRAINTS = { topicCode: 'M-GEO-002', boundedRationalParameters: true, rationalNumeratorMax: 1000000000000, rationalDenominatorMax: 1000000000, maximumConstructionAttempts: 256, minimumEvidenceSlots: 4, minimumIndependentEvidenceGroups: 3, minimumReasoningSteps: 4, minimumQuantitativeRelations: 2, externalContextAllowed: false, requiresImage: false };
function gq(n, d = 1) { let a = BigInt(n), b = BigInt(d); if (!b || (a < 0n ? -a : a).toString(2).length > 512 || (b < 0n ? -b : b).toString(2).length > 512)
    throw Error('geometry_arithmetic_bound'); if (b < 0n) {
    a = -a;
    b = -b;
} let x = a < 0n ? -a : a, y = b; while (y) {
    [x, y] = [y, x % y];
} return { n: a / x, d: b / x }; }
const gadd = (a, b) => gq(a.n * b.d + b.n * a.d, a.d * b.d), gneg = (a) => gq(-a.n, a.d), gsub = (a, b) => (0, exports.gadd)(a, (0, exports.gneg)(b)), gmul = (a, b) => gq(a.n * b.n, a.d * b.d), gdiv = (a, b) => gq(a.n * b.d, a.d * b.n), gsq = (a) => (0, exports.gmul)(a, a);
exports.gadd = gadd, exports.gneg = gneg, exports.gsub = gsub, exports.gmul = gmul, exports.gdiv = gdiv, exports.gsq = gsq;
const gcmp = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0, gtxt = (a) => String(a.n) + (a.d === 1n ? '' : '/' + a.d);
exports.gcmp = gcmp, exports.gtxt = gtxt;
function gread(s) { if (typeof s !== 'string' || s.length > 64 || !/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(s))
    throw Error('geometry_rational_syntax'); const [n, d = '1'] = s.split('/'); return gq(BigInt(n), BigInt(d)); }
const bounded = (q) => q.n >= -1000000000000n && q.n <= 1000000000000n && q.d <= 1000000000n;
const Z = gq(0), T = gq(2), F = gq(4), obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : null;
const gnorm = (a, b) => (0, exports.gadd)((0, exports.gsq)(a), (0, exports.gsq)(b));
exports.gnorm = gnorm;
const dot = (a, b, x, y) => (0, exports.gadd)((0, exports.gmul)(a, x), (0, exports.gmul)(b, y));
const lineValue = (l, x, y) => (0, exports.gadd)(dot(l[0], l[1], x, y), l[2]);
function intersect(l, m) { const determinant = (0, exports.gsub)((0, exports.gmul)(l[0], m[1]), (0, exports.gmul)(l[1], m[0])); if (!determinant.n)
    throw Error('nonunique_intersection'); return { x: (0, exports.gdiv)((0, exports.gsub)((0, exports.gmul)(l[1], m[2]), (0, exports.gmul)(l[2], m[1])), determinant), y: (0, exports.gdiv)((0, exports.gsub)((0, exports.gmul)(l[2], m[0]), (0, exports.gmul)(l[0], m[2])), determinant), determinant }; }
function solidGeometryConstraintScopeFrom(value) { const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactSolidGeometryConstraintScope; return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1' && p?.subject === 'math' && p?.topicId === 74 && p?.targetDifficulty === 'hard' && p?.representationType === 'text' && p?.taskFamily === exports.SOLID_GEOMETRY_CONSTRAINT_FAMILY && p?.planTemplate === exports.SOLID_GEOMETRY_CONSTRAINT_TEMPLATE && r?.questionType === 'single_choice' && Object.entries(exports.SOLID_GEOMETRY_CONSTRAINT_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'solid_geometry_constraint_system' && s?.scenarioAction === scope && exports.SOLID_GEOMETRY_CONSTRAINT_SCOPES.includes(scope) ? scope : null; }
const names = [["P", "Q", "R", "t"], ["U", "W", "V", "t"], ["a", "b", "E", "t"], ["P", "A", "B", "C"]];
const startsZh = ["长方体中 O=(0,0,0)、U=(a,0,0)、V=(0,b,0)、W=(0,0,c)，对顶点 K=(a,b,c)，a、b、c>0（长度单位 cm）。三个过 O 的面对角线长度的平方为 P=a^2+b^2、Q=a^2+c^2、R=b^2+c^2（单位 cm^2）。T 在线段 OK 上，OT/OK=t。已知 ", "长方体 ABCD-A1B1C1D1 中 A=(0,0,0)、B=(a,0,0)、C=(a,b,0)、A1=(0,0,c)，a、b、c>0（长度单位 cm）。相邻面面积 U=ab、W=ac（单位 cm^2），体积 V=abc（单位 cm^3）。E 在线段 CC1 上，CE/CC1=t。已知 ", "矩形底四棱锥 S-ABCD 中，AB=a cm、BC=b cm，S 在底面中心的正上方，SA^2=E cm^2。T 在线段 AB 内，AT/AB=t。已知 ", "直圆锥的轴截面周长为 P cm，包含底面的总表面积为 Aπ cm^2。两个内部截面均平行于底面，面积依次为 Bπ、Cπ cm^2，且 0<B<C。已知 "], startsEn = ["In a cuboid, O=(0,0,0), U=(a,0,0), V=(0,b,0), W=(0,0,c), and opposite vertex K=(a,b,c), with a,b,c>0 in cm. The three face-diagonal squares at O are P=a^2+b^2, Q=a^2+c^2, R=b^2+c^2 in cm^2. T lies on OK with OT/OK=t. Given ", "In cuboid ABCD-A1B1C1D1, A=(0,0,0), B=(a,0,0), C=(a,b,0), A1=(0,0,c), with a,b,c>0 in cm. Adjacent face areas are U=ab and W=ac in cm^2, and volume V=abc in cm^3. E lies on CC1 with CE/CC1=t. Given ", "In rectangular pyramid S-ABCD, AB=a cm, BC=b cm, S lies vertically above the base center, and SA^2=E cm^2. T is inside segment AB with AT/AB=t. Given ", "A right circular cone has axial-section perimeter P cm and total surface area Aπ cm^2 including the base. Two internal sections parallel to the base have areas Bπ and Cπ cm^2, with 0<B<C. Given "], endsZh = ["求点 T 到平面 UVW 的距离平方（单位 cm^2）。", "求异面直线 AB1 与 BE 所成锐角的余弦平方。", "求平面 SAB 与 SCT 所成锐角的余弦平方。", "求两截面之间圆台的总表面积，包含两端圆面（单位 cm^2，保留 π）。"], endsEn = ["Find the squared distance from T to plane UVW in cm^2.", "Find the squared cosine of the acute angle between skew lines AB1 and BE.", "Find the squared cosine of the acute angle between planes SAB and SCT.", "Find the total surface area of the frustum between these sections, including both circular ends, in cm^2; keep π exact."];
function solidGeometryConstraintPrompt(p, lang) { const i = exports.SOLID_GEOMETRY_CONSTRAINT_SCOPES.indexOf(p.scope); return (lang === 'zh' ? startsZh : startsEn)[i] + names[i].map((n, j) => n + '=(' + p.data[j] + ')').join(', ') + '. ' + (lang === 'zh' ? endsZh : endsEn)[i]; }
function solidGeometryConstraintParametersFrom(text, scope, lang) { if (!scope || typeof text !== 'string' || text.length > 3000)
    return null; const i = exports.SOLID_GEOMETRY_CONSTRAINT_SCOPES.indexOf(scope), data = [...text.matchAll(/=\(([-+]?\d+(?:\/[1-9]\d*)?)\)/g)].map(m => m[1]), p = { scope, data }; return data.length === names[i].length && solidGeometryConstraintPrompt(p, lang) === text ? p : null; }
function spatialAnswer(q, i) { return (0, exports.gtxt)(q) + (i === 0 ? ' cm^2' : i === 3 ? 'π cm^2' : ''); }
function solidGeometryConstraintOptionKey(text, scope) { try {
    const i = exports.SOLID_GEOMETRY_CONSTRAINT_SCOPES.indexOf(scope);
    if (i < 0)
        return null;
    const s = text.trim().replace(/\u00b2/g, '^2').replace(/\*π/g, 'π').replace(/\s+/g, ' '), suffix = i === 0 ? ' cm^2' : i === 3 ? 'π cm^2' : '';
    if (suffix && !s.endsWith(suffix))
        return null;
    const q = gread(suffix ? s.slice(0, -suffix.length) : s);
    return bounded(q) ? spatialAnswer(q, i) : null;
}
catch {
    return null;
} }
const half = (q) => (0, exports.gdiv)(q, gq(2)), quarter = (q) => (0, exports.gdiv)(q, gq(4)), inv = (q) => (0, exports.gdiv)(gq(1), q), positive = (q) => q.n > 0n, unit = (q) => positive(q) && (0, exports.gcmp)(q, gq(1)) < 0;
function spatialCalculation(data, i) {
    try {
        if (i < 0 || i > 3 || data.length !== 4)
            return null;
        const v = data.map(gread);
        if (!v.every(bounded))
            return null;
        let answer, steps, certificate;
        const errors = [], err = (intent, value) => errors.push({ intent, value });
        if (i === 0) {
            const [P, Q, R, t] = v, X = half((0, exports.gsub)((0, exports.gadd)(P, Q), R)), Y = half((0, exports.gsub)((0, exports.gadd)(P, R), Q)), Z = half((0, exports.gsub)((0, exports.gadd)(Q, R), P));
            if (![P, Q, R, X, Y, Z].every(positive) || !unit(t) || !(0, exports.gcmp)(t, gq(1, 3)))
                return null;
            const N = (0, exports.gadd)((0, exports.gadd)(inv(X), inv(Y)), inv(Z)), res = (0, exports.gsub)((0, exports.gmul)(gq(3), t), gq(1));
            answer = (0, exports.gdiv)((0, exports.gsq)(res), N);
            certificate = { kind: 'unique_positive_cuboid_and_plane', squaredEdges: [X, Y, Z].map(exports.gtxt), normalNormSquared: (0, exports.gtxt)(N), planeResidual: (0, exports.gtxt)(res), complete: true };
            steps = ['a^2=(' + data[0] + '+' + data[1] + '-' + data[2] + ')/2=' + (0, exports.gtxt)(X) + '; b^2=' + (0, exports.gtxt)(Y) + '; c^2=' + (0, exports.gtxt)(Z),
                'P=a^2+b^2=' + (0, exports.gtxt)((0, exports.gadd)(X, Y)) + '; Q=a^2+c^2=' + (0, exports.gtxt)((0, exports.gadd)(X, Z)) + '; R=b^2+c^2=' + (0, exports.gtxt)((0, exports.gadd)(Y, Z)) + '; a,b,c>0',
                'plane UVW: x/a+y/b+z/c=1; T=(' + data[3] + 'a,' + data[3] + 'b,' + data[3] + 'c)',
                'normal^2=1/(' + (0, exports.gtxt)(X) + ')+1/(' + (0, exports.gtxt)(Y) + ')+1/(' + (0, exports.gtxt)(Z) + ')=' + (0, exports.gtxt)(N),
                'residual=3*(' + data[3] + ')-1=' + (0, exports.gtxt)(res) + '; distance^2=(' + (0, exports.gtxt)(res) + ')^2/(' + (0, exports.gtxt)(N) + ')=' + (0, exports.gtxt)(answer) + ' cm^2'];
            err('ignore_division_point_use_origin', inv(N));
            err('omit_normal_norm', (0, exports.gsq)(res));
            err('multiply_by_normal_norm', (0, exports.gmul)((0, exports.gsq)(res), N));
            err('omit_third_normal_component', (0, exports.gdiv)((0, exports.gsq)(res), (0, exports.gadd)(inv(X), inv(Y))));
            err('reverse_division_ratio', (0, exports.gdiv)((0, exports.gsq)((0, exports.gsub)((0, exports.gmul)(gq(3), (0, exports.gsub)(gq(1), t)), gq(1))), N));
        }
        else if (i === 1) {
            const [U, W, V, t] = v;
            if (![U, W, V].every(positive) || !unit(t))
                return null;
            const a = (0, exports.gdiv)((0, exports.gmul)(U, W), V), b = (0, exports.gdiv)(V, W), c = (0, exports.gdiv)(V, U), A = (0, exports.gsq)(a), B = (0, exports.gsq)(b), C = (0, exports.gsq)(c), n1 = (0, exports.gadd)(A, C), n2 = (0, exports.gadd)(B, (0, exports.gmul)((0, exports.gsq)(t), C)), dot = (0, exports.gmul)(t, C), den = (0, exports.gmul)(n1, n2);
            answer = (0, exports.gdiv)((0, exports.gsq)(dot), den);
            if (!unit(answer))
                return null;
            certificate = { kind: 'unique_cuboid_skew_directions', edges: [a, b, c].map(exports.gtxt), tripleProduct: (0, exports.gtxt)((0, exports.gmul)(a, (0, exports.gmul)(b, c))), directionNorms: [n1, n2].map(exports.gtxt), dot: (0, exports.gtxt)(dot), complete: true };
            steps = ['a=U*W/V=(' + data[0] + ')*(' + data[1] + ')/(' + data[2] + ')=' + (0, exports.gtxt)(a) + '; b=V/W=' + (0, exports.gtxt)(b) + '; c=V/U=' + (0, exports.gtxt)(c),
                'ab=' + (0, exports.gtxt)((0, exports.gmul)(a, b)) + '; ac=' + (0, exports.gtxt)((0, exports.gmul)(a, c)) + '; abc=' + (0, exports.gtxt)((0, exports.gmul)(a, (0, exports.gmul)(b, c))),
                'AB1=(' + (0, exports.gtxt)(a) + ',0,' + (0, exports.gtxt)(c) + '); BE=(0,' + (0, exports.gtxt)(b) + ',' + (0, exports.gtxt)((0, exports.gmul)(t, c)) + '); scalar triple product=' + (0, exports.gtxt)((0, exports.gmul)(a, (0, exports.gmul)(b, c))) + ' !=0',
                'dot=(' + data[3] + ')*(' + (0, exports.gtxt)(c) + ')^2=' + (0, exports.gtxt)(dot) + '; norm squares=' + (0, exports.gtxt)(n1) + ',' + (0, exports.gtxt)(n2),
                'cos^2=(' + (0, exports.gtxt)(dot) + ')^2/((' + (0, exports.gtxt)(n1) + ')*(' + (0, exports.gtxt)(n2) + '))=' + (0, exports.gtxt)(answer)];
            err('ignore_edge_division', (0, exports.gdiv)((0, exports.gsq)(C), (0, exports.gmul)((0, exports.gadd)(A, C), (0, exports.gadd)(B, C))));
            err('omit_dot_square', (0, exports.gdiv)(dot, den));
            err('omit_second_vertical_norm', (0, exports.gdiv)((0, exports.gsq)(dot), (0, exports.gmul)(n1, B)));
            err('omit_first_vertical_norm', (0, exports.gdiv)((0, exports.gsq)(dot), (0, exports.gmul)(A, n2)));
            err('unsquared_division_ratio', (0, exports.gdiv)((0, exports.gmul)(t, (0, exports.gsq)(C)), den));
            err('use_horizontal_product_dot', (0, exports.gdiv)((0, exports.gmul)(A, B), den));
        }
        else if (i === 2) {
            const [a, b, E, t] = v, H = (0, exports.gsub)(E, quarter((0, exports.gadd)((0, exports.gsq)(a), (0, exports.gsq)(b))));
            if (![a, b, E, H].every(positive) || !unit(t))
                return null;
            const A = (0, exports.gsq)(a), B = (0, exports.gsq)(b), u = (0, exports.gmul)(a, (0, exports.gmul)(H, (0, exports.gsub)(gq(1), t))), w = quarter((0, exports.gmul)(a, (0, exports.gmul)(B, t))), D = (0, exports.gadd)(u, w), n1 = (0, exports.gadd)(H, quarter(B)), n2 = (0, exports.gadd)((0, exports.gadd)((0, exports.gmul)(B, H), (0, exports.gmul)(A, (0, exports.gmul)(H, (0, exports.gsq)((0, exports.gsub)(gq(1), t))))), quarter((0, exports.gmul)(A, (0, exports.gmul)(B, (0, exports.gsq)(t))))), den = (0, exports.gmul)(n1, n2);
            answer = (0, exports.gdiv)((0, exports.gsq)(D), den);
            if (!unit(answer))
                return null;
            certificate = { kind: 'right_pyramid_complete_section_planes', heightSquared: (0, exports.gtxt)(H), baseSquared: [A, B].map(exports.gtxt), normalNorms: [n1, n2].map(exports.gtxt), negativeNormalDot: (0, exports.gtxt)((0, exports.gneg)(D)), complete: true };
            steps = ['h^2=E-(a^2+b^2)/4=(' + data[2] + ')-((' + data[0] + ')^2+(' + data[1] + ')^2)/4=' + (0, exports.gtxt)(H) + '>0',
                'A=(-a/2,-b/2,0); B=(a/2,-b/2,0); C=(a/2,b/2,0); S=(0,0,h); T=(' + (0, exports.gtxt)((0, exports.gmul)(a, (0, exports.gsub)(t, gq(1, 2)))) + ',' + (0, exports.gtxt)((0, exports.gneg)(half(b))) + ',0)',
                'n1=(0,-h,b/2); n2=(-b*h,a*h*(1-t),-a*b*t/2); t=' + data[3],
                'n1^2=' + (0, exports.gtxt)(n1) + '; n2^2=' + (0, exports.gtxt)(n2) + '; n1 dot n2=-(' + (0, exports.gtxt)(u) + '+' + (0, exports.gtxt)(w) + ')=' + (0, exports.gtxt)((0, exports.gneg)(D)),
                'cos^2=(' + (0, exports.gtxt)(D) + ')^2/((' + (0, exports.gtxt)(n1) + ')*(' + (0, exports.gtxt)(n2) + '))=' + (0, exports.gtxt)(answer)];
            err('omit_section_first_dot_term', (0, exports.gdiv)((0, exports.gsq)(w), den));
            err('omit_section_second_dot_term', (0, exports.gdiv)((0, exports.gsq)(u), den));
            err('reverse_section_dot_sign', (0, exports.gdiv)((0, exports.gsq)((0, exports.gsub)(u, w)), den));
            err('omit_dot_cross_term', (0, exports.gdiv)((0, exports.gadd)((0, exports.gsq)(u), (0, exports.gsq)(w)), den));
            err('omit_first_normal_base_component', (0, exports.gdiv)((0, exports.gsq)(D), (0, exports.gmul)(H, n2)));
        }
        else {
            const [P, A, B, C] = v;
            if (!v.every(positive))
                return null;
            const sum = half(P), r = (0, exports.gdiv)(A, sum), l = (0, exports.gsub)(sum, r), R = (0, exports.gsq)(r), H = (0, exports.gsub)((0, exports.gsq)(l), R);
            if (!positive(H) || (0, exports.gcmp)(l, r) <= 0 || (0, exports.gcmp)(B, C) >= 0 || (0, exports.gcmp)(C, R) >= 0)
                return null;
            const ratio = (0, exports.gdiv)(l, r), lateral = (0, exports.gmul)(ratio, (0, exports.gsub)(C, B));
            answer = (0, exports.gadd)((0, exports.gadd)(B, C), lateral);
            certificate = { kind: 'unique_positive_cone_two_internal_sections', radius: (0, exports.gtxt)(r), slantHeight: (0, exports.gtxt)(l), heightSquared: (0, exports.gtxt)(H), squaredSectionScales: [(0, exports.gdiv)(B, R), (0, exports.gdiv)(C, R)].map(exports.gtxt), complete: true };
            steps = ['r+l=P/2=(' + data[0] + ')/2=' + (0, exports.gtxt)(sum) + '; r*(r+l)=A=' + data[1],
                'r=A/(P/2)=' + (0, exports.gtxt)(r) + '; l=P/2-r=' + (0, exports.gtxt)(l) + '; h^2=l^2-r^2=' + (0, exports.gtxt)(H) + '>0',
                '0<B=' + data[2] + '<C=' + data[3] + '<r^2=' + (0, exports.gtxt)(R) + '; squared similarity ratios=' + (0, exports.gtxt)((0, exports.gdiv)(B, R)) + ',' + (0, exports.gtxt)((0, exports.gdiv)(C, R)),
                'lateral area/pi=(l/r)*(C-B)=(' + (0, exports.gtxt)(ratio) + ')*((' + data[3] + ')-(' + data[2] + '))=' + (0, exports.gtxt)(lateral),
                'total area/pi=B+C+lateral/pi=(' + data[2] + ')+(' + data[3] + ')+(' + (0, exports.gtxt)(lateral) + ')=' + (0, exports.gtxt)(answer)];
            err('omit_both_frustum_end_faces', lateral);
            err('omit_larger_frustum_end_face', (0, exports.gadd)(lateral, B));
            err('omit_smaller_frustum_end_face', (0, exports.gadd)(lateral, C));
            err('add_cone_lateral_areas', (0, exports.gadd)((0, exports.gadd)(B, C), (0, exports.gmul)(ratio, (0, exports.gadd)(B, C))));
        }
        if (!bounded(answer) || !positive(answer))
            return null;
        return { answer, steps, certificate, errors };
    }
    catch {
        return null;
    }
}
function solidGeometryConstraintDerive(p) {
    try {
        const i = exports.SOLID_GEOMETRY_CONSTRAINT_SCOPES.indexOf(p.scope), d = spatialCalculation(p.data, i);
        if (!d)
            return null;
        const witnesses = [];
        for (let j = 0; j < 4; j++) {
            let found = false;
            for (const delta of (i === 1 ? [gq(1), gq(-1), gq(1, 2), gq(-1, 2), gq(1, 4), gq(-1, 4), gq(1, 8), gq(-1, 8), gq(1, 16), gq(-1, 16), gq(1, 32), gq(-1, 32), gq(1, 64), gq(-1, 64)] : [gq(1, 16), gq(-1, 16), gq(1, 32), gq(-1, 32), gq(1, 64), gq(-1, 64)])) {
                const alt = p.data.slice();
                alt[j] = (0, exports.gtxt)((0, exports.gadd)(gread(alt[j]), delta));
                const other = spatialCalculation(alt, i);
                if (other && (0, exports.gcmp)(other.answer, d.answer)) {
                    witnesses.push({ omitted: names[i][j], alternativeData: alt, differentAnswer: spatialAnswer(other.answer, i) });
                    found = true;
                    break;
                }
            }
            if (!found)
                return null;
        }
        const answer = spatialAnswer(d.answer, i), errors = d.errors.filter(e => bounded(e.value) && positive(e.value) && ((i === 1 || i === 2) ? unit(e.value) : true))
            .map(e => ({ intent: e.intent, text: spatialAnswer(e.value, i), key: spatialAnswer(e.value, i) }))
            .filter((e, j, a) => e.key !== answer && a.findIndex(x => x.key === e.key) === j).slice(0, 3);
        if (errors.length !== 3)
            return null;
        const proof = 'givens=' + p.data.join(',') + '; ' + d.steps.join('; '), hardEvidence = { version: 'solid-geometry-constraint-hard-evidence-v1', evidenceSlots: 4, independentEvidenceGroups: 4, reasoningSteps: d.steps.length, quantitativeRelations: 2, groups: names[i].slice(), effectiveConstraints: witnesses, completeSolidGeometryCertificate: d.certificate, criticalPoints: [], answer, visibleProof: proof, studentCalibrated: false };
        return { answer, text: answer, errors, proof, steps: d.steps, hardEvidence };
    }
    catch {
        return null;
    }
}
function solveSubjectPracticeMathSolidGeometryConstraint(candidate, context = {}) {
    const scope = solidGeometryConstraintScopeFrom(context.questionPlan), parameters = solidGeometryConstraintParametersFrom(candidate.prompt, scope, 'zh'), d = parameters ? solidGeometryConstraintDerive(parameters) : null, reasonCodes = [];
    if (!d)
        reasonCodes.push('solid_geometry_constraint_outside_hard_scope');
    if (candidate.subject !== 'math' || candidate.topicId !== 74 || candidate.designedDifficulty !== 'hard' || candidate.questionType !== 'single_choice')
        reasonCodes.push('solid_geometry_constraint_identity');
    const options = candidate.options ?? [], keys = options.map(o => scope ? solidGeometryConstraintOptionKey(o.text, scope) : null);
    if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4)
        reasonCodes.push('solid_geometry_constraint_options');
    for (const lang of ['zh', 'en']) {
        const l = candidate.localizations?.[lang];
        if (!parameters || JSON.stringify(solidGeometryConstraintParametersFrom(l?.prompt ?? '', scope, lang)) !== JSON.stringify(parameters))
            reasonCodes.push('solid_geometry_constraint_' + lang + '_stem');
        if (JSON.stringify(l?.options?.map(o => [o.id, scope ? solidGeometryConstraintOptionKey(o.text, scope) : null])) !== JSON.stringify(options.map((o, j) => [o.id, keys[j]])))
            reasonCodes.push('solid_geometry_constraint_' + lang + '_options');
    }
    const expected = d?.answer ?? null, optionVerdicts = options.map((o, j) => ({ optionId: o.id, semanticValue: keys[j], verdict: keys[j] === null ? 'unknown' : keys[j] === expected ? 'true' : 'false' })), trueOptionIds = optionVerdicts.filter(x => x.verdict === 'true').map(x => x.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
    if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer)
        reasonCodes.push('solid_geometry_constraint_answer');
    const meta = candidate.optionMetadata ?? [];
    if (meta.length !== 3 || new Set(meta.map(m => m.optionId)).size !== 3 || new Set(meta.map(m => m.distractorIntent)).size !== 3 || meta.some(m => m.optionId === selectedOptionId || !d?.errors.some(e => e.intent === m.distractorIntent && e.key === keys[options.findIndex(o => o.id === m.optionId)])))
        reasonCodes.push('solid_geometry_constraint_error_intent');
    const scopeId = parameters ? exports.SOLID_GEOMETRY_CONSTRAINT_SCOPE_VERSION + ':' + scope : null;
    return { solverVersion: exports.SOLID_GEOMETRY_CONSTRAINT_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' : 'unparsed') : 'verified', taskFamily: exports.SOLID_GEOMETRY_CONSTRAINT_FAMILY, scopeId, exactScope: scope, parameters, expectedAnswer: expected, proof: d?.proof ?? null, hardEvidence: d?.hardEvidence ?? null, optionVerdicts, trueOptionIds, selectedOptionId, verificationScope: { scopeVersion: exports.SOLID_GEOMETRY_CONSTRAINT_SCOPE_VERSION, scopeId, matched: !!d, exactScope: scope, reasonCodes: d ? [] : ['solid_geometry_constraint_scope_not_matched'] }, uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer, providerImpact: 'none_no_provider_call', productionGateImpact: 'none_shadow_only', reasonCodes };
}
