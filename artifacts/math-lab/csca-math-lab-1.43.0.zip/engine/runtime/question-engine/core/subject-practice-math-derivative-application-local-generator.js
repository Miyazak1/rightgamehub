"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DERIVATIVE_APPLICATION_GENERATOR_VERSION = void 0;
exports.createSubjectPracticeMathDerivativeApplicationLocalGenerator = createSubjectPracticeMathDerivativeApplicationLocalGenerator;
const subject_practice_math_derivative_application_solver_1 = require("./subject-practice-math-derivative-application-solver");
const subject_practice_math_derivative_application_independent_oracle_1 = require("./subject-practice-math-derivative-application-independent-oracle");
const subject_practice_math_derivative_application_explanation_verifier_1 = require("./subject-practice-math-derivative-application-explanation-verifier");
exports.DERIVATIVE_APPLICATION_GENERATOR_VERSION = 'math-derivative-application-generator-v1-bounded';
function parameters(scope, seed, attempt) {
    const n = seed % 100000, sign = n % 2 ? -1 : 1, c0 = n % 17 - 8;
    if (scope === subject_practice_math_derivative_application_solver_1.DERIVATIVE_APPLICATION_SCOPES[0])
        return { scope, c3: 0, c2: sign * (1 + (Math.floor(n / 2) + attempt) % 3),
            c1: (Math.floor(n / 6) + attempt) % 13 - 6, c0, t: [-3, -2, -1, 1, 2, 3][(Math.floor(n / 3) + attempt) % 6], l: 0, u: 0, target: 'tangent' };
    const pairs = [];
    for (let a = -3; a < 3; a++)
        for (let b = a + 1; b <= 3; b++)
            pairs.push([a, b]);
    const [r1, r2] = pairs[(Math.floor(n / 4) + attempt) % pairs.length], A = sign * (1 + Math.floor(n / 8) % 2);
    const intervals = [[-4, 4], [r1, 4], [-4, r2], [r1 - 1, r2 + 1]], [l, u] = intervals[Math.floor(n / 4) % 4];
    return { scope, c3: 2 * A, c2: -3 * A * (r1 + r2), c1: 6 * A * r1 * r2, c0, t: 0,
        l: scope === subject_practice_math_derivative_application_solver_1.DERIVATIVE_APPLICATION_SCOPES[3] ? l : 0, u: scope === subject_practice_math_derivative_application_solver_1.DERIVATIVE_APPLICATION_SCOPES[3] ? u : 0,
        target: scope === subject_practice_math_derivative_application_solver_1.DERIVATIVE_APPLICATION_SCOPES[1] ? (Math.floor(n / 2) % 2 ? 'decreasing' : 'increasing') : (Math.floor(n / 2) % 2 ? 'minimum' : 'maximum') };
}
function createSubjectPracticeMathDerivativeApplicationLocalGenerator(ports) {
    return (input) => {
        const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0;
        const exactScope = (0, subject_practice_math_derivative_application_solver_1.derivativeApplicationScopeFrom)(input.questionPlan), b = input.blueprint;
        const common = { generatorVersion: exports.DERIVATIVE_APPLICATION_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call',
            estimatedCostUsd: 0, productionImpact: 'none_shadow_only', automaticPublicationEligible: false };
        const unsupported = { ...common, status: 'unsupported_question_plan', candidate: null, solverEvidence: null, oracleEvidence: null,
            explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['derivative_application_local_plan_not_supported'] };
        if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 71 || b.topicCode !== 'M-CALC-001'
            || b.difficulty !== 'medium' || b.questionType !== 'single_choice')
            return unsupported;
        let selected = null, parameterAttempts = 0;
        for (let attempt = 0; attempt < 64; attempt++) {
            parameterAttempts++;
            // A zero constant would erase the meaning of the omit-constant distractor; vary only this local trial.
            const p = parameters(exactScope, seed, attempt);
            if (!p.c0)
                p.c0 = 8;
            if (!(0, subject_practice_math_derivative_application_solver_1.derivativeApplicationParametersFrom)((0, subject_practice_math_derivative_application_solver_1.derivativeApplicationPrompt)(p, 'zh'), exactScope, 'zh'))
                continue;
            const keys = [(0, subject_practice_math_derivative_application_solver_1.derivativeApplicationAnswer)(p), ...(0, subject_practice_math_derivative_application_solver_1.derivativeApplicationDistractors)(p).map(o => o.key)].map(x => (0, subject_practice_math_derivative_application_solver_1.derivativeApplicationOptionKey)(x, exactScope));
            if (keys.includes(null) || new Set(keys).size !== 4)
                continue;
            selected = p;
            break;
        }
        if (!selected)
            return { ...unsupported, status: 'bounded_generation_exhausted', parameterAttempts };
        const p = selected, answer = (0, subject_practice_math_derivative_application_solver_1.derivativeApplicationAnswer)(p), choices = (0, subject_practice_math_derivative_application_solver_1.derivativeApplicationDistractors)(p), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
        choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
        const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: x.key })), alternate = Math.floor(seed / 16) % 2 === 1;
        const prompt = (0, subject_practice_math_derivative_application_solver_1.derivativeApplicationPrompt)(p, 'zh', alternate), enPrompt = (0, subject_practice_math_derivative_application_solver_1.derivativeApplicationPrompt)(p, 'en', alternate), explanation = (0, subject_practice_math_derivative_application_explanation_verifier_1.renderDerivativeApplicationExplanation)(p, answer, correctAnswer);
        const candidate = { subject: 'math', topicId: 71, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice',
            prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['导数与微积分初步', exactScope],
            optionMetadata: choices.flatMap((o, i) => o.intent ? [{ optionId: 'ABCD'[i], distractorIntent: o.intent, misconceptionTags: [o.intent] }] : []),
            localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['导数与微积分初步', exactScope] },
                en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Derivative applications', exactScope] } }, syllabusVersion: b.syllabusVersion };
        const context = { questionPlan: input.questionPlan }, solverEvidence = (0, subject_practice_math_derivative_application_solver_1.solveSubjectPracticeMathDerivativeApplication)(candidate, context);
        const oracleEvidence = (0, subject_practice_math_derivative_application_independent_oracle_1.verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle)(candidate, context), explanationEvidence = (0, subject_practice_math_derivative_application_explanation_verifier_1.verifySubjectPracticeMathDerivativeApplicationExplanation)(candidate, context);
        const adherence = ports.adherenceFor(input.questionPlan, candidate);
        const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres
            && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
        return { ...common, parameterAttempts, status: verified ? 'generated_and_triple_verified' : 'self_verification_failed', candidate: verified ? candidate : null,
            solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
            reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
    };
}
