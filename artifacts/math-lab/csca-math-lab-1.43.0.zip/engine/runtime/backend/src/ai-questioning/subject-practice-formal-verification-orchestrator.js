"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_FORMAL_VERIFICATION_ORCHESTRATOR_VERSION = void 0;
exports.verifySubjectPracticeFormalCandidate = verifySubjectPracticeFormalCandidate;
const subject_practice_math_normal_distribution_constraint_solver_1 = require("./subject-practice-math-normal-distribution-constraint-solver");
const subject_practice_math_statistics_constraint_solver_1 = require("./subject-practice-math-statistics-constraint-solver");
const subject_practice_math_probability_constraint_solver_1 = require("./subject-practice-math-probability-constraint-solver");
const subject_practice_math_solid_geometry_constraint_solver_1 = require("./subject-practice-math-solid-geometry-constraint-solver");
const subject_practice_math_vector_complex_constraint_solver_1 = require("./subject-practice-math-vector-complex-constraint-solver");
const subject_practice_math_plane_analytic_geometry_constraint_solver_1 = require("./subject-practice-math-plane-analytic-geometry-constraint-solver");
const subject_practice_math_sequence_constraint_solver_1 = require("./subject-practice-math-sequence-constraint-solver");
const subject_practice_math_derivative_constraint_solver_1 = require("./subject-practice-math-derivative-constraint-solver");
const subject_practice_math_elementary_exp_log_constraint_solver_1 = require("./subject-practice-math-elementary-exp-log-constraint-solver");
const subject_practice_math_function_composition_solver_1 = require("./subject-practice-math-function-composition-solver");
const subject_practice_math_compound_inequality_solver_1 = require("./subject-practice-math-compound-inequality-solver");
const subject_practice_math_normal_distribution_constraint_independent_oracle_1 = require("./subject-practice-math-normal-distribution-constraint-independent-oracle");
const subject_practice_math_statistics_constraint_independent_oracle_1 = require("./subject-practice-math-statistics-constraint-independent-oracle");
const subject_practice_math_probability_constraint_independent_oracle_1 = require("./subject-practice-math-probability-constraint-independent-oracle");
const subject_practice_math_solid_geometry_constraint_independent_oracle_1 = require("./subject-practice-math-solid-geometry-constraint-independent-oracle");
const subject_practice_math_vector_complex_constraint_independent_oracle_1 = require("./subject-practice-math-vector-complex-constraint-independent-oracle");
const subject_practice_math_plane_analytic_geometry_constraint_independent_oracle_1 = require("./subject-practice-math-plane-analytic-geometry-constraint-independent-oracle");
const subject_practice_math_sequence_constraint_independent_oracle_1 = require("./subject-practice-math-sequence-constraint-independent-oracle");
const subject_practice_math_derivative_constraint_independent_oracle_1 = require("./subject-practice-math-derivative-constraint-independent-oracle");
const subject_practice_math_elementary_exp_log_constraint_independent_oracle_1 = require("./subject-practice-math-elementary-exp-log-constraint-independent-oracle");
const subject_practice_math_function_composition_independent_oracle_1 = require("./subject-practice-math-function-composition-independent-oracle");
const subject_practice_math_compound_inequality_independent_oracle_1 = require("./subject-practice-math-compound-inequality-independent-oracle");
const subject_practice_math_normal_distribution_constraint_explanation_verifier_1 = require("./subject-practice-math-normal-distribution-constraint-explanation-verifier");
const subject_practice_math_statistics_constraint_explanation_verifier_1 = require("./subject-practice-math-statistics-constraint-explanation-verifier");
const subject_practice_math_probability_constraint_explanation_verifier_1 = require("./subject-practice-math-probability-constraint-explanation-verifier");
const subject_practice_math_solid_geometry_constraint_explanation_verifier_1 = require("./subject-practice-math-solid-geometry-constraint-explanation-verifier");
const subject_practice_math_vector_complex_constraint_explanation_verifier_1 = require("./subject-practice-math-vector-complex-constraint-explanation-verifier");
const subject_practice_math_plane_analytic_geometry_constraint_explanation_verifier_1 = require("./subject-practice-math-plane-analytic-geometry-constraint-explanation-verifier");
const subject_practice_math_sequence_constraint_explanation_verifier_1 = require("./subject-practice-math-sequence-constraint-explanation-verifier");
const subject_practice_math_derivative_constraint_explanation_verifier_1 = require("./subject-practice-math-derivative-constraint-explanation-verifier");
const subject_practice_math_elementary_exp_log_constraint_explanation_verifier_1 = require("./subject-practice-math-elementary-exp-log-constraint-explanation-verifier");
const subject_practice_math_function_composition_explanation_verifier_1 = require("./subject-practice-math-function-composition-explanation-verifier");
const subject_practice_math_compound_inequality_explanation_verifier_1 = require("./subject-practice-math-compound-inequality-explanation-verifier");
const subject_practice_math_interval_set_parameter_solver_1 = require("./subject-practice-math-interval-set-parameter-solver");
const subject_practice_math_interval_set_parameter_independent_oracle_1 = require("./subject-practice-math-interval-set-parameter-independent-oracle");
const subject_practice_math_interval_set_parameter_explanation_verifier_1 = require("./subject-practice-math-interval-set-parameter-explanation-verifier");
const subject_practice_math_normal_distribution_two_step_solver_1 = require("./subject-practice-math-normal-distribution-two-step-solver");
const subject_practice_math_descriptive_statistics_two_step_solver_1 = require("./subject-practice-math-descriptive-statistics-two-step-solver");
const subject_practice_math_probability_two_stage_solver_1 = require("./subject-practice-math-probability-two-stage-solver");
const subject_practice_math_solid_geometry_two_step_solver_1 = require("./subject-practice-math-solid-geometry-two-step-solver");
const subject_practice_math_vector_complex_two_step_solver_1 = require("./subject-practice-math-vector-complex-two-step-solver");
const subject_practice_math_plane_analytic_geometry_solver_1 = require("./subject-practice-math-plane-analytic-geometry-solver");
const subject_practice_math_derivative_application_solver_1 = require("./subject-practice-math-derivative-application-solver");
const subject_practice_math_elementary_exp_log_solver_1 = require("./subject-practice-math-elementary-exp-log-solver");
const subject_practice_math_normal_distribution_two_step_explanation_verifier_1 = require("./subject-practice-math-normal-distribution-two-step-explanation-verifier");
const subject_practice_math_descriptive_statistics_two_step_explanation_verifier_1 = require("./subject-practice-math-descriptive-statistics-two-step-explanation-verifier");
const subject_practice_math_probability_two_stage_explanation_verifier_1 = require("./subject-practice-math-probability-two-stage-explanation-verifier");
const subject_practice_math_solid_geometry_two_step_explanation_verifier_1 = require("./subject-practice-math-solid-geometry-two-step-explanation-verifier");
const subject_practice_math_vector_complex_two_step_explanation_verifier_1 = require("./subject-practice-math-vector-complex-two-step-explanation-verifier");
const subject_practice_math_plane_analytic_geometry_explanation_verifier_1 = require("./subject-practice-math-plane-analytic-geometry-explanation-verifier");
const subject_practice_math_derivative_application_explanation_verifier_1 = require("./subject-practice-math-derivative-application-explanation-verifier");
const subject_practice_math_elementary_exp_log_explanation_verifier_1 = require("./subject-practice-math-elementary-exp-log-explanation-verifier");
const subject_practice_math_normal_distribution_two_step_independent_oracle_1 = require("./subject-practice-math-normal-distribution-two-step-independent-oracle");
const subject_practice_math_descriptive_statistics_two_step_independent_oracle_1 = require("./subject-practice-math-descriptive-statistics-two-step-independent-oracle");
const subject_practice_math_probability_two_stage_independent_oracle_1 = require("./subject-practice-math-probability-two-stage-independent-oracle");
const subject_practice_math_solid_geometry_two_step_independent_oracle_1 = require("./subject-practice-math-solid-geometry-two-step-independent-oracle");
const subject_practice_math_vector_complex_two_step_independent_oracle_1 = require("./subject-practice-math-vector-complex-two-step-independent-oracle");
const subject_practice_math_plane_analytic_geometry_independent_oracle_1 = require("./subject-practice-math-plane-analytic-geometry-independent-oracle");
const subject_practice_math_derivative_application_independent_oracle_1 = require("./subject-practice-math-derivative-application-independent-oracle");
const subject_practice_math_elementary_exp_log_independent_oracle_1 = require("./subject-practice-math-elementary-exp-log-independent-oracle");
const subject_practice_math_function_interval_solver_1 = require("./subject-practice-math-function-interval-solver");
const subject_practice_math_function_interval_explanation_verifier_1 = require("./subject-practice-math-function-interval-explanation-verifier");
const subject_practice_math_function_interval_independent_oracle_1 = require("./subject-practice-math-function-interval-independent-oracle");
const subject_practice_math_inequality_sign_chart_solver_1 = require("./subject-practice-math-inequality-sign-chart-solver");
const subject_practice_math_inequality_sign_chart_explanation_verifier_1 = require("./subject-practice-math-inequality-sign-chart-explanation-verifier");
const subject_practice_math_inequality_sign_chart_independent_oracle_1 = require("./subject-practice-math-inequality-sign-chart-independent-oracle");
const subject_practice_math_solid_geometry_solver_1 = require("./subject-practice-math-solid-geometry-solver");
const subject_practice_math_normal_distribution_basic_solver_1 = require("./subject-practice-math-normal-distribution-basic-solver");
const subject_practice_math_normal_distribution_basic_explanation_verifier_1 = require("./subject-practice-math-normal-distribution-basic-explanation-verifier");
const subject_practice_math_normal_distribution_basic_independent_oracle_1 = require("./subject-practice-math-normal-distribution-basic-independent-oracle");
const subject_practice_math_descriptive_statistics_solver_1 = require("./subject-practice-math-descriptive-statistics-solver");
const subject_practice_math_descriptive_statistics_explanation_verifier_1 = require("./subject-practice-math-descriptive-statistics-explanation-verifier");
const subject_practice_math_descriptive_statistics_independent_oracle_1 = require("./subject-practice-math-descriptive-statistics-independent-oracle");
const subject_practice_math_solid_geometry_explanation_verifier_1 = require("./subject-practice-math-solid-geometry-explanation-verifier");
const subject_practice_math_solid_geometry_independent_oracle_1 = require("./subject-practice-math-solid-geometry-independent-oracle");
const subject_practice_math_solver_1 = require("./subject-practice-math-solver");
const subject_practice_math_line_relation_solver_1 = require("./subject-practice-math-line-relation-solver");
const subject_practice_physics_kinematics_solver_1 = require("./subject-practice-physics-kinematics-solver");
const subject_practice_chemistry_acid_base_solver_1 = require("./subject-practice-chemistry-acid-base-solver");
const subject_practice_math_elementary_explanation_verifier_1 = require("./subject-practice-math-elementary-explanation-verifier");
const subject_practice_math_line_relation_explanation_verifier_1 = require("./subject-practice-math-line-relation-explanation-verifier");
const subject_practice_physics_kinematics_explanation_verifier_1 = require("./subject-practice-physics-kinematics-explanation-verifier");
const subject_practice_chemistry_acid_base_explanation_verifier_1 = require("./subject-practice-chemistry-acid-base-explanation-verifier");
const subject_practice_math_elementary_independent_oracle_1 = require("./subject-practice-math-elementary-independent-oracle");
const subject_practice_math_line_relation_independent_oracle_1 = require("./subject-practice-math-line-relation-independent-oracle");
const subject_practice_physics_kinematics_independent_oracle_1 = require("./subject-practice-physics-kinematics-independent-oracle");
const subject_practice_physics_newton_force_solver_1 = require("./subject-practice-physics-newton-force-solver");
const subject_practice_physics_newton_force_explanation_verifier_1 = require("./subject-practice-physics-newton-force-explanation-verifier");
const subject_practice_physics_newton_force_independent_oracle_1 = require("./subject-practice-physics-newton-force-independent-oracle");
const subject_practice_chemistry_acid_base_independent_oracle_1 = require("./subject-practice-chemistry-acid-base-independent-oracle");
const subject_practice_math_derivative_solver_1 = require("./subject-practice-math-derivative-solver");
const subject_practice_math_derivative_explanation_verifier_1 = require("./subject-practice-math-derivative-explanation-verifier");
const subject_practice_math_derivative_independent_oracle_1 = require("./subject-practice-math-derivative-independent-oracle");
const subject_practice_chemistry_ph_operation_error_solver_1 = require("./subject-practice-chemistry-ph-operation-error-solver");
const subject_practice_chemistry_ph_operation_error_explanation_verifier_1 = require("./subject-practice-chemistry-ph-operation-error-explanation-verifier");
const subject_practice_chemistry_ph_operation_error_independent_oracle_1 = require("./subject-practice-chemistry-ph-operation-error-independent-oracle");
const subject_practice_physics_optics_solver_1 = require("./subject-practice-physics-optics-solver");
const subject_practice_physics_optics_explanation_verifier_1 = require("./subject-practice-physics-optics-explanation-verifier");
const subject_practice_physics_optics_independent_oracle_1 = require("./subject-practice-physics-optics-independent-oracle");
const subject_practice_math_set_solver_1 = require("./subject-practice-math-set-solver");
const subject_practice_math_set_explanation_verifier_1 = require("./subject-practice-math-set-explanation-verifier");
const subject_practice_math_set_independent_oracle_1 = require("./subject-practice-math-set-independent-oracle");
const subject_practice_math_set_composite_solver_1 = require("./subject-practice-math-set-composite-solver");
const subject_practice_math_set_composite_explanation_verifier_1 = require("./subject-practice-math-set-composite-explanation-verifier");
const subject_practice_math_set_composite_independent_oracle_1 = require("./subject-practice-math-set-composite-independent-oracle");
const subject_practice_math_sequence_solver_1 = require("./subject-practice-math-sequence-solver");
const subject_practice_math_sequence_explanation_verifier_1 = require("./subject-practice-math-sequence-explanation-verifier");
const subject_practice_math_sequence_independent_oracle_1 = require("./subject-practice-math-sequence-independent-oracle");
const subject_practice_math_sequence_two_condition_solver_1 = require("./subject-practice-math-sequence-two-condition-solver");
const subject_practice_math_sequence_two_condition_explanation_verifier_1 = require("./subject-practice-math-sequence-two-condition-explanation-verifier");
const subject_practice_math_sequence_two_condition_independent_oracle_1 = require("./subject-practice-math-sequence-two-condition-independent-oracle");
const subject_practice_math_basic_function_solver_1 = require("./subject-practice-math-basic-function-solver");
const subject_practice_math_basic_function_explanation_verifier_1 = require("./subject-practice-math-basic-function-explanation-verifier");
const subject_practice_math_basic_function_independent_oracle_1 = require("./subject-practice-math-basic-function-independent-oracle");
const subject_practice_math_inequality_solver_1 = require("./subject-practice-math-inequality-solver");
const subject_practice_math_inequality_explanation_verifier_1 = require("./subject-practice-math-inequality-explanation-verifier");
const subject_practice_math_inequality_independent_oracle_1 = require("./subject-practice-math-inequality-independent-oracle");
const subject_practice_math_vector_complex_solver_1 = require("./subject-practice-math-vector-complex-solver");
const subject_practice_math_vector_complex_explanation_verifier_1 = require("./subject-practice-math-vector-complex-explanation-verifier");
const subject_practice_math_vector_complex_independent_oracle_1 = require("./subject-practice-math-vector-complex-independent-oracle");
const subject_practice_math_probability_solver_1 = require("./subject-practice-math-probability-solver");
const subject_practice_math_probability_explanation_verifier_1 = require("./subject-practice-math-probability-explanation-verifier");
const subject_practice_math_probability_independent_oracle_1 = require("./subject-practice-math-probability-independent-oracle");
exports.SUBJECT_PRACTICE_FORMAL_VERIFICATION_ORCHESTRATOR_VERSION = 'subject-practice-formal-verification-orchestrator-v16-math-normal-basic';
function clean(value) {
    return String(value ?? '').replace(/\s+/g, ' ').trim();
}
function recordFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function verifySubjectPracticeFormalCandidate(input) {
    const subject = clean(input.candidate.subject).toLowerCase();
    const taskFamily = clean(input.taskFamily);
    const planTemplate = clean(recordFrom(input.questionPlan)?.planTemplate);
    const context = { questionPlan: input.questionPlan };
    let solverEvidence;
    let explanationEvidence;
    let independentOracleEvidence;
    if (subject === 'math' && taskFamily === 'elementary_function_direct_property') {
        solverEvidence = (0, subject_practice_math_solver_1.solveElementaryFunctionDirectProperty)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_elementary_explanation_verifier_1.verifySubjectPracticeMathElementaryExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_elementary_independent_oracle_1.verifySubjectPracticeMathElementaryWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_line_relation_direct') {
        solverEvidence = (0, subject_practice_math_line_relation_solver_1.solveSubjectPracticeMathLineRelation)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_line_relation_explanation_verifier_1.verifySubjectPracticeMathLineRelationExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_line_relation_independent_oracle_1.verifySubjectPracticeMathLineRelationWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_finite_set_operation') {
        solverEvidence = (0, subject_practice_math_set_solver_1.solveSubjectPracticeMathSet)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_set_explanation_verifier_1.verifySubjectPracticeMathSetExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_set_independent_oracle_1.verifySubjectPracticeMathSetWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_finite_set_composite_operation') {
        solverEvidence = (0, subject_practice_math_set_composite_solver_1.solveSubjectPracticeMathSetComposite)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_set_composite_explanation_verifier_1.verifySubjectPracticeMathSetCompositeExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_set_composite_independent_oracle_1.verifySubjectPracticeMathSetCompositeWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_basic_sequence_direct_calculation') {
        solverEvidence = (0, subject_practice_math_sequence_solver_1.solveSubjectPracticeMathSequence)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_sequence_explanation_verifier_1.verifySubjectPracticeMathSequenceExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_sequence_independent_oracle_1.verifySubjectPracticeMathSequenceWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_sequence_two_condition_calculation') {
        solverEvidence = (0, subject_practice_math_sequence_two_condition_solver_1.solveSubjectPracticeMathSequenceTwoCondition)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_sequence_two_condition_explanation_verifier_1.verifySubjectPracticeMathSequenceTwoConditionExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_sequence_two_condition_independent_oracle_1.verifySubjectPracticeMathSequenceTwoConditionWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_vector_complex_direct_calculation') {
        solverEvidence = (0, subject_practice_math_vector_complex_solver_1.solveSubjectPracticeMathVectorComplex)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_vector_complex_explanation_verifier_1.verifySubjectPracticeMathVectorComplexExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_vector_complex_independent_oracle_1.verifySubjectPracticeMathVectorComplexWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_quadratic_rational_inequality_solution') {
        solverEvidence = (0, subject_practice_math_inequality_sign_chart_solver_1.solveSubjectPracticeMathInequalitySignChart)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_inequality_sign_chart_explanation_verifier_1.verifySubjectPracticeMathInequalitySignChartExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_inequality_sign_chart_independent_oracle_1.verifySubjectPracticeMathInequalitySignChartWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_normal_distribution_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_normal_distribution_constraint_solver_1.solveSubjectPracticeMathNormalDistributionConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_normal_distribution_constraint_explanation_verifier_1.verifySubjectPracticeMathNormalDistributionConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_normal_distribution_constraint_independent_oracle_1.verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_descriptive_statistics_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_statistics_constraint_solver_1.solveSubjectPracticeMathStatisticsConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_statistics_constraint_explanation_verifier_1.verifySubjectPracticeMathStatisticsConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_statistics_constraint_independent_oracle_1.verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_classical_probability_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_probability_constraint_solver_1.solveSubjectPracticeMathProbabilityConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_probability_constraint_explanation_verifier_1.verifySubjectPracticeMathProbabilityConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_probability_constraint_independent_oracle_1.verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_solid_geometry_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_solid_geometry_constraint_solver_1.solveSubjectPracticeMathSolidGeometryConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_solid_geometry_constraint_explanation_verifier_1.verifySubjectPracticeMathSolidGeometryConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_solid_geometry_constraint_independent_oracle_1.verifySubjectPracticeMathSolidGeometryConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_vector_complex_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_vector_complex_constraint_solver_1.solveSubjectPracticeMathVectorComplexConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_vector_complex_constraint_explanation_verifier_1.verifySubjectPracticeMathVectorComplexConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_vector_complex_constraint_independent_oracle_1.verifySubjectPracticeMathVectorComplexConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_plane_analytic_geometry_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_plane_analytic_geometry_constraint_solver_1.solveSubjectPracticeMathPlaneAnalyticGeometryConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_plane_analytic_geometry_constraint_explanation_verifier_1.verifySubjectPracticeMathPlaneAnalyticGeometryConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_plane_analytic_geometry_constraint_independent_oracle_1.verifySubjectPracticeMathPlaneAnalyticGeometryConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_sequence_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_sequence_constraint_solver_1.solveSubjectPracticeMathSequenceConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_sequence_constraint_explanation_verifier_1.verifySubjectPracticeMathSequenceConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_sequence_constraint_independent_oracle_1.verifySubjectPracticeMathSequenceConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_derivative_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_derivative_constraint_solver_1.solveSubjectPracticeMathDerivativeConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_derivative_constraint_explanation_verifier_1.verifySubjectPracticeMathDerivativeConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_derivative_constraint_independent_oracle_1.verifySubjectPracticeMathDerivativeConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_elementary_exp_log_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_elementary_exp_log_constraint_solver_1.solveSubjectPracticeMathElementaryExpLogConstraint)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_elementary_exp_log_constraint_explanation_verifier_1.verifySubjectPracticeMathElementaryExpLogConstraintExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_elementary_exp_log_constraint_independent_oracle_1.verifySubjectPracticeMathElementaryExpLogConstraintWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_function_composition_piecewise_reasoning') {
        solverEvidence = (0, subject_practice_math_function_composition_solver_1.solveSubjectPracticeMathFunctionComposition)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_function_composition_explanation_verifier_1.verifySubjectPracticeMathFunctionCompositionExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_function_composition_independent_oracle_1.verifySubjectPracticeMathFunctionCompositionWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_compound_inequality_constraint_reasoning') {
        solverEvidence = (0, subject_practice_math_compound_inequality_solver_1.solveSubjectPracticeMathCompoundInequality)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_compound_inequality_explanation_verifier_1.verifySubjectPracticeMathCompoundInequalityExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_compound_inequality_independent_oracle_1.verifySubjectPracticeMathCompoundInequalityWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_interval_set_parameter_reasoning') {
        solverEvidence = (0, subject_practice_math_interval_set_parameter_solver_1.solveSubjectPracticeMathIntervalSetParameter)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_interval_set_parameter_explanation_verifier_1.verifySubjectPracticeMathIntervalSetParameterExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_interval_set_parameter_independent_oracle_1.verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_normal_distribution_two_step_reasoning') {
        solverEvidence = (0, subject_practice_math_normal_distribution_two_step_solver_1.solveSubjectPracticeMathNormalTwoStep)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_normal_distribution_two_step_explanation_verifier_1.verifySubjectPracticeMathNormalTwoStepExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_normal_distribution_two_step_independent_oracle_1.verifySubjectPracticeMathNormalTwoStepWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_descriptive_statistics_two_step_calculation') {
        solverEvidence = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.solveSubjectPracticeMathStatisticsTwoStep)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_descriptive_statistics_two_step_explanation_verifier_1.verifySubjectPracticeMathStatisticsTwoStepExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_descriptive_statistics_two_step_independent_oracle_1.verifySubjectPracticeMathStatisticsTwoStepWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_classical_probability_two_stage_calculation') {
        solverEvidence = (0, subject_practice_math_probability_two_stage_solver_1.solveSubjectPracticeMathProbabilityTwoStage)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_probability_two_stage_explanation_verifier_1.verifySubjectPracticeMathProbabilityTwoStageExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_probability_two_stage_independent_oracle_1.verifySubjectPracticeMathProbabilityTwoStageWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_solid_geometry_two_step_calculation') {
        solverEvidence = (0, subject_practice_math_solid_geometry_two_step_solver_1.solveSubjectPracticeMathSolidGeometryTwoStep)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_solid_geometry_two_step_explanation_verifier_1.verifySubjectPracticeMathSolidGeometryTwoStepExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_solid_geometry_two_step_independent_oracle_1.verifySubjectPracticeMathSolidGeometryTwoStepWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_vector_complex_two_step_calculation') {
        solverEvidence = (0, subject_practice_math_vector_complex_two_step_solver_1.solveSubjectPracticeMathVectorComplexTwoStep)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_vector_complex_two_step_explanation_verifier_1.verifySubjectPracticeMathVectorComplexTwoStepExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_vector_complex_two_step_independent_oracle_1.verifySubjectPracticeMathVectorComplexTwoStepWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_plane_analytic_geometry_relation') {
        solverEvidence = (0, subject_practice_math_plane_analytic_geometry_solver_1.solveSubjectPracticeMathPlaneAnalyticGeometry)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_plane_analytic_geometry_explanation_verifier_1.verifySubjectPracticeMathPlaneAnalyticGeometryExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_plane_analytic_geometry_independent_oracle_1.verifySubjectPracticeMathPlaneAnalyticGeometryWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_polynomial_derivative_application') {
        solverEvidence = (0, subject_practice_math_derivative_application_solver_1.solveSubjectPracticeMathDerivativeApplication)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_derivative_application_explanation_verifier_1.verifySubjectPracticeMathDerivativeApplicationExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_derivative_application_independent_oracle_1.verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_elementary_exp_log_relation_reasoning') {
        solverEvidence = (0, subject_practice_math_elementary_exp_log_solver_1.solveSubjectPracticeMathElementaryExpLog)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_elementary_exp_log_explanation_verifier_1.verifySubjectPracticeMathElementaryExpLogExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_elementary_exp_log_independent_oracle_1.verifySubjectPracticeMathElementaryExpLogWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_function_interval_property_reasoning') {
        solverEvidence = (0, subject_practice_math_function_interval_solver_1.solveSubjectPracticeMathFunctionInterval)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_function_interval_explanation_verifier_1.verifySubjectPracticeMathFunctionIntervalExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_function_interval_independent_oracle_1.verifySubjectPracticeMathFunctionIntervalWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_normal_distribution_basic_concepts') {
        solverEvidence = (0, subject_practice_math_normal_distribution_basic_solver_1.solveSubjectPracticeMathNormalDistributionBasic)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_normal_distribution_basic_explanation_verifier_1.verifySubjectPracticeMathNormalDistributionBasicExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_normal_distribution_basic_independent_oracle_1.verifySubjectPracticeMathNormalDistributionBasicWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_descriptive_statistics_direct_calculation') {
        solverEvidence = (0, subject_practice_math_descriptive_statistics_solver_1.solveSubjectPracticeMathDescriptiveStatistics)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_descriptive_statistics_explanation_verifier_1.verifySubjectPracticeMathDescriptiveStatisticsExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_descriptive_statistics_independent_oracle_1.verifySubjectPracticeMathDescriptiveStatisticsWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_solid_geometry_direct_calculation') {
        solverEvidence = (0, subject_practice_math_solid_geometry_solver_1.solveSubjectPracticeMathSolidGeometry)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_solid_geometry_explanation_verifier_1.verifySubjectPracticeMathSolidGeometryExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_solid_geometry_independent_oracle_1.verifySubjectPracticeMathSolidGeometryWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_classical_probability_basic_calculation') {
        solverEvidence = (0, subject_practice_math_probability_solver_1.solveSubjectPracticeMathProbability)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_probability_explanation_verifier_1.verifySubjectPracticeMathProbabilityExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_probability_independent_oracle_1.verifySubjectPracticeMathProbabilityWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_basic_function_property') {
        solverEvidence = (0, subject_practice_math_basic_function_solver_1.solveSubjectPracticeMathBasicFunction)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_basic_function_explanation_verifier_1.verifySubjectPracticeMathBasicFunctionExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_basic_function_independent_oracle_1.verifySubjectPracticeMathBasicFunctionWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'math_linear_inequality_solution') {
        solverEvidence = (0, subject_practice_math_inequality_solver_1.solveSubjectPracticeMathInequality)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_inequality_explanation_verifier_1.verifySubjectPracticeMathInequalityExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_inequality_independent_oracle_1.verifySubjectPracticeMathInequalityWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'math' && taskFamily === 'derivative_direct_evaluation') {
        solverEvidence = (0, subject_practice_math_derivative_solver_1.solveSubjectPracticeMathDerivative)(input.candidate, context);
        explanationEvidence = (0, subject_practice_math_derivative_explanation_verifier_1.verifySubjectPracticeMathDerivativeExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_math_derivative_independent_oracle_1.verifySubjectPracticeMathDerivativeWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'physics' && taskFamily === 'kinematics_basic_direct_relation') {
        solverEvidence = (0, subject_practice_physics_kinematics_solver_1.solveSubjectPracticePhysicsKinematics)(input.candidate, context);
        explanationEvidence = (0, subject_practice_physics_kinematics_explanation_verifier_1.verifySubjectPracticePhysicsKinematicsExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_physics_kinematics_independent_oracle_1.verifySubjectPracticePhysicsKinematicsWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'physics' && taskFamily === 'physics_newton_basic_force_calculation') {
        solverEvidence = (0, subject_practice_physics_newton_force_solver_1.solveSubjectPracticePhysicsNewtonForce)(input.candidate, context);
        explanationEvidence = (0, subject_practice_physics_newton_force_explanation_verifier_1.verifySubjectPracticePhysicsNewtonForceExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_physics_newton_force_independent_oracle_1.verifySubjectPracticePhysicsNewtonForceWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'physics' && taskFamily === 'waves_optics_interference_refraction') {
        solverEvidence = (0, subject_practice_physics_optics_solver_1.solveSubjectPracticePhysicsOptics)(input.candidate, context);
        explanationEvidence = (0, subject_practice_physics_optics_explanation_verifier_1.verifySubjectPracticePhysicsOpticsExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_physics_optics_independent_oracle_1.verifySubjectPracticePhysicsOpticsWithIndependentOracle)(input.candidate, context);
    }
    else if (subject === 'chemistry' && taskFamily === 'ph_dilution_strong_acid_base_neutralization') {
        const chemistryContext = { taskFamily, questionPlan: input.questionPlan };
        solverEvidence = (0, subject_practice_chemistry_acid_base_solver_1.solveSubjectPracticeChemistryAcidBase)(input.candidate, chemistryContext);
        explanationEvidence = (0, subject_practice_chemistry_acid_base_explanation_verifier_1.verifySubjectPracticeChemistryAcidBaseExplanation)(input.candidate, chemistryContext);
        independentOracleEvidence = (0, subject_practice_chemistry_acid_base_independent_oracle_1.verifySubjectPracticeChemistryAcidBaseWithIndependentOracle)(input.candidate, chemistryContext);
    }
    else if (subject === 'chemistry' && taskFamily === 'basic_ph_measurement_or_preparation_error_judgement') {
        solverEvidence = (0, subject_practice_chemistry_ph_operation_error_solver_1.solveSubjectPracticeChemistryPhOperationError)(input.candidate, context);
        explanationEvidence = (0, subject_practice_chemistry_ph_operation_error_explanation_verifier_1.verifySubjectPracticeChemistryPhOperationErrorExplanation)(input.candidate, context);
        independentOracleEvidence = (0, subject_practice_chemistry_ph_operation_error_independent_oracle_1.verifySubjectPracticeChemistryPhOperationErrorWithIndependentOracle)(input.candidate, context);
    }
    else {
        return null;
    }
    const solverScopeId = solverEvidence.verificationScope.scopeId;
    const oracleScopeId = independentOracleEvidence.scopeId;
    const scopeMatchedAcrossVerifiers = solverEvidence.verificationScope.matched
        && independentOracleEvidence.scopeMatched
        && Boolean(solverScopeId)
        && solverScopeId === oracleScopeId;
    const reasonCodes = [
        ...solverEvidence.reasonCodes,
        ...explanationEvidence.reasonCodes,
        ...independentOracleEvidence.reasonCodes
    ];
    if (!planTemplate)
        reasonCodes.push('formal_verification_plan_template_missing');
    if (!scopeMatchedAcrossVerifiers)
        reasonCodes.push('formal_verification_cross_verifier_scope_mismatch');
    const fullyVerified = solverEvidence.status === 'verified'
        && explanationEvidence.status === 'verified'
        && independentOracleEvidence.status === 'verified'
        && scopeMatchedAcrossVerifiers
        && Boolean(planTemplate);
    const hasConflict = solverEvidence.status === 'conflict'
        || explanationEvidence.status === 'failed'
        || independentOracleEvidence.status === 'conflict'
        || independentOracleEvidence.status === 'disagreed';
    const status = fullyVerified ? 'verified' : hasConflict ? 'conflict' : 'unparsed';
    if (!fullyVerified)
        reasonCodes.push(`formal_verification_${status}`);
    return {
        orchestratorVersion: exports.SUBJECT_PRACTICE_FORMAL_VERIFICATION_ORCHESTRATOR_VERSION,
        status,
        subject: subject,
        taskFamily,
        planTemplate,
        scopeId: scopeMatchedAcrossVerifiers ? solverScopeId : null,
        plannedScopeId: solverScopeId,
        oracleScopeId,
        scopeMatchedAcrossVerifiers,
        solverVersion: solverEvidence.solverVersion,
        explanationVerifierVersion: explanationEvidence.verifierVersion,
        independentOracleVersion: independentOracleEvidence.oracleVersion,
        solverEvidence,
        explanationEvidence,
        independentOracleEvidence,
        eligibleForProductionShadowObservation: fullyVerified,
        automaticPublicationEligible: false,
        providerImpact: 'none_no_provider_call',
        productionGateImpact: 'none_shadow_only',
        reasonCodes: Array.from(new Set(reasonCodes))
    };
}
