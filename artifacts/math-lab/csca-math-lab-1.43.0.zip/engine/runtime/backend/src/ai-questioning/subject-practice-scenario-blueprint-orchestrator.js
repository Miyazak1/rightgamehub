"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_SCENARIO_BLUEPRINT_ORCHESTRATOR_VERSION = void 0;
exports.subjectPracticeScenarioBlueprintIdeationCycleFor = subjectPracticeScenarioBlueprintIdeationCycleFor;
const node_crypto_1 = require("node:crypto");
const subject_practice_scenario_blueprint_memory_policy_1 = require("./subject-practice-scenario-blueprint-memory-policy");
const subject_practice_scenario_blueprint_response_policy_1 = require("./subject-practice-scenario-blueprint-response-policy");
exports.SUBJECT_PRACTICE_SCENARIO_BLUEPRINT_ORCHESTRATOR_VERSION = 'subject-practice-scenario-blueprint-orchestrator-v1-shadow-only';
function clean(value) {
    return String(value ?? '').trim();
}
function digestFor(value) {
    return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(value)).digest('hex');
}
function subjectPracticeScenarioBlueprintIdeationCycleFor(input) {
    const response = (0, subject_practice_scenario_blueprint_response_policy_1.subjectPracticeScenarioBlueprintResponseGateFor)({
        ideationRequest: input.ideationRequest,
        rawResponse: input.rawResponse
    });
    if (response.status !== 'accepted_provisional_blueprint_batch') {
        return {
            orchestratorVersion: exports.SUBJECT_PRACTICE_SCENARIO_BLUEPRINT_ORCHESTRATOR_VERSION,
            status: 'rejected_response_batch',
            blockers: response.blockers,
            responseStatus: response.status,
            memoryStatus: 'not_run_response_rejected',
            selectedBlueprintFingerprint: null,
            selectedBlueprintDigest: null,
            cycleEvidenceDigest: null,
            providerCallAuthorized: false,
            productionGenerationAuthorized: false,
            publicationAuthorized: false,
            rawResponseRetained: false,
            productionGateImpact: 'none_shadow_only'
        };
    }
    const memory = (0, subject_practice_scenario_blueprint_memory_policy_1.subjectPracticeScenarioBlueprintMemoryRankingFor)({
        candidates: response.blueprints,
        historicalSummaries: input.historicalSummaries
    });
    if (memory.status !== 'ranked_shadow_only') {
        return {
            orchestratorVersion: exports.SUBJECT_PRACTICE_SCENARIO_BLUEPRINT_ORCHESTRATOR_VERSION,
            status: 'rejected_memory_input',
            blockers: [memory.status],
            responseStatus: response.status,
            memoryStatus: memory.status,
            selectedBlueprintFingerprint: null,
            selectedBlueprintDigest: null,
            cycleEvidenceDigest: null,
            providerCallAuthorized: false,
            productionGenerationAuthorized: false,
            publicationAuthorized: false,
            rawResponseRetained: false,
            productionGateImpact: 'none_shadow_only'
        };
    }
    const selectedFingerprint = clean(memory.suggestedSelection);
    const selected = response.blueprints.find((item) => item.blueprintFingerprint === selectedFingerprint);
    if (!selectedFingerprint || !selected) {
        return {
            orchestratorVersion: exports.SUBJECT_PRACTICE_SCENARIO_BLUEPRINT_ORCHESTRATOR_VERSION,
            status: 'no_novel_blueprint_candidate',
            blockers: ['all_response_candidates_duplicate_or_rename_only_against_history'],
            responseStatus: response.status,
            memoryStatus: memory.status,
            acceptedResponseCandidateCount: response.acceptedCandidateCount,
            rankableNovelCandidateCount: 0,
            selectedBlueprintFingerprint: null,
            selectedBlueprintDigest: null,
            cycleEvidenceDigest: null,
            providerCallAuthorized: false,
            productionGenerationAuthorized: false,
            publicationAuthorized: false,
            rawResponseRetained: false,
            productionGateImpact: 'none_shadow_only'
        };
    }
    const rankable = memory.rankedCandidates.filter((item) => item.decision === 'rankable_novel_candidate');
    const cycleEvidence = {
        orchestratorVersion: exports.SUBJECT_PRACTICE_SCENARIO_BLUEPRINT_ORCHESTRATOR_VERSION,
        responseEvidenceDigest: response.responseEvidenceDigest,
        memoryPolicyVersion: memory.policyVersion,
        historicalSummaryCount: memory.historicalSummaryCount,
        rankedCandidates: memory.rankedCandidates.map((item) => ({
            blueprintFingerprint: item.blueprintFingerprint,
            decision: item.decision,
            rankingScore: item.rankingScore
        })),
        selectedBlueprintFingerprint: selectedFingerprint,
        selectedBlueprintDigest: selected.blueprintDigest
    };
    return {
        orchestratorVersion: exports.SUBJECT_PRACTICE_SCENARIO_BLUEPRINT_ORCHESTRATOR_VERSION,
        status: 'selected_provisional_blueprint_shadow_only',
        blockers: [],
        responseStatus: response.status,
        memoryStatus: memory.status,
        acceptedResponseCandidateCount: response.acceptedCandidateCount,
        rankableNovelCandidateCount: rankable.length,
        selectedBlueprintFingerprint: selectedFingerprint,
        selectedBlueprintDigest: selected.blueprintDigest,
        cycleEvidenceDigest: digestFor(cycleEvidence),
        selectionBasis: 'validated_response_then_structural_history_coverage_ranking',
        selectionQuotaFrozen: false,
        providerCallAuthorized: false,
        productionGenerationAuthorized: false,
        publicationAuthorized: false,
        rawResponseRetained: false,
        selectedSurfaceEmitted: false,
        productionGateImpact: 'none_shadow_only'
    };
}
