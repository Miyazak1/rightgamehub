"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_MVP_FEEDBACK_MIN_REPORTERS = exports.SUBJECT_PRACTICE_MVP_FEEDBACK_GOVERNANCE_POLICY_VERSION = exports.SUBJECT_PRACTICE_MVP_VALID_RESPONSE_SECONDS = exports.SUBJECT_PRACTICE_MVP_OBSERVED_DIFFICULTY_MIN_SAMPLE = exports.SUBJECT_PRACTICE_MVP_BLOCKING_DEFECT_TAXONOMY_VERSION = exports.SUBJECT_PRACTICE_MVP_DIFFICULTY_POLICY = exports.SUBJECT_PRACTICE_MVP_PRODUCT_CONTRACT_VERSION = void 0;
exports.subjectPracticeMvpProductContractMetadata = subjectPracticeMvpProductContractMetadata;
exports.subjectPracticeMvpProductContractApplies = subjectPracticeMvpProductContractApplies;
exports.subjectPracticeMvpObservedDifficulty = subjectPracticeMvpObservedDifficulty;
exports.subjectPracticeMvpDifficultyConfidence = subjectPracticeMvpDifficultyConfidence;
exports.subjectPracticeMvpFeedbackGovernance = subjectPracticeMvpFeedbackGovernance;
exports.subjectPracticeMvpDifficultyReason = subjectPracticeMvpDifficultyReason;
exports.subjectPracticeMvpHardErrorIssues = subjectPracticeMvpHardErrorIssues;
exports.subjectPracticeMvpHardFailedDimensions = subjectPracticeMvpHardFailedDimensions;
exports.subjectPracticeMvpNonDifficultyProfileReasons = subjectPracticeMvpNonDifficultyProfileReasons;
exports.subjectPracticeMvpBlockingDefects = subjectPracticeMvpBlockingDefects;
exports.SUBJECT_PRACTICE_MVP_PRODUCT_CONTRACT_VERSION = 'subject-practice-mvp-product-contract-v1';
exports.SUBJECT_PRACTICE_MVP_DIFFICULTY_POLICY = 'observed_after_release_not_generation_or_publish_input';
exports.SUBJECT_PRACTICE_MVP_BLOCKING_DEFECT_TAXONOMY_VERSION = 'subject-practice-mvp-blocking-defect-taxonomy-v1';
exports.SUBJECT_PRACTICE_MVP_OBSERVED_DIFFICULTY_MIN_SAMPLE = 20;
exports.SUBJECT_PRACTICE_MVP_VALID_RESPONSE_SECONDS = {
    min: 2,
    max: 1800
};
exports.SUBJECT_PRACTICE_MVP_FEEDBACK_GOVERNANCE_POLICY_VERSION = 'subject-practice-mvp-feedback-governance-v1';
exports.SUBJECT_PRACTICE_MVP_FEEDBACK_MIN_REPORTERS = 3;
function recordFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? value
        : {};
}
function clean(value) {
    return String(value ?? '').trim();
}
function subjectPracticeMvpProductContractMetadata() {
    return {
        productContractVersion: exports.SUBJECT_PRACTICE_MVP_PRODUCT_CONTRACT_VERSION,
        difficultyPolicy: exports.SUBJECT_PRACTICE_MVP_DIFFICULTY_POLICY
    };
}
function subjectPracticeMvpProductContractApplies(generationMetadata) {
    const generation = recordFrom(generationMetadata);
    const targetProfile = recordFrom(generation.targetProfile);
    return clean(generation.productContractVersion || targetProfile.productContractVersion)
        === exports.SUBJECT_PRACTICE_MVP_PRODUCT_CONTRACT_VERSION;
}
function subjectPracticeMvpObservedDifficulty(input) {
    if (input.attemptCount < exports.SUBJECT_PRACTICE_MVP_OBSERVED_DIFFICULTY_MIN_SAMPLE
        || input.correctRate === null
        || !Number.isFinite(input.correctRate))
        return null;
    if (input.correctRate >= 0.78)
        return '基础';
    if (input.correctRate >= 0.58)
        return '中等';
    if (input.correctRate >= 0.38)
        return '较难';
    return '挑战';
}
function subjectPracticeMvpDifficultyConfidence(attemptCount) {
    const count = Number.isFinite(attemptCount) ? Math.max(0, Math.floor(attemptCount)) : 0;
    return Number(Math.min(1, count / 50).toFixed(4));
}
function subjectPracticeMvpFeedbackGovernance(input) {
    const exposureCount = Number.isFinite(input.exposureCount) ? Math.max(0, Math.floor(input.exposureCount)) : 0;
    const feedbackCount = Number.isFinite(input.feedbackCount) ? Math.max(0, Math.floor(input.feedbackCount)) : 0;
    const breakdown = recordFrom(input.reasonBreakdown);
    const reasonCount = (reason) => {
        const count = Number(breakdown[reason] ?? 0);
        return Number.isFinite(count) ? Math.max(0, Math.floor(count)) : 0;
    };
    const severeFeedbackCount = reasonCount('incorrect_answer')
        + reasonCount('incomplete')
        + reasonCount('rendering');
    const feedbackRate = exposureCount > 0
        ? Number(Math.min(1, feedbackCount / exposureCount).toFixed(4))
        : 0;
    const hasMinimumEvidence = feedbackCount >= exports.SUBJECT_PRACTICE_MVP_FEEDBACK_MIN_REPORTERS;
    const broadDefectSignal = hasMinimumEvidence && feedbackRate >= 0.15;
    const concentratedHardDefectSignal = severeFeedbackCount >= 3 && feedbackRate >= 0.05;
    const reasonCodes = [
        broadDefectSignal ? 'feedback_rate_high' : null,
        concentratedHardDefectSignal ? 'hard_defect_feedback_concentrated' : null,
        reasonCount('incorrect_answer') >= 2 ? 'answer_error_feedback_repeated' : null,
        reasonCount('incomplete') >= 2 ? 'incomplete_question_feedback_repeated' : null,
        reasonCount('rendering') >= 2 ? 'rendering_feedback_repeated' : null,
        reasonCount('duplicate') >= 3 ? 'duplicate_feedback_repeated' : null
    ].filter(Boolean);
    return {
        policyVersion: exports.SUBJECT_PRACTICE_MVP_FEEDBACK_GOVERNANCE_POLICY_VERSION,
        status: broadDefectSignal || concentratedHardDefectSignal
            ? 'quarantined'
            : hasMinimumEvidence
                ? 'monitor'
                : 'insufficient_evidence',
        feedbackCount,
        exposureCount,
        feedbackRate,
        severeFeedbackCount,
        reasonCodes
    };
}
function subjectPracticeMvpDifficultyReason(value) {
    const reason = clean(value).toLowerCase();
    const legacyDifficultyOnlyReasons = new Set([
        'math_hard_simple_task_family',
        'math_medium_basic_task_family',
        'physics_hard_direct_formula_task_family'
    ]);
    return reason === 'profile_difficulty_evidence_mismatch'
        || reason === 'difficulty_band_mismatch'
        || reason === 'difficulty_complexity_mismatch'
        || reason === 'difficulty_mismatch'
        || reason === 'difficulty_target_mismatch'
        || reason === 'target_profile_difficulty_mismatch'
        || reason === 'exam_like_difficulty_low'
        || legacyDifficultyOnlyReasons.has(reason)
        || reason.startsWith('profile_hard_')
        || reason.includes('difficulty');
}
function subjectPracticeMvpHardErrorIssues(review, nonDifficultyProfileReasons) {
    return review.issues.filter((issue) => {
        if (issue.severity !== 'error')
            return false;
        if (subjectPracticeMvpDifficultyReason(issue.code))
            return false;
        if (issue.code === 'profile_alignment_failed' && nonDifficultyProfileReasons.length === 0)
            return false;
        return true;
    });
}
function subjectPracticeMvpHardFailedDimensions(review) {
    return review.dimensions.filter((dimension) => dimension.status === 'failed' && dimension.key !== 'difficulty_match');
}
function subjectPracticeMvpNonDifficultyProfileReasons(reasons) {
    if (!Array.isArray(reasons))
        return [];
    return Array.from(new Set(reasons
        .map((reason) => clean(reason).toLowerCase())
        .filter(Boolean)
        .filter((reason) => !subjectPracticeMvpDifficultyReason(reason))));
}
function canonicalBlockingDefect(reason) {
    if (/fallback|smoke|untrusted.*source/.test(reason)) {
        return { code: 'mvp_untrusted_generation_source', category: 'generation_provenance' };
    }
    if (/syllabus|out_of_scope|excluded_scope|topic_mismatch|subject_mismatch/.test(reason)) {
        return { code: 'mvp_out_of_scope', category: 'content_scope' };
    }
    if (/source_similarity|past_paper_similarity|duplicate|near_duplicate|source_copy|prompt_leakage/.test(reason)) {
        return { code: 'mvp_duplicate_or_source_copy', category: 'duplication_and_source_safety' };
    }
    if (/localization|bilingual|translation|unbacked_visual|missing_(diagram|figure|graph)|render|latex|math_text|math_format/.test(reason)) {
        return { code: 'mvp_localization_or_rendering_invalid', category: 'localization_and_rendering' };
    }
    if (/explanation/.test(reason)) {
        return { code: 'mvp_explanation_invalid', category: 'explanation' };
    }
    if (/answer|option|distractor|mutual_exclusion/.test(reason)) {
        return { code: 'mvp_answer_or_options_invalid', category: 'answer_and_options' };
    }
    if (/domain_sanity|physics_|chemistry_|math_/.test(reason)) {
        return { code: 'mvp_subject_logic_invalid', category: 'subject_logic' };
    }
    if (/profile_contract|profile_alignment|required_stem|question_form|cognitive_skill/.test(reason)) {
        return { code: 'mvp_profile_contract_broken', category: 'content_scope' };
    }
    if (/trivial|style_alignment|quality_floor|unusable|weak_/.test(reason)) {
        return { code: 'mvp_minimum_quality_failed', category: 'minimum_quality' };
    }
    if (/schema|invalid_prompt|provider_schema|structure/.test(reason)) {
        return { code: 'mvp_structure_invalid', category: 'structure' };
    }
    return { code: 'mvp_automated_validator_hard_error', category: 'automated_validator' };
}
function subjectPracticeMvpBlockingDefects(rawReasons) {
    if (!Array.isArray(rawReasons))
        return [];
    const grouped = new Map();
    for (const rawValue of rawReasons) {
        const rawReason = clean(rawValue).toLowerCase();
        if (!rawReason || subjectPracticeMvpDifficultyReason(rawReason))
            continue;
        const canonical = canonicalBlockingDefect(rawReason);
        const existing = grouped.get(canonical.code);
        if (existing) {
            if (!existing.rawReasons.includes(rawReason))
                existing.rawReasons.push(rawReason);
            continue;
        }
        grouped.set(canonical.code, { ...canonical, rawReasons: [rawReason] });
    }
    return Array.from(grouped.values());
}
