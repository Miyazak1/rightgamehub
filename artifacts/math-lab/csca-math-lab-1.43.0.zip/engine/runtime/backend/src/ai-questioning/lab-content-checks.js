'use strict';
function questionMathTextIssueReasons(question) {
    const reasons = collectQuestionMathTexts(question).flatMap(mathTextIssueReasons);
    if (isPureStatisticsVarianceLinearTransformCandidate(question)) {
        reasons.push('statistics_linear_transform_template');
    }
    if (isTrivialStatisticsRawListCandidate(question)) {
        reasons.push('statistics_raw_list_template');
    }
    return Array.from(new Set(reasons));
}
function collectQuestionMathTexts(question) {
    const generation = recordFrom(question.generationMetadata) ?? {};
    const localizations = recordFrom(generation.localizations) ?? {};
    const zh = recordFrom(localizations.zh) ?? {};
    const en = recordFrom(localizations.en) ?? {};
    const optionTexts = mathOptionTextsFromUnknown(question.options);
    const localizedOptionTexts = [
        ...mathOptionTextsFromUnknown(zh.options),
        ...mathOptionTextsFromUnknown(en.options)
    ];
    return [
        question.prompt,
        question.explanation,
        ...optionTexts,
        zh.prompt,
        zh.explanation,
        en.prompt,
        en.explanation,
        ...localizedOptionTexts
    ].map((value) => cleanString(value)).filter(Boolean);
}
function recordFrom(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
function mathOptionTextsFromUnknown(value) {
    if (!Array.isArray(value))
        return [];
    return value
        .map((item) => cleanString(recordFrom(item)?.text ?? item))
        .filter(Boolean);
}
function cleanString(value, fallback = '') {
    const text = String(value ?? '').trim();
    return text || fallback;
}
function mathTextIssueReasons(value) {
    const reasons = [];
    if (!value)
        return reasons;
    const hasMathSignal = /\\(?:frac|dfrac|sqrt|leq|geq|cdot|times|pm|infty|left|right|sin|cos|tan|log|ln|alpha|beta|theta|pi|Delta|sum|lim|cup|cap|neq|approx|parallel|perp|angle)\b|[_^]\s*\{|\$/.test(value);
    if (!hasMathSignal)
        return reasons;
    if (!hasBalancedLatexDelimiters(value))
        reasons.push('math_latex_unbalanced_delimiters');
    for (const segment of delimitedLatexSegments(value)) {
        if (/[\u3400-\u9fff]/.test(segment) && !/\\(?:text|mathrm)\s*\{/.test(segment))
            reasons.push('math_latex_cjk_in_formula');
    }
    for (const match of value.matchAll(/\\(?:d?frac)\b/g)) {
        const numeratorEnd = latexCommandGroupEnd(value, match.index + match[0].length);
        const denominatorEnd = numeratorEnd > 0 ? latexCommandGroupEnd(value, numeratorEnd) : -1;
        if (numeratorEnd < 0 || denominatorEnd < 0)
            reasons.push('math_latex_invalid_fraction');
    }
    for (const match of value.matchAll(/\\sqrt\b/g)) {
        let cursor = match.index + match[0].length;
        while (/\s/.test(value[cursor] ?? ''))
            cursor += 1;
        if (value[cursor] === '[') {
            const close = value.indexOf(']', cursor + 1);
            cursor = close >= 0 ? close + 1 : -1;
        }
        const radicandEnd = cursor >= 0 ? latexCommandGroupEnd(value, cursor) : -1;
        if (radicandEnd < 0)
            reasons.push('math_latex_invalid_sqrt');
    }
    if (/\\left\b/.test(value) !== /\\right\b/.test(value))
        reasons.push('math_latex_unpaired_left_right');
    return Array.from(new Set(reasons));
}
function hasBalancedLatexDelimiters(input) {
    let braceDepth = 0;
    let dollarCount = 0;
    for (let index = 0; index < input.length; index += 1) {
        const char = input[index];
        const escaped = index > 0 && input[index - 1] === '\\';
        if (char === '{' && !escaped)
            braceDepth += 1;
        if (char === '}' && !escaped)
            braceDepth -= 1;
        if (braceDepth < 0)
            return false;
        if (char === '$' && !escaped)
            dollarCount += 1;
    }
    return braceDepth === 0 && dollarCount % 2 === 0;
}
function delimitedLatexSegments(input) {
    const segments = [];
    const tokenPattern = /(\$\$[\s\S]+?\$\$|\$[^$\n]+?\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\))/g;
    for (const match of input.matchAll(tokenPattern)) {
        const token = match[0];
        const body = token.startsWith('$$') || token.startsWith('\\[') || token.startsWith('\\(')
            ? token.slice(2, -2)
            : token.slice(1, -1);
        if (body.trim())
            segments.push(body.trim());
    }
    return segments;
}
function latexCommandGroupEnd(input, start) {
    let index = start;
    while (/\s/.test(input[index] ?? ''))
        index += 1;
    if (input[index] !== '{')
        return -1;
    let depth = 0;
    for (let cursor = index; cursor < input.length; cursor += 1) {
        const char = input[cursor];
        const escaped = cursor > 0 && input[cursor - 1] === '\\';
        if (char === '{' && !escaped)
            depth += 1;
        if (char === '}' && !escaped)
            depth -= 1;
        if (depth === 0)
            return cursor + 1;
    }
    return -1;
}
function isPureStatisticsVarianceLinearTransformCandidate(question) {
    if (hasExactStatisticsAffineFilterStructure(question))
        return false;
    const generation = recordFrom(question.generationMetadata) ?? {};
    const targetProfile = recordFrom(generation.targetProfile) ?? {};
    const scope = recordFrom(generation.scope) ?? {};
    const topicText = [
        generation.topicTitle,
        generation.topic,
        scope.topicTitle,
        scope.topic,
        targetProfile.topicTitle,
        targetProfile.gapKey
    ].map((value) => cleanString(value)).join(' ');
    const promptText = questionPromptText(question).replace(/\s+/g, ' ');
    const isStatisticsTopic = /数据的数字特征|统计|statistics|data/i.test(topicText)
        || /方差|平均数|均值|标准差|中位数|极差|variance|mean|standard deviation/i.test(promptText);
    if (!isStatisticsTopic || !/方差|variance/i.test(promptText))
        return false;
    const hasIndexedDataFamily = /x\s*[₁-₉0-9_i，,\s…\.]{3,}x/i.test(promptText)
        || /x1\s*[,，、]\s*x2.{0,12}x10/i.test(promptText)
        || /x_?1\s*[,，、]\s*x_?2.{0,12}x_?10/i.test(promptText);
    const hasKnownMeanOrVariance = /(均值|平均数|方差|variance|mean).{0,18}(为|=)\s*[-+]?\d/i.test(promptText);
    const hasLinearTransform = /(每个|各|所有)?数据(?:都|均|分别)?.{0,16}(乘以|乘|×|\*).{0,16}(再|然后)?(加上|加|减去|减|\+|-)/.test(promptText)
        || /(?:新数据|所得数据|y|yi|y_i|yᵢ)\s*=\s*[0-9a-z]*x(?:i|_i|ᵢ)?\s*[+＋-]\s*\d/i.test(promptText)
        || /(?:2x|3x|kx|ax)(?:i|_i|ᵢ)?\s*[+＋-]\s*\d/i.test(promptText);
    const asksNewVariance = /(新数据|所得数据|变换后|新样本|new data|transformed).{0,24}(方差|variance)|(?:求|计算|find|calculate).{0,24}(方差|variance)/i.test(promptText);
    const hasMeaningfulAlternativeStructure = /缺失|未知|待定|中位数|极差|标准差|比较|两组|甲|乙|频数|频率|分组|权重|样本容量|删去|去掉|替换|解释|判断/i.test(promptText);
    const pureKnownStatisticTransform = hasKnownMeanOrVariance && hasIndexedDataFamily && hasLinearTransform && asksNewVariance;
    return (pureKnownStatisticTransform || (hasLinearTransform && asksNewVariance)) && !hasMeaningfulAlternativeStructure;
}
function hasExactStatisticsAffineFilterStructure(question) {
    const generation = recordFrom(question.generationMetadata) ?? {};
    const exactScope = (0, subject_practice_math_statistics_constraint_solver_1.statisticsConstraintScopeFrom)(generation.questionPlan);
    if (exactScope !== 'affine_moments_sign_threshold_subset_variance')
        return false;
    const localizations = recordFrom(generation.localizations) ?? {};
    const parse = (text, language) => typeof text === 'string'
        ? (0, subject_practice_math_statistics_constraint_solver_1.statisticsConstraintParametersFrom)(text, exactScope, language) : null;
    const zh = parse(recordFrom(localizations.zh)?.prompt, 'zh');
    const en = parse(recordFrom(localizations.en)?.prompt, 'en');
    if (!zh || !en || JSON.stringify(zh) !== JSON.stringify(en))
        return false;
    const matches = (text) => {
        const parameters = parse(text, 'zh') ?? parse(text, 'en');
        return parameters !== null && JSON.stringify(parameters) === JSON.stringify(zh);
    };
    if (!matches(question.prompt)
        || (Object.prototype.hasOwnProperty.call(generation, 'prompt') && !matches(generation.prompt)))
        return false;
    // Structure recognition never grants answer, novelty or publication approval.
    return (0, subject_practice_math_statistics_constraint_solver_1.statisticsConstraintDerive)(zh) !== null;
}
const subject_practice_math_statistics_constraint_solver_1 = require("./subject-practice-math-statistics-constraint-solver");
function questionPromptText(question) {
    const generation = recordFrom(question.generationMetadata) ?? {};
    const localizations = recordFrom(generation.localizations) ?? {};
    const zh = recordFrom(localizations.zh) ?? {};
    const en = recordFrom(localizations.en) ?? {};
    return [
        question.prompt,
        generation.prompt,
        zh.prompt,
        en.prompt
    ].map((value) => cleanString(value)).filter(Boolean).join(' ');
}
function isTrivialStatisticsRawListCandidate(question) {
    if (hasExactStatisticsAffineFilterStructure(question))
        return false;
    if (hasExactStatisticsMissingValueStructure(question))
        return false;
    const generation = recordFrom(question.generationMetadata) ?? {};
    const targetProfile = recordFrom(generation.targetProfile) ?? {};
    const scope = recordFrom(generation.scope) ?? {};
    const topicText = [
        generation.topicTitle,
        generation.topic,
        scope.topicTitle,
        scope.topic,
        targetProfile.topicTitle,
        targetProfile.gapKey
    ].map((value) => cleanString(value)).join(' ');
    const promptText = questionPromptText(question).replace(/\s+/g, ' ');
    const isStatisticsTopic = /数据的数字特征|统计|statistics|data/i.test(topicText)
        || /方差|平均数|均值|标准差|中位数|极差|variance|mean|standard deviation/i.test(promptText);
    if (!isStatisticsTopic)
        return false;
    const asksDirectStatistic = /(?:求|计算|find|calculate).{0,20}(方差|样本方差|平均数|均值|标准差|极差|variance|mean|standard deviation|range)/i.test(promptText);
    const hasShortRawList = /(?:\d+(?:\.\d+)?\s*[,，、]\s*){3,}\d+(?:\.\d+)?/.test(promptText);
    const hasAlternativeStructure = /缺失|未知|待定|x\s*=|设x|中位数.*极差|极差.*中位数|比较|两组|甲|乙|频数|频率|分组|权重|样本容量|删去|去掉|替换|加入|增加|减少|变化|前后|原来|现在|若.*则|如果.*则/i.test(promptText);
    return asksDirectStatistic && hasShortRawList && !hasAlternativeStructure;
}
function hasExactStatisticsMissingValueStructure(question) {
    const generation = recordFrom(question.generationMetadata) ?? {};
    const exactScope = (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepScopeFrom)(generation.questionPlan);
    if (exactScope !== 'missing_value_from_mean_to_population_variance')
        return false;
    const localizations = recordFrom(generation.localizations) ?? {};
    const parseParameters = (text, language) => typeof text === 'string'
        ? (0, subject_practice_math_descriptive_statistics_two_step_solver_1.statisticsTwoStepParametersFrom)(text, exactScope, language) : null;
    const zh = parseParameters(recordFrom(localizations.zh)?.prompt, 'zh');
    const en = parseParameters(recordFrom(localizations.en)?.prompt, 'en');
    if (!zh || !en || JSON.stringify(zh) !== JSON.stringify(en))
        return false;
    const matchesParameters = (text) => {
        const parameters = parseParameters(text, 'zh') ?? parseParameters(text, 'en');
        return parameters !== null && JSON.stringify(parameters) === JSON.stringify(zh);
    };
    // Recognize structure only: every visible/audit stem must share the bounded two-step contract.
    // Answers, explanations, novelty and publication gates are still checked independently.
    return matchesParameters(question.prompt)
        && (!Object.prototype.hasOwnProperty.call(generation, 'prompt') || matchesParameters(generation.prompt));
}
const subject_practice_math_descriptive_statistics_two_step_solver_1 = require("./subject-practice-math-descriptive-statistics-two-step-solver");
module.exports={questionMathTextIssueReasons};
