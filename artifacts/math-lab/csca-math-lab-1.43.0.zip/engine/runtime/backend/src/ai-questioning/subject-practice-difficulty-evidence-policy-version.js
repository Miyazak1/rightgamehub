"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBJECT_PRACTICE_DIFFICULTY_EVIDENCE_POLICY_VERSION = void 0;
exports.SUBJECT_PRACTICE_DIFFICULTY_EVIDENCE_POLICY_VERSION = 'subject-practice-difficulty-evidence-v66-math-normal-basic-plan-bound';
