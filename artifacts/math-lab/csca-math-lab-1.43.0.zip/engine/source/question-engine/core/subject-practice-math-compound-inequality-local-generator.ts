import { GeneratedQuestionCandidate,QuestionGenerationBlueprint,SubjectPracticeQuestionPlanPorts } from './types';
import { ExactInterval,CompoundInequalityParameters,COMPOUND_INEQUALITY_SCOPES,compoundInequalityScopeFrom,compoundInequalityPrompt,compoundInequalityDerive,solveSubjectPracticeMathCompoundInequality } from './subject-practice-math-compound-inequality-solver';
import { verifySubjectPracticeMathCompoundInequalityWithIndependentOracle } from './subject-practice-math-compound-inequality-independent-oracle';
import { renderCompoundInequalityExplanation,verifySubjectPracticeMathCompoundInequalityExplanation } from './subject-practice-math-compound-inequality-explanation-verifier';
export const COMPOUND_INEQUALITY_GENERATOR_VERSION='math-compound-inequality-generator-v1-bounded';
export function createSubjectPracticeMathCompoundInequalityLocalGenerator(ports:SubjectPracticeQuestionPlanPorts){
 return(input:{blueprint:QuestionGenerationBlueprint;questionPlan:unknown;seed:number})=>{
  const validSeed=Number.isSafeInteger(input.seed)&&input.seed>=0,seed=validSeed?input.seed:0,scope=compoundInequalityScopeFrom(input.questionPlan),b=input.blueprint;
  const common={generatorVersion:COMPOUND_INEQUALITY_GENERATOR_VERSION,seed,exactScope:scope,providerImpact:'none_no_provider_call' as const,estimatedCostUsd:0 as const,productionImpact:'none_shadow_only' as const,automaticPublicationEligible:false as const};
  const unsupported={...common,status:'unsupported_question_plan' as const,candidate:null,solverEvidence:null,oracleEvidence:null,explanationEvidence:null,adherence:null,scopeId:null,reasonCodes:['compound_inequality_local_plan_not_supported']};
  if(!validSeed||!scope||!ports.validate(input.questionPlan).valid||b.subject!=='math'||b.topicId!==67||b.topicCode!=='M-INEQ-001'||b.difficulty!=='hard'||b.questionType!=='single_choice')return unsupported;
  for(let attempt=0;attempt<128;attempt++){
   const n=(seed+attempt)%100000,shift=Math.floor(n/16)%7-3,bit=(k:number)=>!!(n&(1<<k)),i=COMPOUND_INEQUALITY_SCOPES.indexOf(scope);
   const seg=(lo:number,hi:number,lc=true,hc=true):ExactInterval=>({lo:lo+shift,hi:hi+shift,lc,hc});
   const a=(bit(2)?-1:1)*(1+Math.floor(n/112)%3);
   const q=(l:number,h:number,out:boolean)=>({a,b:-a*(l+h+2*shift),c:a*(l+shift)*(h+shift),rel:((out===(a>0)?'>':'<')+(bit(0)?'=':'')) as '<'|'<='|'>'|'>='});
   const k=bit(3)?-2:1;
   const f=(z:number,p:number)=>({k,z:z+shift,p:p+shift,rel:((k>0?'>':'<')+(bit(1)?'=':'')) as '<'|'<='|'>'|'>='});
   const p:CompoundInequalityParameters={scope,D:seg(-8,8,bit(4),bit(5)),T:null,Q:null,F:null,band:null,radius:null,universal:null};
   if(i===0){p.Q=q(-5,1,true);p.F=f(-2,4);}
   if(i===1){p.D=seg(-5,7,bit(4),bit(5));p.F=f(1,-4);p.band={c:shift,l:2,u:6,lc:bit(0),hc:bit(2)};}
   if(i===2){p.Q=q(-3,3,false);p.D=seg(-2,5,bit(4),bit(5));p.T=seg(-6,6);p.radius=4+Number(bit(3));p.universal=bit(1)?'<=':'<';}
   if(i===3){p.F=f(-2,3);p.D=seg(-6,6,bit(4),bit(5));p.T=seg(-9,9);p.radius=1+Number(bit(0));p.universal=bit(2)?'>=':'>';}
   const d=compoundInequalityDerive(p);if(!d)continue;
   const choices=d.errors.map(e=>({text:e.text,intent:e.intent})),correctAnswer='ABCD'[Math.floor(seed/16)%4];
   choices.splice('ABCD'.indexOf(correctAnswer),0,{text:d.text,intent:''});
   const options=choices.map((e,j)=>({id:'ABCD'[j],text:e.text})),prompt=compoundInequalityPrompt(p,'zh'),enPrompt=compoundInequalityPrompt(p,'en'),explanation=renderCompoundInequalityExplanation(p,d.answer,correctAnswer);
   const tags=['不等式的基本性质与解法',scope];
   const candidate:GeneratedQuestionCandidate={subject:'math',topicId:67,blueprintId:b.id,sourceType:'ai',designedDifficulty:'hard',questionType:'single_choice',prompt,options,correctAnswer,explanation:explanation.zh,knowledgeTags:tags,
    optionMetadata:choices.flatMap((e,j)=>e.intent?[{optionId:'ABCD'[j],distractorIntent:e.intent,misconceptionTags:[e.intent]}]:[]),
    localizations:{zh:{prompt,options,explanation:explanation.zh,knowledgeTags:tags},en:{prompt:enPrompt,options:options.map(o=>({...o})),explanation:explanation.en,knowledgeTags:['Inequalities and solution sets',scope]}},syllabusVersion:b.syllabusVersion};
   const context={questionPlan:input.questionPlan},solverEvidence=solveSubjectPracticeMathCompoundInequality(candidate,context),oracleEvidence=verifySubjectPracticeMathCompoundInequalityWithIndependentOracle(candidate,context),explanationEvidence=verifySubjectPracticeMathCompoundInequalityExplanation(candidate,context),adherence=ports.adherenceFor(input.questionPlan,candidate);
   const verified=solverEvidence.status==='verified'&&oracleEvidence.status==='verified'&&explanationEvidence.status==='verified'&&adherence.adheres&&solverEvidence.scopeId===oracleEvidence.scopeId&&solverEvidence.expectedAnswer===oracleEvidence.expectedAnswer&&solverEvidence.selectedOptionId===oracleEvidence.selectedOptionId;
   return{...common,parameterAttempts:attempt+1,status:verified?'generated_and_triple_verified' as const:'self_verification_failed' as const,candidate:verified?candidate:null,solverEvidence,oracleEvidence,explanationEvidence,adherence,scopeId:verified?solverEvidence.scopeId:null,reasonCodes:verified?[]:[...solverEvidence.reasonCodes,...oracleEvidence.reasonCodes,...explanationEvidence.reasonCodes,...adherence.failureCodes]};
  }
  return{...unsupported,status:'bounded_generation_exhausted' as const,parameterAttempts:128};
 };
}
