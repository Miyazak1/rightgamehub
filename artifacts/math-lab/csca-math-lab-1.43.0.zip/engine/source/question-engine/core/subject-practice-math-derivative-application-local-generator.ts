import { GeneratedQuestionCandidate, QuestionGenerationBlueprint, SubjectPracticeQuestionPlanPorts } from './types';
import { DerivativeApplicationScope, DerivativeApplicationParameters, DERIVATIVE_APPLICATION_SCOPES, derivativeApplicationScopeFrom, derivativeApplicationPrompt,
  derivativeApplicationParametersFrom, derivativeApplicationAnswer, derivativeApplicationDistractors, derivativeApplicationOptionKey,
  solveSubjectPracticeMathDerivativeApplication } from './subject-practice-math-derivative-application-solver';
import { verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle } from './subject-practice-math-derivative-application-independent-oracle';
import { renderDerivativeApplicationExplanation, verifySubjectPracticeMathDerivativeApplicationExplanation } from './subject-practice-math-derivative-application-explanation-verifier';
export const DERIVATIVE_APPLICATION_GENERATOR_VERSION = 'math-derivative-application-generator-v1-bounded';
function parameters(scope: DerivativeApplicationScope, seed: number, attempt: number): DerivativeApplicationParameters {
  const n = seed % 100000, sign = n % 2 ? -1 : 1, c0 = n % 17 - 8;
  if (scope === DERIVATIVE_APPLICATION_SCOPES[0]) return { scope, c3: 0, c2: sign * (1 + (Math.floor(n / 2) + attempt) % 3),
    c1: (Math.floor(n / 6) + attempt) % 13 - 6, c0, t: [-3, -2, -1, 1, 2, 3][(Math.floor(n / 3) + attempt) % 6], l: 0, u: 0, target: 'tangent' };
  const pairs: number[][] = []; for (let a = -3; a < 3; a++) for (let b = a + 1; b <= 3; b++) pairs.push([a, b]);
  const [r1, r2] = pairs[(Math.floor(n / 4) + attempt) % pairs.length], A = sign * (1 + Math.floor(n / 8) % 2);
  const intervals = [[-4, 4], [r1, 4], [-4, r2], [r1 - 1, r2 + 1]], [l, u] = intervals[Math.floor(n / 4) % 4];
  return { scope, c3: 2 * A, c2: -3 * A * (r1 + r2), c1: 6 * A * r1 * r2, c0, t: 0,
    l: scope === DERIVATIVE_APPLICATION_SCOPES[3] ? l : 0, u: scope === DERIVATIVE_APPLICATION_SCOPES[3] ? u : 0,
    target: scope === DERIVATIVE_APPLICATION_SCOPES[1] ? (Math.floor(n / 2) % 2 ? 'decreasing' : 'increasing') : (Math.floor(n / 2) % 2 ? 'minimum' : 'maximum') };
}
export function createSubjectPracticeMathDerivativeApplicationLocalGenerator(ports: SubjectPracticeQuestionPlanPorts) {
  return (input: { blueprint: QuestionGenerationBlueprint; questionPlan: unknown; seed: number }) => {
    const validSeed = Number.isSafeInteger(input.seed) && input.seed >= 0, seed = validSeed ? input.seed : 0;
    const exactScope = derivativeApplicationScopeFrom(input.questionPlan), b = input.blueprint;
    const common = { generatorVersion: DERIVATIVE_APPLICATION_GENERATOR_VERSION, seed, exactScope, providerImpact: 'none_no_provider_call' as const,
      estimatedCostUsd: 0 as const, productionImpact: 'none_shadow_only' as const, automaticPublicationEligible: false as const };
    const unsupported = { ...common, status: 'unsupported_question_plan' as const, candidate: null, solverEvidence: null, oracleEvidence: null,
      explanationEvidence: null, adherence: null, scopeId: null, reasonCodes: ['derivative_application_local_plan_not_supported'] };
    if (!validSeed || !exactScope || !ports.validate(input.questionPlan).valid || b.subject !== 'math' || b.topicId !== 71 || b.topicCode !== 'M-CALC-001'
      || b.difficulty !== 'medium' || b.questionType !== 'single_choice') return unsupported;
    let selected: DerivativeApplicationParameters | null = null, parameterAttempts = 0;
    for (let attempt = 0; attempt < 64; attempt++) {
      parameterAttempts++;
      // A zero constant would erase the meaning of the omit-constant distractor; vary only this local trial.
      const p = parameters(exactScope, seed, attempt); if (!p.c0) p.c0 = 8;
      if (!derivativeApplicationParametersFrom(derivativeApplicationPrompt(p, 'zh'), exactScope, 'zh')) continue;
      const keys = [derivativeApplicationAnswer(p), ...derivativeApplicationDistractors(p).map(o => o.key)].map(x => derivativeApplicationOptionKey(x, exactScope));
      if (keys.includes(null) || new Set(keys).size !== 4) continue;
      selected = p; break;
    }
    if (!selected) return { ...unsupported, status: 'bounded_generation_exhausted' as const, parameterAttempts };
    const p = selected, answer = derivativeApplicationAnswer(p), choices = derivativeApplicationDistractors(p), correctAnswer = 'ABCD'[Math.floor(seed / 8) % 4];
    choices.splice('ABCD'.indexOf(correctAnswer), 0, { key: answer, intent: '' });
    const options = choices.map((x, i) => ({ id: 'ABCD'[i], text: x.key })), alternate = Math.floor(seed / 16) % 2 === 1;
    const prompt = derivativeApplicationPrompt(p, 'zh', alternate), enPrompt = derivativeApplicationPrompt(p, 'en', alternate), explanation = renderDerivativeApplicationExplanation(p, answer, correctAnswer);
    const candidate: GeneratedQuestionCandidate = { subject: 'math', topicId: 71, blueprintId: b.id, sourceType: 'ai', designedDifficulty: 'medium', questionType: 'single_choice',
      prompt, options, correctAnswer, explanation: explanation.zh, knowledgeTags: ['导数与微积分初步', exactScope],
      optionMetadata: choices.flatMap((o, i) => o.intent ? [{ optionId: 'ABCD'[i], distractorIntent: o.intent, misconceptionTags: [o.intent] }] : []),
      localizations: { zh: { prompt, options, explanation: explanation.zh, knowledgeTags: ['导数与微积分初步', exactScope] },
        en: { prompt: enPrompt, options: options.map(o => ({ ...o })), explanation: explanation.en, knowledgeTags: ['Derivative applications', exactScope] } }, syllabusVersion: b.syllabusVersion };
    const context = { questionPlan: input.questionPlan }, solverEvidence = solveSubjectPracticeMathDerivativeApplication(candidate, context);
    const oracleEvidence = verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle(candidate, context), explanationEvidence = verifySubjectPracticeMathDerivativeApplicationExplanation(candidate, context);
    const adherence = ports.adherenceFor(input.questionPlan, candidate);
    const verified = solverEvidence.status === 'verified' && oracleEvidence.status === 'verified' && explanationEvidence.status === 'verified' && adherence.adheres
      && solverEvidence.scopeId === oracleEvidence.scopeId && solverEvidence.selectedOptionId === oracleEvidence.selectedOptionId;
    return { ...common, parameterAttempts, status: verified ? 'generated_and_triple_verified' as const : 'self_verification_failed' as const, candidate: verified ? candidate : null,
      solverEvidence, oracleEvidence, explanationEvidence, adherence, scopeId: verified ? solverEvidence.scopeId : null,
      reasonCodes: verified ? [] : [...solverEvidence.reasonCodes, ...oracleEvidence.reasonCodes, ...explanationEvidence.reasonCodes, ...adherence.failureCodes] };
  };
}
