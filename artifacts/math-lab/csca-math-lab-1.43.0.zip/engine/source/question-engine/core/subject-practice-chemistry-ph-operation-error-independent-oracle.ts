import { GeneratedQuestionCandidate } from './types';
import { SubjectPracticeChemistryPhBias, SubjectPracticeChemistryPhOperationErrorScope } from
  './subject-practice-chemistry-ph-operation-error-solver';

export const SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_INDEPENDENT_ORACLE_VERSION =
  'chemistry-ph-operation-error-independent-oracle-v2-common-species-and-indeterminate';

export type SubjectPracticeChemistryPhOperationErrorIndependentOracleEvidence = {
  oracleVersion: string;
  status: 'verified' | 'conflict' | 'unparsed';
  operationScope: SubjectPracticeChemistryPhOperationErrorScope | null;
  expectedBias: SubjectPracticeChemistryPhBias | null;
  optionVerdicts: Array<{ optionId: string; verdict: 'true' | 'false' | 'unknown'; parsedBias: SubjectPracticeChemistryPhBias | null }>;
  trueOptionIds: string[];
  selectedOptionId: string | null;
  uniqueAnswer: boolean;
  agreesWithGenerator: boolean;
  scopeId: string | null;
  scopeMatched: boolean;
  evidenceBoundary: 'prompt_and_visible_options_only';
  providerImpact: 'none_no_provider_call';
  productionGateImpact: 'none_shadow_only';
  reasonCodes: string[];
};

function compact(value: unknown) {
  return String(value ?? '').replace(/\s+/g, '').toLowerCase();
}

function recordFrom(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function classifyPrompt(prompt: string): SubjectPracticeChemistryPhOperationErrorScope | null {
  const source = compact(prompt);
  const acid = /酸性溶液|强酸溶液|盐酸|硝酸|hcl|hno3|acidicsolution|strongacidsolution/.test(source);
  const base = /碱性溶液|强碱溶液|氢氧化钠|氢氧化钾|naoh|koh|alkalinesolution|basicsolution|strongbasesolution/.test(source);
  if (acid === base) return null;
  if (/ph试纸/.test(source) && /润湿|湿润/.test(source) || /phpaper/.test(source) && /wet|moisten/.test(source)) {
    return acid ? 'ph_paper_wetting_acid' : 'ph_paper_wetting_base';
  }
  if (!/容量瓶|volumetricflask/.test(source)) return null;
  if (/超过.{0,10}刻度线|高于.{0,10}刻度线|加水过量|abovethecalibrationmark|pastthecalibrationmark|overfill/.test(source)) {
    return acid ? 'volumetric_overfill_acid' : 'volumetric_overfill_base';
  }
  if (/未到.{0,10}刻度线|低于.{0,10}刻度线|加水不足|belowthecalibrationmark|shortofthecalibrationmark|underfill/.test(source)) {
    return acid ? 'volumetric_underfill_acid' : 'volumetric_underfill_base';
  }
  return null;
}

function expectedBias(scope: SubjectPracticeChemistryPhOperationErrorScope): SubjectPracticeChemistryPhBias {
  const diluted = scope.startsWith('ph_paper_wetting') || scope.startsWith('volumetric_overfill');
  const acid = scope.endsWith('_acid');
  if (acid) return diluted ? 'higher' : 'lower';
  return diluted ? 'lower' : 'higher';
}

function parseBias(value: unknown): SubjectPracticeChemistryPhBias | null {
  const source = compact(value);
  const table: Array<[SubjectPracticeChemistryPhBias, RegExp]> = [
    ['higher', /偏高|较高|升高|higher|toohigh|increase/],
    ['lower', /偏低|较低|降低|lower|toolow|decrease/],
    ['unchanged', /不变|无影响|unchanged|nochange|unaffected/],
    ['indeterminate', /无法判断|无法确定|不能确定|indeterminate|cannotbedetermined|insufficient/]
  ];
  const hits = table.filter(([, pattern]) => pattern.test(source));
  return hits.length === 1 ? hits[0][0] : null;
}

export function verifySubjectPracticeChemistryPhOperationErrorWithIndependentOracle(
  candidate: GeneratedQuestionCandidate,
  context: { questionPlan?: unknown } = {}
): SubjectPracticeChemistryPhOperationErrorIndependentOracleEvidence {
  const operationScope = classifyPrompt(candidate.prompt);
  const expected = operationScope ? expectedBias(operationScope) : null;
  const plan = recordFrom(context.questionPlan);
  const constraints = recordFrom(plan?.renderConstraints);
  const scopeMatched = Boolean(
    operationScope
    && compact(plan?.schemaVersion) === 'subject-practice-question-plan-v1'
    && compact(plan?.planTemplate) === 'basic_ph_measurement_preparation_error_v1'
    && compact(plan?.taskFamily) === 'basic_ph_measurement_or_preparation_error_judgement'
    && compact(constraints?.exactChemistryOperationErrorScope) === operationScope
  );
  const optionVerdicts = candidate.options.map((option) => {
    const parsedBias = parseBias(option.text);
    return {
      optionId: option.id,
      verdict: !parsedBias || !expected ? 'unknown' as const : parsedBias === expected ? 'true' as const : 'false' as const,
      parsedBias
    };
  });
  const unknown = optionVerdicts.some((item) => item.verdict === 'unknown');
  const trueOptionIds = optionVerdicts.filter((item) => item.verdict === 'true').map((item) => item.optionId);
  const uniqueAnswer = !unknown && trueOptionIds.length === 1;
  const selectedOptionId = uniqueAnswer ? trueOptionIds[0] : null;
  const agreesWithGenerator = uniqueAnswer && selectedOptionId === candidate.correctAnswer;
  const reasonCodes: string[] = [];
  if (!operationScope) reasonCodes.push('chemistry_ph_operation_error_oracle_prompt_unparsed');
  if (unknown) reasonCodes.push('chemistry_ph_operation_error_oracle_option_unparsed');
  if (!unknown && trueOptionIds.length !== 1) reasonCodes.push(trueOptionIds.length
    ? 'chemistry_ph_operation_error_oracle_multiple_true_options'
    : 'chemistry_ph_operation_error_oracle_no_true_option');
  if (uniqueAnswer && !agreesWithGenerator) reasonCodes.push('chemistry_ph_operation_error_oracle_generator_answer_disagrees');
  if (!scopeMatched) reasonCodes.push('chemistry_ph_operation_error_oracle_scope_mismatch');
  const status = !operationScope || unknown
    ? 'unparsed' as const
    : uniqueAnswer && agreesWithGenerator && scopeMatched
      ? 'verified' as const
      : 'conflict' as const;
  return {
    oracleVersion: SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_INDEPENDENT_ORACLE_VERSION,
    status,
    operationScope,
    expectedBias: expected,
    optionVerdicts,
    trueOptionIds,
    selectedOptionId,
    uniqueAnswer,
    agreesWithGenerator,
    scopeId: operationScope ? `chemistry-ph-operation-error-v1:${operationScope}` : null,
    scopeMatched,
    evidenceBoundary: 'prompt_and_visible_options_only',
    providerImpact: 'none_no_provider_call',
    productionGateImpact: 'none_shadow_only',
    reasonCodes
  };
}
