import { GeneratedQuestionCandidate } from './types';
import { DerivativeApplicationParameters, DERIVATIVE_APPLICATION_SCOPES, daPolynomial, daValue, daSlope, daRoots, daCriticalCandidates,
  solveSubjectPracticeMathDerivativeApplication } from './subject-practice-math-derivative-application-solver';
export const DERIVATIVE_APPLICATION_EXPLANATION_VERSION = 'math-derivative-application-explanation-v1-bound-bilingual';
export function renderDerivativeApplicationExplanation(p: DerivativeApplicationParameters, answer: string, option: string) {
  let proof = 'f(x)=' + daPolynomial(p) + "; f'(x)=" + (3 * p.c3) + '*x^2+(' + (2 * p.c2) + ')*x+(' + p.c1 + ')';
  let zh: string, en: string;
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[0]) {
    const x = p.t, y = daValue(p, x), slope = daSlope(p, x);
    proof += "; f'(" + x + ')=' + slope + '; f(' + x + ')=' + y + '; y-(' + y + ')=' + slope + '*(x-(' + x + '))'
      + '; intercept=' + y + '-(' + slope + ')*(' + x + ')=' + (y - slope * BigInt(x));
    zh = '先对多项式求导得到切线斜率，再计算切点纵坐标，用点斜式确定切线：';
    en = 'Differentiate to obtain the slope, evaluate the point on the curve, then use the point-slope equation: ';
  } else {
    const [a, b] = daRoots(p), s = p.c3 > 0 ? '+' : '-', opposite = p.c3 > 0 ? '-' : '+';
    proof += "; f'(x)=" + (3 * p.c3) + '*(x-(' + a + '))*(x-(' + b + ')); stationary=[' + a + ',' + b + ']'
      + '; signs=(-inf,' + a + '):' + s + ';(' + a + ',' + b + '):' + opposite + ';(' + b + ',+inf):' + s;
    if (p.scope === DERIVATIVE_APPLICATION_SCOPES[1]) {
      proof += '; target=' + p.target + '; all_three_open_cells_classified=true; stationary_endpoints_excluded=true';
      zh = '导数的全部零点将实轴分成三个开区间。利用因式符号逐段判断，保留题目要求的全部最大开区间：';
      en = 'All derivative roots partition the real axis into three open cells. Factor signs classify every cell; retain all requested maximal open intervals: ';
    } else if (p.scope === DERIVATIVE_APPLICATION_SCOPES[2]) {
      const x = (p.target === 'maximum') === (p.c3 > 0) ? a : b;
      proof += '; target=local_' + p.target + '; selected_x=' + x + '; sign_change=' + (p.target === 'maximum' ? '+to-' : '-to+')
        + '; f(' + x + ')=' + p.c3 + '*(' + x + ')^3+(' + p.c2 + ')*(' + x + ')^2+(' + p.c1 + ')*(' + x + ')+(' + p.c0 + ')=' + daValue(p, x);
      zh = '先按导数符号变化判定局部极大或极小点，再代入原函数求函数值，不能把横坐标当作极值：';
      en = 'Classify the local extremum by the derivative sign change, then evaluate the original function; the abscissa is not the extremum value: ';
    } else {
      const xs = daCriticalCandidates(p);
      proof += '; closed_interval=[' + p.l + ',' + p.u + ']; candidates=[' + xs.join(',') + ']; continuous_polynomial=true; all_endpoints_and_interior_stationary_points=true';
      for (const x of xs) proof += '; f(' + x + ')=' + p.c3 + '*(' + x + ')^3+(' + p.c2 + ')*(' + x + ')^2+(' + p.c1 + ')*(' + x + ')+(' + p.c0 + ')=' + daValue(p, x);
      proof += '; target=global_' + p.target + '; compared_values=[' + xs.map(x => String(daValue(p, x))).join(',') + ']';
      zh = '多项式在闭区间上连续，最值只能在端点或内部驻点取得。列出全部候选点，端点重合时只计一次，并逐一比较函数值：';
      en = 'Continuity guarantees an extreme value at an endpoint or an interior stationary point. Enumerate every such point once and compare all function values: ';
    }
  }
  proof += '; result=' + answer;
  return { zh: zh + proof + '。对应选项 ' + option + '。', en: en + proof + '. Option ' + option + '.' };
}
export function verifySubjectPracticeMathDerivativeApplicationExplanation(candidate: GeneratedQuestionCandidate, context: { questionPlan?: unknown } = {}) {
  const solved = solveSubjectPracticeMathDerivativeApplication(candidate, context), p = solved.parameters;
  const expected = p && solved.expectedAnswer && solved.selectedOptionId ? renderDerivativeApplicationExplanation(p, solved.expectedAnswer, solved.selectedOptionId) : null;
  const zhBound = Boolean(expected && candidate.explanation === expected.zh && candidate.localizations?.zh?.explanation === expected.zh);
  const enBound = Boolean(expected && candidate.localizations?.en?.explanation === expected.en), reasonCodes: string[] = [];
  if (solved.status !== 'verified') reasonCodes.push('derivative_application_explanation_solver_not_verified');
  if (!zhBound) reasonCodes.push('derivative_application_explanation_zh_mismatch'); if (!enBound) reasonCodes.push('derivative_application_explanation_en_mismatch');
  return { verifierVersion: DERIVATIVE_APPLICATION_EXPLANATION_VERSION, status: reasonCodes.length ? 'failed' as const : 'verified' as const,
    scopeId: solved.scopeId, zhBound, enBound, providerImpact: 'none_no_provider_call' as const, productionGateImpact: 'none_shadow_only' as const, reasonCodes };
}
export type SubjectPracticeMathDerivativeApplicationExplanationEvidence = ReturnType<typeof verifySubjectPracticeMathDerivativeApplicationExplanation>;
