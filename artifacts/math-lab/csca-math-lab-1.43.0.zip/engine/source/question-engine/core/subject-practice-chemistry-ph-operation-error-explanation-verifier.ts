import { GeneratedQuestionCandidate } from './types';
import {
  solveSubjectPracticeChemistryPhOperationError,
  SubjectPracticeChemistryPhOperationErrorSolverEvidence
} from './subject-practice-chemistry-ph-operation-error-solver';

export const SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_EXPLANATION_VERIFIER_VERSION =
  'chemistry-ph-operation-error-explanation-verifier-v1';

type ExplanationCheck = {
  language: 'zh' | 'en';
  operationEffectMatched: boolean;
  ionOrConcentrationDirectionMatched: boolean;
  phConclusionMatched: boolean;
  reasonCodes: string[];
};

export type SubjectPracticeChemistryPhOperationErrorExplanationEvidence = {
  verifierVersion: string;
  status: 'verified' | 'failed' | 'unparsed';
  solverEvidence: SubjectPracticeChemistryPhOperationErrorSolverEvidence;
  causalChainChecked: true;
  checks: ExplanationCheck[];
  mismatchCount: number;
  providerImpact: 'none_no_provider_call';
  productionGateImpact: 'none_shadow_only';
  reasonCodes: string[];
};

function compact(value: unknown) {
  return String(value ?? '').replace(/\s+/g, '').toLowerCase();
}

function checkExplanation(input: {
  language: 'zh' | 'en';
  text: string;
  evidence: SubjectPracticeChemistryPhOperationErrorSolverEvidence;
}): ExplanationCheck {
  const text = compact(input.text);
  const task = input.evidence.canonicalTask;
  const dilution = task?.concentrationDirection === 'decrease';
  const acid = task?.solutionCharacter === 'acid';
  const operationEffectMatched = dilution
    ? /(稀释|体积增大|浓度降低|dilut|largervolume|concentrationdecreases?)/.test(text)
    : /(体积偏小|浓度升高|浓度增大|smallervolume|concentrationincreases?|moreconcentrated)/.test(text);
  const ionOrConcentrationDirectionMatched = acid
    ? dilution
      ? /(\[?h\+?\]?|氢离子).{0,20}(降低|减小|decreas|lower)/.test(text)
      : /(\[?h\+?\]?|氢离子).{0,20}(升高|增大|increas|higher)/.test(text)
    : dilution
      ? /(\[?oh-?\]?|氢氧根).{0,20}(降低|减小|decreas|lower)/.test(text)
      : /(\[?oh-?\]?|氢氧根).{0,20}(升高|增大|increas|higher)/.test(text);
  const biasPattern = input.evidence.expectedBias === 'higher'
    ? /(ph.{0,12}(偏高|升高|增大|higher|increas)|偏高.{0,12}ph)/
    : /(ph.{0,12}(偏低|降低|减小|lower|decreas)|偏低.{0,12}ph)/;
  const phConclusionMatched = biasPattern.test(text);
  const reasonCodes: string[] = [];
  if (!operationEffectMatched) reasonCodes.push(`chemistry_ph_operation_error_explanation_${input.language}_operation_effect_missing`);
  if (!ionOrConcentrationDirectionMatched) reasonCodes.push(`chemistry_ph_operation_error_explanation_${input.language}_ion_direction_missing`);
  if (!phConclusionMatched) reasonCodes.push(`chemistry_ph_operation_error_explanation_${input.language}_ph_conclusion_missing_or_wrong`);
  return { language: input.language, operationEffectMatched, ionOrConcentrationDirectionMatched, phConclusionMatched, reasonCodes };
}

export function verifySubjectPracticeChemistryPhOperationErrorExplanation(
  candidate: GeneratedQuestionCandidate,
  context: { questionPlan?: unknown } = {}
): SubjectPracticeChemistryPhOperationErrorExplanationEvidence {
  const solverEvidence = solveSubjectPracticeChemistryPhOperationError(candidate, context);
  const checks = [
    checkExplanation({ language: 'zh', text: candidate.explanation, evidence: solverEvidence }),
    checkExplanation({ language: 'en', text: candidate.localizations?.en?.explanation ?? '', evidence: solverEvidence })
  ];
  const reasonCodes = checks.flatMap((check) => check.reasonCodes);
  if (solverEvidence.status !== 'verified' || !solverEvidence.verificationScope.matched) {
    reasonCodes.unshift('chemistry_ph_operation_error_explanation_answer_recomputation_not_verified');
  }
  const status = solverEvidence.status === 'unparsed'
    ? 'unparsed' as const
    : reasonCodes.length === 0 ? 'verified' as const : 'failed' as const;
  return {
    verifierVersion: SUBJECT_PRACTICE_CHEMISTRY_PH_OPERATION_ERROR_EXPLANATION_VERIFIER_VERSION,
    status,
    solverEvidence,
    causalChainChecked: true,
    checks,
    mismatchCount: reasonCodes.length,
    providerImpact: 'none_no_provider_call',
    productionGateImpact: 'none_shadow_only',
    reasonCodes: Array.from(new Set(reasonCodes))
  };
}
