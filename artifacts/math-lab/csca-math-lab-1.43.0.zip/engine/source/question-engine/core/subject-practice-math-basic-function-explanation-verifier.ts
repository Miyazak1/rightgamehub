import { GeneratedQuestionCandidate } from './types';
import { solveSubjectPracticeMathBasicFunction } from './subject-practice-math-basic-function-solver';

export const SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_EXPLANATION_VERIFIER_VERSION = 'math-basic-function-explanation-verifier-v1';
export function verifySubjectPracticeMathBasicFunctionExplanation(candidate: GeneratedQuestionCandidate, context: { questionPlan?: unknown } = {}) {
  const solver = solveSubjectPracticeMathBasicFunction(candidate, context); const text = String(candidate.explanation ?? '').replace(/\s+/g, ' ');
  const hasRule = solver.exactScope === 'linear_monotonicity' ? /斜率|slope/i.test(text)
    : solver.exactScope === 'quadratic_axis' ? /顶点式|对称轴|vertex form|axis/i.test(text)
      : solver.exactScope === 'rational_domain_exclusion' ? /分母|denominator/i.test(text)
        : /f\s*\(\s*-x\s*\)|奇函数|偶函数|odd|even/i.test(text);
  const conclusion = solver.exactScope === 'linear_monotonicity' ? /单调递增|单调递减|increasing|decreasing/i.test(text)
    : solver.exactScope === 'quadratic_axis' ? /x\s*=\s*-?\d+/i.test(text)
      : solver.exactScope === 'rational_domain_exclusion' ? /x\s*[≠!=]+\s*-?\d+|R\s*(?:\\|∖)/i.test(text)
        : /奇函数|偶函数|非奇非偶|odd function|even function|neither/i.test(text);
  const parityRelationMatches = solver.exactScope !== 'polynomial_parity'
    || (solver.expectedValue === 'odd'
      ? /(?:=|所以|therefore|thus).{0,12}-f\s*\(\s*x\s*\)/i.test(text)
      : solver.expectedValue === 'even'
        ? /(?:=|所以|therefore|thus).{0,12}(?<!-)f\s*\(\s*x\s*\)/i.test(text)
        : true);
  const reasonCodes: string[] = [];
  if (solver.status !== 'verified') reasonCodes.push('math_basic_function_explanation_primary_solver_not_verified');
  if (!hasRule) reasonCodes.push('math_basic_function_explanation_rule_missing');
  if (!conclusion) reasonCodes.push('math_basic_function_explanation_conclusion_missing');
  if (!parityRelationMatches) reasonCodes.push('math_basic_function_explanation_parity_relation_mismatch');
  return { verifierVersion: SUBJECT_PRACTICE_MATH_BASIC_FUNCTION_EXPLANATION_VERIFIER_VERSION, status: reasonCodes.length ? 'failed' as const : 'verified' as const, scopeId: solver.scopeId, ruleVisible: hasRule, conclusionVisible: conclusion, providerImpact: 'none_no_provider_call' as const, productionGateImpact: 'none_shadow_only' as const, reasonCodes };
}
export type SubjectPracticeMathBasicFunctionExplanationEvidence = ReturnType<typeof verifySubjectPracticeMathBasicFunctionExplanation>;
