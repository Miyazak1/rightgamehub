import { GeneratedQuestionCandidate } from './types';

export const DERIVATIVE_APPLICATION_FAMILY = 'math_polynomial_derivative_application';
export const DERIVATIVE_APPLICATION_TEMPLATE = DERIVATIVE_APPLICATION_FAMILY + '_v1';
export const DERIVATIVE_APPLICATION_SOLVER_VERSION = 'math-derivative-application-solver-v1-exact-polynomial';
export const DERIVATIVE_APPLICATION_SCOPE_VERSION = 'math-medium-derivative-application-v1';
export const DERIVATIVE_APPLICATION_SCOPES = ['quadratic_tangent_line_equation', 'cubic_monotonicity_interval',
  'cubic_local_extremum_value', 'cubic_closed_interval_extremum_value'] as const;
export type DerivativeApplicationScope = typeof DERIVATIVE_APPLICATION_SCOPES[number];
export const DERIVATIVE_APPLICATION_CONSTRAINTS = { topicCode: 'M-CALC-001', boundedIntegerParameters: true,
  exactRationalArithmetic: true, maximumAbsoluteValue: 10000, completeCriticalPointCertificate: true,
  externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 } as const;
export type DerivativeApplicationParameters = { scope: DerivativeApplicationScope; c3: number; c2: number; c1: number; c0: number;
  t: number; l: number; u: number; target: 'tangent' | 'increasing' | 'decreasing' | 'maximum' | 'minimum' };
const obj = (v: unknown): Record<string, unknown> | null => v && typeof v === 'object' && !Array.isArray(v) ? v as Record<string, unknown> : null;
export function derivativeApplicationScopeFrom(value: unknown): DerivativeApplicationScope | null {
  const p = obj(value), r = obj(p?.renderConstraints), s = obj(p?.scenarioContract), scope = r?.exactDerivativeApplicationScope as DerivativeApplicationScope;
  return p?.schemaVersion === 'subject-practice-question-plan-v1' && p?.policyVersion === 'subject-practice-question-plan-policy-v1'
    && p?.subject === 'math' && p?.topicId === 71 && p?.targetDifficulty === 'medium' && p?.representationType === 'text'
    && p?.taskFamily === DERIVATIVE_APPLICATION_FAMILY && p?.planTemplate === DERIVATIVE_APPLICATION_TEMPLATE && r?.questionType === 'single_choice'
    && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'polynomial_derivative_object' && s?.scenarioAction === scope
    && Object.entries(DERIVATIVE_APPLICATION_CONSTRAINTS).every(([k, v]) => r?.[k] === v) && DERIVATIVE_APPLICATION_SCOPES.includes(scope) ? scope : null;
}
export const daPolynomial = (p: DerivativeApplicationParameters) => (p.c3 ? p.c3 + '*x^3+' : '') + '(' + p.c2 + ')*x^2+(' + p.c1 + ')*x+(' + p.c0 + ')';
export function daValue(p: DerivativeApplicationParameters, x: number): bigint {
  const t = BigInt(x); return BigInt(p.c3) * t ** 3n + BigInt(p.c2) * t ** 2n + BigInt(p.c1) * t + BigInt(p.c0);
}
export const daSlope = (p: DerivativeApplicationParameters, x: number) => 3n * BigInt(p.c3) * BigInt(x) ** 2n + 2n * BigInt(p.c2) * BigInt(x) + BigInt(p.c1);
// Bounded coefficient identity, not sampled sign testing. Oracle instead solves the discriminant independently.
export function daRoots(p: DerivativeApplicationParameters): number[] {
  if (![-4, -2, 2, 4].includes(p.c3)) return [];
  const roots: number[] = [];
  for (let x = -3; x <= 3; x++) if (daSlope(p, x) === 0n) roots.push(x);
  if (roots.length !== 2 || 2n * BigInt(p.c2) !== -3n * BigInt(p.c3) * BigInt(roots[0] + roots[1])
    || BigInt(p.c1) !== 3n * BigInt(p.c3) * BigInt(roots[0] * roots[1])) return [];
  return roots;
}
export function derivativeApplicationPrompt(p: DerivativeApplicationParameters, lang: 'zh' | 'en', alternate = false): string {
  const zh = lang === 'zh', start = zh ? (alternate ? '考虑函数 ' : '已知函数 ') : (alternate ? 'Consider ' : 'Given '), f = 'f(x)=' + daPolynomial(p);
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[0]) return start + f + (zh ? '。求在 x=' : '. Find the tangent line at x=') + p.t
    + (zh ? ' 处的切线方程，先求斜率和切点，再确定直线。' : ', using both the derivative and the point on the curve.');
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[1]) return start + f + (zh ? '。求单调' + (p.target === 'increasing' ? '递增' : '递减')
    + '区间；以全部驻点分割实轴，答案列出所有最大开区间（用 U 表示并集）。'
    : '. Find all maximal open intervals of ' + p.target + ' behaviour, partitioned by all stationary points (U denotes union).');
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[2]) return start + f + (zh ? '。由导数符号变化确定局部极' + (p.target === 'maximum' ? '大' : '小')
    + '值，答案为函数值而非横坐标。' : '. Use derivative sign changes to find the local ' + p.target + ' value, not its x-coordinate.');
  return start + f + ', x in [' + p.l + ', ' + p.u + ']' + (zh ? '。求闭区间上的' + (p.target === 'maximum' ? '最大' : '最小')
    + '值，比较端点与区间内全部驻点。' : '. Find the ' + p.target + ' value on the closed interval, comparing endpoints and all interior stationary points.');
}
export function derivativeApplicationParametersFrom(text: string, scope: DerivativeApplicationScope | null, lang: 'zh' | 'en'): DerivativeApplicationParameters | null {
  if (!scope || typeof text !== 'string' || text.length > 1000) return null;
  const q = text.match(/f\(x\)=(?:(-?\d+)\*x\^3\+)?\((-?\d+)\)\*x\^2\+\((-?\d+)\)\*x\+\((-?\d+)\)/);
  if (!q) return null;
  const tangent = scope === DERIVATIVE_APPLICATION_SCOPES[0], monotonic = scope === DERIVATIVE_APPLICATION_SCOPES[1];
  const tm = text.match(/(?:在 x=|at x=)(-?\d+)/), limits = text.match(/x in \[(-?\d+), (-?\d+)\]/);
  const p: DerivativeApplicationParameters = { scope, c3: Number(q[1] ?? 0), c2: Number(q[2]), c1: Number(q[3]), c0: Number(q[4]),
    t: tangent ? Number(tm?.[1]) : 0, l: limits ? Number(limits[1]) : 0, u: limits ? Number(limits[2]) : 0,
    target: tangent ? 'tangent' : monotonic ? (/递增|increasing/.test(text) ? 'increasing' : 'decreasing') : /极大|最大|maximum/.test(text) ? 'maximum' : 'minimum' };
  if (![p.c3, p.c2, p.c1, p.c0, p.t, p.l, p.u].every(Number.isSafeInteger) || Math.abs(p.c0) > 8) return null;
  if (tangent) {
    if (q[1] !== undefined || ![-3, -2, -1, 1, 2, 3].includes(p.c2) || Math.abs(p.c1) > 6
      || ![-3, -2, -1, 1, 2, 3].includes(p.t) || daSlope(p, p.t) === 0n) return null;
  } else {
    const roots = daRoots(p); if (roots.length !== 2) return null;
    if (scope === DERIVATIVE_APPLICATION_SCOPES[3] && (!limits || Math.abs(p.l) > 4 || Math.abs(p.u) > 4 || p.l >= p.u || !roots.some(x => x > p.l && x < p.u))) return null;
  }
  return [false, true].some(alt => derivativeApplicationPrompt(p, lang, alt) === text) ? p : null;
}
const line = (m: bigint, b: bigint) => 'y=' + m + '*x+(' + b + ')';
const inside = (a: number, b: number, closed = false) => (closed ? '[' : '(') + a + ', ' + b + (closed ? ']' : ')');
const outside = (a: number, b: number, closed = false) => '(-inf, ' + a + (closed ? ']' : ')') + ' U ' + (closed ? '[' : '(') + b + ', +inf)';
export const daCriticalCandidates = (p: DerivativeApplicationParameters) => [...new Set([p.l, p.u, ...daRoots(p).filter(x => x >= p.l && x <= p.u)])].sort((a, b) => a - b);
const extremum = (p: DerivativeApplicationParameters, xs: number[]) => xs.map(x => daValue(p, x)).reduce((a, b) => (p.target === 'maximum' ? a > b : a < b) ? a : b);
export function derivativeApplicationAnswer(p: DerivativeApplicationParameters): string {
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[0]) { const m = daSlope(p, p.t); return line(m, daValue(p, p.t) - m * BigInt(p.t)); }
  const [a, b] = daRoots(p);
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[1]) return (p.target === 'increasing') === (p.c3 > 0) ? outside(a, b) : inside(a, b);
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[2]) return String(daValue(p, (p.target === 'maximum') === (p.c3 > 0) ? a : b));
  return String(extremum(p, daCriticalCandidates(p)));
}
export function derivativeApplicationDistractors(p: DerivativeApplicationParameters) {
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[0]) {
    const m = daSlope(p, p.t), y = daValue(p, p.t), missed = BigInt(p.c2 * p.t + p.c1);
    return [{ key: line(m, BigInt(p.c0)), intent: 'reuse_polynomial_constant_as_line_intercept' },
      { key: line(m, y + m * BigInt(p.t)), intent: 'reverse_point_slope_translation_sign' },
      { key: line(missed, y - missed * BigInt(p.t)), intent: 'omit_quadratic_derivative_factor_two' }];
  }
  const [a, b] = daRoots(p), outer = (p.target === 'increasing') === (p.c3 > 0);
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[1]) return [
    { key: outer ? inside(a, b) : outside(a, b), intent: 'reverse_derivative_sign_regions' },
    { key: outer ? outside(a, b, true) : inside(a, b, true), intent: 'include_stationary_endpoints_despite_open_interval_convention' },
    { key: outer ? '(-inf, ' + a + ')' : inside(a, b + 1), intent: outer ? 'omit_right_outer_interval' : 'shift_right_stationary_boundary_by_one' }];
  if (p.scope === DERIVATIVE_APPLICATION_SCOPES[2]) {
    const x = (p.target === 'maximum') === (p.c3 > 0) ? a : b;
    return [{ key: String(x), intent: 'report_stationary_abscissa_instead_of_value' },
      { key: String(daValue(p, x === a ? b : a)), intent: 'choose_other_local_extremum' },
      { key: String(daValue(p, x) - BigInt(p.c0)), intent: 'omit_constant_when_evaluating_extremum' }];
  }
  // Each intent denotes a different, reproducible mathematical mistake, not a random offset.
  const answer = BigInt(derivativeApplicationAnswer(p));
  return [
    { key: String(extremum({ ...p, target: p.target === 'maximum' ? 'minimum' : 'maximum' }, daCriticalCandidates(p))), intent: 'select_opposite_global_extremum' },
    { key: String(answer - BigInt(p.c0)), intent: 'omit_constant_when_evaluating_extremum' },
    { key: String(daCriticalCandidates(p).find(x => daValue(p, x) === answer)), intent: 'report_optimizer_abscissa_instead_of_value' }];
}
// Canonical rational and interval keys preserve every endpoint closure and union component.
function numberKey(text: string): string | null {
  const m = text.trim().match(/^([+-]?\d{1,6})(?:\/(\d{1,6}))?$/); if (!m || BigInt(m[2] ?? 1) === 0n) return null;
  let n = BigInt(m[1]), d = BigInt(m[2] ?? 1), a = n < 0n ? -n : n, b = d;
  while (b) { const t = a % b; a = b; b = t; } n /= a; d /= a;
  if (n < -10000n * d || n > 10000n * d) return null;
  return String(n) + (d === 1n ? '' : '/' + d);
}
export function derivativeApplicationOptionKey(text: string, scope: DerivativeApplicationScope): string | null {
  if (typeof text !== 'string' || text.length > 300) return null;
  if (scope === DERIVATIVE_APPLICATION_SCOPES[0]) {
    const m = text.trim().match(/^y=([^*]+)\*x\+\(([^)]+)\)$/); if (!m) return null;
    const a = numberKey(m[1]), b = numberKey(m[2]); return a !== null && b !== null ? 'y=' + a + '*x+(' + b + ')' : null;
  }
  if (scope !== DERIVATIVE_APPLICATION_SCOPES[1]) return numberKey(text);
  const parts = text.split(/\s*U\s*/); if (parts.length > 2) return null;
  const keys: string[] = [];
  for (const part of parts) {
    const m = part.trim().match(/^([\[(])\s*([^,]+),\s*([^\])]+)([\])])$/); if (!m) return null;
    const a = m[2].trim() === '-inf' ? '-inf' : numberKey(m[2]), b = m[3].trim() === '+inf' ? '+inf' : numberKey(m[3]);
    if (a === null || b === null || a === '-inf' && m[1] !== '(' || b === '+inf' && m[4] !== ')') return null;
    keys.push(m[1] + a + ', ' + b + m[4]);
  }
  return keys.sort().join(' U ');
}
export function solveSubjectPracticeMathDerivativeApplication(candidate: GeneratedQuestionCandidate, context: { questionPlan?: unknown } = {}) {
  const exactScope = derivativeApplicationScopeFrom(context.questionPlan), parameters = derivativeApplicationParametersFrom(candidate.prompt, exactScope, 'zh'), reasonCodes: string[] = [];
  if (!parameters) reasonCodes.push('derivative_application_prompt_or_plan_outside_scope');
  if (candidate.subject !== 'math' || candidate.topicId !== 71 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice') reasonCodes.push('derivative_application_identity_mismatch');
  const options = candidate.options ?? [], keys = options.map(o => exactScope ? derivativeApplicationOptionKey(o.text, exactScope) : null);
  for (const lang of ['zh', 'en'] as const) {
    const loc = candidate.localizations?.[lang];
    if (!parameters || JSON.stringify(derivativeApplicationParametersFrom(loc?.prompt ?? '', exactScope, lang)) !== JSON.stringify(parameters)) reasonCodes.push('derivative_application_' + lang + '_prompt_mismatch');
    if (!loc?.options || JSON.stringify(loc.options.map(o => [o.id, exactScope ? derivativeApplicationOptionKey(o.text, exactScope) : null])) !== JSON.stringify(options.map((o, i) => [o.id, keys[i]]))) reasonCodes.push('derivative_application_' + lang + '_options_mismatch');
  }
  const expectedAnswer = parameters ? derivativeApplicationAnswer(parameters) : null;
  const expectedKey = expectedAnswer && exactScope ? derivativeApplicationOptionKey(expectedAnswer, exactScope) : null;
  if (options.length !== 4 || new Set(options.map(o => o.id)).size !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || keys.includes(null) || new Set(keys).size !== 4) reasonCodes.push('derivative_application_invalid_or_duplicate_options');
  const optionVerdicts = options.map((o, i) => ({ optionId: o.id, semanticValue: keys[i], verdict: keys[i] === null ? 'unknown' as const : keys[i] === expectedKey ? 'true' as const : 'false' as const }));
  const trueOptionIds = optionVerdicts.filter(o => o.verdict === 'true').map(o => o.optionId), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
  if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer) reasonCodes.push('derivative_application_answer_disagreement');
  const wrong = parameters ? derivativeApplicationDistractors(parameters) : [], metadata = candidate.optionMetadata ?? [];
  if (metadata.length !== 3 || new Set(metadata.map(x => x.optionId)).size !== 3 || new Set(metadata.map(x => x.distractorIntent)).size !== 3
    || metadata.some(x => x.optionId === selectedOptionId || !wrong.some(w => w.intent === x.distractorIntent && exactScope && derivativeApplicationOptionKey(w.key, exactScope) === keys[options.findIndex(o => o.id === x.optionId)]))) reasonCodes.push('derivative_application_distractor_intent_mismatch');
  const scopeId = parameters ? DERIVATIVE_APPLICATION_SCOPE_VERSION + ':' + exactScope : null;
  return { solverVersion: DERIVATIVE_APPLICATION_SOLVER_VERSION, status: reasonCodes.length ? (parameters ? 'conflict' as const : 'unparsed' as const) : 'verified' as const,
    taskFamily: DERIVATIVE_APPLICATION_FAMILY, scopeId, exactScope, parameters, expectedAnswer, optionVerdicts, trueOptionIds, selectedOptionId,
    verificationScope: { scopeVersion: DERIVATIVE_APPLICATION_SCOPE_VERSION, scopeId, matched: Boolean(parameters), exactScope, reasonCodes: parameters ? [] : ['derivative_application_scope_not_matched'] },
    uniqueAnswer: trueOptionIds.length === 1, agreesWithGenerator: selectedOptionId === candidate.correctAnswer,
    providerImpact: 'none_no_provider_call' as const, productionGateImpact: 'none_shadow_only' as const, reasonCodes };
}
export type SubjectPracticeMathDerivativeApplicationSolverEvidence = ReturnType<typeof solveSubjectPracticeMathDerivativeApplication>;
