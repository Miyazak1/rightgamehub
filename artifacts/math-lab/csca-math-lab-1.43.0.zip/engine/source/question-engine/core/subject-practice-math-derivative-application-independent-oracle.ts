import type { GeneratedQuestionCandidate } from './types';

// Independent visible-text parser, coefficient differentiation, discriminant roots and Horner evaluation.
// No imports of the generator, Solver, explanation renderer or their mathematical helpers.
export const DERIVATIVE_APPLICATION_ORACLE_VERSION = 'math-derivative-application-oracle-v1-complete-polynomial-certificates';
type Q = [bigint, bigint];
type Model = { coefficients: bigint[]; point: number; left: number; right: number; mode: string; roots: number[] };
const scopes = ['quadratic_tangent_line_equation', 'cubic_monotonicity_interval', 'cubic_local_extremum_value', 'cubic_closed_interval_extremum_value'];
const object = (v: unknown): Record<string, unknown> | null => v && typeof v === 'object' && !Array.isArray(v) ? v as Record<string, unknown> : null;
function rational(s: string): Q | null {
  const a = s.trim().split('/'); if (a.length > 2 || !/^[+-]?\d{1,6}$/.test(a[0]) || a[1] !== undefined && !/^\d{1,6}$/.test(a[1])) return null;
  let n = BigInt(a[0]), d = BigInt(a[1] ?? 1); if (!d || n < -10000n * d || n > 10000n * d) return null;
  let x = n < 0n ? -n : n, y = d; while (y) { const z = x % y; x = y; y = z; } n /= x; d /= x; return [n, d];
}
const show = (q: Q) => String(q[0]) + (q[1] === 1n ? '' : '/' + q[1]);
const evaluate = (coefficients: bigint[], x: bigint) => coefficients.slice().reverse().reduce((sum, c) => sum * x + c, 0n);
function integerSqrt(n: bigint): bigint | null {
  if (n < 0n) return null; let low = 0n, high = n + 1n;
  while (high - low > 1n) { const middle = (low + high) / 2n; if (middle * middle > n) high = middle; else low = middle; }
  return low * low === n ? low : null;
}
function read(text: string, scope: string, lang: 'zh' | 'en'): Model | null {
  if (typeof text !== 'string' || text.length > 1000) return null;
  const zh = lang === 'zh', start = zh ? /^(已知函数 |考虑函数 )f\(x\)=/ : /^(Given |Consider )f\(x\)=/;
  if (!start.test(text)) return null;
  const body = text.replace(start, ''), cubic = scope !== scopes[0], parts = body.match(cubic
    ? /^(-?\d+)\*x\^3\+\((-?\d+)\)\*x\^2\+\((-?\d+)\)\*x\+\((-?\d+)\)/
    : /^\((-?\d+)\)\*x\^2\+\((-?\d+)\)\*x\+\((-?\d+)\)/);
  if (!parts || parts.slice(1).some(x => x.length > 5)) return null;
  const coefficients = parts.slice(1).map(BigInt).reverse(), suffix = body.slice(parts[0].length);
  if (coefficients[0] < -8n || coefficients[0] > 8n) return null;
  const m: Model = { coefficients, point: 0, left: 0, right: 0, mode: '', roots: [] };
  if (!cubic) {
    const t = suffix.match(zh ? /^。求在 x=(-?\d+) 处的切线方程，先求斜率和切点，再确定直线。$/
      : /^\. Find the tangent line at x=(-?\d+), using both the derivative and the point on the curve\.$/);
    if (!t || ![-3, -2, -1, 1, 2, 3].includes(Number(t[1])) || ![-3n, -2n, -1n, 1n, 2n, 3n].includes(coefficients[2])
      || coefficients[1] < -6n || coefficients[1] > 6n) return null;
    m.point = Number(t[1]); m.mode = 'tangent';
    if (coefficients[1] + 2n * coefficients[2] * BigInt(m.point) === 0n) return null;
    return m;
  }
  if (![-4n, -2n, 2n, 4n].includes(coefficients[3])) return null;
  const derivative = coefficients.slice(1).map((c, i) => c * BigInt(i + 1)), [c, b, a] = derivative;
  const discriminant = b * b - 4n * a * c, sqrt = integerSqrt(discriminant);
  if (!sqrt || (-b - sqrt) % (2n * a) || (-b + sqrt) % (2n * a)) return null;
  m.roots = [Number((-b - sqrt) / (2n * a)), Number((-b + sqrt) / (2n * a))].sort((x, y) => x - y);
  const [r, s] = m.roots;
  if (r < -3 || s > 3 || r >= s || b !== -a * BigInt(r + s) || c !== a * BigInt(r * s)) return null;
  if (scope === scopes[1]) {
    const match = suffix.match(zh ? /^。求单调(递增|递减)区间；以全部驻点分割实轴，答案列出所有最大开区间（用 U 表示并集）。$/
      : /^\. Find all maximal open intervals of (increasing|decreasing) behaviour, partitioned by all stationary points \(U denotes union\)\.$/);
    if (!match) return null; m.mode = ['递增', 'increasing'].includes(match[1]) ? 'increasing' : 'decreasing';
  } else if (scope === scopes[2]) {
    const match = suffix.match(zh ? /^。由导数符号变化确定局部极(大|小)值，答案为函数值而非横坐标。$/
      : /^\. Use derivative sign changes to find the local (maximum|minimum) value, not its x-coordinate\.$/);
    if (!match) return null; m.mode = ['大', 'maximum'].includes(match[1]) ? 'maximum' : 'minimum';
  } else {
    const match = suffix.match(zh ? /^, x in \[(-?\d+), (-?\d+)\]。求闭区间上的(最大|最小)值，比较端点与区间内全部驻点。$/
      : /^, x in \[(-?\d+), (-?\d+)\]\. Find the (maximum|minimum) value on the closed interval, comparing endpoints and all interior stationary points\.$/);
    if (!match) return null;
    m.left = Number(match[1]); m.right = Number(match[2]); m.mode = ['最大', 'maximum'].includes(match[3]) ? 'maximum' : 'minimum';
    if (m.left < -4 || m.right > 4 || m.left >= m.right || !m.roots.some(x => m.left < x && x < m.right)) return null;
  }
  return m;
}
function optionKey(text: string, scope: string): string | null {
  if (typeof text !== 'string' || text.length > 300) return null;
  if (scope === scopes[0]) {
    if (!text.trim().startsWith('y=') || !text.trim().endsWith(')')) return null;
    const pieces = text.trim().slice(2, -1).split('*x+('); if (pieces.length !== 2) return null;
    const slope = rational(pieces[0]), intercept = rational(pieces[1]); return slope && intercept ? show(slope) + ':' + show(intercept) : null;
  }
  if (scope !== scopes[1]) { const q = rational(text); return q ? show(q) : null; }
  const pieces = text.split('U'); if (pieces.length > 2) return null;
  const intervals: string[] = [];
  for (const item of pieces) {
    const t = item.trim(), ends = t.slice(1, -1).split(',');
    if (!['(', '['].includes(t[0]) || ![')', ']'].includes(t[t.length - 1]) || ends.length !== 2) return null;
    const lo = ends[0].trim() === '-inf' ? '-inf' : rational(ends[0]), hi = ends[1].trim() === '+inf' ? '+inf' : rational(ends[1]);
    if (!lo || !hi || lo === '-inf' && t[0] !== '(' || hi === '+inf' && !t.endsWith(')')) return null;
    if (typeof lo !== 'string' && typeof hi !== 'string' && lo[0] * hi[1] >= hi[0] * lo[1]) return null;
    intervals.push(t[0] + (typeof lo === 'string' ? lo : show(lo)) + ',' + (typeof hi === 'string' ? hi : show(hi)) + t[t.length - 1]);
  }
  return intervals.sort().join('U');
}
const serialize = (v: unknown) => JSON.stringify(v, (_, x) => typeof x === 'bigint' ? x.toString() : x);
export function verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle(candidate: GeneratedQuestionCandidate, context: { questionPlan?: unknown } = {}) {
  const plan = object(context.questionPlan), r = object(plan?.renderConstraints), s = object(plan?.scenarioContract), scope = String(r?.exactDerivativeApplicationScope ?? '');
  const required = { topicCode: 'M-CALC-001', boundedIntegerParameters: true, exactRationalArithmetic: true, maximumAbsoluteValue: 10000,
    completeCriticalPointCertificate: true, externalContextAllowed: false, requiresImage: false, minimumVisibleMoves: 2 };
  const bound = plan?.schemaVersion === 'subject-practice-question-plan-v1' && plan?.policyVersion === 'subject-practice-question-plan-policy-v1'
    && plan?.subject === 'math' && plan?.topicId === 71 && plan?.targetDifficulty === 'medium' && plan?.representationType === 'text'
    && plan?.taskFamily === 'math_polynomial_derivative_application' && plan?.planTemplate === 'math_polynomial_derivative_application_v1'
    && r?.questionType === 'single_choice' && scopes.includes(scope) && Object.entries(required).every(([k, v]) => r?.[k] === v)
    && s?.scenarioMode === 'abstract' && s?.scenarioEntity === 'polynomial_derivative_object' && s?.scenarioAction === scope;
  const model = bound ? read(candidate.prompt, scope, 'zh') : null, reasonCodes: string[] = [];
  if (!model) reasonCodes.push('derivative_application_oracle_scope_unparsed');
  if (candidate.subject !== 'math' || candidate.topicId !== 71 || candidate.designedDifficulty !== 'medium' || candidate.questionType !== 'single_choice') reasonCodes.push('derivative_application_oracle_identity_mismatch');
  const options = candidate.options ?? [], keys = options.map(o => optionKey(o.text, scope));
  if (options.length !== 4 || options.some(o => !['A', 'B', 'C', 'D'].includes(o.id)) || new Set(options.map(o => o.id)).size !== 4 || keys.includes(null) || new Set(keys).size !== 4) reasonCodes.push('derivative_application_oracle_invalid_options');
  for (const lang of ['zh', 'en'] as const) {
    const loc = candidate.localizations?.[lang];
    if (!model || serialize(read(loc?.prompt ?? '', scope, lang)) !== serialize(model)) reasonCodes.push('derivative_application_oracle_' + lang + '_parameters');
    if (!loc?.options || serialize(loc.options.map(o => [o.id, optionKey(o.text, scope)])) !== serialize(options.map((o, i) => [o.id, keys[i]]))) reasonCodes.push('derivative_application_oracle_' + lang + '_options');
  }
  let expected: string | null = null, certificate = '', criticalPoints: number[] = [], candidateValues: Array<{ x: number; value: string }> = [], signPartition: number[] = [];
  if (model) {
    const m = model, coefficients = m.coefficients, derivative = coefficients.slice(1).map((c, i) => c * BigInt(i + 1));
    if (scope === scopes[0]) {
      const x = BigInt(m.point), y = evaluate(coefficients, x), slope = evaluate(derivative, x);
      expected = slope + ':' + (y - slope * x); candidateValues = [{ x: m.point, value: String(y) }];
      certificate = 'exact_derivative_at_point_and_line_incidence_unique_tangent';
    } else {
      criticalPoints = m.roots; const [a, b] = m.roots, outerSign = derivative[2] > 0n ? 1 : -1;
      // Exact factor identity proved in read(): signs constant on all three open cells, not finite probes.
      signPartition = [outerSign, -outerSign, outerSign];
      if (scope === scopes[1]) {
        const requested = m.mode === 'increasing' ? 1 : -1, intervals = ['(-inf,' + a + ')', '(' + a + ',' + b + ')', '(' + b + ',+inf)'];
        expected = intervals.filter((_, i) => signPartition[i] === requested).sort().join('U');
        certificate = 'discriminant_all_roots_factor_identity_complete_three_cell_sign_partition_maximal_open_intervals';
      } else {
        const xs = scope === scopes[2] ? [((m.mode === 'maximum') === (outerSign === 1)) ? a : b]
          : [...new Set([m.left, m.right, ...m.roots.filter(x => m.left < x && x < m.right)])];
        candidateValues = xs.map(x => ({ x, value: String(evaluate(coefficients, BigInt(x))) }));
        const values = candidateValues.map(x => BigInt(x.value));
        expected = String(values.reduce((x, y) => (m.mode === 'maximum' ? x > y : x < y) ? x : y));
        certificate = scope === scopes[2] ? 'all_stationary_points_classified_by_sign_changes_then_independent_horner_value'
          : 'polynomial_continuity_extreme_value_theorem_all_endpoints_and_all_interior_stationary_points_exact_comparison';
      }
    }
  }
  const trueOptionIds = options.filter((_, i) => keys[i] !== null && keys[i] === expected).map(o => o.id), selectedOptionId = trueOptionIds.length === 1 ? trueOptionIds[0] : null;
  if (!selectedOptionId || selectedOptionId !== candidate.correctAnswer) reasonCodes.push('derivative_application_oracle_answer_disagreement');
  return { oracleVersion: DERIVATIVE_APPLICATION_ORACLE_VERSION, status: reasonCodes.length ? (model ? 'disagreed' as const : 'unparsed' as const) : 'verified' as const,
    scopeMatched: Boolean(model), scopeId: model ? 'math-medium-derivative-application-v1:' + scope : null, exactScope: scope,
    selectedOptionId, trueOptionIds, uniqueAnswer: trueOptionIds.length === 1, certificate, criticalPoints, candidateValues, signPartition, completeCertificate: Boolean(model),
    providerImpact: 'none_no_provider_call' as const, productionGateImpact: 'none_shadow_only' as const, reasonCodes };
}
export type SubjectPracticeMathDerivativeApplicationOracleEvidence = ReturnType<typeof verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle>;
