import { createHash } from 'node:crypto';

export const SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION = 'subject-practice-scenario-contract-v1';
export const SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION_V1 =
  'subject-practice-scenario-diversity-shadow-v1';
export const SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION =
  'subject-practice-scenario-diversity-shadow-v3-newton-force-evidence';

export type SubjectPracticeScenarioMode =
  | 'abstract'
  | 'real_world'
  | 'experimental'
  | 'hypothetical'
  | 'not_applicable';

export type SubjectPracticeScenarioContextNecessity =
  | 'required_for_solution'
  | 'decorative'
  | 'not_applicable';

export type SubjectPracticeScenarioContract = {
  schemaVersion: typeof SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION;
  policyVersion: typeof SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION;
  stage: 'shadow_only_thresholds_not_frozen';
  scenarioMode: SubjectPracticeScenarioMode;
  scenarioFamilyId: string;
  scenarioDomain: string;
  scenarioEntity: string;
  scenarioAction: string;
  informationForm: string;
  scenarioFingerprint: string;
  contextNecessity: SubjectPracticeScenarioContextNecessity;
  requiredInformationFields: string[];
  solverRelevantFields: string[];
  surface: {
    zhEntity: string;
    enEntity: string;
    zhSetting: string;
    enSetting: string;
    cueTokens: string[];
  };
  plausibility: Record<string, unknown>;
  sourceIsolation: {
    officialQuestionContentUsed: false;
    reversibleSourceFieldsUsed: false;
    selectionBasis: 'controlled_catalog_and_sealed_ordinal_only';
  };
};

type ScenarioCatalogEntry = {
  scenarioMode: Exclude<SubjectPracticeScenarioMode, 'abstract' | 'not_applicable'>;
  scenarioFamilyId: string;
  scenarioDomain: string;
  scenarioEntity: string;
  informationForm: string;
  zhEntity: string;
  enEntity: string;
  zhSetting: string;
  enSetting: string;
  cueTokens: string[];
  allowedScopes?: string[];
};

const PHYSICS_SCENARIOS: ScenarioCatalogEntry[] = [
  { scenarioMode: 'experimental', scenarioFamilyId: 'physics_lab_cart_track', scenarioDomain: 'mechanics_laboratory', scenarioEntity: 'wheeled_vehicle', informationForm: 'numeric_text', zhEntity: '实验小车', enEntity: 'laboratory cart', zhSetting: '水平直轨实验', enSetting: 'a horizontal straight-track experiment', cueTokens: ['实验小车', 'laboratory cart'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'physics_warehouse_robot_aisle', scenarioDomain: 'warehouse_logistics', scenarioEntity: 'mobile_robot', informationForm: 'numeric_text', zhEntity: '搬运机器人', enEntity: 'warehouse robot', zhSetting: '仓库直线通道', enSetting: 'a straight warehouse aisle', cueTokens: ['搬运机器人', 'warehouse robot'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'physics_train_straight_segment', scenarioDomain: 'rail_transport', scenarioEntity: 'rail_vehicle', informationForm: 'numeric_text', zhEntity: '列车', enEntity: 'train', zhSetting: '平直轨道区间', enSetting: 'a straight level track segment', cueTokens: ['列车', 'train'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'physics_elevator_vertical_shaft', scenarioDomain: 'building_transport', scenarioEntity: 'elevator_car', informationForm: 'numeric_text', zhEntity: '电梯轿厢', enEntity: 'elevator car', zhSetting: '竖直井道', enSetting: 'a vertical shaft', cueTokens: ['电梯轿厢', 'elevator car'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'physics_athlete_straight_track', scenarioDomain: 'sports_motion', scenarioEntity: 'athlete', informationForm: 'numeric_text', zhEntity: '运动员', enEntity: 'athlete', zhSetting: '直线跑道', enSetting: 'a straight running track', cueTokens: ['运动员', 'athlete'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'physics_drone_straight_route', scenarioDomain: 'aviation_motion', scenarioEntity: 'drone', informationForm: 'numeric_text', zhEntity: '无人机', enEntity: 'drone', zhSetting: '无风直线路段', enSetting: 'a windless straight route', cueTokens: ['无人机', 'drone'] }
];

const PHYSICS_OPTICS_SCENARIOS: ScenarioCatalogEntry[] = [
  { scenarioMode: 'experimental', scenarioFamilyId: 'physics_optics_bench_screen', scenarioDomain: 'optics_laboratory', scenarioEntity: 'illuminated_object_and_screen', informationForm: 'numeric_text', zhEntity: '发光物体与光屏', enEntity: 'illuminated object and screen', zhSetting: '光具座成像实验', enSetting: 'an optical-bench imaging experiment', cueTokens: ['光具座成像实验', 'optical-bench imaging experiment'], allowedScopes: ['convex_lens_image_distance_and_nature', 'convex_lens_magnification'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'physics_camera_focus_model', scenarioDomain: 'imaging_system', scenarioEntity: 'camera_lens_and_sensor', informationForm: 'numeric_text', zhEntity: '相机镜头与感光面', enEntity: 'camera lens and sensor', zhSetting: '简化相机调焦模型', enSetting: 'a simplified camera-focusing model', cueTokens: ['简化相机调焦模型', 'simplified camera-focusing model'], allowedScopes: ['convex_lens_image_distance_and_nature', 'convex_lens_magnification'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'physics_projector_lens_model', scenarioDomain: 'projection_system', scenarioEntity: 'projector_lens_and_screen', informationForm: 'numeric_text', zhEntity: '投影镜头与屏幕', enEntity: 'projector lens and screen', zhSetting: '简化投影成像模型', enSetting: 'a simplified projection-imaging model', cueTokens: ['简化投影成像模型', 'simplified projection-imaging model'], allowedScopes: ['convex_lens_image_distance_and_nature', 'convex_lens_magnification'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'physics_refraction_tank', scenarioDomain: 'optics_laboratory', scenarioEntity: 'light_ray_and_transparent_medium', informationForm: 'numeric_text', zhEntity: '光线与透明介质', enEntity: 'light ray and transparent medium', zhSetting: '透明介质折射实验', enSetting: 'a transparent-medium refraction experiment', cueTokens: ['透明介质折射实验', 'transparent-medium refraction experiment'], allowedScopes: ['refraction_angle_and_direction'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'physics_optical_fiber_interface', scenarioDomain: 'optical_communication', scenarioEntity: 'light_ray_at_interface', informationForm: 'numeric_text', zhEntity: '界面处光线', enEntity: 'light ray at an interface', zhSetting: '光通信界面模型', enSetting: 'an optical-communication interface model', cueTokens: ['光通信界面模型', 'optical-communication interface model'], allowedScopes: ['refraction_angle_and_direction'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'physics_refractometer_cell', scenarioDomain: 'instrument_measurement', scenarioEntity: 'probe_light_ray', informationForm: 'numeric_text', zhEntity: '探测光线', enEntity: 'probe light ray', zhSetting: '折射率测量池', enSetting: 'a refractive-index measurement cell', cueTokens: ['折射率测量池', 'refractive-index measurement cell'], allowedScopes: ['refraction_angle_and_direction'] }
];

const CHEMISTRY_SCENARIOS: ScenarioCatalogEntry[] = [
  { scenarioMode: 'experimental', scenarioFamilyId: 'chemistry_lab_solution_dilution', scenarioDomain: 'chemistry_laboratory', scenarioEntity: 'reagent_solution', informationForm: 'numeric_procedure_text', zhEntity: '试剂溶液', enEntity: 'reagent solution', zhSetting: '实验室稀释操作', enSetting: 'a laboratory dilution', cueTokens: ['试剂溶液', 'reagent solution'], allowedScopes: ['strong_acid_dilution', 'strong_base_dilution'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'chemistry_quality_control_dilution', scenarioDomain: 'quality_control', scenarioEntity: 'quality_control_sample', informationForm: 'numeric_procedure_text', zhEntity: '质控样品', enEntity: 'quality-control sample', zhSetting: '浓度复核前的定量稀释', enSetting: 'a quantitative dilution before concentration verification', cueTokens: ['质控样品', 'quality-control sample'], allowedScopes: ['strong_acid_dilution', 'strong_base_dilution'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'chemistry_calibration_solution', scenarioDomain: 'instrument_calibration', scenarioEntity: 'calibration_solution', informationForm: 'numeric_procedure_text', zhEntity: '校准溶液', enEntity: 'calibration solution', zhSetting: '酸碱检测仪校准', enSetting: 'acid-base meter calibration', cueTokens: ['校准溶液', 'calibration solution'], allowedScopes: ['strong_acid_dilution', 'strong_base_dilution'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'chemistry_lab_neutralization_test', scenarioDomain: 'chemistry_laboratory', scenarioEntity: 'acid_base_aliquots', informationForm: 'numeric_procedure_text', zhEntity: '酸碱试样', enEntity: 'acid and base aliquots', zhSetting: '实验室定量混合', enSetting: 'a quantitative laboratory mixing test', cueTokens: ['酸碱试样', 'acid and base aliquots'], allowedScopes: ['strong_acid_base_neutralization'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'chemistry_wastewater_bench_neutralization', scenarioDomain: 'environmental_treatment', scenarioEntity: 'simulated_wastewater_sample', informationForm: 'numeric_procedure_text', zhEntity: '模拟废水样品', enEntity: 'simulated wastewater sample', zhSetting: '小试中和处理', enSetting: 'a bench-scale neutralization treatment', cueTokens: ['模拟废水样品', 'simulated wastewater sample'], allowedScopes: ['strong_acid_base_neutralization'] },
  { scenarioMode: 'real_world', scenarioFamilyId: 'chemistry_process_neutralization_check', scenarioDomain: 'process_quality_control', scenarioEntity: 'process_sample', informationForm: 'numeric_procedure_text', zhEntity: '工艺样品', enEntity: 'process sample', zhSetting: '中和后酸碱性复核', enSetting: 'an acid-base check after neutralization', cueTokens: ['工艺样品', 'process sample'], allowedScopes: ['strong_acid_base_neutralization'] }
];

const CHEMISTRY_PH_OPERATION_ERROR_SCENARIOS: ScenarioCatalogEntry[] = [
  { scenarioMode: 'experimental', scenarioFamilyId: 'chemistry_ph_paper_training', scenarioDomain: 'chemistry_laboratory', scenarioEntity: 'acid_base_sample', informationForm: 'qualitative_procedure_text', zhEntity: '酸碱试样', enEntity: 'acid-base sample', zhSetting: 'pH 试纸操作训练', enSetting: 'pH-paper procedure training', cueTokens: ['pH 试纸操作训练', 'pH-paper procedure training'], allowedScopes: ['ph_paper_wetting_acid', 'ph_paper_wetting_base'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'chemistry_ph_paper_quality_check', scenarioDomain: 'quality_control', scenarioEntity: 'quality_control_sample', informationForm: 'qualitative_procedure_text', zhEntity: '质控试样', enEntity: 'quality-control sample', zhSetting: '酸碱样品复核', enSetting: 'an acid-base sample verification', cueTokens: ['酸碱样品复核', 'acid-base sample verification'], allowedScopes: ['ph_paper_wetting_acid', 'ph_paper_wetting_base'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'chemistry_volumetric_flask_training', scenarioDomain: 'chemistry_laboratory', scenarioEntity: 'prepared_solution', informationForm: 'qualitative_procedure_text', zhEntity: '待配溶液', enEntity: 'solution being prepared', zhSetting: '容量瓶操作训练', enSetting: 'volumetric-flask procedure training', cueTokens: ['容量瓶操作训练', 'volumetric-flask procedure training'], allowedScopes: ['volumetric_overfill_acid', 'volumetric_overfill_base', 'volumetric_underfill_acid', 'volumetric_underfill_base'] },
  { scenarioMode: 'experimental', scenarioFamilyId: 'chemistry_standard_solution_check', scenarioDomain: 'quality_control', scenarioEntity: 'standard_solution', informationForm: 'qualitative_procedure_text', zhEntity: '标准溶液', enEntity: 'standard solution', zhSetting: '标准溶液配制复核', enSetting: 'a standard-solution preparation check', cueTokens: ['标准溶液配制复核', 'standard-solution preparation check'], allowedScopes: ['volumetric_overfill_acid', 'volumetric_overfill_base', 'volumetric_underfill_acid', 'volumetric_underfill_base'] }
];

const ENTITY_SYNONYMS: Record<string, string> = {
  '汽车': 'wheeled_vehicle', '小车': 'wheeled_vehicle', '车辆': 'wheeled_vehicle', '实验小车': 'wheeled_vehicle',
  car: 'wheeled_vehicle', cart: 'wheeled_vehicle', automobile: 'wheeled_vehicle', vehicle: 'wheeled_vehicle',
  'laboratory cart': 'wheeled_vehicle', laboratory_cart: 'wheeled_vehicle', wheeled_vehicle: 'wheeled_vehicle'
};

function clean(value: unknown) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
}

function sameStringArray(actual: unknown, expected: string[]) {
  return Array.isArray(actual)
    && actual.length === expected.length
    && actual.every((value, index) => clean(value) === clean(expected[index]));
}

function normalizedRecord(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(normalizedRecord);
  const record = recordFrom(value);
  if (!record) return typeof value === 'string' ? clean(value) : value;
  return Object.fromEntries(Object.keys(record).sort().map((key) => [key, normalizedRecord(record[key])]));
}

function sameRecord(actual: unknown, expected: unknown) {
  return JSON.stringify(normalizedRecord(actual)) === JSON.stringify(normalizedRecord(expected));
}

function normalizedSeed(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.abs(Math.trunc(number)) : 0;
}

function canonicalToken(value: unknown) {
  const cleaned = clean(value)
    .replace(/\d+(?:\.\d+)?/g, '#')
    .replace(/\b(?:km\/h|m\/s(?:\^?2)?|mol\/l|mmol\/l|ml|kg|km|cm|mm|g|s|m|l)\b/gi, 'unit')
    .replace(/[#_\-\s]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return ENTITY_SYNONYMS[clean(value)] ?? ENTITY_SYNONYMS[cleaned] ?? cleaned;
}

export function subjectPracticeScenarioFingerprintFor(input: {
  scenarioDomain?: unknown;
  scenarioEntity?: unknown;
  scenarioAction?: unknown;
  informationForm?: unknown;
}) {
  const canonical = [
    canonicalToken(input.scenarioDomain),
    canonicalToken(input.scenarioEntity),
    canonicalToken(input.scenarioAction),
    canonicalToken(input.informationForm)
  ].join('|');
  return `scenario-${createHash('sha256').update(canonical).digest('hex').slice(0, 20)}`;
}

function contractFromEntry(entry: ScenarioCatalogEntry, scenarioAction: string): SubjectPracticeScenarioContract {
  const phOperationError = /^(?:ph_paper_wetting|volumetric_(?:overfill|underfill))_(?:acid|base)$/.test(scenarioAction);
  const optics = /^(?:convex_lens_|refraction_)/.test(scenarioAction);
  const requiredInformationFields = phOperationError
    ? ['scenarioAction', 'acid_or_base_character', 'single_operation_deviation']
    : optics
      ? ['scenarioAction', 'text_complete_optical_setup', 'two_linked_optical_relations']
    : ['scenarioAction', 'motion_or_reaction_condition', 'quantities_with_units'];
  return {
    schemaVersion: SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION,
    policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
    stage: 'shadow_only_thresholds_not_frozen',
    scenarioMode: entry.scenarioMode,
    scenarioFamilyId: entry.scenarioFamilyId,
    scenarioDomain: entry.scenarioDomain,
    scenarioEntity: entry.scenarioEntity,
    scenarioAction,
    informationForm: entry.informationForm,
    scenarioFingerprint: subjectPracticeScenarioFingerprintFor({ ...entry, scenarioAction }),
    contextNecessity: 'required_for_solution',
    requiredInformationFields,
    solverRelevantFields: [...requiredInformationFields],
    surface: {
      zhEntity: entry.zhEntity,
      enEntity: entry.enEntity,
      zhSetting: entry.zhSetting,
      enSetting: entry.enSetting,
      cueTokens: entry.cueTokens
    },
    plausibility: phOperationError
      ? { singleOperationError: true, numericPhCalculationForbidden: true, acidBaseCharacterExplicit: true }
      : optics
        ? { textCompleteOpticalSetup: true, unseenDiagramForbidden: true, physicallyValidOpticalRegion: true }
      : entry.scenarioDomain.includes('chemistry') || entry.scenarioFamilyId.startsWith('chemistry_')
      ? { temperatureC: 25, completeDissociationOnly: true, visibleConcentrationAndVolumeUnits: true }
      : { straightLineMotion: true, siUnitsRequired: true, signedVelocityAndAccelerationAllowed: true },
    sourceIsolation: {
      officialQuestionContentUsed: false,
      reversibleSourceFieldsUsed: false,
      selectionBasis: 'controlled_catalog_and_sealed_ordinal_only'
    }
  };
}

export function subjectPracticeScenarioContractFor(input: {
  subject?: unknown;
  taskFamily?: unknown;
  planTemplate?: unknown;
  exactScope?: unknown;
  seed?: unknown;
  scenarioFamilyId?: unknown;
}): SubjectPracticeScenarioContract | null {
  const subject = clean(input.subject);
  const taskFamily = clean(input.taskFamily);
  const planTemplate = clean(input.planTemplate);
  const exactScope = clean(input.exactScope) || 'unspecified_scope';
  const seed = normalizedSeed(input.seed);
  if ((taskFamily==="math_normal_distribution_constraint_reasoning" || planTemplate==="math_normal_distribution_constraint_reasoning_v1")
    && (input.subject!=='math' || input.taskFamily!=="math_normal_distribution_constraint_reasoning" || input.planTemplate!=="math_normal_distribution_constraint_reasoning_v1"
      || input.exactScope!==exactScope || !["two_standardized_positions_interval_probability","affine_absolute_value_interval_probability","interval_union_difference_probability","empirical_affine_two_tail_threshold_combination"].includes(exactScope))) return null; else if ((taskFamily==="math_descriptive_statistics_constraint_reasoning" || planTemplate==="math_descriptive_statistics_constraint_reasoning_v1")
    && (input.subject!=='math' || input.taskFamily!=="math_descriptive_statistics_constraint_reasoning" || input.planTemplate!=="math_descriptive_statistics_constraint_reasoning_v1"
      || input.exactScope!==exactScope || !["two_missing_values_moments_order_replacement_variance","three_missing_frequencies_moments_trimmed_variance","two_group_moments_order_reweighted_mean","affine_moments_sign_threshold_subset_variance"].includes(exactScope))) return null; else if ((taskFamily==="math_classical_probability_constraint_reasoning" || planTemplate==="math_classical_probability_constraint_reasoning_v1")
    && (input.subject!=='math' || input.taskFamily!=="math_classical_probability_constraint_reasoning" || input.planTemplate!=="math_classical_probability_constraint_reasoning_v1"
      || input.exactScope!==exactScope || !["without_replacement_nonadjacent_target_count","without_replacement_all_colors_distinct_endpoints","independent_boxes_three_red_each_box_nonempty","numbered_cards_odd_sum_window_and_span"].includes(exactScope))) return null; else if ((taskFamily==="math_solid_geometry_constraint_reasoning" || planTemplate==="math_solid_geometry_constraint_reasoning_v1")
    && (input.subject!=='math' || input.taskFamily!=="math_solid_geometry_constraint_reasoning" || input.planTemplate!=="math_solid_geometry_constraint_reasoning_v1"
      || input.exactScope!==exactScope || !["cuboid_face_diagonals_division_point_plane_distance_squared","cuboid_volume_face_areas_skew_lines_cosine_squared","rectangular_pyramid_lateral_edge_section_plane_cosine_squared","cone_two_sections_frustum_total_surface_area"].includes(exactScope))) return null; else if ((taskFamily==="math_vector_complex_constraint_reasoning" || planTemplate==="math_vector_complex_constraint_reasoning_v1")
    && (input.subject!=='math' || input.taskFamily!=="math_vector_complex_constraint_reasoning" || input.planTemplate!=="math_vector_complex_constraint_reasoning_v1"
      || input.exactScope!==exactScope || !["vector_gram_constraints_linear_combination_norm_squared","vector_angle_interval_parameter_combination_norm_squared","complex_two_moduli_real_constraint_quotient_norm_squared","complex_unit_modulus_real_constraint_cubic_reciprocal_real_part"].includes(exactScope))) return null;
  if ((taskFamily==='math_plane_analytic_geometry_constraint_reasoning'||planTemplate==='math_plane_analytic_geometry_constraint_reasoning_v1')&&(subject!=='math'||taskFamily!=='math_plane_analytic_geometry_constraint_reasoning'||planTemplate!=='math_plane_analytic_geometry_constraint_reasoning_v1'||!["circle_center_line_two_points_tangent_length_squared","diameter_circle_secant_intersection_triangle_area_squared","circle_line_pencil_chord_parameter_square_sum","external_point_tangency_points_distance_squared_sum"].includes(exactScope))) return null; else if ((taskFamily==='math_sequence_constraint_reasoning'||planTemplate==='math_sequence_constraint_reasoning_v1')&&(subject!=='math'||taskFamily!=='math_sequence_constraint_reasoning'||planTemplate!=='math_sequence_constraint_reasoning_v1'||!["arithmetic_term_sum_positive_window_sum","arithmetic_two_terms_partial_sum_threshold_index","geometric_two_terms_partial_sum_threshold_index","affine_recurrence_two_terms_partial_sum"].includes(exactScope))) return null; else if ((taskFamily==='math_derivative_constraint_reasoning'||planTemplate==='math_derivative_constraint_reasoning_v1')&&(subject!=='math'||taskFamily!=='math_derivative_constraint_reasoning'||planTemplate!=='math_derivative_constraint_reasoning_v1'||!["cubic_tangent_constraint_closed_interval_extremum","cubic_two_interval_monotonic_parameter_range","cubic_level_equation_closed_interval_root_count","cubic_extrema_gap_point_constraint_tangent_line"].includes(exactScope))) return null; else if ((taskFamily==='math_elementary_exp_log_constraint_reasoning'||planTemplate==='math_elementary_exp_log_constraint_reasoning_v1')&&(subject!=='math'||taskFamily!=='math_elementary_exp_log_constraint_reasoning'||planTemplate!=='math_elementary_exp_log_constraint_reasoning_v1'||!["exponential_substitution_rational_inequality","logarithmic_difference_domain_inequality","exponential_quadratic_closed_interval_range","nested_logarithm_rational_domain_intersection"].includes(exactScope))) return null; else if ((taskFamily==='math_function_composition_piecewise_reasoning'||planTemplate==='math_function_composition_piecewise_reasoning_v1')&&(subject!=='math'||taskFamily!=='math_function_composition_piecewise_reasoning'||planTemplate!=='math_function_composition_piecewise_reasoning_v1'||!["quadratic_composition_closed_interval_range","piecewise_quadratic_interval_range","restricted_quadratic_inverse_fraction_domain","piecewise_affine_monotonic_parameter"].includes(exactScope)))return null;
  if ((taskFamily==='math_compound_inequality_constraint_reasoning'||planTemplate==='math_compound_inequality_constraint_reasoning_v1')&&(subject!=='math'||taskFamily!=='math_compound_inequality_constraint_reasoning'||planTemplate!=='math_compound_inequality_constraint_reasoning_v1'||!["quadratic_and_fraction_conjunction","absolute_band_and_fraction_conjunction","quadratic_domain_implies_absolute_bound","fraction_domain_implies_absolute_separation"].includes(exactScope)))return null;
  if ((taskFamily==='math_interval_set_parameter_reasoning'||planTemplate==='math_interval_set_parameter_reasoning_v1')&&(subject!=='math'||taskFamily!=='math_interval_set_parameter_reasoning'||planTemplate!=='math_interval_set_parameter_reasoning_v1'||!['translated_interval_subset_two_component_union','translated_interval_disjoint_two_component_union','translated_interval_meets_relative_complement','translated_interval_union_covers_target'].includes(exactScope)))return null;
  if ((taskFamily === 'math_normal_distribution_two_step_reasoning' || planTemplate === 'math_normal_distribution_two_step_reasoning_v1')
    && (subject !== 'math' || taskFamily !== 'math_normal_distribution_two_step_reasoning' || planTemplate !== 'math_normal_distribution_two_step_reasoning_v1'
      || !["standardized_interval_from_cdf_values","symmetric_interval_from_one_tail_probability","empirical_asymmetric_interval_probability","empirical_tail_probability_to_threshold"].includes(exactScope))) return null;
  if ((taskFamily === 'math_descriptive_statistics_two_step_calculation' || planTemplate === 'math_descriptive_statistics_two_step_calculation_v1')
    && (subject !== 'math' || taskFamily !== 'math_descriptive_statistics_two_step_calculation' || planTemplate !== 'math_descriptive_statistics_two_step_calculation_v1'
      || !['missing_value_from_mean_to_population_variance', 'missing_frequency_from_total_to_weighted_mean',
        'missing_frequency_from_mean_to_population_variance', 'affine_mean_constraint_to_population_variance'].includes(exactScope))) return null;
  if ((taskFamily === 'math_classical_probability_two_stage_calculation' || planTemplate === 'math_classical_probability_two_stage_calculation_v1')
    && (subject !== 'math' || taskFamily !== 'math_classical_probability_two_stage_calculation' || planTemplate !== 'math_classical_probability_two_stage_calculation_v1')) return null;
  if ((taskFamily === 'math_solid_geometry_two_step_calculation' || planTemplate === 'math_solid_geometry_two_step_calculation_v1')
    && (subject !== 'math' || taskFamily !== 'math_solid_geometry_two_step_calculation' || planTemplate !== 'math_solid_geometry_two_step_calculation_v1')) return null;
  if ((taskFamily === 'math_vector_complex_two_step_calculation' || planTemplate === 'math_vector_complex_two_step_calculation_v1')
    && (subject !== 'math' || taskFamily !== 'math_vector_complex_two_step_calculation' || planTemplate !== 'math_vector_complex_two_step_calculation_v1')) return null;
  if ((taskFamily === 'math_plane_analytic_geometry_relation' || planTemplate === 'math_plane_analytic_geometry_relation_v1')
    && (subject !== 'math' || taskFamily !== 'math_plane_analytic_geometry_relation' || planTemplate !== 'math_plane_analytic_geometry_relation_v1')) return null;
  if ((taskFamily === 'math_polynomial_derivative_application' || planTemplate === 'math_polynomial_derivative_application_v1')
    && (subject !== 'math' || taskFamily !== 'math_polynomial_derivative_application' || planTemplate !== 'math_polynomial_derivative_application_v1')) return null;
  if ((taskFamily === 'math_elementary_exp_log_relation_reasoning' || planTemplate === 'math_elementary_exp_log_relation_reasoning_v1')
    && (subject !== 'math' || taskFamily !== 'math_elementary_exp_log_relation_reasoning' || planTemplate !== 'math_elementary_exp_log_relation_reasoning_v1')) return null;
  if ((taskFamily === 'math_function_interval_property_reasoning' || planTemplate === 'math_function_interval_property_reasoning_v1')
    && (subject !== 'math' || taskFamily !== 'math_function_interval_property_reasoning' || planTemplate !== 'math_function_interval_property_reasoning_v1')) return null;
  if ((taskFamily === 'math_quadratic_rational_inequality_solution' || planTemplate === 'math_quadratic_rational_inequality_solution_v1')
    && (subject !== 'math' || taskFamily !== 'math_quadratic_rational_inequality_solution' || planTemplate !== 'math_quadratic_rational_inequality_solution_v1')) return null;
  if (subject==='math'&&taskFamily==='math_normal_distribution_constraint_reasoning'&&planTemplate==='math_normal_distribution_constraint_reasoning_v1') {
    const scenarioEntity = taskFamily==='math_normal_distribution_constraint_reasoning'?'normal_distribution_constraint_system':taskFamily==='math_solid_geometry_constraint_reasoning'?'solid_geometry_constraint_system':taskFamily==='math_vector_complex_constraint_reasoning'?'vector_complex_constraint_system':taskFamily==='math_plane_analytic_geometry_constraint_reasoning'?'plane_analytic_geometry_constraint_system':taskFamily==='math_sequence_constraint_reasoning'?'sequence_constraint_system':taskFamily==='math_elementary_exp_log_constraint_reasoning'?'elementary_exp_log_constraint_system':taskFamily==='math_function_composition_piecewise_reasoning'?'function_composition_piecewise_system':taskFamily==='math_compound_inequality_constraint_reasoning'?'compound_inequality_constraint_system':taskFamily==='math_interval_set_parameter_reasoning'?'parameterized_interval_set_system': taskFamily === 'math_normal_distribution_two_step_reasoning' ? 'normal_distribution_object' : taskFamily === 'math_descriptive_statistics_two_step_calculation' ? 'bounded_two_step_statistics_object' : taskFamily === 'math_classical_probability_two_stage_calculation' ? 'finite_two_stage_probability_experiment' : taskFamily === 'math_solid_geometry_two_step_calculation' ? 'solid_geometry_two_step_object' : taskFamily === 'math_vector_complex_two_step_calculation' ? 'vector_or_complex_two_step_object' : taskFamily === 'math_plane_analytic_geometry_relation' ? 'plane_line_circle_object' : taskFamily === 'math_polynomial_derivative_application' ? 'polynomial_derivative_object' : taskFamily === 'math_elementary_exp_log_relation_reasoning' ? 'elementary_exp_log_object' : taskFamily === 'math_function_interval_property_reasoning' ? 'function_interval_object' : taskFamily === 'math_quadratic_rational_inequality_solution' ? 'inequality_sign_chart_object' : taskFamily === 'math_line_relation_direct'
      ? 'line_object'
      : ['math_finite_set_operation', 'math_finite_set_composite_operation'].includes(taskFamily)
        ? 'finite_set_object'
      : taskFamily === 'math_linear_inequality_solution'
        ? 'linear_inequality_object'
      : taskFamily === 'math_basic_function_property'
        ? 'function_object'
      : ['math_basic_sequence_direct_calculation', 'math_sequence_two_condition_calculation'].includes(taskFamily)
        ? 'sequence_object'
      : taskFamily === 'math_vector_complex_direct_calculation'
        ? 'vector_or_complex_object'
      : taskFamily === 'math_classical_probability_basic_calculation'
        ? 'finite_random_experiment'
      : taskFamily === 'math_solid_geometry_direct_calculation'
        ? 'simple_solid_object'
      : taskFamily === 'math_descriptive_statistics_direct_calculation'
        ? 'bounded_dataset_object'
      : taskFamily === 'math_normal_distribution_basic_concepts'
        ? 'normal_distribution_object'
      : taskFamily === 'derivative_direct_evaluation'
        ? 'derivative_function_object'
        : 'function_object';
    const scenarioAction = exactScope;
    return {
      schemaVersion: SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION,
      policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
      stage: 'shadow_only_thresholds_not_frozen',
      scenarioMode: 'abstract',
      scenarioFamilyId: `math_abstract_${scenarioEntity}`,
      scenarioDomain: 'pure_mathematics',
      scenarioEntity,
      scenarioAction,
      informationForm: 'symbolic_text',
      scenarioFingerprint: subjectPracticeScenarioFingerprintFor({
        scenarioDomain: 'pure_mathematics', scenarioEntity, scenarioAction, informationForm: 'symbolic_text'
      }),
      contextNecessity: 'not_applicable',
      requiredInformationFields: [],
      solverRelevantFields: [],
      surface: { zhEntity: '', enEntity: '', zhSetting: '', enSetting: '', cueTokens: [] },
      plausibility: { externalContextForbidden: true },
      sourceIsolation: {
        officialQuestionContentUsed: false,
        reversibleSourceFieldsUsed: false,
        selectionBasis: 'controlled_catalog_and_sealed_ordinal_only'
      }
    };
  } else if (subject==='math'&&taskFamily==='math_descriptive_statistics_constraint_reasoning'&&planTemplate==='math_descriptive_statistics_constraint_reasoning_v1') {
    const scenarioEntity = taskFamily==='math_descriptive_statistics_constraint_reasoning'?'statistics_constraint_system':taskFamily==='math_solid_geometry_constraint_reasoning'?'solid_geometry_constraint_system':taskFamily==='math_vector_complex_constraint_reasoning'?'vector_complex_constraint_system':taskFamily==='math_plane_analytic_geometry_constraint_reasoning'?'plane_analytic_geometry_constraint_system':taskFamily==='math_sequence_constraint_reasoning'?'sequence_constraint_system':taskFamily==='math_elementary_exp_log_constraint_reasoning'?'elementary_exp_log_constraint_system':taskFamily==='math_function_composition_piecewise_reasoning'?'function_composition_piecewise_system':taskFamily==='math_compound_inequality_constraint_reasoning'?'compound_inequality_constraint_system':taskFamily==='math_interval_set_parameter_reasoning'?'parameterized_interval_set_system': taskFamily === 'math_normal_distribution_two_step_reasoning' ? 'normal_distribution_object' : taskFamily === 'math_descriptive_statistics_two_step_calculation' ? 'bounded_two_step_statistics_object' : taskFamily === 'math_classical_probability_two_stage_calculation' ? 'finite_two_stage_probability_experiment' : taskFamily === 'math_solid_geometry_two_step_calculation' ? 'solid_geometry_two_step_object' : taskFamily === 'math_vector_complex_two_step_calculation' ? 'vector_or_complex_two_step_object' : taskFamily === 'math_plane_analytic_geometry_relation' ? 'plane_line_circle_object' : taskFamily === 'math_polynomial_derivative_application' ? 'polynomial_derivative_object' : taskFamily === 'math_elementary_exp_log_relation_reasoning' ? 'elementary_exp_log_object' : taskFamily === 'math_function_interval_property_reasoning' ? 'function_interval_object' : taskFamily === 'math_quadratic_rational_inequality_solution' ? 'inequality_sign_chart_object' : taskFamily === 'math_line_relation_direct'
      ? 'line_object'
      : ['math_finite_set_operation', 'math_finite_set_composite_operation'].includes(taskFamily)
        ? 'finite_set_object'
      : taskFamily === 'math_linear_inequality_solution'
        ? 'linear_inequality_object'
      : taskFamily === 'math_basic_function_property'
        ? 'function_object'
      : ['math_basic_sequence_direct_calculation', 'math_sequence_two_condition_calculation'].includes(taskFamily)
        ? 'sequence_object'
      : taskFamily === 'math_vector_complex_direct_calculation'
        ? 'vector_or_complex_object'
      : taskFamily === 'math_classical_probability_basic_calculation'
        ? 'finite_random_experiment'
      : taskFamily === 'math_solid_geometry_direct_calculation'
        ? 'simple_solid_object'
      : taskFamily === 'math_descriptive_statistics_direct_calculation'
        ? 'bounded_dataset_object'
      : taskFamily === 'math_normal_distribution_basic_concepts'
        ? 'normal_distribution_object'
      : taskFamily === 'derivative_direct_evaluation'
        ? 'derivative_function_object'
        : 'function_object';
    const scenarioAction = exactScope;
    return {
      schemaVersion: SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION,
      policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
      stage: 'shadow_only_thresholds_not_frozen',
      scenarioMode: 'abstract',
      scenarioFamilyId: `math_abstract_${scenarioEntity}`,
      scenarioDomain: 'pure_mathematics',
      scenarioEntity,
      scenarioAction,
      informationForm: 'symbolic_text',
      scenarioFingerprint: subjectPracticeScenarioFingerprintFor({
        scenarioDomain: 'pure_mathematics', scenarioEntity, scenarioAction, informationForm: 'symbolic_text'
      }),
      contextNecessity: 'not_applicable',
      requiredInformationFields: [],
      solverRelevantFields: [],
      surface: { zhEntity: '', enEntity: '', zhSetting: '', enSetting: '', cueTokens: [] },
      plausibility: { externalContextForbidden: true },
      sourceIsolation: {
        officialQuestionContentUsed: false,
        reversibleSourceFieldsUsed: false,
        selectionBasis: 'controlled_catalog_and_sealed_ordinal_only'
      }
    };
  } else if (subject === 'math' && [
    'math_classical_probability_constraint_reasoning','math_solid_geometry_constraint_reasoning','math_vector_complex_constraint_reasoning','math_plane_analytic_geometry_constraint_reasoning',
'math_sequence_constraint_reasoning',
'math_elementary_exp_log_constraint_reasoning',
'math_function_composition_piecewise_reasoning',
    'math_compound_inequality_constraint_reasoning',
    'math_interval_set_parameter_reasoning',
    'math_normal_distribution_two_step_reasoning',
    'math_descriptive_statistics_two_step_calculation',
    'math_classical_probability_two_stage_calculation',
    'math_solid_geometry_two_step_calculation',
    'math_vector_complex_two_step_calculation',
    'math_function_interval_property_reasoning',
    'math_plane_analytic_geometry_relation',
    'math_polynomial_derivative_application',
    'math_elementary_exp_log_relation_reasoning',
    'math_quadratic_rational_inequality_solution',
    'elementary_function_direct_property', 'math_line_relation_direct', 'math_finite_set_operation', 'math_finite_set_composite_operation', 'math_basic_function_property',
    'math_linear_inequality_solution', 'math_basic_sequence_direct_calculation', 'math_sequence_two_condition_calculation', 'math_vector_complex_direct_calculation', 'math_classical_probability_basic_calculation', 'math_solid_geometry_direct_calculation', 'math_descriptive_statistics_direct_calculation', 'math_normal_distribution_basic_concepts', 'derivative_direct_evaluation'
  ].includes(taskFamily) && [
    'math_classical_probability_constraint_reasoning_v1','math_solid_geometry_constraint_reasoning_v1','math_vector_complex_constraint_reasoning_v1','math_plane_analytic_geometry_constraint_reasoning_v1',
'math_sequence_constraint_reasoning_v1',
'math_elementary_exp_log_constraint_reasoning_v1',
'math_function_composition_piecewise_reasoning_v1',
    'math_compound_inequality_constraint_reasoning_v1',
    'math_interval_set_parameter_reasoning_v1',
    'math_normal_distribution_two_step_reasoning_v1',
    'math_descriptive_statistics_two_step_calculation_v1',
    'math_classical_probability_two_stage_calculation_v1',
    'math_solid_geometry_two_step_calculation_v1',
    'math_vector_complex_two_step_calculation_v1',
    'math_function_interval_property_reasoning_v1',
    'math_plane_analytic_geometry_relation_v1',
    'math_polynomial_derivative_application_v1',
    'math_elementary_exp_log_relation_reasoning_v1',
    'math_quadratic_rational_inequality_solution_v1',
    'math_elementary_function_relation_v1', 'math_line_relation_direct_v1', 'math_finite_set_operation_v1', 'math_finite_set_composite_operation_v1', 'math_basic_function_property_v1',
    'math_linear_inequality_solution_v1', 'math_basic_sequence_direct_calculation_v1', 'math_sequence_two_condition_calculation_v1', 'math_vector_complex_direct_calculation_v1', 'math_classical_probability_basic_calculation_v1', 'math_solid_geometry_direct_calculation_v1', 'math_descriptive_statistics_direct_calculation_v1', 'math_normal_distribution_basic_concepts_v1', 'math_derivative_condition_chain_v1'
  ].includes(planTemplate)) {
    const scenarioEntity = taskFamily==='math_classical_probability_constraint_reasoning'?'finite_probability_constraint_experiment':taskFamily==='math_solid_geometry_constraint_reasoning'?'solid_geometry_constraint_system':taskFamily==='math_vector_complex_constraint_reasoning'?'vector_complex_constraint_system':taskFamily==='math_plane_analytic_geometry_constraint_reasoning'?'plane_analytic_geometry_constraint_system':taskFamily==='math_sequence_constraint_reasoning'?'sequence_constraint_system':taskFamily==='math_elementary_exp_log_constraint_reasoning'?'elementary_exp_log_constraint_system':taskFamily==='math_function_composition_piecewise_reasoning'?'function_composition_piecewise_system':taskFamily==='math_compound_inequality_constraint_reasoning'?'compound_inequality_constraint_system':taskFamily==='math_interval_set_parameter_reasoning'?'parameterized_interval_set_system': taskFamily === 'math_normal_distribution_two_step_reasoning' ? 'normal_distribution_object' : taskFamily === 'math_descriptive_statistics_two_step_calculation' ? 'bounded_two_step_statistics_object' : taskFamily === 'math_classical_probability_two_stage_calculation' ? 'finite_two_stage_probability_experiment' : taskFamily === 'math_solid_geometry_two_step_calculation' ? 'solid_geometry_two_step_object' : taskFamily === 'math_vector_complex_two_step_calculation' ? 'vector_or_complex_two_step_object' : taskFamily === 'math_plane_analytic_geometry_relation' ? 'plane_line_circle_object' : taskFamily === 'math_polynomial_derivative_application' ? 'polynomial_derivative_object' : taskFamily === 'math_elementary_exp_log_relation_reasoning' ? 'elementary_exp_log_object' : taskFamily === 'math_function_interval_property_reasoning' ? 'function_interval_object' : taskFamily === 'math_quadratic_rational_inequality_solution' ? 'inequality_sign_chart_object' : taskFamily === 'math_line_relation_direct'
      ? 'line_object'
      : ['math_finite_set_operation', 'math_finite_set_composite_operation'].includes(taskFamily)
        ? 'finite_set_object'
      : taskFamily === 'math_linear_inequality_solution'
        ? 'linear_inequality_object'
      : taskFamily === 'math_basic_function_property'
        ? 'function_object'
      : ['math_basic_sequence_direct_calculation', 'math_sequence_two_condition_calculation'].includes(taskFamily)
        ? 'sequence_object'
      : taskFamily === 'math_vector_complex_direct_calculation'
        ? 'vector_or_complex_object'
      : taskFamily === 'math_classical_probability_basic_calculation'
        ? 'finite_random_experiment'
      : taskFamily === 'math_solid_geometry_direct_calculation'
        ? 'simple_solid_object'
      : taskFamily === 'math_descriptive_statistics_direct_calculation'
        ? 'bounded_dataset_object'
      : taskFamily === 'math_normal_distribution_basic_concepts'
        ? 'normal_distribution_object'
      : taskFamily === 'derivative_direct_evaluation'
        ? 'derivative_function_object'
        : 'function_object';
    const scenarioAction = exactScope;
    return {
      schemaVersion: SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION,
      policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
      stage: 'shadow_only_thresholds_not_frozen',
      scenarioMode: 'abstract',
      scenarioFamilyId: `math_abstract_${scenarioEntity}`,
      scenarioDomain: 'pure_mathematics',
      scenarioEntity,
      scenarioAction,
      informationForm: 'symbolic_text',
      scenarioFingerprint: subjectPracticeScenarioFingerprintFor({
        scenarioDomain: 'pure_mathematics', scenarioEntity, scenarioAction, informationForm: 'symbolic_text'
      }),
      contextNecessity: 'not_applicable',
      requiredInformationFields: [],
      solverRelevantFields: [],
      surface: { zhEntity: '', enEntity: '', zhSetting: '', enSetting: '', cueTokens: [] },
      plausibility: { externalContextForbidden: true },
      sourceIsolation: {
        officialQuestionContentUsed: false,
        reversibleSourceFieldsUsed: false,
        selectionBasis: 'controlled_catalog_and_sealed_ordinal_only'
      }
    };
  } else if (subject === 'math' && [
    'math_classical_probability_constraint_reasoning','math_solid_geometry_constraint_reasoning','math_vector_complex_constraint_reasoning','math_plane_analytic_geometry_constraint_reasoning',
'math_sequence_constraint_reasoning',
    'math_derivative_constraint_reasoning',
'math_elementary_exp_log_constraint_reasoning',
'math_function_composition_piecewise_reasoning',
    'math_compound_inequality_constraint_reasoning',
    'math_interval_set_parameter_reasoning',
    'math_normal_distribution_two_step_reasoning',
    'math_descriptive_statistics_two_step_calculation',
    'math_classical_probability_two_stage_calculation',
    'math_solid_geometry_two_step_calculation',
    'math_vector_complex_two_step_calculation',
    'math_function_interval_property_reasoning',
    'math_plane_analytic_geometry_relation',
    'math_polynomial_derivative_application',
    'math_elementary_exp_log_relation_reasoning',
    'math_quadratic_rational_inequality_solution',
    'elementary_function_direct_property', 'math_line_relation_direct', 'math_finite_set_operation', 'math_finite_set_composite_operation', 'math_basic_function_property',
    'math_linear_inequality_solution', 'math_basic_sequence_direct_calculation', 'math_sequence_two_condition_calculation', 'math_vector_complex_direct_calculation', 'math_classical_probability_basic_calculation', 'math_solid_geometry_direct_calculation', 'math_descriptive_statistics_direct_calculation', 'math_normal_distribution_basic_concepts', 'derivative_direct_evaluation'
  ].includes(taskFamily) && [
    'math_classical_probability_constraint_reasoning_v1','math_solid_geometry_constraint_reasoning_v1','math_vector_complex_constraint_reasoning_v1','math_plane_analytic_geometry_constraint_reasoning_v1',
'math_sequence_constraint_reasoning_v1',
    'math_derivative_constraint_reasoning_v1',
'math_elementary_exp_log_constraint_reasoning_v1',
'math_function_composition_piecewise_reasoning_v1',
    'math_compound_inequality_constraint_reasoning_v1',
    'math_interval_set_parameter_reasoning_v1',
    'math_normal_distribution_two_step_reasoning_v1',
    'math_descriptive_statistics_two_step_calculation_v1',
    'math_classical_probability_two_stage_calculation_v1',
    'math_solid_geometry_two_step_calculation_v1',
    'math_vector_complex_two_step_calculation_v1',
    'math_function_interval_property_reasoning_v1',
    'math_plane_analytic_geometry_relation_v1',
    'math_polynomial_derivative_application_v1',
    'math_elementary_exp_log_relation_reasoning_v1',
    'math_quadratic_rational_inequality_solution_v1',
    'math_elementary_function_relation_v1', 'math_line_relation_direct_v1', 'math_finite_set_operation_v1', 'math_finite_set_composite_operation_v1', 'math_basic_function_property_v1',
    'math_linear_inequality_solution_v1', 'math_basic_sequence_direct_calculation_v1', 'math_sequence_two_condition_calculation_v1', 'math_vector_complex_direct_calculation_v1', 'math_classical_probability_basic_calculation_v1', 'math_solid_geometry_direct_calculation_v1', 'math_descriptive_statistics_direct_calculation_v1', 'math_normal_distribution_basic_concepts_v1', 'math_derivative_condition_chain_v1'
  ].includes(planTemplate)) {
    const scenarioEntity = taskFamily==='math_classical_probability_constraint_reasoning'?'finite_probability_constraint_experiment':taskFamily==='math_solid_geometry_constraint_reasoning'?'solid_geometry_constraint_system':taskFamily==='math_vector_complex_constraint_reasoning'?'vector_complex_constraint_system':taskFamily==='math_plane_analytic_geometry_constraint_reasoning'?'plane_analytic_geometry_constraint_system':taskFamily==='math_sequence_constraint_reasoning'?'sequence_constraint_system':taskFamily==='math_derivative_constraint_reasoning'?'derivative_constraint_system':taskFamily==='math_elementary_exp_log_constraint_reasoning'?'elementary_exp_log_constraint_system':taskFamily==='math_function_composition_piecewise_reasoning'?'function_composition_piecewise_system':taskFamily==='math_compound_inequality_constraint_reasoning'?'compound_inequality_constraint_system':taskFamily==='math_interval_set_parameter_reasoning'?'parameterized_interval_set_system': taskFamily === 'math_normal_distribution_two_step_reasoning' ? 'normal_distribution_object' : taskFamily === 'math_descriptive_statistics_two_step_calculation' ? 'bounded_two_step_statistics_object' : taskFamily === 'math_classical_probability_two_stage_calculation' ? 'finite_two_stage_probability_experiment' : taskFamily === 'math_solid_geometry_two_step_calculation' ? 'solid_geometry_two_step_object' : taskFamily === 'math_vector_complex_two_step_calculation' ? 'vector_or_complex_two_step_object' : taskFamily === 'math_plane_analytic_geometry_relation' ? 'plane_line_circle_object' : taskFamily === 'math_polynomial_derivative_application' ? 'polynomial_derivative_object' : taskFamily === 'math_elementary_exp_log_relation_reasoning' ? 'elementary_exp_log_object' : taskFamily === 'math_function_interval_property_reasoning' ? 'function_interval_object' : taskFamily === 'math_quadratic_rational_inequality_solution' ? 'inequality_sign_chart_object' : taskFamily === 'math_line_relation_direct'
      ? 'line_object'
      : ['math_finite_set_operation', 'math_finite_set_composite_operation'].includes(taskFamily)
        ? 'finite_set_object'
      : taskFamily === 'math_linear_inequality_solution'
        ? 'linear_inequality_object'
      : taskFamily === 'math_basic_function_property'
        ? 'function_object'
      : ['math_basic_sequence_direct_calculation', 'math_sequence_two_condition_calculation'].includes(taskFamily)
        ? 'sequence_object'
      : taskFamily === 'math_vector_complex_direct_calculation'
        ? 'vector_or_complex_object'
      : taskFamily === 'math_classical_probability_basic_calculation'
        ? 'finite_random_experiment'
      : taskFamily === 'math_solid_geometry_direct_calculation'
        ? 'simple_solid_object'
      : taskFamily === 'math_descriptive_statistics_direct_calculation'
        ? 'bounded_dataset_object'
      : taskFamily === 'math_normal_distribution_basic_concepts'
        ? 'normal_distribution_object'
      : taskFamily === 'derivative_direct_evaluation'
        ? 'derivative_function_object'
        : 'function_object';
    const scenarioAction = exactScope;
    return {
      schemaVersion: SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION,
      policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
      stage: 'shadow_only_thresholds_not_frozen',
      scenarioMode: 'abstract',
      scenarioFamilyId: `math_abstract_${scenarioEntity}`,
      scenarioDomain: 'pure_mathematics',
      scenarioEntity,
      scenarioAction,
      informationForm: 'symbolic_text',
      scenarioFingerprint: subjectPracticeScenarioFingerprintFor({
        scenarioDomain: 'pure_mathematics', scenarioEntity, scenarioAction, informationForm: 'symbolic_text'
      }),
      contextNecessity: 'not_applicable',
      requiredInformationFields: [],
      solverRelevantFields: [],
      surface: { zhEntity: '', enEntity: '', zhSetting: '', enSetting: '', cueTokens: [] },
      plausibility: { externalContextForbidden: true },
      sourceIsolation: {
        officialQuestionContentUsed: false,
        reversibleSourceFieldsUsed: false,
        selectionBasis: 'controlled_catalog_and_sealed_ordinal_only'
      }
    };
  }
  if (subject === 'physics'
    && taskFamily === 'kinematics_basic_direct_relation'
    && planTemplate === 'physics_kinematics_basic_relation_v1') {
    const requestedFamilyId = clean(input.scenarioFamilyId);
    const selected = requestedFamilyId
      ? PHYSICS_SCENARIOS.find((entry) => entry.scenarioFamilyId === requestedFamilyId)
      : PHYSICS_SCENARIOS[seed % PHYSICS_SCENARIOS.length];
    return selected ? contractFromEntry(selected, exactScope) : null;
  }
  if (subject === 'physics'
    && taskFamily === 'physics_newton_basic_force_calculation'
    && planTemplate === 'physics_newton_basic_force_calculation_v1') {
    const requestedFamilyId = clean(input.scenarioFamilyId);
    const selected = requestedFamilyId
      ? PHYSICS_SCENARIOS.find((entry) => entry.scenarioFamilyId === requestedFamilyId)
      : PHYSICS_SCENARIOS[seed % PHYSICS_SCENARIOS.length];
    return selected ? contractFromEntry(selected, exactScope) : null;
  }
  if (subject === 'physics'
    && taskFamily === 'waves_optics_interference_refraction'
    && planTemplate === 'physics_medium_optics_two_relation_v1') {
    const eligible = PHYSICS_OPTICS_SCENARIOS.filter((entry) => entry.allowedScopes?.includes(exactScope));
    if (!eligible.length) return null;
    const requestedFamilyId = clean(input.scenarioFamilyId);
    const selected = requestedFamilyId
      ? eligible.find((entry) => entry.scenarioFamilyId === requestedFamilyId)
      : eligible[seed % eligible.length];
    return selected ? contractFromEntry(selected, exactScope) : null;
  }
  if (subject === 'chemistry'
    && taskFamily === 'basic_ph_measurement_or_preparation_error_judgement'
    && planTemplate === 'basic_ph_measurement_preparation_error_v1') {
    const eligible = CHEMISTRY_PH_OPERATION_ERROR_SCENARIOS.filter((entry) => entry.allowedScopes?.includes(exactScope));
    if (!eligible.length) return null;
    const requestedFamilyId = clean(input.scenarioFamilyId);
    const selected = requestedFamilyId
      ? eligible.find((entry) => entry.scenarioFamilyId === requestedFamilyId)
      : eligible[seed % eligible.length];
    return selected ? contractFromEntry(selected, exactScope) : null;
  }
  if (subject === 'chemistry'
    && taskFamily === 'ph_dilution_strong_acid_base_neutralization'
    && planTemplate === 'chemistry_strong_acid_base_single_relation_v1') {
    const eligible = CHEMISTRY_SCENARIOS.filter((entry) => entry.allowedScopes?.includes(exactScope));
    if (!eligible.length) return null;
    const requestedFamilyId = clean(input.scenarioFamilyId);
    const selected = requestedFamilyId
      ? eligible.find((entry) => entry.scenarioFamilyId === requestedFamilyId)
      : eligible[seed % eligible.length];
    return selected ? contractFromEntry(selected, exactScope) : null;
  }
  return null;
}

export function validateSubjectPracticeScenarioContract(input: { questionPlan?: unknown }) {
  const plan = recordFrom(input.questionPlan);
  const contract = recordFrom(plan?.scenarioContract);
  const renderConstraints = recordFrom(plan?.renderConstraints);
  const template = clean(plan?.planTemplate);
  const expectedAction = template==='math_normal_distribution_constraint_reasoning_v1'?clean(renderConstraints?.exactNormalDistributionConstraintScope):template==='math_descriptive_statistics_constraint_reasoning_v1'?clean(renderConstraints?.exactStatisticsConstraintScope):template==='math_classical_probability_constraint_reasoning_v1'?clean(renderConstraints?.exactProbabilityConstraintScope):template==='math_solid_geometry_constraint_reasoning_v1'?clean(renderConstraints?.exactSolidGeometryConstraintScope):template==='math_vector_complex_constraint_reasoning_v1'?clean(renderConstraints?.exactVectorComplexConstraintScope):template==='math_plane_analytic_geometry_constraint_reasoning_v1'?clean(renderConstraints?.exactPlaneAnalyticGeometryConstraintScope):template==='math_sequence_constraint_reasoning_v1'?clean(renderConstraints?.exactSequenceConstraintScope):template==='math_derivative_constraint_reasoning_v1'?clean(renderConstraints?.exactDerivativeConstraintScope):template==='math_elementary_exp_log_constraint_reasoning_v1'?clean(renderConstraints?.exactElementaryExpLogConstraintScope):template==='math_function_composition_piecewise_reasoning_v1'?clean(renderConstraints?.exactFunctionCompositionScope):template==='math_compound_inequality_constraint_reasoning_v1'?clean(renderConstraints?.exactCompoundInequalityScope):template==='math_interval_set_parameter_reasoning_v1'?clean(renderConstraints?.exactIntervalSetParameterScope):template === 'math_normal_distribution_two_step_reasoning_v1' ? clean(renderConstraints?.exactNormalDistributionTwoStepScope) : template === 'math_descriptive_statistics_two_step_calculation_v1' ? clean(renderConstraints?.exactStatisticsTwoStepScope) : template === 'math_classical_probability_two_stage_calculation_v1' ? clean(renderConstraints?.exactProbabilityTwoStageScope) : template === 'math_solid_geometry_two_step_calculation_v1' ? clean(renderConstraints?.exactSolidGeometryTwoStepScope) : template === 'math_vector_complex_two_step_calculation_v1' ? clean(renderConstraints?.exactVectorComplexTwoStepScope) : template === 'math_plane_analytic_geometry_relation_v1' ? clean(renderConstraints?.exactPlaneAnalyticGeometryScope) : template === 'math_polynomial_derivative_application_v1' ? clean(renderConstraints?.exactDerivativeApplicationScope) : template === 'math_elementary_exp_log_relation_reasoning_v1' ? clean(renderConstraints?.exactElementaryExpLogScope) : template === 'math_function_interval_property_reasoning_v1' ? clean(renderConstraints?.exactFunctionIntervalScope) : template === 'math_line_relation_direct_v1'
    ? clean(renderConstraints?.exactLineRelationScope) || 'slope_from_two_distinct_points'
    : template === 'math_finite_set_operation_v1'
      ? clean(renderConstraints?.exactSetOperationScope) || 'finite_union'
    : template === 'math_finite_set_composite_operation_v1'
      ? clean(renderConstraints?.exactSetCompositeScope) || 'union_then_intersection'
    : template === 'math_basic_function_property_v1'
      ? clean(renderConstraints?.exactBasicFunctionScope) || 'linear_monotonicity'
    : template === 'math_linear_inequality_solution_v1'
      ? clean(renderConstraints?.exactInequalityScope) || 'linear_gt_positive'
    : template === 'math_quadratic_rational_inequality_solution_v1'
      ? clean(renderConstraints?.exactInequalitySignChartScope)
    : template === 'math_basic_sequence_direct_calculation_v1'
      ? clean(renderConstraints?.exactSequenceScope) || 'arithmetic_explicit_term'
    : template === 'math_sequence_two_condition_calculation_v1'
      ? clean(renderConstraints?.exactSequenceTwoConditionScope) || 'arithmetic_two_terms_target_term'
    : template === 'math_vector_complex_direct_calculation_v1'
      ? clean(renderConstraints?.exactVectorComplexScope) || 'vector_coordinate_addition'
    : template === 'math_classical_probability_basic_calculation_v1'
      ? clean(renderConstraints?.exactProbabilityScope) || 'colored_objects_single_draw'
    : template === 'math_solid_geometry_direct_calculation_v1'
      ? clean(renderConstraints?.exactSolidGeometryScope) || 'cuboid_volume'
    : template === 'math_normal_distribution_basic_concepts_v1'
      ? clean(renderConstraints?.exactNormalDistributionScope) || 'normal_parameter_identification'
    : template === 'math_descriptive_statistics_direct_calculation_v1'
      ? clean(renderConstraints?.exactStatisticsScope) || 'arithmetic_mean'
    : template === 'math_derivative_condition_chain_v1'
      ? clean(renderConstraints?.exactDerivativeScope) || 'direct_polynomial_value'
    : template === 'physics_kinematics_basic_relation_v1'
      ? clean(renderConstraints?.exactPhysicsKinematicsScope) || 'unspecified_scope'
    : template === 'physics_newton_basic_force_calculation_v1'
      ? clean(renderConstraints?.exactPhysicsNewtonForceScope) || 'unspecified_scope'
      : template === 'physics_medium_optics_two_relation_v1'
        ? clean(renderConstraints?.exactPhysicsOpticsScope) || 'unspecified_scope'
      : template === 'basic_ph_measurement_preparation_error_v1'
        ? clean(renderConstraints?.exactChemistryOperationErrorScope) || 'unspecified_scope'
      : template === 'chemistry_strong_acid_base_single_relation_v1'
        ? clean(renderConstraints?.exactChemistryRelationKind) || 'unspecified_scope'
        : template === 'math_elementary_function_relation_v1'
          ? [clean(renderConstraints?.requiredElementaryFunctionClass) || 'unspecified_function', clean(renderConstraints?.requiredSinglePropertyTarget) || 'unspecified_property'].join(':')
          : clean(contract?.scenarioAction);
  const expected = subjectPracticeScenarioContractFor({
    subject: plan?.subject,
    taskFamily: plan?.taskFamily,
    planTemplate: plan?.planTemplate,
    exactScope: expectedAction,
    scenarioFamilyId: contract?.scenarioFamilyId
  });
  const valid = Boolean(expected
    && contract?.schemaVersion === expected.schemaVersion
    && contract?.policyVersion === expected.policyVersion
    && contract?.stage === expected.stage
    && clean(contract?.scenarioMode) === expected.scenarioMode
    && clean(contract?.scenarioFamilyId) === expected.scenarioFamilyId
    && clean(contract?.scenarioDomain) === expected.scenarioDomain
    && clean(contract?.scenarioEntity) === expected.scenarioEntity
    && clean(contract?.scenarioAction) === expectedAction
    && clean(contract?.informationForm) === expected.informationForm
    && clean(contract?.scenarioFingerprint) === expected.scenarioFingerprint
    && clean(contract?.contextNecessity) === expected.contextNecessity
    && sameStringArray(contract?.requiredInformationFields, expected.requiredInformationFields)
    && sameStringArray(contract?.solverRelevantFields, expected.solverRelevantFields)
    && sameRecord(contract?.surface, expected.surface)
    && sameRecord(contract?.plausibility, expected.plausibility)
    && recordFrom(contract?.sourceIsolation)?.officialQuestionContentUsed === false
    && recordFrom(contract?.sourceIsolation)?.reversibleSourceFieldsUsed === false
    && recordFrom(contract?.sourceIsolation)?.selectionBasis === 'controlled_catalog_and_sealed_ordinal_only');
  return {
    policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
    valid,
    failureCodes: valid ? [] : ['scenario_contract_missing_or_invalid']
  };
}

function recordFrom(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

export function subjectPracticeScenarioEvidenceFor(input: { questionPlan?: unknown; candidate?: unknown }) {
  const plan = recordFrom(input.questionPlan);
  const contract = recordFrom(plan?.scenarioContract);
  const candidate = recordFrom(input.candidate);
  const localizations = recordFrom(candidate?.localizations);
  const en = recordFrom(localizations?.en);
  const text = [candidate?.prompt, candidate?.explanation, en?.prompt, en?.explanation].map(clean).join(' ');
  const mode = clean(contract?.scenarioMode);
  const surface = recordFrom(contract?.surface);
  const cueTokens = Array.isArray(surface?.cueTokens) ? surface.cueTokens.map(clean).filter(Boolean) : [];
  const expectedFingerprint = subjectPracticeScenarioFingerprintFor({
    scenarioDomain: contract?.scenarioDomain,
    scenarioEntity: contract?.scenarioEntity,
    scenarioAction: contract?.scenarioAction,
    informationForm: contract?.informationForm
  });
  const abstractMath = clean(plan?.subject) === 'math' && ['abstract', 'not_applicable'].includes(mode);
  const surfaceMatched = abstractMath || cueTokens.some((token) => text.includes(token));
  const action = clean(contract?.scenarioAction);
  const opticsAction = /^(?:convex_lens_|refraction_)/.test(action);
  const newtonForceAction = [
    'net_force_from_mass_acceleration',
    'acceleration_from_net_force_mass',
    'horizontal_opposed_forces_acceleration',
    'single_axis_equilibrium_unknown_force'
  ].includes(action);
  const relationEvidenceMatched = abstractMath
    || (clean(plan?.subject) === 'physics'
      ? opticsAction
        ? /凸透镜|焦距|物距|像距|放大率|折射率|入射角|折射角|convex lens|focal length|object distance|image distance|magnification|refractive index|incidence angle|refraction angle/i.test(text)
        : newtonForceAction
          ? /(?:f_?(?:net|right|left|known)|合力|已知力|未知力|net force|known .*force|unknown .*force)/i.test(text)
            && /(?:\bkg\b|质量|mass)/i.test(text + (action === 'single_axis_equilibrium_unknown_force' ? ' mass' : ''))
            && /(?:\bn\b|牛顿|force)/i.test(text)
        : /m\/s|m\/s\^2|m\/s²|位移|速度|加速度|speed|velocity|acceleration|displacement/i.test(text)
      : /mol\/l|ml|ph|稀释|混合|dilut|mix/i.test(text));
  const physicsActionEvidenceMatched = abstractMath || clean(plan?.subject) !== 'physics'
    || (action === 'uniform_speed'
      ? /位移|displacement/.test(text) && /用时|time|in \d/.test(text) && /速度|speed/.test(text)
      : action === 'acceleration_from_velocity_change'
        ? /初速度|initial velocity/.test(text) && /末速度|final velocity|reaches/.test(text) && /加速度|acceleration/.test(text)
        : action === 'final_velocity_from_initial_acceleration_time'
          ? /初速度|initial velocity/.test(text) && /加速度|acceleration/.test(text) && /最终速度|final velocity/.test(text)
      : action === 'displacement_from_initial_acceleration_time'
          ? /初速度|initial velocity/.test(text) && /加速度|acceleration/.test(text) && /位移|displacement/.test(text)
          : action === 'convex_lens_image_distance_and_nature'
            ? /凸透镜|convex lens/.test(text) && /焦距|focal length/.test(text) && /物距|object distance/.test(text) && /像距|image distance/.test(text)
          : action === 'convex_lens_magnification'
            ? /凸透镜|convex lens/.test(text) && /焦距|focal length/.test(text) && /物距|object distance/.test(text) && /放大率|magnification/.test(text)
          : action === 'refraction_angle_and_direction'
            ? /折射率|refractive index/.test(text) && /入射角|incidence angle/.test(text) && /折射角|refraction angle/.test(text) && /法线|normal/.test(text)
          : action === 'net_force_from_mass_acceleration'
            ? /质量|mass/.test(text) && /加速度|acceleration/.test(text) && /合力|net force/.test(text)
          : action === 'acceleration_from_net_force_mass'
            ? /质量|mass/.test(text) && /合力|net force/.test(text) && /加速度|acceleration/.test(text)
          : action === 'horizontal_opposed_forces_acceleration'
            ? /向右|right/.test(text) && /向左|left/.test(text) && /加速度|acceleration/.test(text)
          : action === 'single_axis_equilibrium_unknown_force'
            ? /平衡|equilibrium/.test(text) && /未知力|unknown .*force/.test(text) && /同一直线|same line/.test(text)
            : false);
  const chemistryActionEvidenceMatched = abstractMath || clean(plan?.subject) !== 'chemistry'
    || (['strong_acid_dilution', 'strong_base_dilution'].includes(action)
      ? /稀释|dilut/.test(text)
        && /mol\/l/i.test(text)
        && /ml/i.test(text)
        && (action === 'strong_acid_dilution'
          ? /hcl|hno3|盐酸|硝酸/i.test(text)
          : /naoh|koh|氢氧化钠|氢氧化钾/i.test(text))
      : action === 'strong_acid_base_neutralization'
        ? /hcl/i.test(text) && /naoh/i.test(text) && /混合|mix/.test(text) && /ml/i.test(text)
        : /^ph_paper_wetting_(?:acid|base)$/.test(action)
          ? /ph.{0,8}试纸|ph paper/.test(text) && /润湿|wet|moisten/.test(text)
            && (action.endsWith('_acid') ? /酸性|acidic/.test(text) : /碱性|basic|alkaline/.test(text))
        : /^volumetric_(?:overfill|underfill)_(?:acid|base)$/.test(action)
          ? /容量瓶|volumetric flask/.test(text)
            && (action.includes('overfill') ? /超过|高于|above|overfill/.test(text) : /未到|低于|below|underfill|short of/.test(text))
            && (action.endsWith('_acid') ? /酸性|acidic/.test(text) : /碱性|basic|alkaline/.test(text))
        : false);
  const numericValues = text.match(/-?\d+(?:\.\d+)?/g)?.map(Number).filter(Number.isFinite) ?? [];
  const physicalPlausibilityMatched = abstractMath || clean(plan?.subject) !== 'physics'
    || (recordFrom(contract?.plausibility)?.textCompleteOpticalSetup === true
      ? recordFrom(contract?.plausibility)?.unseenDiagramForbidden === true
        && recordFrom(contract?.plausibility)?.physicallyValidOpticalRegion === true
        && physicsActionEvidenceMatched
        && !/如图|见图|下图|as shown|diagram below/.test(text)
      : newtonForceAction
        ? recordFrom(contract?.plausibility)?.straightLineMotion === true
          && /直线|straight|轨道|track|井道|shaft|跑道|route|通道|aisle|同一直线|same line/.test(text)
          && /(?:\bn\b|牛顿|force)/i.test(text)
          && (action === 'single_axis_equilibrium_unknown_force'
            ? numericValues.length >= 1 && /平衡|equilibrium/.test(text)
            : numericValues.length >= 3 && /\bkg\b/i.test(text) && /m\/s\^2|m\/s²/.test(text))
          && numericValues.every((value) => Math.abs(value) <= 100000)
        : recordFrom(contract?.plausibility)?.straightLineMotion === true
          && /直线|straight|轨道|track|井道|shaft|跑道|route|通道|aisle/.test(text)
          && /m\/s|m\/s\^2|m\/s²/.test(text)
          && numericValues.length >= 3
          && numericValues.every((value) => Math.abs(value) <= 100000));
  const chemistryPlausibilityMatched = abstractMath || clean(plan?.subject) !== 'chemistry'
    || (recordFrom(contract?.plausibility)?.singleOperationError === true
      ? recordFrom(contract?.plausibility)?.numericPhCalculationForbidden === true
        && recordFrom(contract?.plausibility)?.acidBaseCharacterExplicit === true
        && chemistryActionEvidenceMatched
        && !/(?:求|计算|calculate).{0,20}(?:数值|numeric)?\s*ph/i.test(text)
      : recordFrom(contract?.plausibility)?.temperatureC === 25
      && recordFrom(contract?.plausibility)?.completeDissociationOnly === true
      && /25\s*°?\s*c/i.test([candidate?.explanation, en?.explanation].map(String).join(' '))
      && chemistryActionEvidenceMatched);
  const informationParticipationMatched = abstractMath || Boolean(
    surfaceMatched
    && relationEvidenceMatched
    && physicsActionEvidenceMatched
    && chemistryActionEvidenceMatched
  );
  const contractValid = contract?.schemaVersion === SUBJECT_PRACTICE_SCENARIO_CONTRACT_SCHEMA_VERSION
    && contract?.policyVersion === SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION
    && clean(contract?.scenarioFingerprint) === expectedFingerprint
    && contract?.sourceIsolation && recordFrom(contract.sourceIsolation)?.officialQuestionContentUsed === false;
  const contextNecessityVerified = abstractMath
    ? clean(contract?.contextNecessity) === 'not_applicable'
    : clean(contract?.contextNecessity) === 'required_for_solution' && relationEvidenceMatched;
  const consistent = Boolean(contractValid
    && surfaceMatched
    && relationEvidenceMatched
    && contextNecessityVerified
    && physicsActionEvidenceMatched
    && chemistryActionEvidenceMatched
    && physicalPlausibilityMatched
    && chemistryPlausibilityMatched
    && informationParticipationMatched);
  return {
    policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
    stage: 'shadow_only_thresholds_not_frozen',
    status: consistent ? 'consistent' : 'inconsistent',
    scenarioMode: mode || null,
    scenarioFamilyId: clean(contract?.scenarioFamilyId) || null,
    scenarioDomain: clean(contract?.scenarioDomain) || null,
    scenarioEntity: clean(contract?.scenarioEntity) || null,
    scenarioAction: clean(contract?.scenarioAction) || null,
    informationForm: clean(contract?.informationForm) || null,
    scenarioFingerprint: clean(contract?.scenarioFingerprint) || null,
    contextNecessity: clean(contract?.contextNecessity) || null,
    surfaceEntity: clean(surface?.zhEntity || surface?.enEntity) || null,
    contractValid,
    surfaceMatched,
    relationEvidenceMatched,
    contextNecessityVerified,
    physicsActionEvidenceMatched,
    chemistryActionEvidenceMatched,
    physicalPlausibilityMatched,
    chemistryPlausibilityMatched,
    informationParticipationMatched,
    sourceContentExposedToGenerator: false,
    productionGateImpact: 'none_shadow_only'
  };
}

export function subjectPracticeScenarioDiversityBatchMetrics(input: { expectedCount?: unknown; evidence?: unknown[] }) {
  const expectedCount = Math.max(0, Math.trunc(Number(input.expectedCount) || 0));
  const evidence = (input.evidence ?? []).map(recordFrom).filter((item): item is Record<string, unknown> => Boolean(item));
  const applicable = evidence.filter((item) => !['abstract', 'not_applicable'].includes(clean(item.scenarioMode)));
  const familyCounts = applicable.reduce<Record<string, number>>((counts, item) => {
    const key = clean(item.scenarioFamilyId) || 'missing';
    counts[key] = (counts[key] ?? 0) + 1;
    return counts;
  }, {});
  const fingerprintGroups = applicable.reduce<Record<string, Record<string, number>>>((groups, item) => {
    const fingerprint = clean(item.scenarioFingerprint) || 'missing';
    const surface = clean(item.surfaceEntity) || 'missing';
    groups[fingerprint] ??= {};
    groups[fingerprint][surface] = (groups[fingerprint][surface] ?? 0) + 1;
    return groups;
  }, {});
  const uniqueFingerprints = Object.keys(fingerprintGroups).filter((key) => key !== 'missing').length;
  const duplicateFingerprintCount = Math.max(0, applicable.length - uniqueFingerprints);
  const renameOnlyCount = Object.values(fingerprintGroups).reduce((sum, surfaces) => {
    const variants = Object.keys(surfaces).filter((key) => key !== 'missing');
    return sum + (variants.length > 1 ? Object.values(surfaces).reduce((a, b) => a + b, 0) : 0);
  }, 0);
  const maximumFamilyCount = Math.max(0, ...Object.values(familyCounts));
  const evidenceConsistent = (item: Record<string, unknown>) => {
    const status = clean(item.status);
    if (status === 'consistent') return true;
    if (status !== 'shadow_candidate_evidence_complete') return false;
    const blockers = Array.isArray(item.blockers) ? item.blockers.filter(Boolean) : [];
    const subject = clean(item.subject);
    return blockers.length === 0
      && item.contextNecessityVerified === true
      && item.informationParticipationMatched === true
      && item.generatorSelfVerified === true
      && item.planAdherent === true
      && item.solverVerified === true
      && (subject !== 'physics' || item.physicsRelationMatched === true)
      && (subject !== 'chemistry'
        || (item.chemistryRelationMatched === true && item.chemistryPlausibilityMatched === true));
  };
  const inconsistencyCount = evidence.filter((item) => !evidenceConsistent(item)).length;
  const decorativeBackgroundCount = evidence.filter((item) =>
    clean(item.contextNecessity) === 'decorative' || item.contextNecessityVerified !== true).length;
  return {
    policyVersion: SUBJECT_PRACTICE_SCENARIO_DIVERSITY_POLICY_VERSION,
    stage: 'shadow_only_thresholds_not_frozen',
    expectedCount,
    observedEvidenceCount: evidence.length,
    applicableScenarioCount: applicable.length,
    abstractOrNotApplicableCount: evidence.length - applicable.length,
    scenarioFamilyCoverageCount: Object.keys(familyCounts).filter((key) => key !== 'missing').length,
    scenarioFingerprintCoverageCount: uniqueFingerprints,
    scenarioFamilyCounts: familyCounts,
    singleScenarioFamilyMaximumShare: applicable.length ? maximumFamilyCount / applicable.length : null,
    scenarioFingerprintDuplicateRate: applicable.length ? duplicateFingerprintCount / applicable.length : null,
    renameOnlyStructureRate: applicable.length ? renameOnlyCount / applicable.length : null,
    decorativeBackgroundRate: evidence.length ? decorativeBackgroundCount / evidence.length : null,
    scenarioConsistencyFailureRate: evidence.length ? inconsistencyCount / evidence.length : null,
    completeEvidenceCoverage: evidence.length === expectedCount,
    thresholdsFrozen: false,
    releaseQualification: false,
    productionGateImpact: 'none_shadow_only'
  };
}
