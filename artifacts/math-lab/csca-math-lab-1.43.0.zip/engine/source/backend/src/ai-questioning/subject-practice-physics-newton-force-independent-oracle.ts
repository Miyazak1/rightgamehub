export * from '../../../question-engine/core/subject-practice-physics-newton-force-independent-oracle';
