// Compatibility facade. Canonical implementation lives in question-engine/core.
export * from '../../../question-engine/core/subject-practice-chemistry-ph-operation-error-independent-oracle';
