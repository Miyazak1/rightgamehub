export const SUBJECT_PRACTICE_DIFFICULTY_EVIDENCE_POLICY_VERSION =
  'subject-practice-difficulty-evidence-v66-math-normal-basic-plan-bound';
