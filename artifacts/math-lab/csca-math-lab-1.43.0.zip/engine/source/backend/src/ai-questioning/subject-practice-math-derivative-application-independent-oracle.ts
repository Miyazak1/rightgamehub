export * from '../../../question-engine/core/subject-practice-math-derivative-application-independent-oracle';
