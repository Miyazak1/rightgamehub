import { solveSubjectPracticeMathNormalDistributionConstraint } from './subject-practice-math-normal-distribution-constraint-solver';
import { solveSubjectPracticeMathStatisticsConstraint } from './subject-practice-math-statistics-constraint-solver';
import { solveSubjectPracticeMathProbabilityConstraint } from './subject-practice-math-probability-constraint-solver';
import { solveSubjectPracticeMathSolidGeometryConstraint } from './subject-practice-math-solid-geometry-constraint-solver';
import { solveSubjectPracticeMathVectorComplexConstraint } from './subject-practice-math-vector-complex-constraint-solver';
import { solveSubjectPracticeMathPlaneAnalyticGeometryConstraint } from './subject-practice-math-plane-analytic-geometry-constraint-solver';
import { solveSubjectPracticeMathSequenceConstraint } from './subject-practice-math-sequence-constraint-solver';
import { solveSubjectPracticeMathDerivativeConstraint } from './subject-practice-math-derivative-constraint-solver';
import { solveSubjectPracticeMathElementaryExpLogConstraint } from './subject-practice-math-elementary-exp-log-constraint-solver';
import { solveSubjectPracticeMathFunctionComposition } from './subject-practice-math-function-composition-solver';
import { solveSubjectPracticeMathCompoundInequality } from './subject-practice-math-compound-inequality-solver';
import { verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle } from './subject-practice-math-normal-distribution-constraint-independent-oracle';
import { verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle } from './subject-practice-math-statistics-constraint-independent-oracle';
import { verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle } from './subject-practice-math-probability-constraint-independent-oracle';
import { verifySubjectPracticeMathSolidGeometryConstraintWithIndependentOracle } from './subject-practice-math-solid-geometry-constraint-independent-oracle';
import { verifySubjectPracticeMathVectorComplexConstraintWithIndependentOracle } from './subject-practice-math-vector-complex-constraint-independent-oracle';
import { verifySubjectPracticeMathPlaneAnalyticGeometryConstraintWithIndependentOracle } from './subject-practice-math-plane-analytic-geometry-constraint-independent-oracle';
import { verifySubjectPracticeMathSequenceConstraintWithIndependentOracle } from './subject-practice-math-sequence-constraint-independent-oracle';
import { verifySubjectPracticeMathDerivativeConstraintWithIndependentOracle } from './subject-practice-math-derivative-constraint-independent-oracle';
import { verifySubjectPracticeMathElementaryExpLogConstraintWithIndependentOracle } from './subject-practice-math-elementary-exp-log-constraint-independent-oracle';
import { verifySubjectPracticeMathFunctionCompositionWithIndependentOracle } from './subject-practice-math-function-composition-independent-oracle';
import { verifySubjectPracticeMathCompoundInequalityWithIndependentOracle } from './subject-practice-math-compound-inequality-independent-oracle';
import { verifySubjectPracticeMathNormalDistributionConstraintExplanation } from './subject-practice-math-normal-distribution-constraint-explanation-verifier';
import { verifySubjectPracticeMathStatisticsConstraintExplanation } from './subject-practice-math-statistics-constraint-explanation-verifier';
import { verifySubjectPracticeMathProbabilityConstraintExplanation } from './subject-practice-math-probability-constraint-explanation-verifier';
import { verifySubjectPracticeMathSolidGeometryConstraintExplanation } from './subject-practice-math-solid-geometry-constraint-explanation-verifier';
import { verifySubjectPracticeMathVectorComplexConstraintExplanation } from './subject-practice-math-vector-complex-constraint-explanation-verifier';
import { verifySubjectPracticeMathPlaneAnalyticGeometryConstraintExplanation } from './subject-practice-math-plane-analytic-geometry-constraint-explanation-verifier';
import { verifySubjectPracticeMathSequenceConstraintExplanation } from './subject-practice-math-sequence-constraint-explanation-verifier';
import { verifySubjectPracticeMathDerivativeConstraintExplanation } from './subject-practice-math-derivative-constraint-explanation-verifier';
import { verifySubjectPracticeMathElementaryExpLogConstraintExplanation } from './subject-practice-math-elementary-exp-log-constraint-explanation-verifier';
import { verifySubjectPracticeMathFunctionCompositionExplanation } from './subject-practice-math-function-composition-explanation-verifier';
import { verifySubjectPracticeMathCompoundInequalityExplanation } from './subject-practice-math-compound-inequality-explanation-verifier';
import { solveSubjectPracticeMathIntervalSetParameter } from './subject-practice-math-interval-set-parameter-solver';
import { verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle } from './subject-practice-math-interval-set-parameter-independent-oracle';
import { verifySubjectPracticeMathIntervalSetParameterExplanation } from './subject-practice-math-interval-set-parameter-explanation-verifier';
import { solveSubjectPracticeMathNormalTwoStep, SubjectPracticeMathNormalTwoStepSolverEvidence } from './subject-practice-math-normal-distribution-two-step-solver';
import { solveSubjectPracticeMathStatisticsTwoStep, SubjectPracticeMathStatisticsTwoStepSolverEvidence } from './subject-practice-math-descriptive-statistics-two-step-solver';
import { solveSubjectPracticeMathProbabilityTwoStage, SubjectPracticeMathProbabilityTwoStageSolverEvidence } from './subject-practice-math-probability-two-stage-solver';
import { solveSubjectPracticeMathSolidGeometryTwoStep, SubjectPracticeMathSolidGeometryTwoStepSolverEvidence } from './subject-practice-math-solid-geometry-two-step-solver';
import { solveSubjectPracticeMathVectorComplexTwoStep, SubjectPracticeMathVectorComplexTwoStepSolverEvidence } from './subject-practice-math-vector-complex-two-step-solver';
import { solveSubjectPracticeMathPlaneAnalyticGeometry, SubjectPracticeMathPlaneAnalyticGeometrySolverEvidence } from './subject-practice-math-plane-analytic-geometry-solver';
import { solveSubjectPracticeMathDerivativeApplication, SubjectPracticeMathDerivativeApplicationSolverEvidence } from './subject-practice-math-derivative-application-solver';
import { solveSubjectPracticeMathElementaryExpLog, SubjectPracticeMathElementaryExpLogSolverEvidence } from './subject-practice-math-elementary-exp-log-solver';
import { verifySubjectPracticeMathNormalTwoStepExplanation, SubjectPracticeMathNormalTwoStepExplanationEvidence } from './subject-practice-math-normal-distribution-two-step-explanation-verifier';
import { verifySubjectPracticeMathStatisticsTwoStepExplanation, SubjectPracticeMathStatisticsTwoStepExplanationEvidence } from './subject-practice-math-descriptive-statistics-two-step-explanation-verifier';
import { verifySubjectPracticeMathProbabilityTwoStageExplanation, SubjectPracticeMathProbabilityTwoStageExplanationEvidence } from './subject-practice-math-probability-two-stage-explanation-verifier';
import { verifySubjectPracticeMathSolidGeometryTwoStepExplanation, SubjectPracticeMathSolidGeometryTwoStepExplanationEvidence } from './subject-practice-math-solid-geometry-two-step-explanation-verifier';
import { verifySubjectPracticeMathVectorComplexTwoStepExplanation, SubjectPracticeMathVectorComplexTwoStepExplanationEvidence } from './subject-practice-math-vector-complex-two-step-explanation-verifier';
import { verifySubjectPracticeMathPlaneAnalyticGeometryExplanation, SubjectPracticeMathPlaneAnalyticGeometryExplanationEvidence } from './subject-practice-math-plane-analytic-geometry-explanation-verifier';
import { verifySubjectPracticeMathDerivativeApplicationExplanation, SubjectPracticeMathDerivativeApplicationExplanationEvidence } from './subject-practice-math-derivative-application-explanation-verifier';
import { verifySubjectPracticeMathElementaryExpLogExplanation, SubjectPracticeMathElementaryExpLogExplanationEvidence } from './subject-practice-math-elementary-exp-log-explanation-verifier';
import { verifySubjectPracticeMathNormalTwoStepWithIndependentOracle, SubjectPracticeMathNormalTwoStepOracleEvidence } from './subject-practice-math-normal-distribution-two-step-independent-oracle';
import { verifySubjectPracticeMathStatisticsTwoStepWithIndependentOracle, SubjectPracticeMathStatisticsTwoStepOracleEvidence } from './subject-practice-math-descriptive-statistics-two-step-independent-oracle';
import { verifySubjectPracticeMathProbabilityTwoStageWithIndependentOracle, SubjectPracticeMathProbabilityTwoStageOracleEvidence } from './subject-practice-math-probability-two-stage-independent-oracle';
import { verifySubjectPracticeMathSolidGeometryTwoStepWithIndependentOracle, SubjectPracticeMathSolidGeometryTwoStepOracleEvidence } from './subject-practice-math-solid-geometry-two-step-independent-oracle';
import { verifySubjectPracticeMathVectorComplexTwoStepWithIndependentOracle, SubjectPracticeMathVectorComplexTwoStepOracleEvidence } from './subject-practice-math-vector-complex-two-step-independent-oracle';
import { verifySubjectPracticeMathPlaneAnalyticGeometryWithIndependentOracle, SubjectPracticeMathPlaneAnalyticGeometryOracleEvidence } from './subject-practice-math-plane-analytic-geometry-independent-oracle';
import { verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle, SubjectPracticeMathDerivativeApplicationOracleEvidence } from './subject-practice-math-derivative-application-independent-oracle';
import { verifySubjectPracticeMathElementaryExpLogWithIndependentOracle, SubjectPracticeMathElementaryExpLogOracleEvidence } from './subject-practice-math-elementary-exp-log-independent-oracle';
import { solveSubjectPracticeMathFunctionInterval, SubjectPracticeMathFunctionIntervalSolverEvidence } from './subject-practice-math-function-interval-solver';
import { verifySubjectPracticeMathFunctionIntervalExplanation, SubjectPracticeMathFunctionIntervalExplanationEvidence } from './subject-practice-math-function-interval-explanation-verifier';
import { verifySubjectPracticeMathFunctionIntervalWithIndependentOracle, SubjectPracticeMathFunctionIntervalOracleEvidence } from './subject-practice-math-function-interval-independent-oracle';
import { solveSubjectPracticeMathInequalitySignChart, SubjectPracticeMathInequalitySignChartSolverEvidence } from './subject-practice-math-inequality-sign-chart-solver';
import { verifySubjectPracticeMathInequalitySignChartExplanation, SubjectPracticeMathInequalitySignChartExplanationEvidence } from './subject-practice-math-inequality-sign-chart-explanation-verifier';
import { verifySubjectPracticeMathInequalitySignChartWithIndependentOracle, SubjectPracticeMathInequalitySignChartIndependentOracleEvidence } from './subject-practice-math-inequality-sign-chart-independent-oracle';
import { solveSubjectPracticeMathSolidGeometry, SubjectPracticeMathSolidGeometrySolverEvidence } from './subject-practice-math-solid-geometry-solver';
import { solveSubjectPracticeMathNormalDistributionBasic, SubjectPracticeMathNormalDistributionBasicSolverEvidence } from './subject-practice-math-normal-distribution-basic-solver';
import { verifySubjectPracticeMathNormalDistributionBasicExplanation, SubjectPracticeMathNormalDistributionBasicExplanationEvidence } from './subject-practice-math-normal-distribution-basic-explanation-verifier';
import { verifySubjectPracticeMathNormalDistributionBasicWithIndependentOracle, SubjectPracticeMathNormalDistributionBasicIndependentOracleEvidence } from './subject-practice-math-normal-distribution-basic-independent-oracle';
import { solveSubjectPracticeMathDescriptiveStatistics, SubjectPracticeMathDescriptiveStatisticsSolverEvidence } from './subject-practice-math-descriptive-statistics-solver';
import { verifySubjectPracticeMathDescriptiveStatisticsExplanation, SubjectPracticeMathDescriptiveStatisticsExplanationEvidence } from './subject-practice-math-descriptive-statistics-explanation-verifier';
import { verifySubjectPracticeMathDescriptiveStatisticsWithIndependentOracle, SubjectPracticeMathDescriptiveStatisticsIndependentOracleEvidence } from './subject-practice-math-descriptive-statistics-independent-oracle';
import { verifySubjectPracticeMathSolidGeometryExplanation, SubjectPracticeMathSolidGeometryExplanationEvidence } from './subject-practice-math-solid-geometry-explanation-verifier';
import { verifySubjectPracticeMathSolidGeometryWithIndependentOracle, SubjectPracticeMathSolidGeometryIndependentOracleEvidence } from './subject-practice-math-solid-geometry-independent-oracle';
import { GeneratedQuestionCandidate } from './ai-questioning.types';
import {
  solveElementaryFunctionDirectProperty,
  SubjectPracticeMathSolverEvidence
} from './subject-practice-math-solver';
import {
  solveSubjectPracticeMathLineRelation,
  SubjectPracticeMathLineRelationSolverEvidence
} from './subject-practice-math-line-relation-solver';
import {
  solveSubjectPracticePhysicsKinematics,
  SubjectPracticePhysicsKinematicsSolverEvidence
} from './subject-practice-physics-kinematics-solver';
import {
  solveSubjectPracticeChemistryAcidBase,
  SubjectPracticeChemistryAcidBaseSolverEvidence
} from './subject-practice-chemistry-acid-base-solver';
import {
  verifySubjectPracticeMathElementaryExplanation,
  SubjectPracticeMathElementaryExplanationEvidence
} from './subject-practice-math-elementary-explanation-verifier';
import {
  verifySubjectPracticeMathLineRelationExplanation,
  SubjectPracticeMathLineRelationExplanationEvidence
} from './subject-practice-math-line-relation-explanation-verifier';
import {
  verifySubjectPracticePhysicsKinematicsExplanation,
  SubjectPracticePhysicsKinematicsExplanationEvidence
} from './subject-practice-physics-kinematics-explanation-verifier';
import {
  verifySubjectPracticeChemistryAcidBaseExplanation,
  SubjectPracticeChemistryAcidBaseExplanationEvidence
} from './subject-practice-chemistry-acid-base-explanation-verifier';
import {
  verifySubjectPracticeMathElementaryWithIndependentOracle,
  SubjectPracticeMathElementaryIndependentOracleEvidence
} from './subject-practice-math-elementary-independent-oracle';
import {
  verifySubjectPracticeMathLineRelationWithIndependentOracle,
  SubjectPracticeMathLineRelationIndependentOracleEvidence
} from './subject-practice-math-line-relation-independent-oracle';
import {
  verifySubjectPracticePhysicsKinematicsWithIndependentOracle,
  SubjectPracticePhysicsKinematicsIndependentOracleEvidence
} from './subject-practice-physics-kinematics-independent-oracle';
import { solveSubjectPracticePhysicsNewtonForce, SubjectPracticePhysicsNewtonForceSolverEvidence } from './subject-practice-physics-newton-force-solver';
import { verifySubjectPracticePhysicsNewtonForceExplanation, SubjectPracticePhysicsNewtonForceExplanationEvidence } from './subject-practice-physics-newton-force-explanation-verifier';
import { verifySubjectPracticePhysicsNewtonForceWithIndependentOracle, SubjectPracticePhysicsNewtonForceIndependentOracleEvidence } from './subject-practice-physics-newton-force-independent-oracle';
import {
  verifySubjectPracticeChemistryAcidBaseWithIndependentOracle,
  SubjectPracticeChemistryAcidBaseIndependentOracleEvidence
} from './subject-practice-chemistry-acid-base-independent-oracle';
import {
  solveSubjectPracticeMathDerivative,
  SubjectPracticeMathDerivativeSolverEvidence
} from './subject-practice-math-derivative-solver';
import {
  verifySubjectPracticeMathDerivativeExplanation,
  SubjectPracticeMathDerivativeExplanationEvidence
} from './subject-practice-math-derivative-explanation-verifier';
import {
  verifySubjectPracticeMathDerivativeWithIndependentOracle,
  SubjectPracticeMathDerivativeIndependentOracleEvidence
} from './subject-practice-math-derivative-independent-oracle';
import {
  solveSubjectPracticeChemistryPhOperationError,
  SubjectPracticeChemistryPhOperationErrorSolverEvidence
} from './subject-practice-chemistry-ph-operation-error-solver';
import {
  verifySubjectPracticeChemistryPhOperationErrorExplanation,
  SubjectPracticeChemistryPhOperationErrorExplanationEvidence
} from './subject-practice-chemistry-ph-operation-error-explanation-verifier';
import {
  verifySubjectPracticeChemistryPhOperationErrorWithIndependentOracle,
  SubjectPracticeChemistryPhOperationErrorIndependentOracleEvidence
} from './subject-practice-chemistry-ph-operation-error-independent-oracle';
import { solveSubjectPracticePhysicsOptics, SubjectPracticePhysicsOpticsSolverEvidence } from './subject-practice-physics-optics-solver';
import { verifySubjectPracticePhysicsOpticsExplanation, SubjectPracticePhysicsOpticsExplanationEvidence } from './subject-practice-physics-optics-explanation-verifier';
import { verifySubjectPracticePhysicsOpticsWithIndependentOracle, SubjectPracticePhysicsOpticsIndependentOracleEvidence } from './subject-practice-physics-optics-independent-oracle';
import { solveSubjectPracticeMathSet, SubjectPracticeMathSetSolverEvidence } from './subject-practice-math-set-solver';
import { verifySubjectPracticeMathSetExplanation, SubjectPracticeMathSetExplanationEvidence } from './subject-practice-math-set-explanation-verifier';
import { verifySubjectPracticeMathSetWithIndependentOracle, SubjectPracticeMathSetIndependentOracleEvidence } from './subject-practice-math-set-independent-oracle';
import { solveSubjectPracticeMathSetComposite, SubjectPracticeMathSetCompositeSolverEvidence } from './subject-practice-math-set-composite-solver';
import { verifySubjectPracticeMathSetCompositeExplanation, SubjectPracticeMathSetCompositeExplanationEvidence } from './subject-practice-math-set-composite-explanation-verifier';
import { verifySubjectPracticeMathSetCompositeWithIndependentOracle, SubjectPracticeMathSetCompositeIndependentOracleEvidence } from './subject-practice-math-set-composite-independent-oracle';
import { solveSubjectPracticeMathSequence, SubjectPracticeMathSequenceSolverEvidence } from './subject-practice-math-sequence-solver';
import { verifySubjectPracticeMathSequenceExplanation, SubjectPracticeMathSequenceExplanationEvidence } from './subject-practice-math-sequence-explanation-verifier';
import { verifySubjectPracticeMathSequenceWithIndependentOracle, SubjectPracticeMathSequenceIndependentOracleEvidence } from './subject-practice-math-sequence-independent-oracle';
import { solveSubjectPracticeMathSequenceTwoCondition, SubjectPracticeMathSequenceTwoConditionSolverEvidence } from './subject-practice-math-sequence-two-condition-solver';
import { verifySubjectPracticeMathSequenceTwoConditionExplanation, SubjectPracticeMathSequenceTwoConditionExplanationEvidence } from './subject-practice-math-sequence-two-condition-explanation-verifier';
import { verifySubjectPracticeMathSequenceTwoConditionWithIndependentOracle, SubjectPracticeMathSequenceTwoConditionIndependentOracleEvidence } from './subject-practice-math-sequence-two-condition-independent-oracle';
import { solveSubjectPracticeMathBasicFunction, SubjectPracticeMathBasicFunctionSolverEvidence } from './subject-practice-math-basic-function-solver';
import { verifySubjectPracticeMathBasicFunctionExplanation, SubjectPracticeMathBasicFunctionExplanationEvidence } from './subject-practice-math-basic-function-explanation-verifier';
import { verifySubjectPracticeMathBasicFunctionWithIndependentOracle, SubjectPracticeMathBasicFunctionIndependentOracleEvidence } from './subject-practice-math-basic-function-independent-oracle';
import { solveSubjectPracticeMathInequality, SubjectPracticeMathInequalitySolverEvidence } from './subject-practice-math-inequality-solver';
import { verifySubjectPracticeMathInequalityExplanation, SubjectPracticeMathInequalityExplanationEvidence } from './subject-practice-math-inequality-explanation-verifier';
import { verifySubjectPracticeMathInequalityWithIndependentOracle, SubjectPracticeMathInequalityIndependentOracleEvidence } from './subject-practice-math-inequality-independent-oracle';
import { solveSubjectPracticeMathVectorComplex, SubjectPracticeMathVectorComplexSolverEvidence } from './subject-practice-math-vector-complex-solver';
import { verifySubjectPracticeMathVectorComplexExplanation, SubjectPracticeMathVectorComplexExplanationEvidence } from './subject-practice-math-vector-complex-explanation-verifier';
import { verifySubjectPracticeMathVectorComplexWithIndependentOracle, SubjectPracticeMathVectorComplexIndependentOracleEvidence } from './subject-practice-math-vector-complex-independent-oracle';
import { solveSubjectPracticeMathProbability, SubjectPracticeMathProbabilitySolverEvidence } from './subject-practice-math-probability-solver';
import { verifySubjectPracticeMathProbabilityExplanation, SubjectPracticeMathProbabilityExplanationEvidence } from './subject-practice-math-probability-explanation-verifier';
import { verifySubjectPracticeMathProbabilityWithIndependentOracle, SubjectPracticeMathProbabilityIndependentOracleEvidence } from './subject-practice-math-probability-independent-oracle';

export const SUBJECT_PRACTICE_FORMAL_VERIFICATION_ORCHESTRATOR_VERSION =
  'subject-practice-formal-verification-orchestrator-v16-math-normal-basic';

type SolverEvidence = SubjectPracticeMathSolverEvidence
  | ReturnType<typeof solveSubjectPracticeMathStatisticsConstraint> | ReturnType<typeof solveSubjectPracticeMathProbabilityConstraint> | ReturnType<typeof solveSubjectPracticeMathSolidGeometryConstraint> | ReturnType<typeof solveSubjectPracticeMathVectorComplexConstraint> | ReturnType<typeof solveSubjectPracticeMathPlaneAnalyticGeometryConstraint> | ReturnType<typeof solveSubjectPracticeMathSequenceConstraint> | ReturnType<typeof solveSubjectPracticeMathDerivativeConstraint> | ReturnType<typeof solveSubjectPracticeMathElementaryExpLogConstraint> | ReturnType<typeof solveSubjectPracticeMathFunctionComposition>
  | ReturnType<typeof solveSubjectPracticeMathCompoundInequality>
  | ReturnType<typeof solveSubjectPracticeMathIntervalSetParameter>
  | SubjectPracticeMathNormalTwoStepSolverEvidence
  | SubjectPracticeMathStatisticsTwoStepSolverEvidence
  | SubjectPracticeMathProbabilityTwoStageSolverEvidence
  | SubjectPracticeMathSolidGeometryTwoStepSolverEvidence
  | SubjectPracticeMathVectorComplexTwoStepSolverEvidence
  | SubjectPracticeMathPlaneAnalyticGeometrySolverEvidence
  | SubjectPracticeMathDerivativeApplicationSolverEvidence
  | SubjectPracticeMathElementaryExpLogSolverEvidence
  | SubjectPracticeMathFunctionIntervalSolverEvidence
  | SubjectPracticeMathSetSolverEvidence
  | SubjectPracticeMathSetCompositeSolverEvidence
  | SubjectPracticeMathSequenceSolverEvidence
  | SubjectPracticeMathSequenceTwoConditionSolverEvidence
  | SubjectPracticeMathBasicFunctionSolverEvidence
  | SubjectPracticeMathInequalitySolverEvidence
  | SubjectPracticeMathVectorComplexSolverEvidence
  | SubjectPracticeMathProbabilitySolverEvidence
  | SubjectPracticeMathSolidGeometrySolverEvidence
  | SubjectPracticeMathNormalDistributionBasicSolverEvidence
  | SubjectPracticeMathInequalitySignChartSolverEvidence
  | SubjectPracticeMathDescriptiveStatisticsSolverEvidence
  | SubjectPracticeMathLineRelationSolverEvidence
  | SubjectPracticeMathDerivativeSolverEvidence
  | SubjectPracticePhysicsKinematicsSolverEvidence
  | SubjectPracticePhysicsNewtonForceSolverEvidence
  | SubjectPracticeChemistryAcidBaseSolverEvidence
  | SubjectPracticeChemistryPhOperationErrorSolverEvidence
  | SubjectPracticePhysicsOpticsSolverEvidence
  | ReturnType<typeof solveSubjectPracticeMathNormalDistributionConstraint>;
type ExplanationEvidence = SubjectPracticeMathElementaryExplanationEvidence
  | ReturnType<typeof verifySubjectPracticeMathStatisticsConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathProbabilityConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathSolidGeometryConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathVectorComplexConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathPlaneAnalyticGeometryConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathSequenceConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathDerivativeConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathElementaryExpLogConstraintExplanation> | ReturnType<typeof verifySubjectPracticeMathFunctionCompositionExplanation>
  | ReturnType<typeof verifySubjectPracticeMathCompoundInequalityExplanation>
  | ReturnType<typeof verifySubjectPracticeMathIntervalSetParameterExplanation>
  | SubjectPracticeMathNormalTwoStepExplanationEvidence
  | SubjectPracticeMathStatisticsTwoStepExplanationEvidence
  | SubjectPracticeMathProbabilityTwoStageExplanationEvidence
  | SubjectPracticeMathSolidGeometryTwoStepExplanationEvidence
  | SubjectPracticeMathVectorComplexTwoStepExplanationEvidence
  | SubjectPracticeMathPlaneAnalyticGeometryExplanationEvidence
  | SubjectPracticeMathDerivativeApplicationExplanationEvidence
  | SubjectPracticeMathElementaryExpLogExplanationEvidence
  | SubjectPracticeMathFunctionIntervalExplanationEvidence
  | SubjectPracticeMathSetExplanationEvidence
  | SubjectPracticeMathSetCompositeExplanationEvidence
  | SubjectPracticeMathSequenceExplanationEvidence
  | SubjectPracticeMathSequenceTwoConditionExplanationEvidence
  | SubjectPracticeMathBasicFunctionExplanationEvidence
  | SubjectPracticeMathInequalityExplanationEvidence
  | SubjectPracticeMathVectorComplexExplanationEvidence
  | SubjectPracticeMathProbabilityExplanationEvidence
  | SubjectPracticeMathSolidGeometryExplanationEvidence
  | SubjectPracticeMathNormalDistributionBasicExplanationEvidence
  | SubjectPracticeMathInequalitySignChartExplanationEvidence
  | SubjectPracticeMathDescriptiveStatisticsExplanationEvidence
  | SubjectPracticeMathLineRelationExplanationEvidence
  | SubjectPracticeMathDerivativeExplanationEvidence
  | SubjectPracticePhysicsKinematicsExplanationEvidence
  | SubjectPracticePhysicsNewtonForceExplanationEvidence
  | SubjectPracticeChemistryAcidBaseExplanationEvidence
  | SubjectPracticeChemistryPhOperationErrorExplanationEvidence
  | SubjectPracticePhysicsOpticsExplanationEvidence;
type OracleEvidence = SubjectPracticeMathElementaryIndependentOracleEvidence
  | ReturnType<typeof verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathSolidGeometryConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathVectorComplexConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathPlaneAnalyticGeometryConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathSequenceConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathDerivativeConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathElementaryExpLogConstraintWithIndependentOracle> | ReturnType<typeof verifySubjectPracticeMathFunctionCompositionWithIndependentOracle>
  | ReturnType<typeof verifySubjectPracticeMathCompoundInequalityWithIndependentOracle>
  | ReturnType<typeof verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle>
  | SubjectPracticeMathNormalTwoStepOracleEvidence
  | SubjectPracticeMathStatisticsTwoStepOracleEvidence
  | SubjectPracticeMathProbabilityTwoStageOracleEvidence
  | SubjectPracticeMathSolidGeometryTwoStepOracleEvidence
  | SubjectPracticeMathVectorComplexTwoStepOracleEvidence
  | SubjectPracticeMathPlaneAnalyticGeometryOracleEvidence
  | SubjectPracticeMathDerivativeApplicationOracleEvidence
  | SubjectPracticeMathElementaryExpLogOracleEvidence
  | SubjectPracticeMathFunctionIntervalOracleEvidence
  | SubjectPracticeMathSetIndependentOracleEvidence
  | SubjectPracticeMathSetCompositeIndependentOracleEvidence
  | SubjectPracticeMathSequenceIndependentOracleEvidence
  | SubjectPracticeMathSequenceTwoConditionIndependentOracleEvidence
  | SubjectPracticeMathBasicFunctionIndependentOracleEvidence
  | SubjectPracticeMathInequalityIndependentOracleEvidence
  | SubjectPracticeMathVectorComplexIndependentOracleEvidence
  | SubjectPracticeMathProbabilityIndependentOracleEvidence
  | SubjectPracticeMathSolidGeometryIndependentOracleEvidence
  | SubjectPracticeMathNormalDistributionBasicIndependentOracleEvidence
  | SubjectPracticeMathInequalitySignChartIndependentOracleEvidence
  | SubjectPracticeMathDescriptiveStatisticsIndependentOracleEvidence
  | SubjectPracticeMathLineRelationIndependentOracleEvidence
  | SubjectPracticeMathDerivativeIndependentOracleEvidence
  | SubjectPracticePhysicsKinematicsIndependentOracleEvidence
  | SubjectPracticePhysicsNewtonForceIndependentOracleEvidence
  | SubjectPracticeChemistryAcidBaseIndependentOracleEvidence
  | SubjectPracticeChemistryPhOperationErrorIndependentOracleEvidence
  | SubjectPracticePhysicsOpticsIndependentOracleEvidence
  | ReturnType<typeof verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle>;

export type SubjectPracticeFormalVerificationBundle = {
  orchestratorVersion: string;
  status: 'verified' | 'conflict' | 'unparsed';
  subject: 'math' | 'physics' | 'chemistry';
  taskFamily: string;
  planTemplate: string;
  scopeId: string | null;
  plannedScopeId: string | null;
  oracleScopeId: string | null;
  scopeMatchedAcrossVerifiers: boolean;
  solverVersion: string;
  explanationVerifierVersion: string;
  independentOracleVersion: string;
  solverEvidence: SolverEvidence;
  explanationEvidence: ExplanationEvidence;
  independentOracleEvidence: OracleEvidence;
  eligibleForProductionShadowObservation: boolean;
  automaticPublicationEligible: false;
  providerImpact: 'none_no_provider_call';
  productionGateImpact: 'none_shadow_only';
  reasonCodes: string[];
};

function clean(value: unknown) {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

function recordFrom(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

export function verifySubjectPracticeFormalCandidate(input: {
  candidate: GeneratedQuestionCandidate;
  taskFamily: string;
  questionPlan?: unknown;
}): SubjectPracticeFormalVerificationBundle | null {
  const subject = clean(input.candidate.subject).toLowerCase();
  const taskFamily = clean(input.taskFamily);
  const planTemplate = clean(recordFrom(input.questionPlan)?.planTemplate);
  const context = { questionPlan: input.questionPlan };
  let solverEvidence: SolverEvidence;
  let explanationEvidence: ExplanationEvidence;
  let independentOracleEvidence: OracleEvidence;

  if (subject === 'math' && taskFamily === 'elementary_function_direct_property') {
    solverEvidence = solveElementaryFunctionDirectProperty(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathElementaryExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathElementaryWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_line_relation_direct') {
    solverEvidence = solveSubjectPracticeMathLineRelation(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathLineRelationExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathLineRelationWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_finite_set_operation') {
    solverEvidence = solveSubjectPracticeMathSet(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathSetExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathSetWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_finite_set_composite_operation') {
    solverEvidence = solveSubjectPracticeMathSetComposite(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathSetCompositeExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathSetCompositeWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_basic_sequence_direct_calculation') {
    solverEvidence = solveSubjectPracticeMathSequence(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathSequenceExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathSequenceWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_sequence_two_condition_calculation') {
    solverEvidence = solveSubjectPracticeMathSequenceTwoCondition(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathSequenceTwoConditionExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathSequenceTwoConditionWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_vector_complex_direct_calculation') {
    solverEvidence = solveSubjectPracticeMathVectorComplex(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathVectorComplexExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathVectorComplexWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_quadratic_rational_inequality_solution') {
    solverEvidence = solveSubjectPracticeMathInequalitySignChart(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathInequalitySignChartExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathInequalitySignChartWithIndependentOracle(input.candidate, context);
  } else if (subject==='math'&&taskFamily==='math_normal_distribution_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathNormalDistributionConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathNormalDistributionConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathNormalDistributionConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_descriptive_statistics_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathStatisticsConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathStatisticsConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathStatisticsConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_classical_probability_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathProbabilityConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathProbabilityConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathProbabilityConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_solid_geometry_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathSolidGeometryConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathSolidGeometryConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathSolidGeometryConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_vector_complex_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathVectorComplexConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathVectorComplexConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathVectorComplexConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_plane_analytic_geometry_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathPlaneAnalyticGeometryConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathPlaneAnalyticGeometryConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathPlaneAnalyticGeometryConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_sequence_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathSequenceConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathSequenceConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathSequenceConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_derivative_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathDerivativeConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathDerivativeConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathDerivativeConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_elementary_exp_log_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathElementaryExpLogConstraint(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathElementaryExpLogConstraintExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathElementaryExpLogConstraintWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_function_composition_piecewise_reasoning') {
    solverEvidence=solveSubjectPracticeMathFunctionComposition(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathFunctionCompositionExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathFunctionCompositionWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_compound_inequality_constraint_reasoning') {
    solverEvidence=solveSubjectPracticeMathCompoundInequality(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathCompoundInequalityExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathCompoundInequalityWithIndependentOracle(input.candidate,context);
  } else if (subject==='math'&&taskFamily==='math_interval_set_parameter_reasoning') {
    solverEvidence=solveSubjectPracticeMathIntervalSetParameter(input.candidate,context);
    explanationEvidence=verifySubjectPracticeMathIntervalSetParameterExplanation(input.candidate,context);
    independentOracleEvidence=verifySubjectPracticeMathIntervalSetParameterWithIndependentOracle(input.candidate,context);
  } else if (subject === 'math' && taskFamily === 'math_normal_distribution_two_step_reasoning') {
    solverEvidence = solveSubjectPracticeMathNormalTwoStep(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathNormalTwoStepExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathNormalTwoStepWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_descriptive_statistics_two_step_calculation') {
    solverEvidence = solveSubjectPracticeMathStatisticsTwoStep(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathStatisticsTwoStepExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathStatisticsTwoStepWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_classical_probability_two_stage_calculation') {
    solverEvidence = solveSubjectPracticeMathProbabilityTwoStage(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathProbabilityTwoStageExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathProbabilityTwoStageWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_solid_geometry_two_step_calculation') {
    solverEvidence = solveSubjectPracticeMathSolidGeometryTwoStep(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathSolidGeometryTwoStepExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathSolidGeometryTwoStepWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_vector_complex_two_step_calculation') {
    solverEvidence = solveSubjectPracticeMathVectorComplexTwoStep(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathVectorComplexTwoStepExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathVectorComplexTwoStepWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_plane_analytic_geometry_relation') {
    solverEvidence = solveSubjectPracticeMathPlaneAnalyticGeometry(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathPlaneAnalyticGeometryExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathPlaneAnalyticGeometryWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_polynomial_derivative_application') {
    solverEvidence = solveSubjectPracticeMathDerivativeApplication(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathDerivativeApplicationExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathDerivativeApplicationWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_elementary_exp_log_relation_reasoning') {
    solverEvidence = solveSubjectPracticeMathElementaryExpLog(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathElementaryExpLogExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathElementaryExpLogWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_function_interval_property_reasoning') {
    solverEvidence = solveSubjectPracticeMathFunctionInterval(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathFunctionIntervalExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathFunctionIntervalWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_normal_distribution_basic_concepts') {
    solverEvidence = solveSubjectPracticeMathNormalDistributionBasic(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathNormalDistributionBasicExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathNormalDistributionBasicWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_descriptive_statistics_direct_calculation') {
    solverEvidence = solveSubjectPracticeMathDescriptiveStatistics(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathDescriptiveStatisticsExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathDescriptiveStatisticsWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_solid_geometry_direct_calculation') {
    solverEvidence = solveSubjectPracticeMathSolidGeometry(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathSolidGeometryExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathSolidGeometryWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_classical_probability_basic_calculation') {
    solverEvidence = solveSubjectPracticeMathProbability(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathProbabilityExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathProbabilityWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_basic_function_property') {
    solverEvidence = solveSubjectPracticeMathBasicFunction(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathBasicFunctionExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathBasicFunctionWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'math_linear_inequality_solution') {
    solverEvidence = solveSubjectPracticeMathInequality(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathInequalityExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathInequalityWithIndependentOracle(input.candidate, context);
  } else if (subject === 'math' && taskFamily === 'derivative_direct_evaluation') {
    solverEvidence = solveSubjectPracticeMathDerivative(input.candidate, context);
    explanationEvidence = verifySubjectPracticeMathDerivativeExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeMathDerivativeWithIndependentOracle(input.candidate, context);
  } else if (subject === 'physics' && taskFamily === 'kinematics_basic_direct_relation') {
    solverEvidence = solveSubjectPracticePhysicsKinematics(input.candidate, context);
    explanationEvidence = verifySubjectPracticePhysicsKinematicsExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticePhysicsKinematicsWithIndependentOracle(input.candidate, context);
  } else if (subject === 'physics' && taskFamily === 'physics_newton_basic_force_calculation') {
    solverEvidence = solveSubjectPracticePhysicsNewtonForce(input.candidate, context);
    explanationEvidence = verifySubjectPracticePhysicsNewtonForceExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticePhysicsNewtonForceWithIndependentOracle(input.candidate, context);
  } else if (subject === 'physics' && taskFamily === 'waves_optics_interference_refraction') {
    solverEvidence = solveSubjectPracticePhysicsOptics(input.candidate, context);
    explanationEvidence = verifySubjectPracticePhysicsOpticsExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticePhysicsOpticsWithIndependentOracle(input.candidate, context);
  } else if (subject === 'chemistry' && taskFamily === 'ph_dilution_strong_acid_base_neutralization') {
    const chemistryContext = { taskFamily, questionPlan: input.questionPlan };
    solverEvidence = solveSubjectPracticeChemistryAcidBase(input.candidate, chemistryContext);
    explanationEvidence = verifySubjectPracticeChemistryAcidBaseExplanation(input.candidate, chemistryContext);
    independentOracleEvidence = verifySubjectPracticeChemistryAcidBaseWithIndependentOracle(input.candidate, chemistryContext);
  } else if (subject === 'chemistry' && taskFamily === 'basic_ph_measurement_or_preparation_error_judgement') {
    solverEvidence = solveSubjectPracticeChemistryPhOperationError(input.candidate, context);
    explanationEvidence = verifySubjectPracticeChemistryPhOperationErrorExplanation(input.candidate, context);
    independentOracleEvidence = verifySubjectPracticeChemistryPhOperationErrorWithIndependentOracle(input.candidate, context);
  } else {
    return null;
  }

  const solverScopeId = solverEvidence.verificationScope.scopeId;
  const oracleScopeId = independentOracleEvidence.scopeId;
  const scopeMatchedAcrossVerifiers = solverEvidence.verificationScope.matched
    && independentOracleEvidence.scopeMatched
    && Boolean(solverScopeId)
    && solverScopeId === oracleScopeId;
  const reasonCodes = [
    ...solverEvidence.reasonCodes,
    ...explanationEvidence.reasonCodes,
    ...independentOracleEvidence.reasonCodes
  ];
  if (!planTemplate) reasonCodes.push('formal_verification_plan_template_missing');
  if (!scopeMatchedAcrossVerifiers) reasonCodes.push('formal_verification_cross_verifier_scope_mismatch');
  const fullyVerified = solverEvidence.status === 'verified'
    && explanationEvidence.status === 'verified'
    && independentOracleEvidence.status === 'verified'
    && scopeMatchedAcrossVerifiers
    && Boolean(planTemplate);
  const hasConflict = solverEvidence.status === 'conflict'
    || explanationEvidence.status === 'failed'
    || independentOracleEvidence.status === 'conflict'
    || independentOracleEvidence.status === 'disagreed';
  const status = fullyVerified ? 'verified' : hasConflict ? 'conflict' : 'unparsed';
  if (!fullyVerified) reasonCodes.push(`formal_verification_${status}`);

  return {
    orchestratorVersion: SUBJECT_PRACTICE_FORMAL_VERIFICATION_ORCHESTRATOR_VERSION,
    status,
    subject: subject as 'math' | 'physics' | 'chemistry',
    taskFamily,
    planTemplate,
    scopeId: scopeMatchedAcrossVerifiers ? solverScopeId : null,
    plannedScopeId: solverScopeId,
    oracleScopeId,
    scopeMatchedAcrossVerifiers,
    solverVersion: solverEvidence.solverVersion,
    explanationVerifierVersion: explanationEvidence.verifierVersion,
    independentOracleVersion: independentOracleEvidence.oracleVersion,
    solverEvidence,
    explanationEvidence,
    independentOracleEvidence,
    eligibleForProductionShadowObservation: fullyVerified,
    automaticPublicationEligible: false,
    providerImpact: 'none_no_provider_call',
    productionGateImpact: 'none_shadow_only',
    reasonCodes: Array.from(new Set(reasonCodes))
  };
}
