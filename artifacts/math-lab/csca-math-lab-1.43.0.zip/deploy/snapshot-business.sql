-- Read-only, stable snapshot. Authentication sessions are intentionally excluded.
-- Run with psql -X -qAt -v ON_ERROR_STOP=1. Contains private data: store only in backup directory.
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL timezone = 'UTC';
SELECT 'lab_meta|' || to_jsonb(t)::text FROM lab_meta t ORDER BY key;
SELECT 'lab_batches|' || to_jsonb(t)::text FROM lab_batches t ORDER BY id;
SELECT 'lab_slots|' || to_jsonb(t)::text FROM lab_slots t ORDER BY batch_id,slot;
SELECT 'lab_attempts|' || to_jsonb(t)::text FROM lab_attempts t ORDER BY id;
SELECT 'lab_questions|' || to_jsonb(t)::text FROM lab_questions t ORDER BY id;
SELECT 'lab_audit_runs|' || to_jsonb(t)::text FROM lab_audit_runs t ORDER BY id;
SELECT 'lab_audits|' || to_jsonb(t)::text FROM lab_audits t ORDER BY id;
SELECT 'lab_question_audits|' || to_jsonb(t)::text FROM lab_question_audits t ORDER BY id;
SELECT 'lab_question_audit_calls|' || to_jsonb(t)::text FROM lab_question_audit_calls t ORDER BY id;
-- New tables are absent before first upgrade. Empty new tables emit no rows.
SELECT format('SELECT %L || to_jsonb(t)::text FROM %I t ORDER BY 1', name || '|', name)
FROM (VALUES ('lab_question_polishes'),('lab_question_polish_calls'),('lab_audit_presentations'),('lab_polish_batches'),('lab_polish_batch_items'),('lab_human_reviews'),('lab_math_identities'),('lab_history_jobs'),('lab_history_checks'),('lab_history_current'),('lab_history_controls')) AS tables(name)
WHERE to_regclass('public.' || name) IS NOT NULL
ORDER BY name
\gexec
ROLLBACK;
