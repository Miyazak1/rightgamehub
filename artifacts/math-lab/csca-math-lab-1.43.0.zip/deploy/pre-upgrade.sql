BEGIN READ ONLY;
DO $$ DECLARE has_polish boolean; BEGIN
 IF current_database() !~ '^csca_math_lab(_[a-z0-9]+)*$' THEN
  RAISE EXCEPTION 'This is not the isolated Math Lab database';
 END IF;
 IF EXISTS (SELECT 1 FROM lab_batches WHERE status IN ('queued','running'))
 OR EXISTS (SELECT 1 FROM lab_audits WHERE status IN ('queued','running'))
 OR EXISTS (SELECT 1 FROM lab_question_audits WHERE status IN ('queued','running')) THEN
  RAISE EXCEPTION 'Wait for generation and audits to finish before upgrading';
 END IF;
 IF to_regclass('public.lab_question_polishes') IS NOT NULL THEN
  EXECUTE 'SELECT EXISTS(SELECT 1 FROM lab_question_polishes WHERE status IN (''queued'',''running''))' INTO has_polish;
  IF has_polish THEN RAISE EXCEPTION 'Wait for polishing to finish before upgrading'; END IF;
 END IF;
 IF to_regclass('public.lab_polish_batches') IS NOT NULL THEN
  EXECUTE 'SELECT EXISTS(SELECT 1 FROM lab_polish_batches WHERE status IN (''waiting_generation'',''active''))' INTO has_polish;
  IF has_polish THEN RAISE EXCEPTION 'Wait for automatic polishing to finish before upgrading'; END IF;
 END IF;
 IF to_regclass('public.lab_history_jobs') IS NOT NULL THEN
  EXECUTE 'SELECT EXISTS(SELECT 1 FROM lab_history_jobs WHERE state IN (''queued'',''running''))' INTO has_polish;
  IF has_polish THEN RAISE EXCEPTION 'Wait for historical verification or pause it before upgrading'; END IF;
 END IF;
END $$;
SELECT 'READY: no active generation, polishing or AI audits';
ROLLBACK;
