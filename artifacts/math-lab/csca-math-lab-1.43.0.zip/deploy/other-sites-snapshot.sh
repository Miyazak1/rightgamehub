#!/usr/bin/env bash
set -euo pipefail
# Read-only identity and start-time evidence. Never changes these projects.
for project in deploy moodlelike-next; do
  ids="$(docker ps -aq --filter "label=com.docker.compose.project=$project")"
  if [[ -z "$ids" ]]; then
    printf 'Cannot verify existing project: %s\n' "$project" >&2
    exit 1
  fi
  while IFS= read -r id; do
    [[ "$id" =~ ^[0-9a-f]{12,64}$ ]] || exit 1
    printf '%s\t' "$project"
    docker inspect --format '{{.Id}} {{.Image}} {{.State.StartedAt}}' "$id"
  done <<< "$ids"
done | sort
