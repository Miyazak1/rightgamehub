#!/usr/bin/env bash
set -euo pipefail
port=${1:-18082}
[[ "$port" =~ ^[0-9]+$ ]] && ((port>1024 && port<65536)) || exit 2
echo 'Read-only host inventory. A failed query is UNKNOWN, never a free port.'
date -u
docker compose version
docker compose ls
docker ps --format 'table {{.Names}}\t{{.Ports}}\t{{.Status}}'
free -m
df -h /www/wwwroot
listeners=$(ss -H -ltnp) || { echo 'UNKNOWN: ss capture failed.' >&2; exit 1; }
matches=$(printf '%s\n' "$listeners" | awk -v p=":$port" '$4 ~ (p "$") {print}')
if [[ -n "$matches" ]]; then printf '%s\n' "$matches"; echo "Port $port is occupied; choose another loopback port." >&2; exit 1; fi
echo "No TCP listener observed on port $port in this successful snapshot. Recheck immediately before deployment."
echo 'Check available RAM/CPU before adding approximately 1.2 GB of container memory limits. This script does not start or modify any service.'
