#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
origin=${1:-https://test.cscapilot.com}
[[ "$origin" =~ ^https://[a-zA-Z0-9.-]+(:[0-9]+)?$ ]] || { echo 'Expected an HTTPS origin without a trailing slash.' >&2; exit 1; }
[[ ! -e "$root/.env" ]] || { echo '.env already exists; refusing to overwrite credentials.' >&2; exit 1; }
command -v openssl >/dev/null
umask 077
db_secret=$(openssl rand -hex 32)
admin_secret=$(openssl rand -hex 24)
set -o noclobber
cat > "$root/.env" <<EOF
PUBLIC_ORIGIN=$origin
HOST_PORT=18082
POSTGRES_USER=mathlab
POSTGRES_DB=csca_math_lab
POSTGRES_PASSWORD=$db_secret
ADMIN_USER=admin
ADMIN_PASSWORD=$admin_secret
MAX_WORKERS=1
ATTEMPT_TIMEOUT_MS=30000
AUDIT_ENABLED=false
AUDIT_BASE_URL=https://api.openai.com/v1
AUDIT_API_KEY=
AUDIT_MODEL=
AUDIT_INPUT_USD_PER_MILLION=
AUDIT_OUTPUT_USD_PER_MILLION=
AUDIT_MAX_OUTPUT_TOKENS=3000
AUDIT_TOKEN_FIELD=max_completion_tokens
EOF
printf 'Created %s/.env (mode 600). Administrator credentials are stored only in that file.\n' "$root"
