#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
destination=${1:-/www/backup/csca-math-lab}
umask 077
mkdir -p -- "$destination"
file="$destination/math-lab-$(date -u +%Y%m%dT%H%M%SZ).dump"
[[ ! -e "$file" ]] || { echo 'Backup already exists.' >&2; exit 1; }
compose=(docker compose -p csca-math-lab --env-file "$root/.env" -f "$root/deploy/compose.yaml")
"${compose[@]}" exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$file"
"${compose[@]}" exec -T db pg_restore --list < "$file" >/dev/null
sha256sum "$file" > "$file.sha256"
printf 'Backup archive and checksum: %s\n' "$file"
echo 'Archive structure verified. Periodic restore into a separate disposable database is still required.'
