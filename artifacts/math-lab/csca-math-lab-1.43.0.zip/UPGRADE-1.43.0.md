# Math Lab 1.43.0 候选版更新步骤

适用于宝塔上的独立 Math Lab，目录 `/www/wwwroot/csca-math-lab`，Compose 项目 `csca-math-lab`，测试域名 `test.cscapilot.com`。操作时使用同一个 Bash 终端，每次执行一个代码块。预计停用期间仅测试站暂时无法访问。请先通知使用者，等生成、润色、审计结束，有正在运行的历史核验时先在测试站暂停。核验结束再对用户开放测试站。

**1. 上传并校验。** 在宝塔「文件」打开 `/www/wwwroot/`，上传 `csca-math-lab-1.43.0.zip` 和 `csca-math-lab-1.43.0.zip.sha256`。下面每条命令都在服务器终端执行。出现报错时停在该步。

```bash
set -euo pipefail
```
```bash
cd /www/wwwroot
```
```bash
sha256sum -c csca-math-lab-1.43.0.zip.sha256
```

应显示 `csca-math-lab-1.43.0.zip: OK`。

```bash
cd /www/wwwroot/csca-math-lab
```
```bash
test -s .env
```
```bash
lab() { docker compose -p csca-math-lab --env-file /www/wwwroot/csca-math-lab/.env -f /www/wwwroot/csca-math-lab/deploy/compose.yaml "$@"; }
```
```bash
lab_sql() { lab exec -T db sh -c 'exec psql -X -qAt -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"'; }
```
```bash
lab ps
```
```bash
curl -fsS --max-time 5 http://127.0.0.1:18082/health
```

核实当前版本和两个健康容器 `csca-math-lab-app-1`、`csca-math-lab-db-1`。若已是 1.43.0，先核实是否曾完成本次升级。

**2. 暂存文件，记录基线，在旧应用仍提供服务时构建新镜像。**

```bash
umask 077
```
```bash
mkdir -p /www/backup/csca-math-lab
```
```bash
backup_dir="$(mktemp -d /www/backup/csca-math-lab/upgrade-1.43.0-XXXXXXXX)"
```
```bash
printf '%s\n' "$backup_dir" > /www/backup/csca-math-lab/last-upgrade-1.43.0.path
```
```bash
unzip -q /www/wwwroot/csca-math-lab-1.43.0.zip -d "$backup_dir/new"
```
```bash
test ! -e "$backup_dir/new/.env"
```
```bash
(cd "$backup_dir/new" && sha256sum -c RELEASE-FILES.sha256 > "$backup_dir/verified-package-files.txt")
```
```bash
lab ps -q db > "$backup_dir/db-before.txt"
```
```bash
test -s "$backup_dir/db-before.txt"
```
```bash
docker inspect --format '{{.Image}}' "$(lab ps -q app)" > "$backup_dir/app-image-before.txt"
```
```bash
docker tag "$(cat "$backup_dir/app-image-before.txt")" "csca-math-lab:rollback-$(basename "$backup_dir")"
```
```bash
bash "$backup_dir/new/deploy/other-sites-snapshot.sh" > "$backup_dir/other-sites-before.txt"
```
```bash
sha256sum .env > "$backup_dir/env.sha256"
```
```bash
staged() { docker compose -p csca-math-lab --env-file /www/wwwroot/csca-math-lab/.env -f "$backup_dir/new/deploy/compose.yaml" "$@"; }
```
```bash
staged config --quiet
```
```bash
staged build app
```
```bash
docker image inspect csca-math-lab:1.43.0 --format '{{.Id}}' > "$backup_dir/app-image-new.txt"
```

构建日志中应有两个 verified 结果，包括 36 个单元、141 个范围和版本 1.43.0 的库存清单 verified 结果。

**3. 停测试站 app 并核实备份。** 从这一步到完成业务快照比较，请暂停用户提交新任务。

```bash
lab_sql < "$backup_dir/new/deploy/pre-upgrade.sql"
```

应显示 `READY: no active generation, polishing or AI audits`。

```bash
lab stop app
```
```bash
lab_sql < "$backup_dir/new/deploy/pre-upgrade.sql"
```

再次显示 READY 后继续。如果有任务，此时可以 `lab start app` 恢复旧实例并等待任务结束。

```bash
lab exec -T db sh -c 'exec pg_dump -Fc -U "$POSTGRES_USER" -d "$POSTGRES_DB"' > "$backup_dir/database.dump"
```
```bash
test -s "$backup_dir/database.dump"
```
```bash
lab exec -T db pg_restore --list < "$backup_dir/database.dump" > "$backup_dir/database-list.txt"
```
```bash
test -s "$backup_dir/database-list.txt"
```
```bash
lab_sql < "$backup_dir/new/deploy/snapshot-business.sql" > "$backup_dir/business-before.jsonl"
```
```bash
test -s "$backup_dir/business-before.jsonl"
```
```bash
tar --exclude='./node_modules' --exclude='./.git' -czf "$backup_dir/project.tar.gz" .
```
```bash
gzip -t "$backup_dir/project.tar.gz"
```
```bash
sha256sum "$backup_dir/database.dump" "$backup_dir/project.tar.gz" "$backup_dir/business-before.jsonl" > "$backup_dir/backups.sha256"
```
```bash
sha256sum -c "$backup_dir/backups.sha256"
```

三个文件都应显示 OK。备份目录含数据库及旧配置，请留在服务器私有目录。

**4. 覆盖实验室应用文件，启动已构建的新 app。**

```bash
cp -a "$backup_dir/new"/{src,engine,public,scripts,deploy,package.json,package-lock.json,Dockerfile,.dockerignore,.env.example,capacity-release.json,RELEASE-FILES.sha256,UPGRADE-1.43.0.md,VALIDATION-1.43.0.md} /www/wwwroot/csca-math-lab/
```
```bash
sha256sum -c RELEASE-FILES.sha256 > "$backup_dir/verified-installed-files.txt"
```
```bash
sha256sum -c "$backup_dir/env.sha256"
```
```bash
lab config --quiet
```
```bash
lab up -d --no-deps --no-build --pull never app
```
```bash
curl -fsS --retry 12 --retry-connrefused --retry-delay 5 --max-time 5 http://127.0.0.1:18082/health > "$backup_dir/health-after.json"
```
```bash
lab exec -T app node -e 'const j=JSON.parse(require("node:fs").readFileSync(0,"utf8"));require("node:assert/strict").deepEqual([j.status,j.version,j.engineHash],["ok","1.43.0","6f521eea514367a14f1397c7ea3eafb7ff0549aa48c3deab4577cde4c5f38523"]);console.log(j)' < "$backup_dir/health-after.json"
```
```bash
lab ps
```
```bash
docker inspect --format '{{.Image}}' "$(lab ps -q app)" | cmp "$backup_dir/app-image-new.txt" -
```

**5. 核对数据、配置和原站容器。**

```bash
lab ps -q db | cmp "$backup_dir/db-before.txt" -
```
```bash
sha256sum -c "$backup_dir/env.sha256"
```
```bash
lab_sql < deploy/snapshot-business.sql > "$backup_dir/business-after.jsonl"
```
```bash
cmp "$backup_dir/business-before.jsonl" "$backup_dir/business-after.jsonl"
```
```bash
bash deploy/other-sites-snapshot.sh > "$backup_dir/other-sites-after.txt"
```
```bash
cmp "$backup_dir/other-sites-before.txt" "$backup_dir/other-sites-after.txt"
```
```bash
lab exec -T app node scripts/verify-capacity-bundle.cjs
```
```bash
lab logs --tail=30 app
```

全部 cmp 正常退出且无输出，说明实验库容器 ID、快照所含业务行和原站容器的身份及启动时间一致。登录会话不在业务快照内。从线上 1.18 升级时，后续版本引入的派生表会自动建立。请在快照核对完成后才提交新实验。

打开 [测试站](https://test.cscapilot.com/)，刷新后登录，打开一条升级前的题，再创建小批次核对合格题、选项与统计。原站反向代理沿用原配置。会话内 AI Key 需要使用者重新录入。

**终端断线。** 回到 `/www/wwwroot/csca-math-lab`，重新执行第 1 步的 `set`、`lab`、`lab_sql` 定义并恢复原备份目录，再从中断处继续。

```bash
backup_dir="$(cat /www/backup/csca-math-lab/last-upgrade-1.43.0.path)"
```
```bash
test -s "$backup_dir/app-image-before.txt"
```

**出现问题时恢复旧 app。** 尚未切换镜像、仅停旧实例时，使用 `lab start app`。若已换用新镜像且仍在维护期间，可先核对无在途任务，再使用以下命令。若已经开放使用并产生新记录，先保存新快照并诊断，避免用旧备份覆盖这些记录。

```bash
lab_sql < "$backup_dir/new/deploy/pre-upgrade.sql"
```
```bash
printf 'services:\n  app:\n    image: %s\n' "csca-math-lab:rollback-$(basename "$backup_dir")" > "$backup_dir/rollback.yaml"
```
```bash
docker compose -p csca-math-lab --env-file .env -f deploy/compose.yaml -f "$backup_dir/rollback.yaml" up -d --no-deps --no-build --pull never app
```
```bash
curl -fsS --retry 12 --retry-connrefused --retry-delay 5 --max-time 5 http://127.0.0.1:18082/health
```

此操作恢复已记录的旧应用镜像。后续重新构建前，从私有的 `project.tar.gz` 取回对应版本的项目源码。业务数据库继续使用现有数据卷。

